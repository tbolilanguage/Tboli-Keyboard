import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as Link, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PenLine, c as Languages, d as Globe, f as Delete, h as ChevronsDown, n as Smile, p as CornerDownLeft, r as Settings, t as TriangleAlert, u as House, x as ArrowBigUp, y as BookOpen } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DW5w4w-K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error instanceof Error ? error.message : "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var EMOJI_GROUPS = [
	{
		id: "new",
		label: "New",
		items: [
			{
				glyph: "🫪",
				name: "Distorted face"
			},
			{
				glyph: "🫯",
				name: "Fight cloud"
			},
			{
				glyph: "🫈",
				name: "Hairy creature"
			},
			{
				glyph: "🫍",
				name: "Orca"
			},
			{
				glyph: "🪊",
				name: "Trombone"
			},
			{
				glyph: "🪎",
				name: "Treasure chest"
			},
			{
				glyph: "🛘",
				name: "Landslide"
			},
			{
				glyph: "🧑‍🩰",
				name: "Ballet dancer"
			}
		]
	},
	{
		id: "smileys",
		label: "Smileys",
		items: [
			{
				glyph: "😀",
				name: "Grinning"
			},
			{
				glyph: "😃",
				name: "Smiling"
			},
			{
				glyph: "😄",
				name: "Smile"
			},
			{
				glyph: "😁",
				name: "Beaming"
			},
			{
				glyph: "😅",
				name: "Sweat smile"
			},
			{
				glyph: "😂",
				name: "Tears of joy"
			},
			{
				glyph: "🤣",
				name: "ROFL"
			},
			{
				glyph: "😊",
				name: "Blush"
			},
			{
				glyph: "😇",
				name: "Halo"
			},
			{
				glyph: "🙂",
				name: "Slight smile"
			},
			{
				glyph: "😉",
				name: "Wink"
			},
			{
				glyph: "😍",
				name: "Heart eyes"
			},
			{
				glyph: "🥰",
				name: "Smiling hearts"
			},
			{
				glyph: "😘",
				name: "Kiss"
			},
			{
				glyph: "😋",
				name: "Yum"
			},
			{
				glyph: "🤔",
				name: "Thinking"
			},
			{
				glyph: "😴",
				name: "Sleeping"
			},
			{
				glyph: "🥲",
				name: "Tear smile"
			},
			{
				glyph: "😭",
				name: "Loud cry"
			},
			{
				glyph: "😤",
				name: "Huff"
			},
			{
				glyph: "🤯",
				name: "Exploding head"
			},
			{
				glyph: "🥳",
				name: "Party"
			},
			{
				glyph: "😎",
				name: "Cool"
			},
			{
				glyph: "🥺",
				name: "Pleading"
			}
		]
	},
	{
		id: "gestures",
		label: "Hands",
		items: [
			{
				glyph: "👍",
				name: "Thumbs up"
			},
			{
				glyph: "👎",
				name: "Thumbs down"
			},
			{
				glyph: "👏",
				name: "Clap"
			},
			{
				glyph: "🙏",
				name: "Folded hands"
			},
			{
				glyph: "🙌",
				name: "Raised hands"
			},
			{
				glyph: "🤝",
				name: "Handshake"
			},
			{
				glyph: "✌️",
				name: "Victory"
			},
			{
				glyph: "🤞",
				name: "Crossed"
			},
			{
				glyph: "🫶",
				name: "Heart hands"
			},
			{
				glyph: "👋",
				name: "Wave"
			},
			{
				glyph: "💪",
				name: "Flex"
			}
		]
	},
	{
		id: "hearts",
		label: "Hearts",
		items: [
			{
				glyph: "❤️",
				name: "Red heart"
			},
			{
				glyph: "🧡",
				name: "Orange heart"
			},
			{
				glyph: "💛",
				name: "Yellow heart"
			},
			{
				glyph: "💚",
				name: "Green heart"
			},
			{
				glyph: "💙",
				name: "Blue heart"
			},
			{
				glyph: "💜",
				name: "Purple heart"
			},
			{
				glyph: "🖤",
				name: "Black heart"
			},
			{
				glyph: "🤍",
				name: "White heart"
			},
			{
				glyph: "💕",
				name: "Two hearts"
			},
			{
				glyph: "💞",
				name: "Revolving"
			},
			{
				glyph: "💖",
				name: "Sparkling"
			},
			{
				glyph: "💯",
				name: "Hundred"
			}
		]
	},
	{
		id: "nature",
		label: "Nature",
		items: [
			{
				glyph: "🌞",
				name: "Sun"
			},
			{
				glyph: "🌙",
				name: "Moon"
			},
			{
				glyph: "⭐",
				name: "Star"
			},
			{
				glyph: "🌈",
				name: "Rainbow"
			},
			{
				glyph: "🌧️",
				name: "Rain"
			},
			{
				glyph: "🌸",
				name: "Blossom"
			},
			{
				glyph: "🌿",
				name: "Herb"
			},
			{
				glyph: "🌳",
				name: "Tree"
			},
			{
				glyph: "🌊",
				name: "Wave"
			},
			{
				glyph: "🔥",
				name: "Fire"
			},
			{
				glyph: "🐕",
				name: "Dog"
			},
			{
				glyph: "🐈",
				name: "Cat"
			},
			{
				glyph: "🐦",
				name: "Bird"
			},
			{
				glyph: "🐟",
				name: "Fish"
			},
			{
				glyph: "🦋",
				name: "Butterfly"
			},
			{
				glyph: "🌾",
				name: "Sheaf"
			}
		]
	},
	{
		id: "food",
		label: "Food",
		items: [
			{
				glyph: "🍚",
				name: "Rice"
			},
			{
				glyph: "🍜",
				name: "Noodles"
			},
			{
				glyph: "🍌",
				name: "Banana"
			},
			{
				glyph: "🥭",
				name: "Mango"
			},
			{
				glyph: "🥥",
				name: "Coconut"
			},
			{
				glyph: "🐟",
				name: "Fish"
			},
			{
				glyph: "🍖",
				name: "Meat"
			},
			{
				glyph: "☕",
				name: "Coffee"
			},
			{
				glyph: "🍵",
				name: "Tea"
			},
			{
				glyph: "🍯",
				name: "Honey"
			},
			{
				glyph: "🥘",
				name: "Pan"
			},
			{
				glyph: "🎂",
				name: "Cake"
			}
		]
	},
	{
		id: "places",
		label: "Places",
		items: [
			{
				glyph: "🏠",
				name: "House"
			},
			{
				glyph: "🏔️",
				name: "Mountain"
			},
			{
				glyph: "🏞️",
				name: "Park"
			},
			{
				glyph: "⛪",
				name: "Church"
			},
			{
				glyph: "🚤",
				name: "Boat"
			},
			{
				glyph: "🚗",
				name: "Car"
			},
			{
				glyph: "🇵🇭",
				name: "Philippines"
			},
			{
				glyph: "🎉",
				name: "Party"
			},
			{
				glyph: "🎵",
				name: "Music"
			},
			{
				glyph: "🥁",
				name: "Drum"
			},
			{
				glyph: "🧵",
				name: "Thread"
			},
			{
				glyph: "👗",
				name: "Dress"
			}
		]
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function EmojiPanel({ onPick, onAbc }) {
	const [groupId, setGroupId] = (0, import_react.useState)(EMOJI_GROUPS[0]?.id ?? "new");
	const group = EMOJI_GROUPS.find((g) => g.id === groupId) ?? EMOJI_GROUPS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-2 shadow-panel sm:p-3",
		role: "group",
		"aria-label": "Emoji keyboard",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xs leading-snug text-subtle",
					children: "Drawn by this phone — Android 17 or iOS 27 emoji, not a web font"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onPointerDown: (e) => e.preventDefault(),
					onClick: onAbc,
					className: "h-10 shrink-0 rounded-md bg-key-mod px-3 text-sm font-medium text-key-mod-fg transition-transform duration-150 ease-out active:scale-[0.96]",
					children: "ABC"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 flex gap-1 overflow-x-auto pb-1",
				children: EMOJI_GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onPointerDown: (e) => e.preventDefault(),
					onClick: () => setGroupId(g.id),
					className: cn("h-9 shrink-0 rounded-sm px-2.5 text-xs font-medium transition-transform duration-150 ease-out active:scale-[0.96]", g.id === groupId ? "bg-primary text-primary-fg" : "bg-key-mod text-key-mod-fg"),
					children: g.label
				}, g.id))
			}),
			groupId === "new" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-4 gap-1.5",
				children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					title: item.name,
					"aria-label": item.name,
					onPointerDown: (e) => e.preventDefault(),
					onClick: () => onPick(item.glyph),
					className: "flex h-16 w-full flex-col items-center justify-center rounded-md bg-key text-key-fg transition-transform duration-150 ease-out active:scale-[0.96]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-emoji text-2xl leading-none",
						children: item.glyph
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 max-w-full truncate px-1 text-2xs text-subtle",
						children: item.name
					})]
				}) }, item.name))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid max-h-44 grid-cols-8 gap-1 overflow-y-auto sm:max-h-52",
				children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					title: item.name,
					"aria-label": item.name,
					onPointerDown: (e) => e.preventDefault(),
					onClick: () => onPick(item.glyph),
					className: "flex size-10 items-center justify-center rounded-sm bg-key text-key-fg transition-transform duration-150 ease-out active:scale-[0.96] sm:size-11",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-emoji text-xl leading-none sm:text-2xl",
						children: item.glyph
					})
				}) }, `${item.name}-${item.glyph}`))
			})
		]
	});
}
var STORAGE_KEY = "tboli-keyboard-draft";
var VOWELS = [
	{
		letter: "a",
		ipa: "/a/",
		hint: "father"
	},
	{
		letter: "e",
		ipa: "/ə/",
		hint: "about"
	},
	{
		letter: "é",
		ipa: "/ɛ/",
		hint: "bed"
	},
	{
		letter: "i",
		ipa: "/i/",
		hint: "machine"
	},
	{
		letter: "o",
		ipa: "/ɔ/",
		hint: "thought"
	},
	{
		letter: "ó",
		ipa: "/o/",
		hint: "go"
	},
	{
		letter: "u",
		ipa: "/u/",
		hint: "food"
	}
];
var SAMPLES = [
	{
		tboli: "ngà",
		en: "child"
	},
	{
		tboli: "bê",
		en: "don't"
	},
	{
		tboli: "gawì",
		en: "serving spoon"
	},
	{
		tboli: "sdô",
		en: "pig"
	},
	{
		tboli: "tnalak",
		en: "sacred cloth"
	},
	{
		tboli: "Mulu le sfu soging.",
		en: "They planted banana shoots."
	}
];
var DEAD_MAP = {
	acute: {
		a: "á",
		e: "é",
		i: "í",
		o: "ó",
		u: "ú",
		A: "Á",
		E: "É",
		I: "Í",
		O: "Ó",
		U: "Ú"
	},
	grave: {
		a: "à",
		e: "è",
		i: "ì",
		o: "ò",
		u: "ù",
		A: "À",
		E: "È",
		I: "Ì",
		O: "Ò",
		U: "Ù",
		é: "ê",
		É: "Ê",
		ó: "ô",
		Ó: "Ô"
	},
	circumflex: {
		a: "â",
		e: "ê",
		i: "î",
		o: "ô",
		u: "û",
		A: "Â",
		E: "Ê",
		I: "Î",
		O: "Ô",
		U: "Û",
		é: "ê",
		É: "Ê",
		ó: "ô",
		Ó: "Ô"
	}
};
var DEAD_CHAR = {
	acute: "'",
	grave: "`",
	circumflex: "^"
};
function applyDeadKey(dead, letter) {
	return DEAD_MAP[dead][letter] ?? null;
}
function isUpperCase(shift, caps) {
	return shift !== caps;
}
function casedChar(char, shift, caps) {
	const upper = isUpperCase(shift, caps);
	if (char === "ng") {
		if (!upper) return "ng";
		if (caps && !shift) return "NG";
		return "Ng";
	}
	return upper ? char.toUpperCase() : char;
}
function ch(char, special = false) {
	return {
		id: `c-${char}`,
		kind: char === "ng" ? "ng" : "char",
		label: char,
		char,
		special
	};
}
var TBOLI_ROW = [
	ch("é", true),
	ch("ó", true),
	ch("ng", true),
	ch("à", true),
	ch("è", true),
	ch("ì", true),
	ch("ò", true),
	ch("ù", true),
	ch("ê", true),
	ch("ô", true)
];
var LETTER_1 = [
	"q",
	"w",
	"e",
	"r",
	"t",
	"y",
	"u",
	"i",
	"o",
	"p"
].map((c) => ch(c));
var LETTER_2 = [
	"a",
	"s",
	"d",
	"f",
	"g",
	"h",
	"j",
	"k",
	"l"
].map((c) => ch(c));
var LETTER_3 = [
	"z",
	"x",
	"c",
	"v",
	"b",
	"n",
	"m"
].map((c) => ch(c));
var SYMBOL_1 = [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"0"
].map((c) => ch(c));
var SYMBOL_2 = [
	ch("-"),
	ch("/"),
	ch(":"),
	ch(";"),
	ch("("),
	ch(")"),
	ch("₱"),
	ch("&"),
	ch("@")
];
var SYMBOL_EN_2 = [
	ch("-"),
	ch("/"),
	ch(":"),
	ch(";"),
	ch("("),
	ch(")"),
	ch("$"),
	ch("&"),
	ch("@")
];
var SYMBOL_3 = [
	ch("."),
	ch(","),
	ch("?"),
	ch("!"),
	ch("\""),
	ch("'"),
	ch("`"),
	ch("^")
];
var SHIFT = {
	id: "shift",
	kind: "shift",
	label: "Shift",
	wide: "md"
};
var BACKSPACE = {
	id: "backspace",
	kind: "backspace",
	label: "Delete",
	wide: "md"
};
var ENTER = {
	id: "enter",
	kind: "enter",
	label: "Return",
	wide: "md"
};
var EMOJI_KEY = {
	id: "emoji",
	kind: "emoji",
	label: "Emoji",
	wide: "sm"
};
var LANG_KEY = {
	id: "lang",
	kind: "lang",
	label: "lang",
	wide: "sm"
};
function modeKey(symbols) {
	return {
		id: "mode",
		kind: "mode",
		label: symbols ? "ABC" : "123",
		wide: "sm"
	};
}
function spaceKey(lang) {
	return {
		id: "space",
		kind: "space",
		label: lang === "tbl" ? "Tboli" : "English",
		wide: "xl"
	};
}
function getLayout(lang, symbols) {
	const symbolMid = lang === "tbl" ? SYMBOL_2 : SYMBOL_EN_2;
	const space = spaceKey(lang);
	const tboliTop = lang === "tbl" ? [TBOLI_ROW] : [];
	if (symbols) return [
		...tboliTop,
		SYMBOL_1,
		symbolMid,
		[
			modeKey(true),
			EMOJI_KEY,
			...SYMBOL_3.slice(0, 5),
			BACKSPACE
		],
		[
			LANG_KEY,
			space,
			ENTER
		]
	];
	return [
		...tboliTop,
		LETTER_1,
		LETTER_2,
		[
			SHIFT,
			...LETTER_3,
			BACKSPACE
		],
		[
			modeKey(false),
			EMOJI_KEY,
			LANG_KEY,
			space,
			ENTER
		]
	];
}
function ImeKeyboard() {
	const ime = useIme();
	const [shift, setShift] = (0, import_react.useState)(false);
	const [caps, setCaps] = (0, import_react.useState)(false);
	const [symbols, setSymbols] = (0, import_react.useState)(false);
	const [dead, setDead] = (0, import_react.useState)(null);
	const [pressed, setPressed] = (0, import_react.useState)(null);
	const [emojiOpen, setEmojiOpen] = (0, import_react.useState)(false);
	const lastShiftTap = (0, import_react.useRef)(0);
	const typeText = (0, import_react.useCallback)((chunk) => {
		ime.insert(chunk);
	}, [ime]);
	const commitChar = (0, import_react.useCallback)((raw) => {
		const letter = casedChar(raw, shift, caps);
		if (dead && ime.lang === "tbl") {
			const mapped = applyDeadKey(dead, letter) ?? applyDeadKey(dead, raw);
			setDead(null);
			typeText(mapped ?? DEAD_CHAR[dead] + letter);
		} else typeText(letter);
		if (shift) setShift(false);
	}, [
		caps,
		dead,
		ime.lang,
		shift,
		typeText
	]);
	const handleKey = (0, import_react.useCallback)((spec) => {
		setPressed(spec.id);
		window.setTimeout(() => setPressed((id) => id === spec.id ? null : id), 120);
		switch (spec.kind) {
			case "char":
			case "ng":
				commitChar(spec.char ?? spec.label);
				break;
			case "space":
				typeText(" ");
				if (dead) setDead(null);
				break;
			case "enter":
				ime.enter();
				break;
			case "backspace":
				if (dead) {
					setDead(null);
					break;
				}
				ime.backspace();
				break;
			case "shift": {
				const now = Date.now();
				if (now - lastShiftTap.current < 400) {
					setCaps((c) => !c);
					setShift(false);
				} else setShift((s) => !s);
				lastShiftTap.current = now;
				break;
			}
			case "dead":
				setDead((current) => current === spec.dead ? null : spec.dead ?? null);
				break;
			case "mode":
				setSymbols((s) => !s);
				setShift(false);
				setEmojiOpen(false);
				break;
			case "emoji":
				setEmojiOpen(true);
				setSymbols(false);
				break;
			case "lang":
				ime.cycleLang();
				setDead(null);
				setEmojiOpen(false);
		}
	}, [
		commitChar,
		dead,
		ime,
		typeText
	]);
	const rows = getLayout(ime.lang, symbols);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 z-40 bg-ime pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1.5 shadow-panel",
		role: "application",
		"aria-label": `${ime.lang === "tbl" ? "Tboli" : "English"} keyboard`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-lg px-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1.5 flex items-center justify-between px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xs font-medium tracking-wide text-subtle",
					children: ime.lang === "tbl" ? "Tboli" : "English"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Hide keyboard",
					onPointerDown: (e) => e.preventDefault(),
					onClick: () => ime.hide(),
					className: "flex h-8 w-10 items-center justify-center rounded-sm text-subtle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsDown, {
						className: "size-4",
						strokeWidth: 2
					})
				})]
			}), emojiOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiPanel, {
				onPick: (glyph) => typeText(glyph),
				onAbc: () => setEmojiOpen(false)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-1",
				children: rows.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					children: row.map((spec) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						spec,
						shift,
						caps,
						dead,
						lang: ime.lang,
						pressed: pressed === spec.id,
						onPress: handleKey
					}, spec.id))
				}, i))
			})]
		})
	});
}
function KeyButton({ spec, shift, caps, dead, lang, pressed, onPress }) {
	const activeDead = spec.kind === "dead" && dead === spec.dead;
	const activeShift = spec.kind === "shift" && (shift || caps);
	const display = spec.kind === "char" || spec.kind === "ng" ? casedChar(spec.char ?? spec.label, shift, caps) : spec.kind === "space" ? lang === "tbl" ? "Tboli" : "English" : spec.label;
	const flexGrow = spec.wide === "xl" ? 4.2 : spec.wide === "md" ? 1.45 : spec.wide === "sm" ? 1.15 : 1;
	const special = Boolean(spec.special) || spec.kind === "dead";
	const modifier = spec.kind === "shift" || spec.kind === "backspace" || spec.kind === "enter" || spec.kind === "mode" || spec.kind === "emoji" || spec.kind === "lang";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": ariaLabel(spec, display, lang),
		"aria-pressed": spec.kind === "shift" || spec.kind === "dead" ? activeShift || activeDead : void 0,
		onPointerDown: (event) => {
			event.preventDefault();
			onPress(spec);
		},
		style: { flex: flexGrow },
		className: cn("relative flex h-11 min-w-0 items-center justify-center rounded-sm select-none", "text-base font-medium leading-none", "transition-[transform,filter] duration-150 ease-out", "active:scale-[0.96]", special && "bg-key-special text-key-special-fg shadow-key-special", modifier && "bg-key-mod text-key-mod-fg shadow-key-mod text-xs", spec.kind === "space" && "bg-key text-key-fg shadow-key text-xs tracking-wide", !special && !modifier && spec.kind !== "space" && "bg-key text-key-fg shadow-key", (activeDead || spec.kind === "shift" && caps) && "ring-2 ring-ring", pressed && "translate-y-px brightness-90"),
		children: spec.kind === "shift" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowBigUp, {
			className: cn("size-4", caps && "fill-current"),
			strokeWidth: 2
		}) : spec.kind === "backspace" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, {
			className: "size-4",
			strokeWidth: 2
		}) : spec.kind === "enter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownLeft, {
			className: "size-4",
			strokeWidth: 2
		}) : spec.kind === "space" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-2xs font-medium text-subtle",
			children: display
		}) : spec.kind === "emoji" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smile, {
			className: "size-4",
			strokeWidth: 2
		}) : spec.kind === "lang" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
			className: "size-4",
			strokeWidth: 2
		}) : spec.kind === "dead" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-lg leading-none",
			children: spec.label
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display",
			children: display
		})
	});
}
function ariaLabel(spec, display, lang) {
	switch (spec.kind) {
		case "space": return "Space";
		case "backspace": return "Delete";
		case "enter": return "Return";
		case "shift": return "Shift";
		case "mode": return spec.label === "123" ? "Numbers and punctuation" : "Letters";
		case "emoji": return "Emoji";
		case "lang": return lang === "tbl" ? "Switch to English" : "Switch to Tboli";
		case "dead":
			if (spec.dead === "grave") return "Glottal grave accent";
			if (spec.dead === "circumflex") return "Circumflex accent";
			return "Acute accent";
		default: return display;
	}
}
function nativeSet(el, value) {
	const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
	Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, value);
}
function insertInto(el, chunk) {
	const start = el.selectionStart ?? el.value.length;
	const end = el.selectionEnd ?? el.value.length;
	nativeSet(el, el.value.slice(0, start) + chunk + el.value.slice(end));
	const caret = start + chunk.length;
	el.setSelectionRange(caret, caret);
	el.dispatchEvent(new Event("input", { bubbles: true }));
}
function backspaceInto(el) {
	const start = el.selectionStart ?? el.value.length;
	const end = el.selectionEnd ?? el.value.length;
	if (start !== end) {
		nativeSet(el, el.value.slice(0, start) + el.value.slice(end));
		el.setSelectionRange(start, start);
		el.dispatchEvent(new Event("input", { bubbles: true }));
		return;
	}
	if (start <= 0) return;
	const prev = el.value.slice(0, start);
	let cutLen = 1;
	if (typeof Intl !== "undefined" && "Segmenter" in Intl) cutLen = [...new Intl.Segmenter("en", { granularity: "grapheme" }).segment(prev)].at(-1)?.segment.length ?? 1;
	nativeSet(el, el.value.slice(0, start - cutLen) + el.value.slice(end));
	el.setSelectionRange(start - cutLen, start - cutLen);
	el.dispatchEvent(new Event("input", { bubbles: true }));
}
function submitOrNewline(el) {
	if (el instanceof HTMLTextAreaElement) {
		insertInto(el, "\n");
		return;
	}
	const form = el.form;
	if (form) {
		if (typeof form.requestSubmit === "function") form.requestSubmit();
		else form.submit();
		return;
	}
	el.blur();
}
var PREFS_KEY = "tboli-keyboard-prefs";
var DEFAULT_PREFS = {
	installed: false,
	selected: false,
	lang: "tbl"
};
function loadPrefs() {
	try {
		const raw = localStorage.getItem(PREFS_KEY);
		if (!raw) return { ...DEFAULT_PREFS };
		const parsed = JSON.parse(raw);
		return {
			installed: Boolean(parsed.installed),
			selected: Boolean(parsed.selected),
			lang: parsed.lang === "en" ? "en" : "tbl"
		};
	} catch {
		return { ...DEFAULT_PREFS };
	}
}
function savePrefs(prefs) {
	try {
		localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
	} catch {}
}
function openSystemKeyboardSettings() {
	const ua = navigator.userAgent;
	if (/Android/i.test(ua)) {
		window.location.href = "intent:#Intent;action=android.settings.INPUT_METHOD_SETTINGS;end";
		return {
			opened: true,
			platform: "android"
		};
	}
	if (/iPhone|iPad|iPod/i.test(ua)) return {
		opened: false,
		platform: "ios"
	};
	return {
		opened: false,
		platform: "other"
	};
}
var ImeContext = (0, import_react.createContext)(null);
function useIme() {
	const ctx = (0, import_react.useContext)(ImeContext);
	if (!ctx) throw new Error("useIme must be used inside ImeProvider");
	return ctx;
}
function ImeProvider({ children }) {
	const [prefs, setPrefs] = (0, import_react.useState)({
		installed: false,
		selected: false,
		lang: "tbl"
	});
	const [ready, setReady] = (0, import_react.useState)(false);
	const [target, setTarget] = (0, import_react.useState)(null);
	const holdRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		setPrefs(loadPrefs());
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		savePrefs(prefs);
	}, [prefs, ready]);
	const patch = (0, import_react.useCallback)((partial) => {
		setPrefs((p) => ({
			...p,
			...partial
		}));
	}, []);
	const register = (0, import_react.useCallback)((el) => {
		holdRef.current = true;
		setTarget(el);
	}, []);
	const hide = (0, import_react.useCallback)(() => {
		holdRef.current = false;
		window.setTimeout(() => {
			if (!holdRef.current) setTarget(null);
		}, 160);
	}, []);
	const insert = (0, import_react.useCallback)((chunk) => {
		if (!target) return;
		insertInto(target, chunk);
		target.focus();
	}, [target]);
	const backspace = (0, import_react.useCallback)(() => {
		if (!target) return;
		backspaceInto(target);
		target.focus();
	}, [target]);
	const enter = (0, import_react.useCallback)(() => {
		if (!target) return;
		submitOrNewline(target);
	}, [target]);
	const cycleLang = (0, import_react.useCallback)(() => {
		patch({ lang: prefs.lang === "tbl" ? "en" : "tbl" });
	}, [patch, prefs.lang]);
	const visible = Boolean(ready && prefs.installed && prefs.selected && target);
	const value = (0, import_react.useMemo)(() => ({
		ready,
		installed: prefs.installed,
		selected: prefs.selected,
		lang: prefs.lang,
		visible,
		setInstalled: (installed) => patch({
			installed,
			selected: installed ? prefs.selected : false
		}),
		setSelected: (selected) => patch({ selected: selected && prefs.installed }),
		setLang: (lang) => patch({ lang }),
		cycleLang,
		enable: () => patch({
			installed: true,
			selected: true
		}),
		disable: () => patch({
			installed: false,
			selected: false
		}),
		register,
		hide,
		insert,
		backspace,
		enter
	}), [
		backspace,
		cycleLang,
		enter,
		hide,
		insert,
		patch,
		prefs.installed,
		prefs.lang,
		prefs.selected,
		ready,
		register,
		visible
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ImeContext.Provider, {
		value,
		children: [children, visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeKeyboard, {}) : null]
	});
}
var TABS = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/dictionary",
		label: "Words",
		icon: BookOpen
	},
	{
		to: "/translate",
		label: "Translate",
		icon: Languages
	},
	{
		to: "/write",
		label: "Write",
		icon: PenLine
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings
	}
];
function AppShell() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const ime = useIme();
	const hideTabs = ime.visible;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto flex h-dvh max-w-lg flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("min-h-0 flex-1 overflow-y-auto", hideTabs ? "pb-2" : "pb-[calc(4.25rem+env(safe-area-inset-bottom))]", ime.visible && "pb-[min(52vh,24rem)]"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		}), hideTabs ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)]",
			"aria-label": "App",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mx-auto flex h-16 max-w-lg",
				children: TABS.map((tab) => {
					const active = tab.to === "/" ? pathname === "/" : pathname === tab.to || pathname.startsWith(`${tab.to}/`);
					const Icon = tab.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: tab.to,
							className: cn("flex h-full flex-col items-center justify-center gap-1 text-2xs font-medium", active ? "text-fg" : "text-subtle"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.25 : 1.75
							}), tab.label]
						})
					}, tab.to);
				})
			})
		})]
	});
}
var styles_default = "/assets/styles-mfWrc4bh.css";
var APP_NAME = "T'boli Keyboard";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Tboli Keyboard — translate and write in the app, or turn it on as the board that pops up when you type."
			},
			{
				name: "theme-color",
				content: "#000000"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "font-sans",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$6 = () => import("./routes-2j3escaE.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./dictionary-ojcVEWOz.mjs");
var Route$5 = createFileRoute("/dictionary")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./enable-CTPSQkf-.mjs");
var Route$4 = createFileRoute("/enable")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./settings-C60lnMZA.mjs");
var Route$3 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./translate-CY7dElOS.mjs");
var Route$2 = createFileRoute("/translate")({
	validateSearch: (search) => ({ en: typeof search.en === "string" ? search.en.slice(0, 280) : "" }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./try-D5Se-S8J.mjs");
var Route$1 = createFileRoute("/try")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./write-DQ8Cin9A.mjs");
var Route = createFileRoute("/write")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	DictionaryRoute: Route$5.update({
		id: "/dictionary",
		path: "/dictionary",
		getParentRoute: () => Route$7
	}),
	EnableRoute: Route$4.update({
		id: "/enable",
		path: "/enable",
		getParentRoute: () => Route$7
	}),
	SettingsRoute: Route$3.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$7
	}),
	TranslateRoute: Route$2.update({
		id: "/translate",
		path: "/translate",
		getParentRoute: () => Route$7
	}),
	TryRoute: Route$1.update({
		id: "/try",
		path: "/try",
		getParentRoute: () => Route$7
	}),
	WriteRoute: Route.update({
		id: "/write",
		path: "/write",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { STORAGE_KEY as a, SAMPLES as i, useIme as n, VOWELS as o, openSystemKeyboardSettings as r, cn as s, router_exports as t };
