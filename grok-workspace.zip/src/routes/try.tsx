import { createFileRoute } from "@tanstack/react-router";
import { TryScreen } from "@/components/screens/try-screen";

export const Route = createFileRoute("/try")({ component: TryScreen });
