import { Link } from "@tanstack/react-router";
import { BookOpen, ChevronRight, Keyboard, Languages, MessageSquare, PenLine } from "lucide-react";
import { useIme } from "@/components/ime-provider";
import { VOWELS } from "@/lib/tboli";
import { cn } from "@/lib/utils";

export function HomeScreen() {
  const ime = useIme();
  const on = ime.installed && ime.selected;

  return (
    <div className="px-4 pt-6 pb-8">
      <p className="text-sm font-medium tracking-wide text-primary">Lake Sebu</p>
      <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight">
        T'boli Keyboard
      </h1>
      <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted">
        Open the app for translate and writing tools. Turn the keyboard on in
        settings, then it pops up like any other keyboard when you type.
      </p>

      <Link
        to="/enable"
        className={cn(
          "mt-5 flex items-center gap-3 rounded-xl p-4 shadow-panel",
          on ? "bg-surface" : "bg-primary text-primary-fg",
        )}
      >
        <Keyboard className="size-6 shrink-0" strokeWidth={1.75} />
        <div className="min-w-0 flex-1">
          <p className="font-medium">
            {on ? "Keyboard is on" : "Turn on the keyboard"}
          </p>
          <p className={cn("text-sm", on ? "text-subtle" : "text-primary-fg/80")}>
            {on
              ? `${ime.lang === "tbl" ? "Tboli" : "English"} · tap any field to type`
              : "Add it in Keyboard settings, then choose it as your board"}
          </p>
        </div>
        <ChevronRight className="size-5 shrink-0 opacity-70" strokeWidth={2} />
      </Link>

      <ul className="mt-4 grid grid-cols-2 gap-2">
        <Tile
          to="/translate"
          icon={Languages}
          title="Translate"
          hint="English to Tboli"
        />
        <Tile
          to="/dictionary"
          icon={BookOpen}
          title="Dictionary"
          hint="Deymar's word list"
        />
        <Tile to="/write" icon={PenLine} title="Write" hint="Notes in Tboli" />
        <Tile
          to="/try"
          icon={MessageSquare}
          title="Try typing"
          hint="Messages, Notes, Search"
        />
        <Tile
          to="/settings"
          icon={Keyboard}
          title="Settings"
          hint="Languages and keys"
        />
      </ul>

      <section className="mt-6" aria-label="Tboli vowels">
        <h2 className="text-sm font-medium text-muted">Seven vowels</h2>
        <ul className="mt-2 grid grid-cols-7 gap-1">
          {VOWELS.map((v) => (
            <li
              key={v.letter}
              className="flex flex-col items-center rounded-md bg-surface py-2 shadow-panel"
            >
              <span className="font-display text-xl font-semibold leading-none">
                {v.letter}
              </span>
              <span className="mt-1 text-2xs text-subtle">{v.ipa}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function Tile({
  to,
  icon: Icon,
  title,
  hint,
}: {
  to: "/translate" | "/dictionary" | "/write" | "/try" | "/settings";
  icon: typeof Languages;
  title: string;
  hint: string;
}) {
  return (
    <li>
      <Link
        to={to}
        className="flex h-full flex-col rounded-xl bg-surface p-3.5 shadow-panel"
      >
        <Icon className="size-5 text-primary" strokeWidth={1.75} />
        <p className="mt-3 font-medium">{title}</p>
        <p className="mt-0.5 text-xs text-subtle">{hint}</p>
      </Link>
    </li>
  );
}
