export type LayoutLang = "en" | "tbl";

export const PREFS_KEY = "tboli-keyboard-prefs";

export type KeyboardPrefs = {
  installed: boolean;
  selected: boolean;
  lang: LayoutLang;
};

export const DEFAULT_PREFS: KeyboardPrefs = {
  installed: false,
  selected: false,
  lang: "tbl",
};

export function loadPrefs(): KeyboardPrefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return { ...DEFAULT_PREFS };
    const parsed = JSON.parse(raw) as Partial<KeyboardPrefs>;
    return {
      installed: Boolean(parsed.installed),
      selected: Boolean(parsed.selected),
      lang: parsed.lang === "en" ? "en" : "tbl",
    };
  } catch {
    return { ...DEFAULT_PREFS };
  }
}

export function savePrefs(prefs: KeyboardPrefs) {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch {
    /* ignore quota */
  }
}

export function openSystemKeyboardSettings(): { opened: boolean; platform: "android" | "ios" | "other" } {
  const ua = navigator.userAgent;
  if (/Android/i.test(ua)) {
    window.location.href =
      "intent:#Intent;action=android.settings.INPUT_METHOD_SETTINGS;end";
    return { opened: true, platform: "android" };
  }
  if (/iPhone|iPad|iPod/i.test(ua)) {
    return { opened: false, platform: "ios" };
  }
  return { opened: false, platform: "other" };
}
