import { lookupPhrase, primaryTboli, soften, tboliVerb } from "@/lib/dictionary";

export type GrammarLine = { tbl: string };

const EXPAND: Record<string, string[]> = {
  "i'm": ["i", "am"],
  "you're": ["you", "are"],
  "we're": ["we", "are"],
  "they're": ["they", "are"],
  "he's": ["he", "is"],
  "she's": ["she", "is"],
  "it's": ["it", "is"],
  "i'll": ["i", "will"],
  "you'll": ["you", "will"],
  "we'll": ["we", "will"],
  "they'll": ["they", "will"],
  "don't": ["do", "not"],
  "doesn't": ["does", "not"],
  "didn't": ["did", "not"],
  "isn't": ["is", "not"],
  "aren't": ["are", "not"],
  "let's": ["let", "us"],
  "won't": ["will", "not"],
  "can't": ["can", "not"],
};

const DROP = new Set([
  "a",
  "an",
  "the",
  "am",
  "is",
  "are",
  "was",
  "were",
  "be",
  "been",
  "being",
  "do",
  "does",
  "did",
  "to",
  "of",
]);

const VERBS = new Set([
  "eat",
  "drink",
  "sleep",
  "go",
  "cook",
  "see",
  "teach",
  "run",
  "buy",
  "give",
  "sit",
  "wake",
  "boil",
  "fry",
  "know",
  "hear",
  "look",
  "send",
  "pay",
  "plant",
  "build",
  "help",
  "pray",
  "ride",
  "read",
  "write",
  "take",
  "come",
  "walk",
  "feed",
  "rain",
  "want",
  "love",
  "like",
  "hate",
]);

const LIVING = new Set([
  "you",
  "him",
  "her",
  "them",
  "us",
  "me",
  "cat",
  "dog",
  "fish",
  "spider",
  "chicken",
  "snake",
  "bird",
  "horse",
  "pig",
  "child",
  "friend",
  "person",
  "people",
  "mom",
  "dad",
  "mother",
  "father",
]);

const PRONOUN: Record<string, string> = {
  i: "o",
  me: "o",
  you: "u",
  he: "du",
  she: "du",
  it: "du",
  him: "du",
  her: "du",
  we: "kuy",
  us: "tu",
  they: "lu",
  them: "lu",
};

type Person = "i" | "you" | "he" | "we" | "they";

const TEY: Record<Person, string> = {
  i: "Teye",
  you: "Téyu",
  he: "Téy",
  we: "Téykuy",
  they: "Téyle",
};

const NEG: Record<Person, string> = {
  i: "Là e",
  you: "Là u",
  he: "Làen",
  we: "Là kuy",
  they: "Là le",
};

const WILL: Record<Person, string> = {
  i: "Nehe",
  you: "Nehi",
  he: "Ne",
  we: "Ne",
  they: "Nele",
};

const JOINER: Record<string, string> = {
  and: "omin",
  but: "okóm",
  because: "kay",
  so: "kayà",
  if: "ke",
  when: "sok",
  or: "o",
};

function personOf(word: string): Person | null {
  if (word === "i") return "i";
  if (word === "you") return "you";
  if (word === "he" || word === "she" || word === "it") return "he";
  if (word === "we") return "we";
  if (word === "they") return "they";
  return null;
}

function tokenize(text: string): string[] {
  const out: string[] = [];
  for (const piece of text.trim().split(/\s+/)) {
    if (!piece) continue;
    const ask = /[?？]$/.test(piece);
    const bare = piece.replace(/^[("']+|[)"'.!?,;:]+$/g, "").toLowerCase();
    const split = EXPAND[bare];
    if (split) out.push(...split);
    else if (bare) out.push(bare);
    if (ask) out.push("?");
  }
  return out;
}

function lemma(word: string): string {
  if (word.endsWith("ing") && word.length > 4) {
    const stem = word.slice(0, -3);
    if (VERBS.has(stem)) return stem;
    if (VERBS.has(`${stem}e`)) return `${stem}e`;
    if (stem.endsWith("n") && VERBS.has(stem.slice(0, -1))) return stem.slice(0, -1);
  }
  if (word.endsWith("s") && VERBS.has(word.slice(0, -1))) return word.slice(0, -1);
  return word;
}

function isVerb(word: string): boolean {
  const base = lemma(word);
  return VERBS.has(base) || (word.endsWith("ing") && word.length > 4);
}

function lex(word: string): string {
  if (PRONOUN[word] && word !== "i" && word !== "we") return PRONOUN[word];
  const hit = primaryTboli(lemma(word)) ?? primaryTboli(word);
  return hit ?? `[${word}]`;
}

function accented(word: string): boolean {
  return /[àèìòùáéíóúâêîôûÀÈÌÒÙÁÉÍÓÚÂÊÎÔÛ]$/.test(word);
}

function stripFinalAccent(word: string): string {
  const last = word.slice(-1);
  if (last === "ô") return `${word.slice(0, -1)}ó`;
  if (last === "Ô") return `${word.slice(0, -1)}Ó`;
  if (last === "ê") return `${word.slice(0, -1)}é`;
  if (last === "Ê") return `${word.slice(0, -1)}É`;
  const plain: Record<string, string> = {
    à: "a",
    è: "e",
    ì: "i",
    ò: "o",
    ù: "u",
    á: "a",
    é: "e",
    í: "i",
    ó: "o",
    ú: "u",
    â: "a",
    î: "i",
    û: "u",
    À: "A",
    È: "E",
    Ì: "I",
    Ò: "O",
    Ù: "U",
  };
  return plain[last] ? word.slice(0, -1) + plain[last] : word;
}

function attach(phrase: string, ending: "e" | "u" | "em" | "en" | "i"): string {
  const parts = phrase.split(/\s+/);
  const last = parts.pop() ?? phrase;
  let base = last;
  const stop = accented(last);
  if (stop) base = stripFinalAccent(last);
  const vowel = /[aeiouéóAEIOUÉÓ]$/.test(base);
  const next = stop ? base + ending : vowel ? `${base}h${ending}` : base + ending;
  parts.push(next);
  return parts.join(" ");
}

function describe(word: string, person: Person): string {
  const stem = lex(word);
  if (stem.startsWith("[")) return stem;
  if (person === "i") return attach(stem, "e");
  if (person === "you") return attach(stem, "u");
  if (person === "he") return `${stem} du`;
  if (person === "we") return `${stem} kuy`;
  return `${stem} le`;
}

function act(word: string, person: Person, ongoing: boolean): string {
  const verb = tboliVerb(lemma(word), ongoing);
  if (verb.startsWith("[")) return verb;
  if (ongoing) {
    if (person === "i") return attach(verb, "e");
    if (person === "you") return attach(verb, "u");
    if (person === "he") return `${verb} du`;
    if (person === "we") return `${verb} kuy`;
    return `${verb} le`;
  }
  if (person === "i") return attach(verb, "u");
  if (person === "you") return attach(verb, "em");
  if (person === "he") return attach(verb, "en");
  if (person === "we") return `${verb} kuy`;
  return `${verb} le`;
}

function own(word: string): string {
  const stem = lex(word);
  if (stem.startsWith("[")) return stem;
  if (accented(stem)) return stem;
  if (/[aeiouéó]$/i.test(stem)) return `${stem}-hu`;
  return `do ${stem}`;
}

function finish(line: string, ask: boolean): string {
  const clean = line.replace(/\s+/g, " ").trim();
  if (!clean) return "";
  if (ask && !/[?]$/.test(clean)) return `${clean} kô?`;
  return clean;
}

function renderRest(tokens: string[], ongoing: boolean): string {
  return tokens
    .filter((token) => token !== "?")
    .map((token) => {
      if (token === "of" || token === "in" || token === "on" || token === "at") return "bê";
      if (token === "to" && !isVerb(tokens[tokens.indexOf(token) + 1] ?? "")) return "bê";
      if (DROP.has(token) || personOf(token)) return "";
      if (isVerb(token)) return tboliVerb(lemma(token), ongoing || token.endsWith("ing"));
      return lex(token);
    })
    .filter(Boolean)
    .join(" ");
}

function composeClause(tokens: string[]): string {
  const ask = tokens.includes("?");
  const body = tokens.filter((token) => token !== "?");
  if (!body.length) return "";

  const question = body[0];
  if (question && ["what", "where", "who", "why", "how", "when"].includes(question)) {
    const qmap: Record<string, string> = {
      what: "Bon",
      where: "Nô",
      who: "Tadu",
      why: "Moen ke",
      how: "Kmò",
      when: "Kilón",
    };
    const rest = renderRest(body.slice(1), false);
    return [qmap[question], rest].filter(Boolean).join(" ");
  }

  if ((body[0] === "do" && body[1] === "not") || body[0] === "dont") {
    const rest = renderRest(body.slice(body[0] === "do" ? 2 : 1), false);
    return ["Bê", rest].filter(Boolean).join(" ");
  }

  let index = 0;
  let person = personOf(body[0] ?? "");
  if (person) index = 1;
  if (body[0] === "let" && body[1] === "us") {
    const verb = body[2];
    const more = renderRest(body.slice(verb && isVerb(verb) ? 3 : 2), true);
    const head = verb && isVerb(verb) ? tboliVerb(lemma(verb), true) : "";
    return [head, "kuy", more].filter(Boolean).join(" ");
  }

  const negated =
    (body[index] === "am" || body[index] === "is" || body[index] === "are" || body[index] === "do") &&
    body[index + 1] === "not";
  const will = body[index] === "will";
  const going = body[index] === "am" && body[index + 1] === "going" && body[index + 2] === "to";
  const very =
    !negated &&
    (body[index] === "am" || body[index] === "is" || body[index] === "are") &&
    body[index + 1] === "very";
  const copula = body[index] === "am" || body[index] === "is" || body[index] === "are";

  if (person && body[index] === "do" && body[index + 1] === "not" && body[index + 2] === "want") {
    const rest = renderRest(body.slice(index + 3), false);
    const neg = person === "i" ? "Là nóyóu du" : person === "you" ? "Là nóyóem du" : `${NEG[person]} nóyó`;
    return [neg, rest].filter(Boolean).join(" ");
  }

  if (person === "i" && body[index] === "want") {
    const rest = renderRest(body.slice(index + 1), false);
    return ["Nóyóu", rest].filter(Boolean).join(" ");
  }

  if (person && (body[index] === "love" || body[index] === "hate" || body[index] === "like")) {
    const kind = body[index];
    const object = body.slice(index + 1).filter((token) => !DROP.has(token));
    const who = object[0] ?? "";
    const pronoun = PRONOUN[who];
    const living = LIVING.has(who);
    if (kind === "like" || (kind === "love" && !living && !pronoun)) {
      const rest = renderRest(object, false);
      return person === "i" ? ["Nóyóu", rest].filter(Boolean).join(" ") : [act("want", person, false), rest].filter(Boolean).join(" ");
    }
    const stem = kind === "hate" ? "Knutó nawa" : "Kenbong nawa";
    const owned = person === "i" ? attach(stem, "u") : person === "you" ? attach(stem, "em") : `${stem} ${person === "he" ? "du" : person === "we" ? "kuy" : "le"}`;
    const target = pronoun ?? (who ? `du ${lex(who)}` : "");
    return [owned, target].filter(Boolean).join(" ");
  }

  if (body[0] === "my" && copulaAt(body, 2)) {
    const noun = body[1] ?? "";
    const after = body.slice(3).filter((token) => token !== "very");
    const veryMy = body[3] === "very";
    const adj = (veryMy ? after[0] : after[0]) ?? "";
    const tail = renderRest(after.slice(adj ? 1 : 0), false);
    const desc = adj ? (veryMy ? `${TEY.he} ${lex(adj)}` : lex(adj)) : "";
    return [own(noun), desc, tail].filter(Boolean).join(" ");
  }

  if (person && negated) {
    const rest = renderRest(body.slice(index + 2), false);
    return [NEG[person], rest].filter(Boolean).join(" ");
  }

  if (person && very) {
    const words = body.slice(index + 2);
    const first = words[0];
    const rest = renderRest(words.slice(1), false);
    if (first && isVerb(first)) return finish([act(first, person, true), rest].filter(Boolean).join(" "), ask);
    return finish([TEY[person], first ? lex(first) : "", rest].filter(Boolean).join(" "), ask);
  }

  if (person && will) {
    const words = body.slice(index + 1);
    const verb = words.find((token) => isVerb(token));
    const rest = renderRest(
      words.filter((token) => token !== verb),
      false,
    );
    const head = verb ? tboliVerb(lemma(verb), false) : "";
    return [WILL[person], head, rest].filter(Boolean).join(" ");
  }

  if (person && going) {
    const words = body.slice(index + 3);
    const verb = words.find((token) => isVerb(token));
    const rest = renderRest(
      words.filter((token) => token !== verb),
      false,
    );
    const head = verb ? tboliVerb(lemma(verb), true) : "";
    return ["Ne", head, "dé", rest].filter(Boolean).join(" ");
  }

  if (person && copula) {
    const words = body.slice(index + 1);
    const first = words[0];
    if (first && isVerb(first)) {
      const rest = renderRest(words.slice(1), true);
      return [act(first, person, true), rest].filter(Boolean).join(" ");
    }
    if (first) {
      const rest = renderRest(words.slice(1), false);
      return [describe(first, person), rest].filter(Boolean).join(" ");
    }
  }

  if (person) {
    const words = body.slice(index);
    const first = words[0];
    if (first && isVerb(first)) {
      const rest = renderRest(words.slice(1), first.endsWith("ing"));
      return [act(first, person, first.endsWith("ing")), rest].filter(Boolean).join(" ");
    }
  }

  const cop = body.findIndex((token) => token === "is" || token === "are");
  if (!person && cop > 0) {
    const left = body.slice(0, cop).filter((token) => !DROP.has(token));
    const right = body.slice(cop + 1);
    const first = right[0];
    if (left.length === 1 && first && !isVerb(first)) {
      const veryThere = first === "very";
      const adj = veryThere ? right[1] : first;
      const tail = renderRest(right.slice(veryThere ? 2 : 1), false);
      const desc = adj ? (veryThere ? `${TEY.he} ${lex(adj)}` : lex(adj)) : "";
      return finish([desc, lex(left[0] ?? ""), tail].filter(Boolean).join(" "), ask);
    }
  }

  const loose = renderRest(body, false);
  return finish(loose, ask);
}

function copulaAt(tokens: string[], index: number): boolean {
  return tokens[index] === "is" || tokens[index] === "am" || tokens[index] === "are";
}

function composeJoined(tokens: string[]): string {
  const chunks: { join: string | null; tokens: string[] }[] = [];
  let current: string[] = [];
  let pending: string | null = null;
  for (const token of tokens) {
    if (JOINER[token] && current.length) {
      chunks.push({ join: pending, tokens: current });
      pending = JOINER[token];
      current = [];
      continue;
    }
    current.push(token);
  }
  if (current.length) chunks.push({ join: pending, tokens: current });

  return chunks
    .map((chunk) => {
      const text = chunk.tokens.join(" ");
      const stored = lookupPhrase(text)?.tbl;
      let line = stored ?? composeClause(chunk.tokens);
      if (!stored && chunk.join === "kay" && chunk.tokens[0] && personOf(chunk.tokens[0]) === "i") {
        const inner = chunk.tokens.slice(1);
        if (inner[0] === "am" && inner[1] && !isVerb(inner[1])) {
          line = `Kaye ${lex(inner[1] === "very" ? (inner[2] ?? "") : inner[1])}`;
        }
      }
      if (!stored && chunk.join === "ke" && personOf(chunk.tokens[0] ?? "") === "i" && chunk.tokens[1] === "am") {
        const word = chunk.tokens[2] === "very" ? chunk.tokens[3] : chunk.tokens[2];
        if (word && !isVerb(word)) line = `Kehe ${lex(word)}`;
      }
      if (!line) return "";
      if (!chunk.join) return line;
      if (chunk.join === "kay" && line.startsWith("Kaye")) return line;
      if (chunk.join === "ke" && line.startsWith("Kehe")) return line;
      return `${chunk.join} ${line.replace(/^\p{Lu}/u, (letter) => letter.toLowerCase())}`;
    })
    .filter(Boolean)
    .join(" ");
}

function capitalize(text: string): string {
  return text.replace(/^(\s*)(\p{L})/u, (_, space: string, letter: string) => space + letter.toUpperCase());
}

export function composeGrammar(english: string): GrammarLine | null {
  const text = english.trim();
  if (!text || soften(text).split(" ").filter(Boolean).length < 2) return null;
  const clauses = text.split(/(?<=[.!?])\s+/).map((part) => part.trim()).filter(Boolean);
  const lines = clauses.map((clause) => lookupPhrase(clause)?.tbl ?? capitalize(composeJoined(tokenize(clause))));
  const tbl = lines
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line, index, all) => (index < all.length - 1 && !/[.!?]$/.test(line) ? `${line}.` : line))
    .join(" ");
  if (!tbl) return null;
  return { tbl: capitalize(tbl) };
}
