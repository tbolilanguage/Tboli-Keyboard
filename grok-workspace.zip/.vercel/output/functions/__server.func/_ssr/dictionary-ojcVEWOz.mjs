import { i as __toESM } from "../_runtime.mjs";
import { c as entriesForLetter, d as phrasesByTopic, f as searchEnglish, i as LETTERS, m as searchPhrases, n as EN_INDEX, o as TOPICS, p as searchEntries, r as GUIDE, t as ENTRIES } from "./dictionary-D-_jSYMr.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as cn } from "./router-DW5w4w-K.mjs";
import { t as ImeInput } from "./ime-field-WzsZTvOs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dictionary-ojcVEWOz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "words",
		label: "Tboli"
	},
	{
		id: "english",
		label: "English"
	},
	{
		id: "phrases",
		label: "Phrases"
	},
	{
		id: "guide",
		label: "Guide"
	}
];
function DictionaryScreen() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [tab, setTab] = (0, import_react.useState)("words");
	const [letter, setLetter] = (0, import_react.useState)(LETTERS[0] ?? "A");
	const [topic, setTopic] = (0, import_react.useState)(TOPICS[0] ?? "");
	const [open, setOpen] = (0, import_react.useState)(null);
	const [guideOpen, setGuideOpen] = (0, import_react.useState)(GUIDE[0]?.title ?? "");
	const q = query.trim();
	const words = (0, import_react.useMemo)(() => q ? searchEntries(q) : entriesForLetter(letter), [q, letter]);
	const english = (0, import_react.useMemo)(() => q ? searchEnglish(q) : [], [q]);
	const phrases = (0, import_react.useMemo)(() => q ? searchPhrases(q) : phrasesByTopic(topic), [q, topic]);
	const guide = (0, import_react.useMemo)(() => {
		if (!q) return GUIDE;
		const n = q.toLowerCase();
		return GUIDE.map((section) => ({
			...section,
			blocks: section.blocks.filter((b) => b.text.toLowerCase().includes(n))
		})).filter((section) => section.blocks.length > 0 || section.title.toLowerCase().includes(n));
	}, [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium tracking-wide text-primary",
				children: "Deymar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-semibold tracking-tight",
				children: "Dictionary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: [ENTRIES.length, " roots, taught one lesson at a time. Accents change the meaning."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeInput, {
				value: query,
				onChange: (e) => setQuery(e.target.value),
				placeholder: "Search ngà, child, good morning",
				className: "mt-4 bg-surface",
				"aria-label": "Search the dictionary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex rounded-lg bg-surface p-1",
				children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(item.id),
					className: cn("h-9 flex-1 rounded-md text-xs font-medium", tab === item.id ? "bg-primary text-primary-fg" : "text-muted"),
					children: item.label
				}, item.id))
			}),
			tab === "words" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [q ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1 overflow-x-auto pb-1",
				children: LETTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLetter(item),
					className: cn("h-8 w-8 shrink-0 rounded-sm text-xs font-medium", letter === item ? "bg-primary text-primary-fg" : "bg-surface text-muted"),
					children: item
				}, item))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2",
				children: [words.map((entry) => {
					const id = `${entry.letter}:${entry.head}:${entry.gloss}`;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WordRow, {
						entry,
						open: open === id,
						onToggle: () => setOpen((cur) => cur === id ? null : id)
					}, id);
				}), words.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) }) : null]
			})] }) : null,
			tab === "english" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2",
				children: [
					(q ? english : []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnglishRow, { item }, item.en)),
					!q ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-surface px-4 py-3 text-sm text-subtle shadow-panel",
						children: [
							"Type an English word. The index has ",
							EN_INDEX.length,
							" entries."
						]
					}) : null,
					q && english.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) }) : null
				]
			}) : null,
			tab === "phrases" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [q ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1.5 overflow-x-auto pb-1",
				children: TOPICS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTopic(item),
					className: cn("h-8 shrink-0 rounded-sm px-2.5 text-xs font-medium", topic === item ? "bg-primary text-primary-fg" : "bg-surface text-muted"),
					children: item
				}, item))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2",
				children: [phrases.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhraseRow, { item }, `${item.topic}-${item.tbl}`)), phrases.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) }) : null]
			})] }) : null,
			tab === "guide" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-2",
				children: [guide.map((section) => {
					const expanded = guideOpen === section.title || Boolean(q);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl bg-surface shadow-panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setGuideOpen((cur) => cur === section.title ? "" : section.title),
							className: "flex w-full items-center justify-between px-4 py-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: section.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-subtle",
								children: section.blocks.length
							})]
						}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2 px-4 pb-4 text-sm leading-relaxed text-muted",
							children: section.blocks.map((block, i) => block.kind === "li" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "border-l-2 border-primary pl-3",
								children: block.text
							}, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: block.text }, i))
						}) : null]
					}, section.title);
				}), guide.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) : null]
			}) : null
		]
	});
}
function Empty() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-xl bg-surface px-4 py-3 text-sm text-subtle shadow-panel",
		children: "Nothing matches. Try another spelling, or leave the English word in brackets."
	});
}
function WordRow({ entry, open, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-xl bg-surface shadow-panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onToggle,
			className: "w-full px-4 py-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-xl leading-none",
				children: entry.head
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-muted",
				children: entry.gloss || "See the forms below"
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 px-4 pb-4 text-sm",
			children: [
				entry.forms.map((form) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-fg",
					children: form.form
				}), form.gloss ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [" — ", form.gloss]
				}) : null] }, form.form)),
				entry.examples.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "border-l-2 border-primary pl-3 text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: ex.tbl
					}), ex.en ? ` — ${ex.en}` : ""]
				}, ex.tbl)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranslateLink, { english: entry.gloss.split(",")[0]?.trim() ?? entry.head })
			]
		}) : null]
	});
}
function EnglishRow({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-xl bg-surface px-4 py-3 shadow-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: item.en
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-xl",
				children: item.heads
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranslateLink, { english: item.en })
		]
	});
}
function PhraseRow({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-xl bg-surface px-4 py-3 shadow-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-2xs tracking-wide text-subtle",
				children: item.topic
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-lg leading-snug",
				lang: "tbl",
				children: item.tbl
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: item.en
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranslateLink, { english: item.en })
		]
	});
}
function TranslateLink({ english }) {
	if (!english) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/translate",
		search: { en: english },
		className: "mt-2 inline-flex h-8 items-center text-xs font-medium text-primary",
		children: "Translate this"
	});
}
var SplitComponent = DictionaryScreen;
//#endregion
export { SplitComponent as component };
