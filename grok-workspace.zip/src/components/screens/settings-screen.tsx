import { Link } from "@tanstack/react-router";
import { ChevronRight, Globe, Keyboard } from "lucide-react";
import { useIme } from "@/components/ime-provider";
import { cn } from "@/lib/utils";

export function SettingsScreen() {
  const ime = useIme();
  const on = ime.installed && ime.selected;

  return (
    <div className="px-4 pt-6 pb-8">
      <h1 className="font-display text-3xl font-semibold tracking-tight">Settings</h1>
      <p className="mt-1 text-sm text-muted">
        This is the keyboard’s own app — languages, layout, and the switch that
        turns it into the board you type with.
      </p>

      <section className="mt-6">
        <h2 className="px-1 text-xs font-medium tracking-wide text-subtle uppercase">
          Keyboard
        </h2>
        <div className="mt-2 overflow-hidden rounded-xl bg-surface shadow-panel">
          <Link
            to="/enable"
            className="flex items-center gap-3 px-4 py-3.5"
          >
            <Keyboard className="size-5 text-primary" strokeWidth={1.75} />
            <div className="min-w-0 flex-1">
              <p className="font-medium">Keyboard settings</p>
              <p className="text-sm text-subtle">
                {on ? "On · chosen as current keyboard" : "Off · add it to type everywhere"}
              </p>
            </div>
            <ChevronRight className="size-5 text-subtle" strokeWidth={2} />
          </Link>
          <div className="h-px bg-border" />
          <div className="flex items-center gap-3 px-4 py-3.5">
            <Globe className="size-5 text-primary" strokeWidth={1.75} />
            <div className="min-w-0 flex-1">
              <p className="font-medium">Languages</p>
              <p className="text-sm text-subtle">English and Tboli only</p>
            </div>
          </div>
          <div className="flex gap-2 px-4 pb-4">
            {(["en", "tbl"] as const).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => ime.setLang(lang)}
                className={cn(
                  "h-10 flex-1 rounded-md text-sm font-medium",
                  ime.lang === lang
                    ? "bg-primary text-primary-fg"
                    : "bg-key-mod text-key-mod-fg",
                )}
              >
                {lang === "en" ? "English" : "Tboli"}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="mt-6">
        <h2 className="px-1 text-xs font-medium tracking-wide text-subtle uppercase">
          How it works
        </h2>
        <ol className="mt-2 space-y-2 text-sm leading-relaxed text-muted">
          <li className="rounded-xl bg-surface px-4 py-3 shadow-panel">
            <span className="font-medium text-fg">1. Open the app</span>
            <p className="mt-1">
              Translate, write, and look up vowels. This is the full Tboli Keyboard.
            </p>
          </li>
          <li className="rounded-xl bg-surface px-4 py-3 shadow-panel">
            <span className="font-medium text-fg">2. Add it in Keyboard settings</span>
            <p className="mt-1">
              Same place you enable Gboard or the iPhone board. Toggle Tboli Keyboard on,
              then set it as the current keyboard.
            </p>
          </li>
          <li className="rounded-xl bg-surface px-4 py-3 shadow-panel">
            <span className="font-medium text-fg">3. Type anywhere</span>
            <p className="mt-1">
              Tap a field in Messages, Notes, or Search — a normal keyboard pops up.
              Globe switches English and Tboli.
            </p>
          </li>
        </ol>
      </section>
    </div>
  );
}
