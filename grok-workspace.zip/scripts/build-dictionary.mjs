import { readFileSync, writeFileSync } from "node:fs";

const md = readFileSync(new URL("../src/data/tboli-dictionary.md", import.meta.url), "utf8");

function sliceBetween(startMark, endMark) {
  const start = md.indexOf(startMark);
  if (start < 0) throw new Error(`missing ${startMark}`);
  const from = start + startMark.length;
  const end = endMark ? md.indexOf(endMark, from) : md.length;
  return md.slice(from, end < 0 ? md.length : end);
}

function clean(text) {
  return text
    .replace(/\*\*/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function stripPron(text) {
  return text.replace(/\s*\[[^\]]{0,80}\]/g, " ");
}

function cleanPron(text) {
  return clean(stripPron(text));
}

const entries = [];
let letter = "";
let current = null;

function pushCurrent() {
  if (current) entries.push(current);
  current = null;
}

for (const raw of sliceBetween("## Dictionary: T'boli to English", "## English to T'boli index").split("\n")) {
  const line = raw.replace(/\s+$/, "");
  const heading = line.match(/^###\s+(.+)/);
  if (heading) {
    pushCurrent();
    letter = heading[1].trim();
    continue;
  }
  const top = line.match(/^- \*\*(.+?)\*\*(?:\s*\[[^\]]*\])?\s*:?\s*(.*)$/);
  if (top) {
    pushCurrent();
    current = {
      head: clean(top[1]),
      letter,
      gloss: cleanPron(top[2]),
      forms: [],
      examples: [],
    };
    continue;
  }
  const nested = line.match(/^  - (.*)$/);
  if (!nested || !current) continue;
  const body = stripPron(nested[1].trim());
  if (body.startsWith("Example:")) {
    const rest = body.slice("Example:".length).trim();
    const paren = rest.match(/^(.*)\s+\((.+)\)\s*$/);
    current.examples.push(
      paren
        ? { tbl: clean(paren[1]), en: clean(paren[2]) }
        : { tbl: clean(rest), en: "" },
    );
    continue;
  }
  const split = body.match(/^([^:]+):\s+(.+)$/);
  if (split) {
    current.forms.push({ form: cleanPron(split[1]), gloss: cleanPron(split[2]) });
  } else {
    current.forms.push({ form: cleanPron(body), gloss: "" });
  }
}
pushCurrent();

const index = [];
for (const raw of sliceBetween("## English to T'boli index", "## Phrases by topic").split("\n")) {
  const top = raw.match(/^- \*\*(.+?)\*\*(?:\s*\[[^\]]*\])?\s*:?\s*(.*)$/);
  if (!top) continue;
  index.push({ en: clean(top[1]), heads: cleanPron(top[2]) });
}

const phrases = [];
const seenPhrases = new Set();

function tidyEnglish(en) {
  return clean(en)
    .replace(/\s+Note:.*$/i, "")
    .replace(/\s*\(confirmed by Deymar[^)]*\)/gi, "")
    .trim();
}

function expandPair(tbl, en) {
  const tParts = tbl.split(/\s+\/\s+/).map((part) => part.trim()).filter(Boolean);
  const eParts = en.split(/\s+\/\s+/).map((part) => part.trim()).filter(Boolean);
  if (tParts.length > 1 && eParts.length === 1) return tParts.map((part) => [part, en]);
  if (tParts.length > 1 && tParts.length === eParts.length) {
    return tParts.map((part, index) => [part, eParts[index]]);
  }
  return [[tbl, en]];
}

function pushPhrase(topic, tbl, en, lesson = false) {
  const english = tidyEnglish(en);
  const tboli = clean(tbl);
  if (!tboli || !english) return;
  for (const [tRaw, eRaw] of expandPair(tboli, english)) {
    const t = clean(tRaw);
    const e = tidyEnglish(eRaw);
    if (!t || !e) continue;
    const key = `${t.toLowerCase()}|${e.toLowerCase()}`;
    if (seenPhrases.has(key)) {
      if (lesson) {
        const row = phrases.find((item) => `${item.tbl.toLowerCase()}|${item.en.toLowerCase()}` === key);
        if (row) row.lesson = true;
      }
      continue;
    }
    seenPhrases.add(key);
    phrases.push({ topic, tbl: t, en: e, lesson });
  }
}

function takeTopic(line, fallback) {
  return line.replace(/\*\*/g, "").trim() || fallback;
}

let topic = "Example pairs";
for (const raw of sliceBetween("### Example pairs", "## The T'boli alphabet").split("\n")) {
  const heading = raw.match(/^###\s+(.+)/);
  if (heading) {
    topic = takeTopic(heading[1], topic);
    continue;
  }
  const line = raw.match(/^- (.+?):\s+\*\*(.+?)\*\*\s*(.*)$/);
  if (!line) continue;
  pushPhrase(topic, line[2], line[1], true);
}

topic = "Phrases";
for (const raw of sliceBetween("## Phrases by topic", "## Bible verses").split("\n")) {
  const h2 = raw.match(/^##\s+(.+)/);
  const h3 = raw.match(/^###\s+(.+)/);
  if (h2) {
    topic = takeTopic(h2[1], topic);
    continue;
  }
  if (h3) {
    topic = takeTopic(h3[1], topic);
    continue;
  }
  const top = raw.match(/^- \*\*(.+?)\*\*:?\s*(.*)$/);
  if (!top) continue;
  pushPhrase(topic, top[1], top[2], false);
}

topic = "Stories and sentences";
const essayAt = md.indexOf("## A short essay");
const storyAt = md.indexOf("## A bedtime story: the spider");
const fromStory = essayAt >= 0 ? essayAt : storyAt;
if (fromStory >= 0) {
  for (const raw of md.slice(fromStory).split("\n")) {
    const h2 = raw.match(/^##\s+(.+)/);
    if (h2) {
      topic = "Stories and sentences";
      continue;
    }
    const top = raw.match(/^- \*\*(.+?)\*\*:?\s*(.*)$/);
    if (!top) continue;
    const tbl = clean(top[1]);
    const en = tidyEnglish(top[2]);
    if (!en) continue;
    const sentence = /\s/.test(tbl) || /[.!?]$/.test(tbl);
    if (!sentence) continue;
    if (/essay|scored/i.test(tbl) && !/[àáèéêìíòóôùú’]/i.test(tbl)) continue;
    pushPhrase("Stories and sentences", tbl, en, false);
  }
}

function parseGuide(chunk, fallbackTitle) {
  const sections = [];
  let title = fallbackTitle;
  let blocks = [];
  const flush = () => {
    if (blocks.length) sections.push({ title, blocks });
    blocks = [];
  };
  for (const raw of chunk.split("\n")) {
    const line = raw.trim();
    if (!line || line.startsWith("|") || line.startsWith("---")) continue;
    const h2 = line.match(/^##\s+(.+)/);
    const h3 = line.match(/^###\s+(.+)/);
    if (h2 || h3) {
      flush();
      title = (h3 ?? h2)[1].replace(/\*\*/g, "").trim();
      continue;
    }
    const bullet = line.match(/^- (.+)/);
    const text = (bullet ? bullet[1] : line).replace(/\*\*/g, "");
    blocks.push({ kind: bullet ? "li" : "p", text: clean(text) });
  }
  flush();
  return sections;
}

const guide = [
  ...parseGuide(
    sliceBetween("## Translation guide for AI (read this first)", "## Pronunciation"),
    "How to translate",
  ),
  ...parseGuide(sliceBetween("## Pronunciation", "## Grammar"), "Pronunciation"),
  ...parseGuide(sliceBetween("## Grammar", "## Dictionary: T'boli to English"), "Grammar"),
  ...parseGuide(md.slice(md.indexOf("## Bible verses")), "Bible verses"),
];

const out = { entries, index, phrases, guide };
writeFileSync(
  new URL("../src/data/dictionary.json", import.meta.url),
  JSON.stringify(out),
);
console.log(
  JSON.stringify({
    entries: entries.length,
    forms: entries.reduce((n, e) => n + e.forms.length, 0),
    examples: entries.reduce((n, e) => n + e.examples.length, 0),
    index: index.length,
    phrases: phrases.length,
    guide: guide.length,
    bytes: Buffer.byteLength(JSON.stringify(out)),
  }),
);
