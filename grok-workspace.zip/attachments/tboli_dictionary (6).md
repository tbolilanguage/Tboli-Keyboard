# T'boli to English dictionary

A dictionary and grammar guide for T'boli, the language of the T'boli people of South Cotabato, Mindanao. Every word, rule and example here was taught by native speaker Deymar, one lesson at a time, and sorted from the original lesson log into dictionary form. Nothing has been added from outside sources except the two Bible verses, which come from the T'boli Bible.

## About Deymar

This dictionary is credited to Deymar, a native T'boli and native speaker of the language. Every word, rule and example in it comes from him.

He started it so future generations of T'boli can use it and translate between English and T'boli. As the modern world moves in, he doesn't want the T'boli language to fade or disappear, so he's writing it down while it's still spoken every day.

Outside T'boli, Deymar studies other languages for fun, including Spanish, Arabic, Bangla, Hindi, and Malayalam.

### In T'boli

- **Deymar yó tau T'boli, omin udél T'boli udélen.** Deymar is a T'boli person, and T'boli is his language.
- **Kdéen udél ni, tnolok Deymar.** Every word here was taught by Deymar.
- **Nóyóen anì kem ngà T'boli kdeng translate-le udél English bê udél T'boli.** He wants T'boli children in the future to translate English into T'boli.
- **Là nóyóen du ke lana udél T'boli bê benwu ni.** He doesn't want the T'boli language to disappear from this world.
- **Dumu udél gel hnagì Deymar: Spanish, Arabic, Bangla, Hindi, omin Malayalam, fun néen.** Other languages Deymar studies: Spanish, Arabic, Bangla, Hindi, and Malayalam, for fun.

### In Bible T'boli (graded perfect by Deymar, Oct 13)

- **Deymar ni, sotu tau T'boli, ne yóm udél T'boli yó, udélen.** This Deymar is a T'boli person, and the T'boli language is his language.
- **Yó kem kdéen udél bè ni, tnolok Deymar.** All the words here were taught by Deymar.
- **Nóyóen anì yó kem ngà T'boli tmulón yóm lan yó kem udél English bè udél T'boli.** He wants the T'boli children to tell the meaning of English words in T'boli.
- **Abay se là nóyóen du ke lana yóm udél T'boli bè klamangen benwu.** Because he does not want the T'boli language to disappear from all the world.
- **Tódô hnagìen snéen yó kem dumu udél: udél Kestilà, Arabic, Bangla, Hindi, ne Malayalam, abay se kehligalen.** He also studies other languages: Spanish, Arabic, Bangla, Hindi and Malayalam, because they are his joy.

### In traditional T'boli (graded perfect by Deymar, Oct 13)

- **Deymar tau T'boli, udél T'boli udélen.** Deymar is a T'boli person; T'boli is his language.
- **Kdéen udél ni, tnolok Deymar.** Every word here, Deymar taught.
- **Nóyóen anì kem ngà T'boli tmulón lan udél English bê udél T'boli kdeng.** He wants T'boli kids to tell the meaning of English in T'boli, later on.
- **Là nóyóen ke lana udél T'boli bê benwu ni.** He doesn't want T'boli gone from this world.
- **Dumu udél hnagì Deymar: udél Kestilà, Arabic, Bangla, Hindi, Malayalam, kay hligal du.** Other languages Deymar learns: Spanish, Arabic, Bangla, Hindi, Malayalam, because they make him happy.

Note: **udél Kestilà** is Spanish, from Romans 15:24, where Spain is **Spén** and the Spanish people are **Kestilà** (from Castilla). Bible style adds yóm, yó kem, Tódô and abay se; traditional style drops English borrowings like translate and fun.

How to use it: the grammar section explains how words are built, the dictionary lists T'boli words A to Z with every form under its root, the English index lets you look a word up from English, and the phrase section collects ready sentences by topic.

## Translation guide for AI (read this first)

This section is for any AI or person using this dictionary to translate English into T'boli. Everything below it is the full word list and the grammar it comes from.

### Instructions

- Translate the meaning, not word by word. Build each sentence from the rules below and copy the patterns in the example pairs.
- Use only the words in this dictionary. If a word you need isn't here, keep it in English inside [brackets] and say it's missing. Don't guess, and don't swap in Tagalog or another language unless this dictionary lists it as a borrowing.
- English words can be borrowed with T'boli endings (rule 12).
- If a sentence could mean two things, give both and say which situation each one fits.
- Keep the spelling and accent marks exactly as written here. The accents change the meaning (hnóbô is getting angry, hnobò is bladder).

### Core rules

1. **Word order.** The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now). Whatever comes first is the focus: Miles ninumen él (Miles drank the water), Él ninum Miles (the water Miles drank).
2. **Who: endings on the word.** I: -u or -e (Kenu, I eat; Nóyóu, I want; Bitile, I'm hungry; Denge, I'm done). You (one): -em, sometimes -u (Kenem, you eat; Bitilu, you're hungry). Formal you: -i (Dengi). He/she/it: -en (Kenen). They: -le. You all: -ye. We all: -kuy. You and me: -te. We but not you: me. Since -u can mean I or you, add the standalone word when it matters.
3. **Standalone pronouns.** O/Ou (me), U/Uu (you), Yu (you all), Du (him/her/it), Lu (them), Tu (us), Te (you and me), Mi (us, not you). Put them after the action to make it clear: Minume o él (I'm drinking water), Minume mi él (we're drinking water).
4. **No word for "is" when describing.** Coffee-hu kinì (my coffee is hot). Se is used for how someone is: Kmoem se du? (how are you?). Nô is the "is" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table).
5. **Very.** Tey/Téy takes the person ending: Teye bitil (I'm very hungry), Téyu temngón (you're very smart). Alì is extremely.
6. **Action shapes on one root.** Root alone is general (ken, eat). M inside or me- in front is happening or about to happen (meken, kmulón, tmolok). N inside is being done or ongoing with an ending (tnolok, t'nilówem). G- in front is by accident (gkulóne, I accidentally got rained on). S- in front is each other (ston, see each other), and sense- is together and still going (senseken). H- or het- in front is make it or let someone (hkinì, make hot; hetnaw, make cold). Hef- is asking someone to do it with your own thing (hefkodok).
7. **Time.** Deng is done or already: Deng kenu (I ate), Denge meken (I already ate). Ne is now, already, or about to: Ne meken dé (I'm going to eat). Nehe (I will), Nehi (you will), Nele (they will). Bud in front is again: Bud kmulón (it'll rain again). Kdeng at the end is later. He at the end adds "yet" or "again, hopefully". Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday). Leave out kdeng when another word already says when.
8. **Not.** Là with the person: Làe or Là e (I'm not), Làu (you're not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't). Là e deng meken he (I haven't eaten yet). Bê is don't, or refusing: Bê tagad tungô he (don't sleep yet).
9. **Questions.** The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón (when), Moen (why). For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?).
10. **Owning.** The owner word goes before the thing: do (mine), kóm (yours), kun (his/hers/its), kul (theirs), kut (ours, you and me), kum (ours, 3 or more): Yó kóm ken, ni do ken (that's your food, this is my food). Dou dumu sbót (my friend). Body parts take -hu for my: matahu (my eyes), kuluhu (my head).
11. **Places.** Bê covers in, on, at, to, under and beside. Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Bê also goes before a day: bê Byérnis (on Friday).
12. **Borrowed English words.** The ending copies the word's last consonant sound: phone-nu (my phone), update-tu (I update), vitamin-nu (my vitamin). A word ending in a vowel sound takes an h: coffee-hu (my coffee). Endings that start with a consonant attach as they are: movie-le (their movie). Ke- means if or for doing it: Slamat bê ke-sendem du (thanks for sending it).
13. **Joining words.** Omin (and), okóm (but), kay (because), kayà (so, that's why), anì (so that), ke or sok (if, when). Kay, ke and sok take the person ending themselves: Kaye bitil (because I'm hungry), Kehu bitil (if you're hungry), Soke bitil (when I'm hungry).
14. **Three kinds of "we".** Te is you and me, kuy is all of us, me (or mi) is us but not you. Use me when telling a story, since the listener isn't part of it.
15. **Sound rules.** An accented final vowel (silà, ngà) ends in a full stop and takes an ending with no h, losing its accent (silaem, ngaen). A plain final vowel takes h before the ending (nawa, nawahu). Any accent mark on the final vowel (à, ì, ó, ô, é, ê) means no h: nóyóem, tungóe. When an ending attaches, Ô becomes Ó and Ê becomes É, but they sound the same as before: tungô + -e = tungóe, kê (poop) + -en = kéen (its poop). Every other accent drops: silà + -en = silaen (his corn), still said [see-lah-uhn] (Deymar, Oct 15). A separate ending word like le never merges with a full stop word: silà le, never silale.

### How a sentence breaks down

- **Hkodoke béléem itlug** (I'll boil an egg for you): hkodok (boil it) + -e (I), béléem (for you), itlug (egg)
- **Là e deng meken he** (I haven't eaten yet): là e (I'm not), deng (done), meken (eating), he (yet)
- **Kehe bitil, ne meken dé** (if I'm hungry, I'll eat): ke + -he (if I), bitil (hungry), ne meken dé (I'm going to eat)
- **Haya bud te ston he** (see you again tomorrow, hopefully): haya (tomorrow), bud (again), te (you and me), ston (see each other), he (hopefully)

### Example pairs

**Greetings and small talk**

- Good morning: **Hyu hlafus**
- Good morning to you too: **Hyu hlafus béléem skóm**
- Good night: **Hyu kifu**
- What's up?: **Syó du?**
- How are you?: **Kmoem se du?**
- I'm fine: **Ok ye néen**
- And you?: **Kóm du?**
- What's your name?: **Bon boluyem (du)?**
- My name is Miles: **Boluyu Miles**
- What are you doing?: **Bon nmoem (du)?**
- Nothing, just sitting: **Anduen. Len myón.**
- Where are you from?: **Bê du góem lemwót du?**
- Where are you going?: **Góem gów (du)?**
- Is that right?: **Tahu kô?**
- Yes, that's true: **Ell, tahu yó**
- Thank you so much: **Bong slamat**
- Thanks to you: **Slamat béléem**
- You're welcome: **Ominem dé**
- Thanks for teaching me: **Slamat bê ke-teachem do**
- Wait a bit: **Tagad he**
- We'll see each other later: **Bud te ston kdeng**

**Feelings**

- I'm very hungry. And you?: **Teye bitil. Kóm du?**
- I'm very happy: **Teye hligal**
- I'm exhausted: **Teye kapuy**
- I'm sleepy: **Moo ktuku**
- I'm full now: **Besowe ne**
- I'm thirsty, so I'm drinking water: **Meenge, kayà minume o él**
- I'm not scared of spiders: **Là e likô bê wong**
- I'm just joking: **Olohu hlowon néen**
- I don't want to sleep because I'm hungry: **Là nóyóu du tungô, kaye bitil** (du points to the subject, the sleeping)

**Food**

- Let's eat: **Meken kuy**
- If you're hungry, eat: **Kehu bitil, mekenu**
- I ate: **Deng kenu**
- I already ate: **Denge meken**
- I'll eat first: **Ne meken dé anay**
- When I'm hungry, I fry leftover rice: **Soke bitil, senlahu ken tnaw**
- This food is delicious: **Téy mi ken ni**
- That's your food, this is my food: **Yó kóm ken, ni do ken**
- The rice is already cooked: **Deng tógó ne ken**
- My coffee is hot: **Coffee-hu kinì**
- My coffee is on the table: **Coffee-hu nô bê ta lmisa**
- I'm full now. That fish was really tasty!: **Besowe ne. Utón nìen, téy mnóm!**

**Weather and time**

- Is it raining?: **Kmulón ni?**
- It's raining now. You'll be cold: **Kmulón ne. Tnawu yó.**
- Tomorrow it'll rain again: **Haya, bud kmulón**
- Yesterday was extremely hot, but today is very cold: **Ekimel alì kinì, okóm kdaw ni téy tnaw**
- Next week, on Friday, I'll go to the water: **Todol fedyan, bê Byérnis, nehe gów bê él.**
- What's the date today?: **Bon kdaw du ni?**

**People**

- You are my friend: **Uu dou dumu sbót**
- I'm your friend: **Ou kóm dumu sbót**
- I like you: **Nóyóu u**
- I love you: **Kenbong nawahu u**
- I hate you: **Knutó nawahu u**
- I dislike you, I reject you: **Kenbéu u**
- I don't like you: **Là nóyóu kóm** (after là, u for "you" becomes kóm)
- I never liked you: **Là nóyóu kóm se**
- I don't want/like yours: **Là nóyóu du kóm** (du marks the thing, kóm is the owner)
- **Rule after là:** me and you switch to the owner words: o becomes do, u becomes kóm. Se after là means never / at all. When there's a thing, du holds its place, se comes right after du, and the thing is named last.
- He never liked you: **Là nóyóen kóm se**
- I never knew / I don't know at all: **Là t'ngónu du se**
- I don't want to sleep at all: **Là nóyóu du tungô se**
- My dad never listens to me: **Là gungolen do se Pangu**
- I've never seen my cat: **Là tonu du se kuyingu**
- I've never seen a cat: **Làe deng mton kuying se** (làe = I don't, deng = already/ever, mton = seeing; for "never have" the I goes on là, and the action word takes the m form with no ending)
- I've never eaten fish: **Làe deng meken utón se**
- How's my dad?: **Kmoen se Pangu?**
- I've never seen a dog: **Làe deng mton ohu se**
- He never liked me: **Là nóyóen do se**
- I've never cooked fish: **Làe deng tmógó utón se**
- **Four ways with gungol (hear/listen):**
  - Là gungolem do se: you can't even hear me (plain form)
  - Là nungolem do se: you didn't even listen to me (g becomes n: done, past)
  - Là gegungolem do se: you couldn't even hear me (doubled ge-)
  - Làu kô mungol se: you never listened at all ("you" moves onto là, g becomes m, no ending, no "me")
- **Kô after là = never.** Làu kô + m form + se: you never (no ending, no "me"). Làe kô, làen kô work the same. To keep "me" in, use plain Là kô with the ending on the action word.
  - You never eat fish: **Làu kô meken utón se**
  - You never sleep: **Làu kô tungô se**
  - I never eat: **Làe kô meken se**
  - He never cooks: **Làen kô tmógó se**
  - You never see me: **Là kô tonem do se** (not Làu kô mton do se)
  - You can't even see me: **Là tonem do se**
  - I never get seen / nobody notices me: **Làe kô gton se**
  - I never show up: **Làe kô gfan se**
  - I can't even be seen: **Làe gegton se**
  - G- forms act like m forms here: the person goes on là, the action word takes no ending
- **New words:**
  - **móyô**: want, eager (Móyô me bud hmungol du: we want to hear it again)
  - **huluk**: show up without others knowing, drop in unannounced
  - **tehe**: used to be, formerly (yóm lóbô tehe mowil: the beast that was alive)
  - **klawi**: time, period (klawihen: its time)
  - **kni**: back then
  - **kat kô**: how, so (exclamation)
  - **kodun**: pitiful, "nakakaawa". Kodunu (I'm pitiful), Kodunem (you're pitiful), Kodunen (he/she/it's pitiful), Kodun le (they're pitiful), Téy kodunem (you're really pitiful: the ending goes on kodun, not on téy)
  - **ngau**: my child, my children (ngà + -u; the accent drops)
  - **Téyu wélkam**: you're very welcome (wélkam borrowed from English). **Wélkamu**: you're welcome (-u = you, like bitilu)
  - **hlosok**: fallen (done form of mosok). **ebéléu**: from me. **lembés**: more than, beyond. **anien**: even though
  - Deymar's poems (Oct 13):
    - Kem blotik sok kifu tey knóón: the stars at night, so beautiful
    - Él kulón deng le hlosok ne ta tonok, dalang se yóm dou lewok, mosok: the rain has already fallen to the earth, and so have my tears, falling
    - Hnangatu uu, abay se tek sotu lówóhu ke sok kifu: I've been waiting for you, because I'm all alone at night
    - Là móyô klifótu kóm se, anien kehu mayuk ebéléu: I never want to forget you, even when you're far from me
    - Tey nóyóu yóm mohin, okóm yóm dou kekbong nawa kóm tey lembés bê yó he: I love the sea, but my love for you goes far beyond it
  - English poems built into T'boli (Oct 13):
    - Él mlel mógów bê mohin, ne hosòhu mógów béléem: the river runs to the sea, and my heart runs to you
    - Kem blotik nangat le kekifuhen, dalang se kekangatu kóm: the stars wait for the night, the way I wait for you (nangat, n-form of hangat; kekifuhen = ke (if) + kifu (dark) + h + -en (it): when it turns dark; ke- form after dalang se; kóm for "you" as the one waited for)
    - Anien ke klifót bulón kifu, là kô klifótu kóm se: even if the moon forgets the night, I'll never forget you
- **Sentences:**
  - I don't want to keep showing up empty-handed like this: **Lae móyô gel huluk hkawang ni dou**
  - Back in those days, everyone at home was so happy. Not anymore: **Yóm hanà tehe klawihen kni, tey alì ligal kem tau bê gónô. Là ne ni**
  - If only it were like the way you used to love me back then: **Ke lómón yóm tehe kekbong nawahem dou du kni**
  - I'm the eighth one: **Ou gwoluhen yó**
  - Big fire! It's so hot: **Ofi bong! Kat kô alì kinì**
  - We're dirt poor right now. My poor kids: **Glayam bong ni du. Kodun le kem ngau** (glayam = poor, poverty; bong = big; ni = right now; du = the subject, which here is glayam itself. Literally "the poverty is big right now")
- **Là deng**: not yet (deng = already, done)
- I haven't eaten yet: **Làe deng meken** (add se at the end and it becomes never)
- Who's that?: **Tadu yó?**
- That's him / that's us / that's them: **Du yó / Tu yó / Lu yó**
- It's our turn: **Tu ne ni**
- It's not me: **Là o du se**
- I didn't do that: **Là o du mò du yó**
- When will you get back home?: **Kilón ke kulékem bê gónô?**
- Why aren't you sleepy yet?: **Moen ke là u gtungô du?**
- Are you going to sleep?: **Tungóu ne yó?**
- Are you resting?: **Hegnô u?**
- I just woke up: **Lomihe btik** (right now). **Lomi kebtiku**: I woke up a while ago
- I just woke up, so I'm not going back to sleep: **Lomi kebtiku kayà là e bud tungô ne là**
- It's time to get up (everyday): **Udas kebtik kuy ne**
- Where's my phone?: **Góen nô phone-nu (du)?**
- Today, Deymar, you taught me and I taught you. We're teaching each other: **Kdaw ni, Deymar. Tnolokem o, omin tnoloku u. Stolok te.**

## The T'boli alphabet

### Vowels and marks

A, À, E, È, É, Ê, I, Ì, O, Ò, Ó, Ô, U, Ù, and ’ (the glottal mark, as in T'boli, K'nôón)

### Letters

B, D, E, F, G, H, I, K, L, M, N, O, P, R, S, T, U, W, Y

### Borrowed words and names

- **Borrowed words keep their own spelling,** even with letters T'boli doesn't have. Péro (but, from Spanish) stays Péro, not Féro
- **Country names are written with T'boli letters**
- **Ph is always F:** Alfabét (alphabet), Farmasi (pharmacy), Filipinas (Philippines), Faro (Pharaoh), Stéfén (Stephen)
- **P in names:** traditional T'boli uses F where English has P, so older people say Fól for Paul. The Bible mostly keeps P (Pol, Pitér) because its names came through English. It goes word by word: Faris (Paris), Fkistan (Pakistan), Fortugal (Portugal), but Péru (Peru)

### Ng

Ng can be counted as its own letter or as N plus G. Both work. It's there for the sound, as in ngà and t'ngón.

## Pronunciation

Sounds like: every T'boli headword in the dictionary has a sound-it-out spelling in square brackets after it, like **kekifuhen** [kuh-kee-foo-hun]. Hyphens split the syllables; uh is the burn E, eh is the egg É, aw is the law O, o is the obvious Ó, ee is I, oo is U, ah is A, ow is the ow in now; an apostrophe after a vowel is a full stop (silà [see-lah']), and between two consonants it's the quick dropped uh (tnaw [t'now]).

### Vowels

- **E** [uh]: like the u in burn (Ken, Teye, Ell)
- **The burn E can drop out in spelling**: it's just a quick "uh," so writing it or leaving it out sounds the same. This works everywhere: Melóy = Mlóy (run), Meken = Mken (eating), kekifuhen = kkifuhen (confirmed Oct 14)
- **É** [eh]: like the e in egg (néen)
- **Ê** [eh']: the egg É, but cut off with a full stop (bê, dê, yê)
- **È** [uh']: the burn E, but cut off with a full stop (bè)
- **O**: like the a in law
- **Ò**: like the a in law, but cut off with a full stop
- **Ó**: like the o in obvious
- **Ô**: like the o in obvious, but cut off with a full stop
- **An accent on a final vowel** (silà, ngà): the word ends in a full stop (see the sound rules)

### Words that are easy to get wrong

- **Ell** (yes): said like "Ull", the E is the u in burn
- **Fun** (owner): the u sounds like the u in uniform, not like "fan"
- **Ken** (food): the E is the u in burn, not like Kentucky
- **Ken tnaw**: Ken with the u in burn, tnaw like "T'NOW" (the ow in now, with the W said at the end like the w in win)
- **Accents change meaning.** Hnóbô is getting angry, hnobò is bladder. Moen is why, Móen is short for Kmoem. Geslà is a surprise, gesla is being fried. Silà is corn, and silale would lose that meaning.
- **Lemnaw is a root word of its own, with no M added.** It means green, vegetables, herbs, and ulam (the dish you eat with rice). In the Bible, *"som lemnaw ye"* is "your herbs" (Matthew 23:23), and *"sminang lemnaw"* is the green shine of emerald (Revelation 4:3)
- **Msó** is the fast way to say mesó (rice).
- **Mestlu** is how maistru (teacher) is actually said.

## Grammar

### Word order

- The root word carries the meaning, and endings say who.
- The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now).
- The main idea comes first: Meken kuy, Tahu kô ni.
- Whoever or whatever comes first is the focus. Miles ninumen él (Miles drank the water) puts Miles first. Él ninum Miles (the water being drunk by Miles) puts the water first. Él ninumen Miles means the water drank Miles, because -en makes the water the one drinking.
- Word order can change the meaning: Kmoem se du is "how are you", Kmoem du se is "what did you do".
- When "it" does something to a person, the -en ending is the "it" and the person comes after: Hetnawen u yó (it'll make you cold).
- "More" comes after the thing: unged wen, more muscle.
- A color goes before mata: utón hulô mata (red-eye fish).
- With names, the names come first, then sbót le: Miles omin Deymar sbót le (Miles and Deymar are friends).
- Ni and yó point ("this" and "that"), and kô turns a statement into a question.

### No "is" when describing

- Describing something needs no "is" at all: Coffee-hu kinì (my coffee is hot).
- **Se** is the "be" word for how someone is, and it goes in the middle: Kmoem se du? (how are you?).
- **Nô** is the "is" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table). Without nô, Coffee-hu bê ta lmisa is just "my coffee on the table".

### Person endings

These attach to a word to say who.

- **-u**: often "you" (Gówu, you go; Tungóu, you sleep; Mekenu, you're eating or "eat!"; Bitilu, you're hungry). In some words it means "I" (Kenu, I eat; Nóyóu, I want; Tnoloku, I teach). Since -u can mean either, add the standalone word when it matters.
- **-e**: I (Bitile, I'm hungry; Denge, I'm done; Mekene, I'm eating; Teye, I'm very). Bitile can also mean "they're hungry"; Bitile lu is clearer for them.
- **-em**: you (one person) (Kenem, you eat)
- **-i**: the formal "you", more specific than -u (Dengi, you're done; Kehi, you become; Lài, you are not)
- **-en**: him, her, it (Kenen, he/she/it eats)
- **-le**: them, not including the person you're talking to (Kenle, they eat)
- **-ye**: you all, the people you're talking to, speaker not included (Kenye)
- **-kuy**: we, us, 3 or more people (Kenkuy)
- **-te**: us two, just you and me (Kente)
- **me**: we, without the person you're talking to (Deng me, Kmò me du)
- **-hu**: my, on words that end in a plain vowel and on body parts (nawahu, matahu, kuluhu, lówóhu, coffee-hu). Tnoloku takes -u, not -hu.

The ending can jump forward to an earlier word: Kaye bitil (because I'm hungry) instead of Kay bitile. Same with Anìe (so I), and Kehu bitil (if you're hungry) instead of Ke bitilu.

When an ending could mean two people (minume, I or we), add the standalone word: minume o (I), minume mi (we).

#### Second set, with Tey and Meken

- **Teye**: I am very
- **Téyu**: you are very
- **Téy-**: he/she/it is very
- **Téyle**: they are very
- **Téyye**: you all are very
- **Téykuy**: we are very
- **Téyte**: we (you and I) are very
- **Mekene**: I am eating
- **Mekenu**: you are eating, also "eat!" when telling someone to eat
- **Meken du**: he/she/it is eating

### Standalone pronouns

- **O / Ou**: me, I. Ou is specifically me, pointing at yourself.
- **U / Uu**: you (one person). Uu is specifically you.
- **Yu**: you (2 or more people)
- **Du**: him, her, it (used everywhere for he/she/it). It also points back at whatever the subject already is: in Kmoem du, du points at -em (you); in Glayam bong ni du, du points at glayam (the poverty). But after an action word (want, know, flash), du is the one it's done to: Nóyóu du tungô = I want him/her/it to sleep; T'ngónem du? = do you know him/her/it?; Snolokem du = flash him. So: I want to sleep is just Nóyóu tungô, and do you know? has no du. Context decides: when the talk is already about sleep, Là nóyóu du tungô means I don't want to sleep, with du pointing at the sleep. If the talk is about someone else, du becomes that person. A du right after nóyóu points at the action itself, so the thing it's done to needs a second du at the end: Là nóyóu du meken (I don't want to eat), Là nóyóu du meken du (I don't want to eat it). With du pointing back, Coffee-hu. Kinì bong ni du splits into two: My coffee. It's very hot. Plain Coffee-hu kinì is one sentence: my coffee is hot. The du right after nóyóu only comes with Là in front: Nóyóu meken du ni (I want to eat this) vs Là nóyóu du meken du yó (I don't want to eat that). Ni = this, something you're holding or that's in front of you; yó = that, farther away. Sotu nien = this one (Là nóyóu du yó, okóm nóyóu du ni sotu nien: I don't want that one, but I want this one)
- **Love, for things vs living things:** for things, use nóyô: Tey nóyóu ni kgal ni (I love this shirt). For living things, use kenbong nawa: Kenbong nawahu du ni wong ni (I love this spider), Kenbong nawahu ni du (I love this one, like a cat). Du points to the one being loved. New words: **kgal** = shirt, **wong** = spider
- **Lu**: them
- **Tu**: us
- **Te**: me and you
- **Mi**: us, I'm included but not the person I'm talking to
- **Do**: me, when I'm the one something happens to (from dou): Ktolok le do (they taught me)

With yó: **O yó** (that's me), **Ou yó** (that's me, specifically me), **U yó** (that's you), **Uu yó** (that's you, specifically you), **Du yó** (that's him), **Tu yó** (that's us), **Lu yó** (that's them).

### Three kinds of "we"

- **Te**: you and me (Stolok te, we teach each other, like Tagalog "tayo")
- **Kuy**: all of us, 3 or more
- **Me / Mi**: us but not you (Stolok me, like Tagalog "kami"; Mi kem mag-cousin, us cousins, not counting you)

Use me when telling a story, since the listener isn't part of it: Tmógó me utón (we're cooking fish, not you). Never tmógó mi utón. Me works everywhere kuy does: Kmò me du.

### Owning

The owner word goes before the thing: Yó kóm ken, ni do ken (that's your food, this is my food).

- **Do**: mine
- **Dou**: I own, my (Uu dou dumu sbót, you are my friend)
- **Kóm**: you own, yours
- **Kun**: he/she/it owns
- **Kul**: they own, theirs
- **Kum**: we (3 or more) own
- **Kut**: we (me and you) own, ours
- **Do u ni**: this is mine

Body parts and vowel-final words take -hu for "my": kuluhu (my head), matahu (my eyes), lówóhu (my body), nawahu (my breath).

Dumuhu sbót and dou dumu sbót both mean "my friend". Use dumuhu sbót when telling someone else about the friendship (he's my friend). Use dou dumu sbót when talking to the friend directly (Uu dou dumu sbót, you're my friend).

### Pointing words

- **Ni**: it, this; here's (Ni ken para béléem, here's food for you). At the end of a sentence it points to something right here. Ni is also right now, while ne is already.
- **Yó**: that
- **Nìen**: this one, it (ni plus -en, pointing at the subject): Utón nìen, téy mnóm!
- **Yóm**: the
- **Tu**: far, there (see the dictionary entry)

### Action shapes

One root changes shape to show how an action happens.

- **Root alone**: general (ken, eat; tolok, teach; kodok, boil)
- **M inside, or me- in front**: happening or about to happen, like "-ing" (meken, kmulón, tmolok, lmobun, kminì, kmodok)
- **N inside**: being done, already done, or ongoing (tnolok, being taught; nsef, sucked; t'nilówem). With person endings the m becomes n (t'milów, t'nilówem). Kenbong (with -n-) is already happening, continuously, while kbong is still going.
- **Suggesting vs commanding**: -u suggests (Mekenu, go ahead and eat). -em with kun commands (Snolokem du kun, flash him!)
- **Careful with bê u**: it means "don't you," not "onto you." Onto you is ebéléem
- **Hyphen rule**: when n meets g across parts of a word, write a hyphen (Hen-ganagem) so it's said n + g, not the ng in mango
- **G- in front**: by accident, without meaning it (gkulóne, I accidentally got rained on; gtolok, taught unexpectedly; gwa, accidentally taken; gsalig, unintentionally trust; gtungô, sleepy)
- **S- in front**: each other (ston, see each other; stolok, teach each other; swa, taking from each other; stóbóng, helping each other)
- **Doubled first letter**: both or together doing it (ssef, both sucking; kken, ate together)
- **Kk- spelling**: kk- and ke- are the same, said the same way, just spelled differently (kkifuhen = kekifuhen). Context tells you whether it means "together" or the ke- form. Confirmed Oct 14
- **Sense- in front**: together and still going (senseken, eating together; sensesef). It doesn't work on every verb: stowok, not sensetowok.
- **H- or het- in front**: make it, or let someone else do it (hkinì, make hot; hetnaw, make cold; hsef, let someone suck; hsalig, let something trust; hetngón, let someone know). Add the person ending for who does it: Hkinìem ken (you heat the food), Hkinìu ken (I heat the food).
- **Hef- in front**: asking someone to do it with your own thing (hefkodok)
- **Putting something in**: N inside an ingredient word, plus -em kun, asks someone to add it to the food (klamay, sugar → Knamayem kun, put sugar in it please; som → Nsomem kun, season it please). With klamay the l drops and becomes n. Confirmed Oct 15
- **K- form**: already carries "will" (kulékem, you'll come back)

Roots that show the whole system:

- **Take**: ma/mwa (take), nwa (taken), gwa (accidentally taken), swa (taking from each other). N- is done, g- is by accident, s- is each other.
- **Boil**: kodok (boil), kmodok (boiling), hkodok (asking for it to be boiled; hkodoku, I'm boiling it), henkodok (being boiled), hefkodok (asking someone to boil something with your item)
- **Teach**: tolok, tmolok, tnolok, gtolok, htolok, stolok

### Time words

Time is shown with small words around the verb, not by changing the verb itself.

- **Deng**: done, already. Deng kenu (I ate), Denge meken (I already ate).
- **Ne**: now, already, a change happening, about to (like Tagalog "na"). Ne meken dé (I'm going to eat).
- **Nehe**: I will, for something you do yourself, with no object (Nehe dyó dé, Nehe bemli anay). **Nehu**: I will do something to something (Nehu bentik u anay, Nehu henken onuku haya), or telling someone else to do it (Nehu meken dé, you eat first). **Nehi**: you will. **Nele**: they will.
- **Bud**: again, in front, for something that will happen. Bud kmulón (it'll rain again).
- **Ne là**: anymore, at the end of a sentence (là e bud tungô ne là, I'm not going back to sleep anymore). At the start, it means "and not, not even": Ton me du eginu okóm làen temngel béléme. Ne làen se mudél béléme. (We saw him earlier but he didn't look at us. And he didn't even talk to us.)
- **Se after là**: "even" (Ne làen se mudél béléme, and he didn't even talk to us)
- **Là + endings**: là e (I don't), làu (you don't), làen (he/she doesn't). Ston te eginu okóm làu temngel béléu: we saw each other earlier but you didn't look at me. Béléu: to me
- **Kdeng**: later, at the end of a sentence. On its own at the start it means "wait!"
- **He**: at the end, adds "yet" or "again, hopefully". Là e deng meken he (I haven't eaten yet). Bud te ston he (we'll see each other again, hopefully).
- Leave out kdeng when another word already says when: Haya bud kmulón, not Haya bud kmulón kdeng.
- **Days**: Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday), Ekuloy (the day before yesterday), Sotu ni (the day after tomorrow).
- **Todol** is next and **gna** is past: todol bulón (next month), gna halay (last year).
- Time words come from nature: kdaw is sun and day, bulón is moon and month, halay is the rice plant and year.

### Not

- **Là** with the person: Làe or Là e (I'm not), Làu or Là u (you're not), Lài (you, one specific person, are not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't), Là ye (you all aren't), Là kuy (we all aren't), Là me (we aren't, not counting you).
- Là e deng meken he: I haven't eaten yet.
- **Bê** is don't, or refusing: Bê tagad tungô he (don't sleep yet). Bê kuy gów bê yó (don't go there).

### Questions

- The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón (when), Moen (why).
- For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?).
- Kilón (when) and Moen (why) stand alone. A ke after them is its own word, not part of the question word: Kilón ke kulékem bê gónô?, Moen ke là u gtungô du?
- Moen (why) is its own word, not Móen (short for Kmoem).
- Use Kmoem when you're asking someone directly, Kmoen when it's indirect.
- Kô ke offers a choice: Mekenu silà kô ke ken? (are you eating corn or rice?)

### Places

- **Bê** covers every location: on, in, at, to, above, under, beside. The context tells you which.
- Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Kuying bê ta lmisa (the cat is on the table).
- Bê also goes in front of a day: bê Byérnis (on Friday).
- **Nô** is the "is" for where something is.

### Sound rules
- **S- + h becomes sf-**: the h turns into f after the "each other" s-, so it doesn't sound like sh (hangat → sfangat, not shangat)

- **The -h rule**: when a word ends in a plain vowel, add h before the ending: nawa becomes nawahu (my breath), coffee becomes coffee-hu.
- **Full stop vowels**: an accent on a final vowel (silà, ngà) means a full stop at the end of the word, so it takes an ending without h, and the accent goes away when the ending is attached: silà, silaem (your corn); ngà, ngaen (his/her child).
- **Separate ending words never merge**: a separate ending word like le never merges with a full stop word. Silà le, never silale, because losing the accent takes away the word's meaning.

### Joining words

- **Omin**: and
- **Okóm**: but (Okóm close, but close)
- **Péro**: but (borrowed from Spanish)
- **Kay**: because. Takes the person ending: Kaye bitil (because I'm hungry).
- **Kayà**: so, that's why (borrowed from Tagalog)
- **Anì**: so, so that. Anìe (so I).
- **Ke / Sok**: if, when. Both take the person ending: Kehu bitil (if you're hungry), Soke bitil (when I'm hungry).
- **Dé kô**: maybe, perhaps, I guess so; if (something happens), depending on context
- **O**: or (borrowed from English)
- **Kô ke**: or, when suggesting someone pick one
- **Ewen**: so
- **Galì**: oh, so that's why

### Borrowed words

English words follow their sound, not their spelling. The ending copies the last consonant sound of the word, so update (ends in a t sound) becomes update-tu, update-tem, update-ten, and phone becomes phone-nu, not phoneu. When the spelling already ends in that consonant, the ending can attach directly or with a doubled letter and hyphen. The hyphen keeps the English word recognizable.

- **Chatu / Chat-tu**: I chat
- **Vitaminu / Vitamin-nu**: my vitamin
- **Phone-nu**: my phone
- **Slippersu**: my slippers
- **Update-tu**: I update. **Ke-update tu** also works, with the ending standing alone. **Update-le**: they update (endings that start with a consonant attach as they are).
- **Coffee-hu**: my coffee (words that really end in a vowel sound take h)
- **Movie-le**: their movie (consonant endings need no h)
- **Downloadem**: you download. **Downloaden**: he/she/it downloads.
- **Ke-**: if, or for doing it: Ke-savem (if you save, for saving), Ke-downloadem (if you download).

Other borrowings:

- **From Spanish**: the days of the week, the trading numbers, para (for), péro (but), maistru/mestlu (teacher)
- **From Tagalog**: kayà (so, that's why), kailangan (need)
- **From Hiligaynon**: anay (first, for now), aslum (sour), kahang (spicy)
- **From English**: o (or), tisting (tasting), and any English word with T'boli endings
- Akad (Sunday) may come from Malay or Arabic "Ahad" instead of Spanish.

### Ke- after kilón and tey
- After **kilón** (when) and **tey** (very), the m-form of an action becomes a **ke-** form: kmóót turns into kekóót, meken turns into keken, kbong turns into kekbong.
  - Kilón kekóót mósól du? When does the rooster crow?
  - Kilón kekenen du? When will he eat?
  - Kilón kekenem du? When will you eat? (du goes at the end for the subject)
  - Tey kekbong nawahu du ohu. I really love dogs.

### Ke, bê and para bê

- **Ke**: to, for, or, and possession. Ke Dwata: to God, or God's. Ke Dwata yó: that's God's. Ke Miles: or Miles, Miles' belongings, or for Miles.
- **Bê**: to. Bê Miles: to Miles.
- **Para bê**: for something or someone, being given to them. Ken para bê kem ngà: food for the children. Ke is for when it belongs to them.

## Modern words: traditional, Bible, standard

Standard means the English word written in T'boli letters. A dash means there isn't one, or it isn't in the Bible. Confirmed by Deymar, Oct 15.

| English | Traditional | Bible | Standard |
|---|---|---|---|
| picture, photo | kudak | – | – |
| image, likeness | tulad | tulad (Matthew 22:20) | – |
| camera | kudak | – | kmera |
| video | – | – | widyu / bidyu / bidju |
| ingredients | som | – | – |
| tune, tone | utóm | utóm (pray, chant) | – |
| sound, music | snata | – | – |
| call | taba | tnaba (1 Corinthians 1:2) | – |
| message, text | udél | udél | méséj, téks |
| electricity | ofi (fire) | – | kurinti |
| magic power | imò | imò (Galatians 5:20) | – |
| brownout | – | – | branawt, brownout |
| car, truck | – | – | tdak / trak |
| motorcycle | – | – | mótól |
| school | gónô mnagì | mnagì, study (John 7:15) | – |
| store | tindà | tindà (Matthew 25:9) | – |
| TV | – | – | tilibisyun, TB |
| radio | – | – | radyu |
| clock | udasan / urasan | – | – |
| hour | uras / udas | uras (Acts 10:3) | – |

## Dictionary: T'boli to English

Words are sorted A to Z, ignoring apostrophes and accent marks. Each root is one entry, with its forms listed under it. Borrowed words are marked.

### A

- **abal** [ah-bahl]: shoulder
- **adat** [ah-daht]: attitude, personality
  - Madat: respect (kóyô me ke kdéen tau hol madat yóm kóm boluy, we want everyone to respect your name, Matthew 6:9)
  - Example: Nehu madat ke Mà (I also respect Father)
  - Nadat: respected
  - Example: Nadaten lu kem tau (he respects the people)
  - Example: Madat du bê kem tau (he shows respect to the people)
  - Example: Nadatu du (I respected him)
  - Example: Tey nadat yóm boluyem (your name is very respected)
  - Example: Kóyô me ke kdéen tau madat ke Dwata (we want everyone to respect God)
- **akad** [ah-kahd]: Sunday (may come from Malay or Arabic "Ahad")
- **alì** [ah-lee']: extremely
  - Alì kinì: extremely hot
  - Example: Ekimel alì kinì, okóm kdaw ni téy tnaw (yesterday was extremely hot, but today is very cold)
- **amil** [ah-meel]: testicles
- **anay** [ah-nai]: first, for now (borrowed from Hiligaynon, same as Tagalog "muna")
  - Example: Ne meken dé anay (I'll eat first)
- **andù** [ahn-doo']: no one; none, there isn't any (short for làen dù). Not the same as **làen ket**, not enough
- **anduen** [ahn-doo-uhn]: nothing
  - Example: Anduen. Len myón. (nothing, just sitting)
- **angkel** [ahng-kuhl]: uncle (borrowed from English)
- **aprikan** [ahp-ree-kahn]: African oil palm (borrowed through Hiligaynon, from "African"). Its fruit, like tiny coconuts, grows tucked in at the klifak
- **anì** [ah-nee']: so, so that
  - Anìe: so I (the ending jumps onto anì)
  - Example: Kailanganu mekay ken. Anìe meken kdeng. (I need to cook rice so I can eat later)
  - Example: Anì le sgeng tmowok (so they grow together)
- **anti** [ahn-tee]: aunt (borrowed from English)
- **ahós** [ah-hos]: garlic (borrowed). Confirmed Oct 15
- **aslum** [ahs-loom]: sour (borrowed from Hiligaynon, used to make it clear something is sour and not salty)
- **atsal** [aht-sahl]: pepper (borrowed, not a T'boli word). Confirmed Oct 15
  - Example: Téy aslum sinigang nìen, okóm téy mnóm (this sinigang is very sour, but tasty)

### B

- **badak** [bah-dahk]: jackfruit. Also **barak**; which one people say depends on the accent
- **bak** [bahk]: mouth, opening (baken, his mouth)
- **bak bengaw** [bahk buh-ngow]: window, the traditional word: the hole or entry in the wall
- **bak tikeb** [bahk tee-kuhb]: door
- **bali** [bah-lee]: fermented, gone sour, leavened. Ken bali: leavened food; ken là balihen: unleavened (1 Corinthians 5:6–8, Galatians 5:9). Not the same as baling (become). Confirmed Oct 15
- **baling** [bah-leeng]: become
  - Example: Nuclear bomb skas (le), baling ofi bong (the nuclear bomb breaks them, and they become a big fire)
- **balu** [bah-loo]: a strand of hair; tornado
  - Mógów baluhen!: (cuss) may his/her/its cursed day come
- **bangkù** [bahng-koo']: seat, bench, chair
- **barak** [bah-rahk]: jackfruit. Also **badak**; which one people say depends on the accent
- **bayad** [bah-yahd]: pay (bnayadu, I pay it; gbayad, able to pay)
- **beeng** [buh-uhng]: molars, jaw (beeng le, gnashing their teeth, Acts 7:54)
- **beng** [buhng]: wall, door; the general word for the cover of a house
- **benwu** [buhn-woo]: town, place, world
- **betek** [buh-tuhk]: color, style, design
- **bintanà** [been-tah-nah']: window (borrowed from Spanish ventana)
- **bkadu** [b'kah-doo]: avocado
- **blà** [blah']: stop (full stop word, so blaem, blau with no h)
  - Blau ne: I should stop. Blaem ne: stop what you're doing
  - **Blaem** [blah-uhm] also means "unfortunately, turns out," when you find out something you didn't expect. It's like okóm (but), only with surprise
  - Tô me meken tfayà, blaem andù bunguhen: we were going to eat papaya, but it turned out it had no fruit
  - Blaem hanà mowil ulal tu kimel: turns out the snake from yesterday was still alive
- **blat** [blaht]: heavy (keblaten, its heaviness)
- **blawang** [blah-wahng]: mosquito
- **blibóy** [blee-boy]: betel nut palm (not in the Bible)
- **blihen** [blee-huhn]: its price
- **bmidyu / b'midyu** [b'meed-yoo]: taking a video, filming (from **widyu**)
  - I'm filming the kids inside the school: **Bmidyuhe kem ngà bè lem gónô mnagì.** (bmidyu ends in a vowel, so h + -e; Deymar, Oct 15)
- **bnidyu / b'nidyu** [b'need-yoo]: being filmed; was filming (from **widyu**)
  - Can you film me?: **Bnidyuhem o kô?** (not Bmidyuhem; Deymar, Oct 15)
  - Can I take a video of you?: **Vnideo-hu u kô?** (English video with the -n- inside, and -hu because it ends in a vowel)
- **bnos** [b'naws]: hide something (bnosu, I hid it). Hebnos: hide yourself. Buni: hidden, secret
- **bok** [bawk]: book (boku, my books)
- **branawt** [brah-nowt]: brownout, power outage. The English spelling **brownout** works too
- **bratu** [brah-too]: cheap (borrowed from Spanish barato)
- **btik** [b'teek]: wake up, get up (Lomihe btik, I just woke up)
- **btiki** [b'tee-kee]: wake up! / get up! (to one person)
- **bulung** [boo-loong]: medicine (bulung mata, eye medicine; hbulung, being treated)
  - Bulung henok: yeast, literally "medicine to make it grow" (Matthew 13:33, Luke 13:21). Confirmed Oct 15
- **bê** [beh']: one word for any place: to, at, on, in, under, above, below, beside. Also don't, no (refusing or declining), and of.
  - Bê ta: on top of
  - Bê laan: underneath (something)
  - Bê lem: inside
  - Bê lohok: beside
  - Bê Byérnis: on Friday (bê goes in front of a day)
  - Bê Miles: to Miles
  - (Bê) yó: there
  - Bê du?: to, on, in, or at where?
  - Bê?: where? (depends on context)
  - Skél bê: the same as, like
  - Para bê: for (see para)
  - Bê e dou tungô: I'm not sleeping yet
  - Example: Bê tagad tungô he (don't sleep yet)
  - Example: Là! Bê kuy gów bê yó. (No! Don't go there.)
- **bé** [beh]: grandmother (béhem, your grandmother, 2 Timothy 1:5)
- **béem bayà** [beh-uhm bah-yah']: don't abandon, don't leave (béem bayà mi, don't leave us, Matthew 6:13)
- **beklong** [buhk-lawng]: throat
- **bélé** [beh-leh]: to, for
  - Béléu / Béléeu: for me, to me
  - Béléem: to you, for you
  - Béléen: to him/her/it
  - Béléle: to them
  - Béléye: to you all
  - Bélékuy: to all of us
  - Béléte: to just you and me
  - Para béléem: for you (para makes it clear who it's for)
  - Example: Hkodoke béléem itlug (I'll boil an egg for you)
- **bemli** [buhm-lee]: buy, buying
  - Nehe bemli anay: I will buy first
- **bentik** [buhn-teek]: wake up, wake someone up
  - Nehu bentik u anay: I will wake you up later
  - Nehu bentik dé: just get up already
- **benwu** [buhn-woo]: world, place
  - Gu laanen là deng wen benwu he: before there was any world yet, in the beginning (John 1:1)
- **besow** [buh-saww]: full (from eating)
  - Henok / Besow: full
  - Besowe / Besow: I'm full
  - Denge besow: I'm full (I'm already full)
  - Example: Besowe ne (I'm full now)
- **bew** [buhw]: carabao, water buffalo
- **bitil** [bee-teel]: hungry
  - Bitile: I'm hungry (can also mean "they're hungry")
  - Bitile ah: I'm hungry
  - Bitilu: you're hungry
  - Bitile lu: they're hungry (clearer)
  - Example: Teye bitil. Kóm du? (I'm very hungry. And you?)
- **blay** [blai]: give
  - Ne blay: I will give
  - Example: Haya, ne blay lu bê kem twolihu (tomorrow I'll give them to my siblings)
- **blotik** [blaw-teek]: star
- **blutut** [bloo-toot]: belly, stomach; also womb
- **bnes** [b'nuhs]: grass
- **boi** [baw-ee]: princess (a title)
- **bol** [bawl]: mix (root). Bolen: mixed in with it (Luke 13:21); senboolen: mixed together; laen dù bolen: pure, unmixed (Mark 14:3). Not the same as bolok (rotten). Confirmed Oct 15
  - Senbol: mix. Senbolem: mix it (command)
- **bolok** [baw-lawk]: rotten
- **bool** [baw-awl]: soup. Also sóbów, borrowed from Tagalog sabaw. Confirmed Oct 15
- **boo** [baw-aw]: smell (boohen, its smell). Confirmed Oct 15
  - Bolok lembak!: (cuss) rotten mouth
  - Bolok sélék!: (cuss) rotten lips, side to side
  - Bolok sumóng!: (cuss) rotten lips
- **bon** [bawn]: what
  - Bon nmoem (du)?: what are you doing?
  - Bon nmoem ni?: what are you doing now?
  - Bon (tô) nmou: what I do, what to do
  - Bon boluyem (du)?: what's your name?
  - Bon kdaw du ni (kdaw ni)?: what's the date today?
  - Bon kminì kóm du?: what's heating you?
  - Bon se duen hnagì te du?: what else should we learn?
- **bong** [bawng]: big
  - Téy kinì bong: it's really, really hot
  - Bong slamat: thank you so much
  - Example: Kulón bong? (big rain?)
  - See also kbong
- **botò** [baw-taw']: penis
- **boto** [baw-taw]: dick (vulgar)
  - Sbotoen!: (cuss) his dick!
- **botu** [baw-too]: stone
- **boyu** [baw-yoo]: do; also a filler like Tagalog "ano" (um, you know)
  - Là boyu hu du ganì: I don't even do it
  - Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal: um, we were still walking, then we saw a snake
- **bud** [bood]: again (in front, for something that will happen)
  - Bud (ne): anymore
  - Bud te: we will (again)
  - Bud etu he: we will do it again; until then
  - Bud kmulón: it'll rain again
  - Bud moo ktuku: I'm sleepy again
  - Example: Bud te ston kdeng (we'll see each other later)
  - Example: Là nóyóu du kehe bud lehen (I don't want to be skinny anymore)
- **bukay** [boo-kai]: white
- **bumbay** [boom-bai]: onion (borrowed). Confirmed Oct 15
- **bukol** [boo-kawl]: knees
- **bulók** [boo-lok]: flower (bulók lem bnes, flowers in the grass, Luke 12:27)
- **bulón** [boo-lon]: moon; month (like kdaw is sun and day)
  - Todol bulón: next month
  - Example: Bulón nô bê ta (the moon is up above)
- **bulul** [boo-lool]: mountain (Bulul Ulib, Mount of Olives)
- **bungu** [boo-ngoo]: fruit (kbunguhen, its fruit; bunguhen, its fruit)
- **buri** [boo-ree]: buri palm, the huge fan-leaf palm with a thick trunk (borrowed from Tagalog)
- **byabas** [byah-bahs]: guava
- **Byérnis** [byehr-nees]: Friday (borrowed from Spanish)

### D

- **demyol** [duhm-yawl]: pull, drag
- **des kinì** [duhs kee-nee']: fever, literally "hot sickness" (kkinien, its heat)
- **dlag** [d'lahg]: wild (ohu dlag, wild dogs)
- **dlag lamang** [d'lahg lah-mahng]: forest (dlag, wild; lamang, wide)
- **dmilot** [d'mee-lawt]: draw a sword
- **dnadu** [d'nah-doo]: field for planting (dnaduhen, his field)
- **do (me)** [daw] (also dou): me, for me. Nitem do kun sélfónu: carry my phone for me
- **doli beng** [daw-lee buhng]: the other side of the backyard
- **dóryan** [dor-yahn]: durian
- **demsù** [duhm-soo']: to offer a sacrifice (Bible word; confirmed by Deymar, Oct 15). Also, for rain: to come pouring down. *"Ne e demsù yóm tey kulón bong"* and the heavy rain came pouring down (Matthew 7:25, 27)
  - **densù** [duhn-soo']: the thing gets offered for, celebrated or dedicated (the focus is on what receives it, not on the person offering). *"Mli me lomi mótól ekimel, dapat kendel densù me ni"* We bought a new motorcycle yesterday, so it has to be celebrated right away (Deymar, Oct 15; ni at the end is optional). *"densù le"* (Acts 7:41). Never dnemsù. When someone is making the offering, use demsù
  - **hedsù** [huhd-soo']: have it offered by someone else (people bring it, the priest offers it). **hedsuu**: I'll have it offered
  - **kedsù** [kuhd-soo']: the offering as an event or custom. **gel kedsù le**: what they always offer. dsù is the thing that gets offered
  - **tau gel demsù**: a person who performs sacrifices or offerings; a priest (Bible). In standard T'boli people just say **Pastór**
  - **kem geta bè yó kem gel demsù**: the chief priests (Bible)
  - **yóm hol geta bè yó kem gel demsù**: the high priest (Bible)
  - **gónó le gel demsù**: the altar, "the place where they offer" (Bible). Matthew 23 writes it **gónô demsù**, the same word: Ô becomes Ó under the Ô/Ó rule
- **dsù** [d'soo']: sacrifice, in general; an offering (Deymar, Oct 15). With an ending the accent drops: dsuen. Compare liteg, the sacrifice of your own hard work
  - **dsuen** [d'soo-uhn]: what he/she/it offers; can also mean his gift, if that's the sense. *"deng dsuen bélê tekuy"* what he offered for us (Acts 20:28). Confirmed Oct 15
- **duktur** [dook-toor]: doctor (borrowed)
- **dyo** [dyaw]: bathe (whole body)
- **dyo** [dyaw]: bathe (whole body)
- **dyol** [dyawl]: pull, drag (demyol, pulling). Dyol le ówóng bê kilil: they pulled the boat to shore
- **dé** [deh]: softener at the end of a line. On an ask or a plan it's easygoing ("just", "already"): Nehu bentik dé (just get up already), Ne meken dé (I'm going to eat). On a statement about something you want, it turns it into a hopeful hint. Confirmed Oct 15
  - **Lemnaw bê yó dé, guys** (also typed *Lemnaw beyo de guys*): Uh, any ulam over there, guys? (said while eating plain rice, hoping someone shares). Without dé, Lemnaw bê yó just points at the ulam.
- **dé kô** [deh ko']: maybe, perhaps, I guess so, I think so; if (something happens), depending on context
  - Example: Omin likoe dé kô gungolen o Pangu (and I'm afraid my dad will hear me)
- **deng** [duhng]: done, already
  - Denge: I'm done
  - Dengu: you're done
  - Dengi: you're done (formal)
  - Deng ye: you all are done
  - Deng le: they're all done
  - Deng kuy: we're done (including me)
  - Deng te: we're done (just you and me)
  - Deng me: we're done (me and others, not the person I'm talking to)
  - Deng (ne) du: he/she/it is done
  - Deng kenu: I ate
  - Denge meken: I already ate
  - Deng ne meken: I'm done eating
  - Deng t'ngónu ne: now I know
  - Example: Deng tógó (ne) ken / Ken, deng tógó (ne) (the rice is already cooked)
- **des** [duhs]: hurt; sick
- **dilak** [dee-lahk]: tongue
  - Mfól dilak!: (cuss) thick tongue
- **dlimun** [d'lee-moon]: made, created
  - Kedlimunen: what he made, his creation (John 1:3)
- **do** [daw]: mine; me, when I'm the one something happens to (from dou)
  - Do u ni: this is mine
  - In a question, **o** is me and **do** is mine: Nóyóem o? (do you like me?) vs Nóyóem kô do? (do you like mine?). In là ... se sentences do is me: Là gungolem do se (you can't even hear me), Là nóyóen do se (he never liked me), Là tnabahen do se (he didn't even call me). In béem (don't) commands, o is me and do is mine: **Béem ndù o** (don't touch me), **Béem ndù do ken** (don't touch my food), **Béem tnaba o kdeng, kaye tungô** (don't call me later, because I'll be sleeping) (Deymar, Oct 15)
  - He called me yesterday: **Tnabahen o ekimel.** (tnaba + h + -en for he, o for me; not Tnaba du do)
  - I'm drinking coffee: **Minume o kfi / Minume kfi / Minume kfi, ou.** All three work
  - Do ken: my food
  - Example: Yó kóm ken, ni do ken (that's your food, this is my food)
  - Example: Ktolok le do (they taught me)
- **dou** [daw-oo]: I own; mine; my
  - Dou wong: (it's) my spider
  - Do wong / wongu: my spider. -u on the end is for something that belongs to you
  - Example: Uu dou dumu sbót (you are my friend)
- **doun** [daw-oon]: leaf (dounen, its leaves)
- **du** [doo]: him, her, it (used everywhere for he/she/it); in questions like Kmoem du it means "it" or "something"; in kmon du it points to the thing being said
  - Du yó: that's him
  - Meken du: he's eating
  - Mebel du: he/she/it finds (something)
- **dumu** [doo-moo]: other; another (sotu / dumu)
  - Dumuhu: my other
  - Dumu sbót: a friend
  - Dumuhu sbót: my friend (telling someone else)
  - Kem dumuhu sbót: my (other) friends
  - Kem dumu bots: the other bots
  - Example: Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem (other bots like ChatGPT don't understand it even when they read your lesson notes)
- **dumuhen setwoli** [doo-moo-huhn suht-waw-lee]: relatives, kin, cousin (Colossians 4:10, Luke 1:58)
- **Dwata** [dwah-tah]: God
  - Ke Dwata: to God, or God's
  - Ke Dwata yó: that's God's
  - Udél Dwata: the T'boli Bible (see udél)

- **dyó** [dyo]: swim; take a shower
  - Nehe dyó dé: I'm going to swim / take a shower
- **dê** [deh']: many (tey dê, very many; là holen wen, few)
- **dóyón** [do-yon]: proud (dóyón alone always means proud). With ke/dé Dwata it becomes thank: **kdóyón ke Dwata**, thanks to God. *"Ne hol gel dóyón tekuy dé Dwata"* and be thankful (Colossians 3:15). Confirmed by Deymar, Oct 15
- **dù** [doo']: touch (mdù, touching; nduen, he touched it; béem ndù, don't touch)
- **dù (touch)** [doo']: touch (mdù, touching; gemdù, touch). Béem ndù sélfónu: don't touch my phone
- **dapat** [dah-paht]: must, has to (borrowed, not in the Bible). Bible says **nan** for must and **hol … dé** for should. Traditional: **móyô yó dé**
### E

- **ebuteng** [uh-boo-tuhng]: last night
  - Henslòu mlóy ebuteng: I was running fast last night
  - Nógówu u ebuteng: I went to you last night
- **eginu** [uh-ghee-noo]: earlier
  - Eginu hlafus: earlier this morning
  - Eginu kifu: earlier at night, last night
- **Ekimel** [uh-kee-muhl]: yesterday
- **Ekimel kimel** [uh-kee-muhl kee-muhl]: yesterday afternoon
  - Ekimel kimel téy kinì: yesterday afternoon was so hot
- **Ekuloy** [uh-koo-loy]: the day before yesterday
- **elaan** [uh-lah-ahn]: down, downward
- **elem** [uh-luhm]: into, up to (elem mohin, into the sea; elem bulul, up the mountain)
- **enahaw** [uh-nah-how]: anahaw, the round fan-leaf palm (borrowed from Tagalog anahaw)
- **él** [ehl]: water
  - Minum él: drink water
  - Example: Haya, nehe gów bê él, mebel utón (tomorrow I will go to the water and find fish)
- **él alah** [ehl ah-lahh]: the Allah River, in Allah Valley, what Deymar's place calls the river
- **él mlel** [ehl m'luhl]: river, literally flowing water
- **él mohin** [ehl maw-heen]: ocean water, sea water (James 3:11–12). Confirmed Oct 15
- **él tahu** [ehl tah-hoo]: fresh water (James 3:11–12). Confirmed Oct 15
- **él héét** [ehl heh-eht]: salty water, the way to describe it. Él mohin can work, but él héét says what it is. Confirmed Oct 15
- **Ell** [ull]: yes (said like "Ull")
  - Ell, tahu yó: yes, that's true
  - Ell, tahu ni: yes, it is real
- **ene** [uh-nuh]: come
  - Ene bê ni: come here
- **esolu** [uh-saw-loo]: (where) will be going
  - Example: Olohu hetngón du béléem bê du góem esolu (I just want you to know where you're supposed to be going)
- **etu** [uh-too]: then (sometime in the future)
  - Bud etu he: we will do it again; until then
- **ewen** [uh-wuhn]: so
  - Example: T'ngónem galì ewenu se ke hentahumen udélu kô? (oh, so you'll believe anything I say, huh?)

### F

- **fak** [fahk]: frog
- **fen** [fuhn]: the one assigned to. **tau fen gel demsù**: the people assigned to offer, priests (Acts 14:13, 1 Peter 2:5). **du fen demsù**: the one assigned to offer (Hebrews 8:4). Also *yóm fen bemlay sumóng ke Jisas*, the one who would betray Jesus. Confirmed Oct 15
- **fro** [fraw]: thought (it was), assumed, and it turned out wrong. Takes the person: fro kum (we thought)
  - Fro ke du: I thought it was him
  - Fro ke Deadpool character: I thought it was the Deadpool character
  - Ekuloy tô me mwa kmatì bê farm, fro kum ke wen blaem anduen: the day before yesterday we were going to get tomatoes at the farm, we thought there were some, but there were none
- **fakay** [fah-kai]: can, may; allow
  - Fakay kô?: is it allowed? can I?
  - Fakay ke: can I...
  - Fakay kô ke...?: can we / is it allowed to...? (ke is the "if" that links fakay kô to the action)
- **fan** [fahn]: trap
  - Fanen: his/her/its trap
  - Example: Nmoem fanen dé (put a trap on it)
  - Gfan, hegfan, segfan (showing up) are built from this root
- **fat** [faht]: four
- **fedyan** [fuhd-yahn]: week
  - Todol fedyan: next week
- **filak** [fee-lahk]: money, silver
- **fishtail palm**: placeholder, borrowed from English until the T'boli name is found (Tagalog: pugahan)
- **fig**: fig (borrowed from English; no everyday T'boli word). Koyu fig, fig tree (Matthew 21:19, Matthew 24:32); bungu fig, figs (James 3:12). The sycamore-fig Zacchaeus climbs is **sikamor** (Luke 19:4)
- **folò** [faw-law']: tens (Lwu folò, 20)
- **fun** [fyoon]: owner (the u like in uniform)
  - Funu: my owner
  - Funem: your owner
  - Funen: his/her/its owner
  - Funle: their owner (people not in the conversation)
  - Funye: you all's owner (speaker not included)
  - Funkuy: our owner (me and 2 or more people)
  - Funte: our owner (just me and one other person)

### G

- **gafit** [gah-feet]: caught in the act
- **galì** [gah-lee']: oh, so that's why (Tagalog "kaya pala")
- **ganag** [gah-nahg]: slow
  - Hen-ganagem: slow down (you). The hyphen keeps n and g apart, so it isn't read as the ng in mango
- **ganì** [gah-nee']: even, really; backs up that something is true
  - Là t'ngónu du ganì do: I don't even know (it)
  - Là boyu hu du ganì: I don't even do it
- **gebtik** [guhb-teek]: woken up suddenly
- **gemnóm des** [guhm-nom duhs]: being sick (desen, his sickness)
- **geta** [guh-tah]: high, for status or the height of something (tau geta, rich person)
- **ginggung** [gheeng-goong]: blue
- **glayam** [glah-yahm]: suffering (tey keglayamu, I am in anguish)
- **gónô mnagì** [go-no' m'nah-ghee']: school, "place of studying." **mnagì**: study. Bible: *"Là sem dengen mnagì"* "He never studied" (John 7:15)
- **gotu** [gaw-too]: nothing left, all gone (gotu le yóm ken, they left no rice)
- **gulom** [goo-lawm]: ant
- **grép** [grehp]: grape (borrowed from English; bungu grép, grapes)
- **gungol** [goo-ngawl]: hear (gungolen o, he hears/heard me). Gungolen o Pangu: my dad hears/heard me. **Gegungolem o / Gel gungolem o**: you always hear me (gel = always, also shown by doubling ge-)
- **guta** [goo-tah]: catch, get something (like fish)
- **géhél** [geh-hehl]: hurry; also soon
- **ge / gel** [guh / guhl]: always, usually; the one who does it (ge is everyday speech, gel is the Bible spelling). Dumu udél gel hnagì Deymar: other languages Deymar studies
  - Example: Gel mi coffee-hu, wen klamay nô lemmen (my coffee's always sweet, it has sugar in it)
  - Example: Ni kdaw ni tey gel tnaw (today is really, really cold)
- **gfan** [g'fahn]: show up unexpectedly
  - Hegfan: show up intentionally, walking into the fan (trap or event) someone set, on purpose
  - Segfan: show up to each other
  - Example: Haya gfan yó du (tomorrow he will show up)
  - Built from fan (trap): gfan is getting caught by it, showing up by surprise
- **genléd** [guhn-lehd]: rely
  - Genléd nawa: rely on (putting your own breath, your self, onto something)
- **geslà** [guhs-lah']: a surprise, something you didn't expect
  - Geslàu wong / Gebele wong: I stumbled on a spider
  - Not the same as gesla (no accent): (being) fried
- **gna** [g'nah]: first (the general word); past; old
  - Gna halay: last year
  - Gna kesfasad: old covenant
- **góem** [go-uhm]: where? where to? (said short like this, it means "where" and stops meaning "your house")
  - Góem gów (du)?: where are you going?
  - Góen nô phone-nu (du)?: where's my phone?
- **gónô** [go-no']: house; home
  - Gónóem lemwót du?: where are you from?
  - Gónóem gu du? / Góem gu?: where did you go? where have you been? (like Tagalog "saan ka galing?")
  - Gónóem msut? / Góem sut?: where were you born?
  - Gónóem: your house, your place
  - Gónô le: their home
  - Gónô mnô: home
  - Example: Kilón ke kulékem bê gónô? (when will you get back home?)
- **gónô fedyan** [go-no' fuhd-yahn]: market (the place); fedyan alone is week or market day
- **gów** [gohw]: go
  - Gówu: you go
  - Nehe gów: I will go
  - Example: Bê du góem gów du? (where are you going? the full way)
  - Example: Hene, gówu bê ni. Tungóu. (come, go here. Sleep.)
- **gwa** [gwah]: get; accidentally taken (see ma)

### H

- **haha** [hah-hah]: legs
- **halay** [hah-lai]: year; also living rice, the rice plant
  - Gna halay: last year
- **hampang** [hahm-pahng]: play, like kids playing (borrowed from Hiligaynon)
- **hanga** [hah-ngah]: branch (hanga koyu, tree branches). Confirmed Oct 15
- **hangat** [hah-ngaht]: wait, wait for (the subject is the one waiting)
  - Hangat ye o dé!: wait for me!
  - Hangatu kkól Yê: I'm waiting for Mother to come back
  - Tagad dé, Mà. Ne hangat ken: wait, Father. I'm still waiting for the food
- **hanà** [hah-nah']: still
  - Hanà là deng t'ngónu du bon nmou: I still don't know what to do
  - Example: Là nóyóu du tungô, kaye (hanà) bitil (I don't want to sleep because I'm (still) hungry)
- **hatay** [hah-tai]: death, dying
  - Là gógówen elem hatay: he won't be lost to death
- **haya** [hah-yah]: tomorrow
  - Key haya: every day (written ket haya in Matthew 6:11)
  - Example: Haya, bud kmulón (tomorrow it'll rain again)
- **hbalù** [h'bah-loo']: sell (hbaluen, he sold it)
- **hboo** [h'baw-aw]: perfume, fragrance (Luke 23:56, Mark 14:3)
- **he** [huh]: at the end of a sentence: yet; again, with a hope in it
  - Tagad he: wait a bit
  - Là e deng meken he: I haven't eaten yet
  - Bud te ston he: we'll see each other again, hopefully
- **hebetik** [huh-buh-teek]: jump up, leap to your feet
- **hedem** [huh-duhm]: think; also the closest word for bored
  - Kehedem: to think
  - Kehdem: to be thinking
  - Kmò kehdemem du se?: what do you think? (one person)
  - Kmò kehdem u du se?: what do I think?
  - Kmò kehdem ye du se?: what do you all think?
  - Kehegdemu du: I think
  - Kehegdemem du: you think
  - Kehegdem le du: they think
- **heglaan** [huhg-lah-ahn]: humble
- **heglomboy** [huhg-lawm-boy]: long robe
- **hegmón** [huhg-mon]: proud in a bad way, arrogant. Kehegmón: pride
- **hegnô** [huhg-no']: rest, lie down
- **helek** [huh-luhk]: sand (helek bè kilil mohin, sand on the seashore)
- **hemken** [huhm-kuhn]: to feed (from ken)
- **hemsag** [huhm-sahg]: shouted
  - Tong ye hemsag: so you guys shouted
- **hemtedeng knô** [huhm-tuh-duhng k'no']: acting righteous, fake. Tau gel hemtedeng knô: a hypocrite (Acts 23:3)
- **henged** [huhn-guhd]: as, serving as, standing in for; calling something by the job it does. Confirmed Oct 15
  - *"Ou se yóm henged bak tikeb"* I am the door (John 10:9)
  - *"Yó se henged dou ken"* this is my food (John 4:34)
  - **henged dsù**: as an offering (Romans 15:16, Hebrews 13:16)
  - **henged lówó**: standing in for someone; *yóm tau henged lówó yóm tau hol geta bè Rom*, the one standing in for Caesar (Acts 25:10)
- **henok** [huh-nawk]: to grow (from lemnok, growing); also full (Revelation 5:8, bowls full of incense). Bulung henok: yeast
- **hemyak** [huhm-yahk]: shameful
- **hendóm** [huhn-dom]: lend, let someone borrow
- **hentulón nawa** [huhn-too-lon nah-wah]: remember (keep in mind on purpose). Gtulón bè nawa: it came back to mind
- **hitok** [hee-tawk]: muddy, mud
- **hkawang** [h'kah-wahng]: empty, empty-handed
- **hlifót** [h'lee-fot]: pretend not to know something (in a bad way). Compare hlingu (pretend to be someone)
- **hlingu / hlingón** [h'lee-ngoo / h'lee-ngon]: pretend to be someone, disguise yourself as. Hlingu le tau hemtahu: they pretend to be believers (Galatians 2:4)
- **hmungol** [h'moo-ngawl]: listen (hnungol ye, you all listen)
- **hmungol** [h'moo-ngawl]: listen (hnungol, listen to it). Hnungol ye o dé: listen to me, all of you
- **hnas** [h'nahs]: opened up, uncovered
- **hnifót** [h'nee-fot]: forgive (hnifótem, you forgive) (Matthew 6:12)
- **hnifótem du kun** [h'nee-fo-tuhm doo koon]: forgive him, please
- **hnifótem o** [h'nee-fo-tuhm aw]: sorry, forgive me (the everyday apology)
- **hninggel** [h'neeng-guhl]: do it properly, kindly, with care (from minggel). Hol gel hninggel ye kmò kestulón ye: let your speech always be gracious (Colossians 4:6). Confirmed Oct 15
- **hnolo** [h'naw-law]: oil
- **htò** [h'taw']: jumping, jump, jumped (same form for now and past)
  - Wong htò / Htò wong: the spider is jumping; the spider jumped; jumping spider
  - Wót wong htò: the spider keeps jumping
- **huket** [hoo-kuht]: fishing net
- **huli** [hoo-lee]: following, coming after
- **hulu** [hoo-loo]: planted garden, orchard
- **hutóng** [hoo-tong]: lend (money), from utóng (debt)
- **huyów** [hoo-yohw]: plate, platter
- **héfê** [heh-feh']: wet
- **héét** [heh-eht]: salty, sour, and bitter
- **hféét** [h'feh-eht]: make it salty (Matthew 5:13). Confirmed Oct 15
- **hegléd** [huhg-lehd]: lean, leaning, leaned
- **hene** [huh-nuh]: come (here)
  - Hene edi ni: come over here
  - Hene, gówu bê ni. Tungóu.: come, go here. Sleep.
- **hitem** [hee-tuhm]: black
- **hitu** [hee-too]: seven
- **hligal** [h'lee-gahl]: happy, rejoice, celebrate (77 times in the Bible; the prodigal son party in Luke 15:23-32 is all hligal: *"anì na tekuy hol hligal mken"* let's eat and celebrate)
  - **henligal** [huhn-lee-gahl]: celebrate something (Deymar, Oct 15; not in the Bible, same hen- shape as hentahu)
  - **kligal / kehligal**: joy, blessed. **hefligal**: please someone, make them happy (1 Cor 7:33)
  - Hligale: I'm happy
  - Teye hligal: I'm very happy
- **hlós** [h'los]: continue
  - Làe hlós meken se: I didn't eat (I didn't go on to eat)
- **hlowon** [h'law-wawn]: joking
  - Olohu hlowon néen: I'm just joking
- **hnagì** [h'nah-ghee']: learn, schooling; lessons
  - Hemnagì: to study something
  - Kehnagì: still studying something (ongoing)
  - Mnagì: studying
  - Example: Bon se duen hnagì te du? (what else should we learn?)
  - Example: Lnóngónu meken wen para bê kem lomi hnagì (I need to eat more for new lessons)
- **hnobò** [h'naw-baw']: bladder (careful, one accent off from hnóbô)
- **hosò** [haw-saw']: heart
- **htolo** [h'taw-law]: curse; what you say when something gets in the way of what was still going on, like "dammit"
- **hulô** [hoo-lo']: red
  - Utón hulô mata: red-eye fish
- **hyu** [hyoo]: good
  - Hyu hlafus: good morning
  - Hyu kifu: good night (more like good evening)
  - Hyu se yó: that's good (hyu good, se is, yó that)
  - Hyu yó msó: that rice is good

- **hólólen** [ho-lo-luhn]: his/her hands
- **hol … dé** [hawl … deh]: should, ought to (Bible). *"Hol hentulón ye nawa dé yóm sotu tehe mon Jisas"* you ought to remember the words of the Lord Jesus (Acts 20:35)
### I

- **ilung** [ee-loong]: nose
- **imò** [ee-maw']: magic power; sorcery. Bible: "witchcraft" (Galatians 5:20)
- **inget** [ee-nguht]: sweat
  - Ninget: sweaty
  - Sa inget ganì o: I'm all sweat
- **inggit / sélus** [eeng-gheet / seh-loos]: jealous (borrowed)
- **itlug** [eet-loog]: egg
  - Example: Senlahu itlug, kayà meken kuy (I fried eggs, so let's eat)

- **iwas** [ee-wahs]: monkey
- **iwóng** [ee-wong]: left
### K

- **kahang** [kah-hahng]: spicy (borrowed from Hiligaynon)
- **kahì** [kah-hee']: salt
  - Example: Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen (my coffee has salt in it)
- **kailangan** [kah-ee-lah-ngahn]: need (borrowed from Tagalog)
  - Kailanganu: I need
  - Example: Kailanganu mekay ken. (I need to cook rice.)
- **kambing** [kahm-beeng]: goat
- **kluon** [kloo-awn]: grass (what animals eat). Yóm kambing mótób kluon: the goat eats grass. Confirmed Oct 15
- **kaong** [kah-awng]: sugar palm (borrowed from Tagalog). Its fruit hangs in long strings; not the same as aprikan
- **kapuy** [kah-pooy]: tired
  - Kapuye: I'm tired
  - Teye kapuy: I'm exhausted
- **katay** [kah-tai]: death (katayen, his death)
- **katri** [kaht-ree]: bed
  - Katrihu: my bed
  - Katrihem: your bed (katri ends in a vowel, so h goes in before -em)
  - Mógówu bê ta katri kun: go to bed
- **katù** [kah-too']: puppy
- **kay** [kai]: because; so
  - Kaye: because I; so I (the -e from bitile jumps to kay): Kaye bitil, because I'm hungry
  - Kaye bemli onuk: because I buy chicken
  - Kay nehe bemli onuk: because I will buy chicken (nehe already carries the "I," so kay stays bare)
  - Kay bitil le / Kay le bitil: because they are hungry (both orders work)
  - Careful: Bitile kaye meken means "I'm hungry because I ate," not "so I'm eating." For "X, so Y," use tong
- **kayà** [kah-yah']: so, that's why (borrowed from Tagalog)
  - Example: Meenge, kayà minume o él (I'm thirsty, so I'm drinking water)
- **kbong** [k'bawng]: big
  - Kbong nawa: love (literally "big breath"; Blaan has a close version, kanbong nawa)
  - Kbong nawahu kóm: my love for you
  - Kenbong (with -n-): already happening, continuously; kbong is still going
  - Kenbong nawahu u: I love you (literally "my breath for you is big": you are their breath)
  - Kenbong nawahu kóm: I love yours
- **kdaw** [k'dow]: sun; day
  - Kdaw ni: today (or just Ni when the context makes it clear)
  - Sok kemdaw: during the day
  - Example: Hkinì u bê kdaw dé (get yourself heated by the sun)
- **kdê** [k'deh']: all (general word)
  - Kdéen: all of it
  - Kdéle: all of them
  - Yóm kdéen tau: all people, everyone (John 1:4)
  - Example: Slamat bê ke-savem du kdéen (thanks for saving all of it)
- **kdeng** [k'duhng]: later (at the end of a sentence); wait! (on its own at the start)
  - Kdeng, hkinìu ken: wait, I'll heat up the food
  - Kdeng! Là o du mò du yó: wait! I didn't do that
  - Kmulón kdeng: it's raining again
  - Moo ktuku kdeng: I'll be sleepy later
  - Bud moo ktuku kdeng: I'll be sleepy again
  - Bud kmulón kdeng: it's going to rain again (later)
- **ke** [kuh]: if; to, for, or, and possession
  - Kehe: if I; also to be, to become (when it's "I")
  - Kehi: you become
  - Kehu bitil, mekenu: if you're hungry, eat
  - Kehe bitil, ne meken dé: if I'm hungry, I'll eat
  - Ke Dwata: to God, or God's
  - Ke Miles: or Miles / Miles' belongings / for Miles
  - Ke- (on borrowed verbs): if, or for doing it (ke-savem, ke-downloadem, ke-sendem)
  - Kilón (when) and Moen (why) stand alone; ke after them is its own word, as in Kilón ke kulékem bê gónô?
  - Kô ke: or, pick one
  - Example: Là nóyóu du kehe lehen (I don't want to be skinny)
- **kebel** [kuh-buhl]: smoke; also to find (same word, both meanings)
- **kebtik** [kuhb-teek]: the waking up (bang kebtik tekuy, time for us to wake up)
- **kama** [kah-mah]: pillow. Temdanan te kama fi: resting on the pillow (Mark 4:38)
- **kegnóm** [kuhg-nom]: feeling; also opinion. Bè kegnómu du: in my opinion (1 Corinthians 7:40). Root gnóm: to feel, go through something. Gemnóm: feeling it. Hol lómón kegnóm ye du: feel it as if it were yours (Hebrews 13:3)
- **kehlifót** [kuh-h'lee-fot]: to forget on purpose in a good way, to move on; forgiving in the Bible (Matthew 6:12). Compare hlifót (pretend not to know, in a bad way) and klifót (forget, forgot)
- **kem** [kuhm]: plural marker before a noun; these
- **kemdaw** [kuhm-dow]: noon
- **kemfô** [kuhm-fo']: grab, catch hold of
- **kemgis** [kuhm-ghees]: strong (kgis, strength)
- **kenleng** [kuhn-luhng]: cut off
- **kenleng** [kuhn-luhng]: cut off (kenlengem, you cut it off)
- **kenyak** [kuhn-yahk]: to be shy or ashamed, embarrassed of someone ("nakakahiya"). Miles, tey kenyaken Màen: Miles is ashamed of his father. Mô kóm kenyak: your own shame, your own regret
- **ket** [kuht]: enough; every. **Làen ket**: not enough
  - Ket tonu kuying bê lan ket knwahu: every cat I see in the street, I take
  - Ket me lwu me. Wen kun, wen sdo: we're even. He has his, I have mine
  - Kem utón: fish (more than one)
  - Kem ngà: children
  - Kem tau: people
  - Kem twolihu: my siblings
  - Kem udél: words
  - Kem dumu bots: the other bots
- **ken** [kuhn]: food in general; cooked rice; eat
  - Meken / Mken: eating, to eat (same word, just said faster)
  - Henken: feeding (someone)
  - Nehu henken kem kuyingu, kay le bitil: I'm going to feed my cats because they're hungry
  - Hken: feed something to something
  - Hkenu bê wongu ne ni: I'm going to feed it to my spider
  - Mekene: I am eating
  - Mekenu: you are eating; also "eat!"
  - Meken du: he/she/it is eating right now
  - Meken kuy: we are going to eat, let's eat
  - Kenu: I eat (it)
  - Kenem: you eat
  - Kenen: he/she/it eats or ate (general)
  - Kenle: they eat
  - Kenye: you all eat
  - Kenkuy: we eat
  - Kente: just you and me eat
  - Deng kenu: I ate
  - Denge meken: I already ate
  - Deng ne meken: I'm done eating
  - Meken he (kdeng): I'll eat (later)
  - Ne meken dé: I'm going to eat
  - Ne meken he dé: I'll eat first
  - Nehe meken: I will be eating
  - Là e deng meken (he): I haven't eaten (yet)
  - Kken: ate together (past)
  - Henken: feed
  - Henkenu ohu: I feed the dog
  - Hefken: wants to be fed
  - Hefkenu bê ohu: I fed it to the dog
  - Nehu henken kem wongu anay: I will feed my spiders first
  - Hefkene bê ohu: I fed myself to the dog
  - Henken do: feed it for me (asking someone to feed something of yours, like your dog)
  - Henken o: feed me
  - Kenken: be fed
  - Ohu nóyóen ke kenken (du): the dog wants to be fed
  - Sken: eat each other
  - Senseken: eating together (still going)
  - Ken tnaw: leftover rice (literally "cold rice")
  - Mekay ken: to cook rice
  - Example: Téy mi ken ni (this food is delicious)
  - Example: Mekenu silà kô ke ken? (are you eating corn or rice?)
- **ket hilu?** [kuht hee-loo]: how much?
- **ketdak** [kuht-dahk]: being dropped, leaked (from **tdak**)
- **kfi** [k'fee]: coffee
- **kfu** [k'foo]: chest
- **kfung** [k'foong]: dry desert sand
- **kgal** [k'gahl]: shirt, tunic
- **khahù** [k'hah-hoo']: miss someone, long for someone
- **khééten** [k'heh-eh-tuhn]: its saltiness (from héét; Matthew 5:13, Luke 14:34). Confirmed Oct 15
- **kifu** [kee-foo]: night (sok kifu, at night); also dim
  - Kekifuhen: if it turns dark, when it gets dark (ke + kifu + h + -en)
  - The ke- + word + ending form usually names an event, "the time/the way it happened," often with yóm in front and a time word. It doesn't work as a plain "if" (Kekulónen, ne tungô dé was wrong):
    - Yóm kekulónen ekimel, gehedemem? The way it rained yesterday, remember?
    - Tu du yóm tô kekékéten kut ohu ebuteng: last night, the way we almost got bitten by the dog
    - Kebitilem yóm hanà knóem bê gónô mnagì du: the time you were hungry while you were at school
    - Yóm kekinien ekimel, tey kebitilu: the way it was so hot yesterday, I was really hungry (kinì takes -en with no h; bitil goes to kebitil after tey)
  - Kmifu: getting dark, getting dim; darkness (lem gónón kmifu, in the darkness, John 1:5)
  - Eginu kifu: earlier at night, last night
  - Hyu kifu: good night (more like good evening)
- **kigol** [kee-gawl]: stir
- **kihu** [kee-hoo]: whoever, whatever
  - Kihu kóm: up to you (whatever is yours)
  - Kihu tau hemtahu béléen: whoever believes in him (John 3:16)
- **kilil beng** [kee-leel buhng]: side of the backyard
- **kilón** [kee-lon]: when?
  - Example: Kilón ke kulékem bê gónô? (when will you get back home?)
- **kimel** [kee-muhl]: afternoon
- **kimoy** [kee-moy]: withered (a hand)
- **kinì** [kee-nee']: hot
  - Kminì: being heated by (something)
  - Hkinì: make hot
  - Hkinìem ken: heat up the food (you do it)
  - Hkinìu ken: I heat the food
  - Hkinì u bê kdaw dé: get yourself heated by the sun
  - Bon kminì kóm du?: what's heating you?
  - Example: Coffee-hu kinì (my coffee is hot)
- **kis-a / tlagsa** [kees'-ah / t'lahg-sah]: sometimes (from Hiligaynon). The hyphen in kis-a is a full stop (confirmed Oct 14)
- **klamangen** [klah-mah-nguhn]: it's whole, all of it (géhél nogotem yóm klamangen, Matthew 6:10)
- **klamansì** [klah-mahn-see']: calamansi (the standard word). The traditional word is **klamunding**
- **klamay** [klah-mai]: sugar
- **knamay** [knah-mai]: put sugar in (Knamayem kun, put sugar in it please)
- **knigol** [knee-gawl]: stir it (Knigolem kun, stir it please)
- **klamunding** [klah-moon-deeng]: calamansi (the traditional word). The standard word is **klamansì**
- **klifak** [klee-fahk]: the base of a palm frond, where the leaf stalk meets the trunk
- **klifót** [klee-fot]: forget, forgot (by accident)
- **klingu** [klee-ngoo]: ear
- **klinggel** [kleeng-guhl]: glory, grace, beauty (from minggel). Klinggel nawa: grace, kindness (John 1:14). Confirmed Oct 15
- **klung** [kloong]: shield
  - Kenlung: protect
  - Kenlungem: you protect (hol kenlungem mi bè Seitan, protect us from Satan, Matthew 6:13)
- **kmera** [k'muh-rah]: camera (standard). Traditional: **kudak**
- **kmimet** [k'mee-muht]: when the sun is almost setting
- **kmatì** [k'mah-tee']: tomato (confirmed; Matthew 7:16 and Luke 6:44 use it in place of figs/grapes)
- **kmò** [k'maw']: how
  - Kmou du: how am I going to do it? what am I going to do?
  - Kmou se do(u): how am I? what about me?
  - Kmou du se?: how or what am I supposed to do?
  - Kmoem du?: what or how would you do? what's up to you? also how are you? what's up?
  - Kmoem se du?: how are you?
  - Kmoem du se?: what or how did you do? how would you do it?
  - Móen: short for Kmoem (Teye bitil. Móen skóm? I'm very hungry. How about you?)
  - Kmoen du?: how was it?
  - Kmoen se du?: how is he/she/it?
  - Kmoen du se du?: what or how did he/she/it do (to something)?
  - Kmò le du?: how are they? how did they do it?
  - Kmò le se lu?: how are they?
  - Kmò le du se?: what did they do? how would they do it?
  - Kmò ye du?: how are you all? how did you all do it?
  - Kmò ye du du?: what did you all do to him/her/it?
  - Kmò ye du se?: how would you do it? how did you do it?
  - Kmò kuy du?: what do we do? how about you all?
  - Kmò kuy du se du?: what are we supposed to do to him/her/it?
  - Kmò kuy?: how about you all?
  - Kmò te du?: what about us (you and me)? what do we do?
  - Kmò me du: the same with me (we, not you)
  - Kmò kmon (du): how to say (it)
  - Use Kmoem when asking someone directly, Kmoen when it's indirect
- **kmoen kun ke...** [k'maw-uhn koon kuh]: what if...
  - Also said: Kmoen kun..., Kmoen kun ke sok..., Kmoen ke sok...
  - Example: Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying? (What if I cook 1,936 fish and feed them to my 127 cats?)
- **kmuli** [k'moo-lee]: laughed
  - Tong kmuli du: so he/she/it laughed
- **kmustahu du?** [k'moos-tah-hoo doo]: how are you?
- **kna** [k'nah]: dream (knahen, his dream)
- **kohù / kusina** [kaw-hoo' / koo-see-nah]: kitchen
- **kow** [kaww]: cough
- **ktai** [kuh-tah-ee]: lemongrass. Confirmed Oct 15
- **kti** [k'tee]: dried up, for water
- **kudak** [koo-dahk]: picture, photo; camera (traditional). Not in the Bible. Standard for camera: **kmera**
- **kuleng** [koo-luhng]: cooking pot
- **kumù** [koo-moo']: blanket
- **kurinti** [koo-reen-tee]: electricity. Also **ofi**, literally fire, for electricity and power in general
- **kutsilyu** [koot-seel-yoo]: knife (borrowed, from Spanish cuchillo)
- **kutó nawa** [koo-to nah-wah]: hate. Opposite of kenbong nawa (love). Takes the n inside because it lands on someone: **knutó nawa** (hated, hates someone), **kmutó nawa** (hating). **Knutó nawahu u**: I hate you (confirmed by Deymar). Matt 5:43: knutó nawahem yó kem hmohon kóm, you hate your enemy. 1 John 2:9: knutó nawahen yóm dumuhen, he hates his brother
- **kenbé** [kuhn-beh]: reject, dislike, deny. **Kenbéu u**: I reject you, I dislike you. Rom 9:13: kenbéu Iso, Esau I rejected. John 3:20: kenbéen yóm layag, he rejects the light
- **kwanan** [kwah-nahn]: right (kwananen, his right side)
- **kwang beng** [kwahng buhng]: backyard
- **kê** [keh']: poop. **kéen**: its poop
- **kô** [ko']: turns a sentence into a yes or no question
  - Tahu kô?: is it true? is it right? correct?
  - Where kô goes changes the meaning (Deymar, Oct 15): **Gungolem o kô?** can you hear me? **Gungolem kô, o?** can you hear... me? (a pause before o) **Gungolem kô do?** can you hear mine?
  - **Nóyóem o?** do you like me? **Nóyóem o kô? / Nóyóem kô, o?** can you like me? **Nóyóem kô do?** can/do you like mine?
  - **mkô** [m'ko']: really, in a question. **Nóyóem o mkô?** do you really like me? **Tnabahem o mkô haya?** will/would you really call me tomorrow? (Deymar, Oct 15)
  - I'm going to sleep now, because it's already night: **Tungóe ne, kay deng kifu.**
  - Kô ke: or, when suggesting someone pick one
  - Example: Downloadem kô? (would you download it?)
- **kodok** [kaw-dawk]: boil
  - Kmodok: boiling
  - Hkodok: asking for it to be boiled
  - Hkodoku: I'm boiling it (now or later, depending on context)
  - Hkodokem: you're boiling it
  - Hkodoke béléem itlug: I'll boil an egg for you
  - Henkodok: being boiled
  - Hefkodok: asking someone to boil something (hef- is asking; you hand over your own item)
  - Hefkodoku béléeu kun él: please boil me water (I gave you my item, you do the work)
  - Hkodoku béléeu kun él: please boil me water (I don't have the item, you find it and do it)
  - Hefkodoku béléem itlug: I'm asking you to boil the eggs
  - Hefkodoke béléem itlug: boiling an egg for you
  - Hefkodoku béléeu itlug: please boil an egg for me (my egg, you do the work)
  - Kmodok él ne / Kmodok ne él: the water's boiling now
  - Él deng kmodok: the water is already boiling
- **kóm** [kom]: yours, you own; you
  - Kóm du?: and you?
  - Kóm ken: your food
  - Example: Ou kóm dumu sbót (I'm your friend)
- **kóyô** [ko-yo']: want, will (kóyô me, we want; yóm kóm kóyô, your will) (Matthew 6:10)
- **koyu** [kaw-yoo]: tree, wood (Matthew 7:17)
- **kudà** [koo-dah']: horse, donkey
- **kuli** [koo-lee]: laugh
- **kulit** [koo-leet]: skin
- **kulón** [kuh-lawn]: rain
  - Kmulón: raining, to rain
  - Knulón: (being) rained on
  - Kmulón ne?: is it already raining?
  - Kmulón ni?: is it raining?
  - Gkulóne: I accidentally got rained on
  - Haya làen kmulón he: tomorrow it won't rain yet
  - Knulóne: I got rained on (on purpose)
  - Example: Kmulón ne. Tnawu yó. (it's raining now. You'll be cold.)
  - Example: Haya bud kmulón (tomorrow it'll rain again; no kdeng, since haya already says when)
- **kulu** [koo-loo]: head
  - Kuluhu: my head
- **kul** [kool]: they own, theirs; them, the whole group as the object
  - Kul yó: that's theirs
  - Khulék kul: return them all
  - Tnógóhu kul: I cook theirs
  - Tnógóhu kul he: I'll cook them all (a threat)
- **kum** [koom]: we (3 or more) own
- **kukù** [koo-koo']: kitten
- **kun** [koon]: he/she/it owns; allegedly; in a request it works as "please"
  - Kun él: on its own, his/her/its water
- **kut** [koot]: we (me and you) own; ours
  - Kut yó: that's ours (me and you, or me and my people)
  - Kut ne yó: that's our turn
- **kuy** [kooy]: we, us (3 or more); all of us
  - Meken kuy: let's eat
  - Kuy yó: that's yours; also that's you all
  - Tnógóhu kuy he: I'll cook all of you (a threat)
- **kuying** [koo-yeeng]: cat
  - Kuying bê ta lmisa: the cat is on the table
- **kwang** [kwahng]: back (body)
- **kyemet** [kyuh-muht]: fingers
- **K'nóón** [k'no-on]: very good, very cool, very nice, very beautiful (an earlier lesson wrote it K'nôón, beautiful)
- **kendel** [kuhn-duhl]: right away, quickly, too soon. *"Bê ye kendel tódô hentahu udél tau"* don't be quick to believe what people say (hentahu needs no bè; hemtahu takes bè). *"móyô kendel myehen du"* he wants to marry her right away (1 Cor 7:36). *"bê ye kendel tódô hentahu"* don't be quick to believe (1 John 4:1). 126 times in the Bible
- **keslamat** [kuhs-lah-maht]: thankfulness (Bible, 4 times). *"tey bong keslamat me béléem"* with all thankfulness (Acts 24:3). Peslamat/pslamat isn't in the Bible

### L

- **lamang** [lah-mahng]: wide
- **lana** [lah-nah]: lost, gone. Lana béléen: he lost it, it's gone from him
- **lanas** [lah-nahs]: pineapple (the traditional word). The newer word is **pinya**. Where it comes from: the Tupi word nanas became Portuguese ananás and Malay nanas (sourced); that lanas came from Malay nanas is only a guess, not confirmed
- **langgaw** [lahng-gow]: vinegar, the everyday word (borrowed). The Bible's sour wine is ninum lóbô là mebtesen. Confirmed Oct 15
- **lansunis** [lahn-soo-nees]: lanzones
- **lapis** [lah-pees]: pen
- **lebwón** [luhb-won]: water jar, water pot
- **legen** [luh-guhn]: long, for time (kegenen, how long)
- **leteng** [luh-tuhng]: messy, tangled plants on the ground; also a very toxic plant that makes you itchy if it touches you. Stands in for "thistle" in Matthew 7:16 and Luke 6:44
- **lemnaw** [luhm-now]: green; vegetables, herbs; dish, viand (ulam, putahe: what you eat with rice). A root word of its own
- **lewà** [luh-wah']: outside (bè lewà, out there)
- **lmaan** [l'mah-ahn]: light, not heavy
- **lumaken** [loo-mah-kuhn]: its sheath
- **lfò** [l'faw']: coconut, coconut palm
- **lungkà** [loong-kah']: open (lemungkà, opening it; lenungkà, opened it)
- **lungkà** [loong-kah']: open something (lemungkà, opening it; lenungkà, opened it)
- **lunog** [loo-nawg]: weak
- **là** [lah']: no (general); not
  - Làe / Là e: I am not (literally "no I")
  - Làu / Là u: you are not
  - Lài: you (the one specific person I'm talking to) are not
  - Làen: he/she/it is not
  - Là le: they are not
  - Là te: we (you and me) are not
  - Là ye: you all are not
  - Là kuy: we all are not
  - Là me: we are not (not counting the person I'm talking to)
  - Là du du: he/she/it did not (do something)
  - Là du: never mind; nothing much
  - Là sdu: of course not
  - Làen dù (andù): no one; none, there isn't any. **Kay làen dù kurinti**: because there's no electricity
  - Làen ket: not enough. **Kay làen ket kurinti**: because there's not enough electricity (Deymar, Oct 15)
  - Là o du se / Là ou du (se): it's not me (when someone accuses you)
  - Là o du mò du yó: I didn't do that
  - Là ou du mò du yó: I'm not the one who did that
  - Example: Là e deng meken he (I haven't eaten yet)
- **laan** [lah-ahn]: under; also "before" in time
  - Laanen: underneath it, her or him (-en is it/him/her)
  - Laanu: underneath me; laanem: underneath you
  - Gu laanen: before it (literally from underneath it)
  - Laan lmisa: under the table
  - Bê laan: underneath (something)
- **lan** [lahn]: way, road
  - Example: Tey sidek lan yó mulék bê gónô (that is a very bad way to get back home)
- **lanaw** [lah-now]: lake (Lanaw Galili, Sea of Galilee)
- **latu** [lah-too]: hundreds
  - Lmatu (Sotu latu): one hundred
  - Lwu latu: 200
- **layag** [lah-yahg]: light
  - Lmayag: bright
  - Lemayag: shining, giving light; hlayag: lighting up (John 1:4-5)
- **lehen** [luh-huhn]: skinny
- **lem** [luhm]: inside
  - Lemmen: inside of something or someone
  - Bê lem: inside
  - Example: Coffee-hu wen klamay nô lemmen (my coffee has sugar in it)
- **lembak** [luhm-bahk]: mouth
  - Bolok lembak!: (cuss) rotten mouth
- **lemwót** [luhm-wot]: going; coming from
  - Lemwótu bê él?: are you from the water?
  - Gónóem lemwót du?: where are you from?
  - Lemwót te?: are we going?
  - Lemwót te ne?: are we going now/already?
  - Lemwót ye ne?: are you all going now/already?
  - Lemwót tu?: are you going?
  - Lemwót le?: are they going?
  - Lemwót kuy?: are we going? (all of us, me included)
- **len** [luhn]: just
  - Anduen. Len myón.: nothing, just sitting
- **lemnok** [luhm-nawk]: growing (henok, to grow)
- **lenagas** [luh-nah-gahs]: lamp oil, the Bible's word (Matthew 25:3–8). Traditionally, older people call it **solok gas**, gas light. Confirmed Oct 15
- **lengel** [luh-nguhl]: drunk
  - Example: Kay wen tau lengel tungô laan lmisa (because there's a drunk guy sleeping under the table)
- **lenibun** [luh-nee-boon]: what you call a girl or woman, like "daughter" (Luke 8:48)
- **lenos** [luh-naws]: wind
- **lewók** [luh-wok]: waves
- **libu** [lee-boo]: thousands
  - Lmibu (Sotu libu): one thousand
- **libun** [lee-boon]: female
  - Tau libun: woman
  - Libun: girl
- **lihol** [lee-hawl]: neck
- **likò / likô** [lee-kaw' / lee-ko']: afraid, scared (both spellings appear in the lessons)
  - Likoe: I'm afraid
  - Example: Là e likô (bê) wong (I'm not scared (of) spiders)
  - Example: Ngà laen likò bê wong (the child isn't scared of the spider)
- **limu** [lee-moo]: five
- **lingón** [lee-ngon]: song
- **litô** [lee-to']: blood
- **lmangat** [l'mah-ngaht]: screamed
  - Tongu lmangat: so you screamed
- **lmisa** [l'mee-sah]: table
  - Bê ta lmisa: on top of the table
- **lmiteg** [l'mee-tuhg]: tired (the more T'boli way to say it)
- **liteg** [lee-tuhg]: hard work; the sacrifice you make for something you work for (Deymar, Oct 15). Lmiteg isn't in the T'boli Bible, but liteg and kliteg are:
  - **kliteg** [k'lee-tuhg]: tiredness from work. *"alì sidek klitegen bè yóm kógówen"* he was very tired from his journey (John 4:6). *"efet sidek klitegu"* my hard work and tiredness (2 Corinthians 11:27). *"gel kliteg me"* our labors (2 Corinthians 6:5)
  - **litegen**: his work, what he sacrificed. *"kaem bayad litegen"* it's payment for his work (Romans 4:4)
  - **towok liteg**: pay back the sacrifice. *"mò towok liteg yê le kul ne bé le"* repay their parents (1 Timothy 5:4)
- **lnos** [l'naws]: wind
- **lobun** [law-boon]: cloud
  - Lmobun: cloudy, getting cloudy
  - Kdaw lmobun: a cloudy day
  - Example: Kdaw ni, Denlag tey lmobun (tonight Denlag is very cloudy)
- **là mebtesen** [lah' muhb-tuh-suhn]: cheap, literally "not expensive"
- **lóbô** [lo-bo']: angry (in general)
  - Hlóbô: angry, mad
  - Hnóbô: scold, get angry at someone (not hnobò, bladder)
  - Example: Ominen bud hlóbô mton do meken (he'll get mad again if he sees me eating)
- **logi** [law-ghee]: male
  - Tau logi: man
  - Logi: boy
- **lohok** [law-hawk]: beside
  - Bê lohok: beside
- **lomi** [law-mee]: new
  - Lomi kesfasad: new covenant
- **lomon** [law-mawn] (also lómón): it's like
  - Mlóy du lómón ke ohu: he runs like a dog
  - Ke làen mlan béléem, làen lomon ni se ke t'ngónu T'boli: if it weren't for you, I wouldn't know T'boli like this
- **longit** [law-ngeet]: heaven, sky (bè longit, in heaven)
- **lómón ke** [lo-mon kuh]: like, as (lómón ke bnes, like grass)
- **lóngón** [lo-ngon]: need, have to; also worry. **Lnóngóu**: I have to, I worry about (something)
  - Lnóngón: to need (to)
  - Example: Lwu folò fat utón lnóngón (24 fish are needed)
  - Example: Lnóngón kuy kebel kuy dumu lan (we need to find another way)
- **lówóhu** [lo-wo-hoo]: my body
  - Lówóhem: your body
- **lték** [l'tehk]: thunder
- **lu** [loo]: them
  - Lu yó: that's them
- **lwu** [l'woo]: two
  - Lwu te yó: that's the two of us

### M
- **malak** [mah-lahk]: lead, govern. Confirmed Oct 15
  - *"yóm tau mò malak yó kem dou tau Israél"* a governor who will lead my people Israel (Matthew 2:6)
  - *"tau néléken mò malak yó kem tau hemtahu"* people chosen to lead the believers, pastors (Ephesians 4:11)
- **mangà** [mah-ngah']: mango (confirmed). The full stop at the end means the accent drops with an ending: mangaem, your mango. Goes back to Tamil māṅkāy, through Malay and Tagalog mangga
- **mangustin** [mah-ngoos-teen]: mangosteen
- **marang** [mah-rahng]: marang
- **mélón** [meh-lon]: melon. Not confirmed for watermelon yet. In the Bible, melons only appear in Numbers 11:5 (Old Testament, not in the T'boli Bible)
- **méséj / méséds** [meh-sehj]: message (standard). Also **téks** [tehks]: text. Traditional and Bible: **udél**
- **mótób** [mo-tob]: get something to eat, graze, consume (John 10:9). Yóm kambing mótób kluon: the goat eats grass. Confirmed Oct 15
- **mótól** [mo-tol]: motorcycle
- **msó** [m'so]: rice; also to count. Nsóhem kun msó: count the rice, please. Wót Miles nsóhen msó: Miles was counting rice (back then, still going). Wót Miles msó msó: Miles counted rice (telling someone). Msó nsó Miles: the rice was counted by Miles

- **ma / mwa** [mah / m'wah]: take
  - Ma / Gemwa: to get
  - Nwa: taken; get (nwahu, I get)
  - Gwa: get; accidentally taken
  - Swa: taking from each other
  - Example: Anì(e) gemwa [lówóhu] unged wen (so I can get more muscle)
- **madal** [mah-dahl]: dance
- **mahi du** [mah-hee doo]: which one
- **matay** [mah-tai]: die, dead
- **mayuk** [mah-yook]: far (keslayuk, distance)
- **mdà** [m'dah']: stand, standing
- **mdóm** [m'dom]: borrow
- **mebtes** [muhb-tuhs]: expensive, valuable (alì mebtes, very expensive)
- **menes** [muh-nuhs]: wilted (plants)
- **menwu** [muhn-woo]: living somewhere (from benwu)
- **mit** [meet]: carry, take
- **mit edini** [meet uh-dee-nee]: bring here (nit, nwit, brought)
- **mkaf** [m'kahf]: climb
- **mkik** [m'keek]: cry, weep
- **mnagaw** [m'nah-gow]: steal. Tau mnagaw: thief. Knagaw: stealing
- **mni** [m'nee]: to ask for something, request (Mnihe seflifót béléem, I ask you forgiveness) Ends in a vowel? Add h before e for I: Lomihe, Mnihe.
- **moni** [maw-nee]: near
- **mouf** [maw-oof]: wash your face
- **mouf** [maw-oof]: wash your face
- **mudél** [moo-dehl]: speak (from udél, word)
- **myak** [myahk]: being shy. Myak du: she's shy
- **myón** [myon]: sitting (myón tahen, sitting on it)
- **mà** [mah']: father
  - Mà me bè longit: our Father in heaven (Matthew 6:9)
- **mabù** [mah-boo']: fat
- **maistru / mestlu** [mah-ees-troo / muhs-t'loo]: teacher (borrowed from Spanish maestro; mestlu is how it's actually said)
  - Deymar Mestlu / Mestlu Deymar: both work. The first is like "Deymar the teacher", the second like "Teacher Deymar", a title
  - Tau tmolok: a person who teaches
- **mala** [mah-lah]: spicy; chili. Confirmed Oct 15
- **mala tonok** [mah-lah taw-nawk]: ginger, literally ground chili. Confirmed Oct 15
- **man** [mahn]: prince (a title)
- **mang** [mahng]: mama
- **masa** [mah-sah]: read
- **mata** [mah-tah]: eye
  - Matahu: my eyes
  - The color goes before mata: Tnógóu lu kô ni utón hulô mata? (should I cook this red-eye fish?)
- **me** [muh]: we, I'm part of it but the person I'm talking to isn't (see the three kinds of "we")
  - Example: Tmógó me utón (we're cooking fish, not you)
- **meeng** [muh-uhng]: thirsty
  - Meenge: I'm thirsty
  - Example: Soke meeng, minume él (when I'm thirsty, I drink water)
- **mekay** [muh-kai]: to lift something
  - Mekay ken: to cook rice (literally lifting the rice)
- **mekô** [muh-ko']: really? huh? (kô plus surprise, at the end of a question). Làu bud tungô ne mekô?: you're not going back to sleep, huh?
  - Tóu tungô mekô?: you're going to sleep, really?
- **mfól** [m'fol]: thick
  - Mfól sumóng!: (cuss) thick lips
  - Mfól dilak!: (cuss) thick tongue
- **mgel** [m'guhl]: hard
- **mi** [mee]: sweet
  - Téy mi: delicious (literally "very sweet")
- **mi** [mee]: us, we (I'm included but not the person I'm talking to); sounds exactly like mi, sweet
  - Mi kem mag-cousin: us cousins (not counting you)
  - Tu mi: there we are; that's us (to people who aren't part of it)
- **minggel** [meeng-guhl]: nice, fine, beautiful, done well. Confirmed Oct 15
  - Alì minggel boohen: fragrant things, spices, incense; "its smell is very nice" (Luke 23:56, Revelation 5:8)
  - Tey minggel nmoen béléu: she did a good thing for me (Mark 14:6)
  - Minggel kmò Dwata kul yó kem bulók: God clothes the grass so beautifully (Matthew 6:30)
  - Yóm minggel: whatever is lovely (Philippians 4:8)
- **minum** [mee-noom]: drink (still happening)
  - Ninum: drunk by something
  - Minume: I'm drinking or we're drinking, depending on context
  - Minume o él: I was drinking water
  - Minume mi él: we were drinking water
  - Ninumu él: I drank the water
  - Ninume él: we drank the water
  - Miles ninumen él: Miles drank the water
  - Él ninum Miles: the water being drunk by Miles
  - Él ninumen Miles: the water drank Miles
  - Example: Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng (I don't want to be skinny, so I'll take my vitamins later)
- **mlan bê** [m'lahn beh']: because of (someone or something)
  - Là e deng meken mlan bê Pangu: I haven't eaten yet because of my dad
- **mlel** [m'luhl]: flowing
- **mlóy** [m'loy]: ran; also spelled **melóy** (same sound, the e is the u in burn)
  - Tong kuy mlóy: so we ran
- **mluy** [m'looy]: tripped, fell and rolled
  - Tong te mluy: so we (you and I) tripped, fell and rolled
- **moen** [maw-uhn]: why? (its own word, not Móen). Moen asks for a reason; bon (what) asks for a thing. Moen boluyem? doesn't work for "what's your name?"
  - Moen du kun?: why is that?
  - Moen yó du ke ntó ye?: why are you untying it? (Mark 11:3, 11:5; Luke 19:33)
  - Moen yó?: what's that about? why's that? (Bon yó? is "what is that thing?")
  - Example: Moen ke là u gtungô du? (why aren't you sleepy yet?)
- **mékéng** [meh-kehng]: dry, dried out (kti: dry up, evaporate, something making it dry)
  - Deng mékéng kilil él: the edge of the water is dry
  - Deng kti él: the water has evaporated, dried up
- **mélél** [meh-lehl]: yellow
- **mógów** [mo-gohw]: walk, walking, walked
- **mtob** [m'tawb]: cut something out in nature, like branches. Mtob me hanga koyu ekuloy: we cut tree branches the day before yesterday. Confirmed Oct 15
  - Mógówu bê él? Nehe mógów sdo: are you going to the water? I'll go too
  - Nógów: continuously walking
  - Mógówe: I went
  - Mógówu: you went; (you) go there
  - Nógówem: (you) go there
  - Mógówu bê ta katri kun: go to bed (kun makes it a command)
  - Nógówu u ebuteng: I went to you last night
  - Mógówe béléem ebuteng: I went for you last night
- **mohin** [maw-heen]: sea, ocean
- **mon** [mawn]: say
  - Kmon: mon with the m infix
  - Kmò kmon (du): how to say (it)
- **moo** [maw-aw]: smelly, stinks (smell itself is boo). Same moo as in Moo ktuku, I'm sleepy. Confirmed Oct 15
  - Moo ktuk: sleepy (literally "smells sleepy")
  - Moo ktuku: I'm sleepy
  - Example: Moo ktuk wong. Tluyab. (the spider is sleepy. Yawn.)
- **mowil** [maw-weel]: alive
  - Klowil: life (John 1:4)
- **msó / mesó** [m'so / muh-so]: rice (uncooked). Msó is the fast way to say mesó. Cooked rice is ken. **Msó** also means count: same spelling, same accent, different meaning.
  - Hyu yó msó: that rice is good
  - Example: Tadu se duen mulék bê gónô anì tmógó msó béléu? (who else is going to get home to cook rice for me?)

- **mwas** [m'wahs]: dawn
- **myehen** [myuh-huhn]: to marry (from yehen, spouse)
- **mólós** [mo-los]: clean; also pure, holy (là mólósen, dirty)
- **mólów** [mo-lohw]: to step in, calm things down, break up a fight; also correct/rebuke someone. Mólów is the name of the action; in real sentences use bnólów (Ne bnólów lu, I'll step in now; Bnólów kuy lu, let's all step in). Bnólówu lu anì là le sfatay: I stepped in between them so they don't fight
- **móyóng** [mo-yong]: fly. Hafak: wings
- **mli** [mlee]: bought. *"Mli me lomi mótól ekimel"* we bought a new motorcycle yesterday
- **móyô yó dé** [mo-yoh' yo deh]: should, has to (traditional; not in the Bible). *"Móyô yó dé kun keye peslamat bê gónó ye wen"* you should be thankful for what you have
### N

- **nawa** [nah-wah]: breath, to breathe
  - Nawahu: my breath (not the same as nwahu, "I get")
  - Kbong nawa: love (see kbong)
  - Kenbong nawahu u: I love you
  - Genléd nawa: rely on
- **ne** [nuh]: now, already, a change happening (like Tagalog "na"); about to
  - Ne + h + ending: ne ends in a vowel, so an h goes in before the ending (ne + -e = nehe, ne + -u = nehu). Endings that start with a consonant don't need it (nele)
  - Nehe / Ne(he): I will (do something), on your own, no object
  - Nehu: I will do something to something; also telling someone to do something
  - Nehu bentik u anay: I will wake you up later
  - Nehu bentik dé: just get up already
  - Nehu henken onuku haya: I will feed my chickens tomorrow
  - Nehu meken dé: (you) eat first
  - Nehe meken dé: I'm going to eat
  - Nehe bemli anay: I will buy first
  - Nehe dyó dé: I'm going to swim / take a shower
  - Nehi: you will (nehu works too, but it can also mean "I will")
  - Nele: they will
  - Nehi mulék: come back first
  - Ni vs ne: ni = right now, ne = already
  - Example: Tu ne ni (it's our turn)
  - Example: Ne meken dé (I'm going to eat)
- **nebel** [nuh-buhl]: find
  - Mebel: to find
  - Mebel du: he/she/it finds (something)
  - Example: Nehe mebel lomi utón bê lwu bulón (I will find new fish in 2 months)
- **nem** [nuhm]: six
- **nes** [nuhs]: clothes
  - Nesem: your clothes
  - Henslòem lemsek du nesem: put your clothes on faster
- **ngà** [ngah']: child, kid, son, daughter, offspring, baby (ngà libun, daughter; ngà logi, son)
  - Ngaen: his/her child (the accent drops when an ending is attached)
  - Ngaen tek sotu: his only child
  - Kem ngà: children
- **ngà libun** [ngah' lee-boon]: daughter
- **ngà logi** [ngah' law-ghee]: son
- **ngunte** [ngoon-tuh]: I don't know (general, straightforward, the quick shrug; Là t'ngónu is the full "I don't know it")
- **ni** [nee]: it, this; here's; right now; at the end, points to something right here
  - Nìen: this one, it (ni plus -en)
  - Kdaw ni / Ni: today
  - Sotu ni: the day after tomorrow
  - Example: Kehu bitil, ni ken para béléem (if you're hungry, here's food for you)
- **nihi** [nee-hee]: tooth, teeth (written ngihi in Matthew 5:38)
- **nitem** [nee-tuhm]: carry, bring it (you). Nitem do kun sélfónu: carry my phone, please
- **nmò** [n'maw']: work (mò nmò, go to work)
- **nô** [no']: where?; also the "is" for where something is
  - Nô (bê)?: at, on, in, or to where?
  - Nô (se)?: where is it?
  - Example: Coffee-hu nô bê ta lmisa (my coffee is on the table)
- **nogot** [naw-gawt]: hold
  - Nogotem: you hold
- **noko** [naw-kaw]: sugarcane
- **nóm** [nom]: taste
  - Andù nóm: no taste, bland
  - Deng mkó yóm nómen: its taste is gone (Mark 9:50)
  - Mnóm: tasty
  - Tey mnóm: delicious
  - Example: Utón nìen, téy mnóm! (this fish, it's very tasty!)
- **nóyó / nóyô** [no-yo / no-yo']: want; like; liked, loved
  - Nóyóu meken: I want to eat, I like to eat
  - Nóyóu meken du: I want to eat it/him/her
  - Nóyóu wong htò: I like jumping spiders
  - Nóyóu: I want (to)
  - Là nóyóu (du): I don't want (to)
  - Nóyóe: I am liked
  - Nóyóu u / Nóyô te u: I like you
  - Nóyóte u: I like you (the poetic way)
  - Example: Là nóyóu du ke-delete du (I don't want to delete it)
- **nan / na** [nahn / nah]: must, should, has to (Bible), takes the person ending: **Nane mulék ne**, I have to go home now. *"nan matay"* he must die (Acts 26:23). Other ways to say it: **Nehe mulék ne** (I'm going home now), **Ne mulék ne** (I'm going back now)

### O

- **o / ou** [aw / aw-oo]: me, I (ou is specifically me)
  - O yó: that's me
  - Ou yó: that's me, specifically me
- **o** [aw]: or (borrowed from English)
- **ofi** [aw-fee]: fire
- **ohu** [aw-hoo]: dog
  - Mlóy du lómón ke ohu: he runs like a dog
  - Tô kay ohu du: he looks like a dog
  - Skél le ohu: he and the dog are the same (skél le, they are the same)
  - Skél du ohu: the dog looks like him
- **ok ye néen / ok néen** [awk yuh neh-uhn / awk neh-uhn]: I'm fine
- **okóm** [aw-kom]: but
  - Okóm close: but close
- **olob** [aw-lawb]: wash (molob, washing hands, feet or things; nolob, washed; molob tdok, wash hands)
- **olob** [aw-lawb]: wash (molob, washing; nolob, washed). Molob tdok: wash hands
- **olohu** [aw-law-hoo]: I'm just
  - Olohem: you are just
  - Olohen: it's just
  - Olohu hlowon néen: I'm just joking
  - Example: Là, olohen kulón udì (no, just a little rain)
- **omin** [aw-meen]: and
  - Ominen: and maybe he/she/it
  - Ominem dé: you're welcome
- **onuk** [aw-nook]: chicken
  - Onuku: my chickens

- **onuk koyu** [aw-nook kaw-yoo]: bird, literally tree chicken
- **ówóng** [o-wong]: boat; also airplane
### P

- **pang** [pahng]: dad, papa
  - Pangu: my dad
- **Pastór** [pahs-tor]: pastor; the standard T'boli word for a priest (borrowed). The Bible says tau gel demsù (Deymar, Oct 15)
- **para** [pah-rah]: for (borrowed from Spanish)
  - Para bê: for something or someone (being given to them): Ken para bê kem ngà, food for the children
  - Para béléem: for you
- **péro** [peh-raw]: but (borrowed from Spanish)

- **pinya** [peen-yah]: pineapple (borrowed from Spanish piña, "pine cone," for how the fruit looks). The traditional word is **lanas**
- **pméló** [p'meh-lo]: pomelo
- **pnahón** [p'nah-hon]: weather

### R

- **radyu** [rahd-yoo]: radio
- **rambutan** [rahm-boo-tahn]: rambutan

### S

- **sa** [sah]: pure, all
  - Sa mata etahu: all eyes on me
  - Sa inget ganì o: I'm all sweat
- **sabad** [sah-bahd]: annoying
  - Téyu sabad u: you're annoying
- **safì** [sah-fee']: cow, ox (ngà safì, calf)
- **sala** [sah-lah]: nest (not salà, sin; the accent changes the word)
- **salà** [sah-lah']: sin, wrong (kem salà me, our sins); gemsalà: who wronged
- **salig** [sah-leeg]: trust
  - Ksalig: to trust
  - Gsalig: unintentionally trust
  - Hsalig: letting something trust something
  - Snalig: trust that's actively happening (salig with the -n- infix)
  - Ksaligem: your trust
  - Ksaligu ke Dwata: the trust I have for God
  - Snaligu Dwata: I trust in God
  - Hsaligu kóm ni kdéen: I will trust everything to you
- **santól** [sahn-tol]: santol
- **sargér** [sahr-gehr]: phone charger; also chargér, charger
- **sawang** [sah-wahng]: unmarried (Acts 21:9)
- **sbót / sebót** [s'bot / suh-bot]: friend (general word)
  - Dumu sbót: a friend
  - Uu dou dumu sbót: you are my friend (dou: my)
  - Ou kóm dumu sbót: I'm your friend
  - Dumuhu sbót: my friend (telling someone else)
  - Example: Miles omin Deymar sbót le (Miles and Deymar are friends)
- **sdô** [s'do']: pig
- **se** [suh]: is, am, are (goes in the middle); the "be" word for how someone is
  - Example: Kmoem se du? (how are you?)
- **sef** [suhf]: suck
  - Nsef: sucked (the n infix for something already done)
  - Hsef: to let someone (not me) suck
  - Ssef: both sucking
  - Msef: sucking
  - Sensesef: sucking together
- **seflifót** [suhf-lee-fot]: forgiveness given or asked of each other (Deng le seflifót lu lwu le, they already forgave each other)
- **sek** [suhk]: put on, wear (clothes)
  - Msek: wore, put on
  - Lemsek: putting on
  - Henslòu msek du swelu eginu hlafus: I put my pants on fast earlier this morning
- **semgyok** [suhm-gyawk]: watch over, take care of (like a shepherd with sheep). Confirmed Oct 15
  - **tau semgyok ubiha**: shepherd, the person who watches the sheep (Luke 2:8)
  - **sen-gyok**: same word, different form. *"Hol sen-gyok ye yó kem tau deng hesegyok Dwata kuy"* shepherd the flock of God (1 Peter 5:2)
  - **kesegyoken**: his way of caring. *"Ou se yóm tau tilob kesegyoken ubiha"* I am the good shepherd (John 10:11)
- **semngal** [suhm-ngahl]: sing (from sngal, song)
- **sfangat** [sfah-ngaht]: wait for each other (Sfangat le bê gónô fedyan, they wait for each other at the market)
- **sfatay** [sfah-tai]: fight each other (là le sfatay, so they don't fight)
- **sfek** [sfuhk]: cut down a tree (senfeken, is cut down)
- **sfek** [sfuhk]: cut down a tree
- **simbahan** [seem-bah-hahn]: church (borrowed from Tagalog); kem tau hemtahu, the believers
- **slidut** [slee-doot]: spoon
- **sngal** [s'ngahl]: song (kesngalen, his singing)
- **snilas** [snee-lahs]: slippers (borrowed, like Tagalog tsinelas)
- **solu** [saw-loo]: front (bè soluhen, in front of him)
- **som** [sawm]: ingredients; seasonings, herbs and spices
  - Som lemnaw: herbs (literally "green ingredients"; Matthew 23:23, Luke 11:42)
  - Dê kay som: spices, like cinnamon (Revelation 18:13)
- **nsom** [n'sawm]: season it (Nsomem kun, season it please)
- **star apól** [stahr ah-pol]: star apple (borrowed from English). Apple itself only appears in the Old Testament (Proverbs 25:11, Song of Songs, Joel), so the T'boli Bible has no word for it
- **ston te kdeng** [stawn tuh k'duhng]: we'll see each other later (Ston te anay is "we'll see each other first")
- **stulón** [stoo-lon]: talk together (from tulón, tell)
- **tuyù** [too-yoo']: soy sauce (borrowed). Confirmed Oct 15
- **tulón** [too-lon]: tell. **Tulónem do**: you told me. Not tnulónem o, which is about being said or talked about (like tnudaen o, he stoned me)
- **sudeng** [soo-duhng]: sword, knife, long blade
- **sual** [soo-ahl]: thorn
  - **semual / smual** [suh-moo-ahl / smoo-ahl]: grows thorns. Ni bulók nien tey alì smual: this flower here has so many thorns
  - **semnual** [suhm-noo-ahl]: grows thorns by itself (koyu semnual, a thorny tree, Matthew 7:16)
  - **snual** [snoo-ahl]: kulitis, spiny amaranth. A thorny weed people cook and eat as a vegetable
- **sulat** [soo-laht]: writing, a letter (smulat, writing it; snulat, written; hsulat boluy, sign up)
- **sulat dwata** [soo-laht dwah-tah]: the Bible, literally "God's writing"
- **syudad** [syoo-dahd]: city
- **sélfón** [sehl-fon]: cellphone (borrowed, spelled how it sounds)
- **sélék** [seh-lehk]: lips, side to side (corners of the mouth)
  - Bolok sélék!: (cuss) rotten lips
- **senbol** [suhn-bawl]: mix (senbolem, mix it). Confirmed Oct 15
- **senla / pritu** [suhn-lah / pree-too]: fry
  - Senlakuy: we fry
  - Example: Fakay kô ke senlakuy lu ni kem utón, lwu libu wolu latu sfolò syóm? (can we fry these 2,819 fish?)
  - Senlahu lu: I fry them
  - Example: Soke bitil, senlahu ken tnaw (when I'm hungry, I fry leftover rice)
  - Example: Senlahu ken tnaw, kayà meken kuy (I fried the leftover rice, so let's eat)
- **sfeng** [sfuhng]: enough (sfeng ken me, enough food for us, Matthew 6:11)
- **sgeng** [s'guhng]: at the same time (Tagalog "sabay")
  - Anì le sgeng tmowok: so they grow together
- **sidek** [see-duhk]: bad
  - Example: Nuclear bom tey sidek ni. (the nuclear bomb is very bad)
- **sigel** [see-guhl]: arms
- **silà** [see-lah']: corn; also lightning (same spelling, same accent, different meaning)
  - Silaem: your corn (the accent drops when an ending attaches)
  - Silà le: their corn (never silale)
- **skas** [skahs]: break
- **skél** [skehl]: same
  - Skél le ohu: he and the dog are the same (skél le, they are the same)
  - Skél du ohu: the dog looks like him
  - Skél bê: the same as, like (before a thing: skél bê ChatGPT)
  - Ou skél béléem: I'm like you, I'm the same as you
  - Uu skél béléu: you're like me
  - Skél + owner word merges into the "too" words: skél kóm becomes skóm (you too)
- **skóm** [skom]: you too, as well as you (from skél kóm)
  - Hyu hlafus béléem skóm: good morning to you too
- **sdo / sdou** [s'daw / s'daw-oo]: me too, as well as me
  - Ominu meken sdo(u): and I'll eat too
- **skun** [skoon]: him/her/it too, as well as him/her/it
- **skul** [skool]: them too, also them
  - Kehegdemu du bitil le skul kem wongu: I think my spiders are hungry too
- **skut** [skoot]: us too, same as us (you and me)
- **sket** [skuht]: enough
  - Sket ne ni: this is enough
  - Sket kut: we're the same
  - Sket kut nê: we're just the same
  - Sket kul: they're just the same
  - Sket te: you and I are the same
- **slamat** [slah-maht]: thanks
  - Bong slamat: thank you so much
  - Slamat béléu: thanks to me
  - Slamat béléem: thanks to you
  - Slamat béléen: thanks to him/her/it
  - Slamat béléle: thanks to them
  - Slamat béléye: thanks to you all
  - Slamat bélékuy: thanks to all of us
  - Slamat béléte: thanks to just you and me
- **s'ngal** [s'ngahl]: title of a song
- **slò** [slaw']: fast
  - Slòem dé: hurry up!
  - Henslòem (dé): (you) hurry! make it fast
  - Henslòu: I (do it) fast
  - Henslòu mlóy ebuteng: I was running fast last night
  - Henslòu msek du swelu eginu hlafus: I put my pants on fast earlier this morning
  - Henslòem lemsek du nesem: put your clothes on faster
- **smakay** [smah-kai]: riding
- **snata / utóm** [snah-tah / oo-tom]: music. **snata** is the sound, the music itself; **utóm** is the tune or tone
- **soging** [saw-gheeng]: banana
- **sok** [sawk]: if, when (another word for ke)
  - Soke bitil: when I'm hungry (the person ending goes on sok)
  - Sok kifu: at night
  - Sok kemdaw: during the day
- **sélés nawa** [seh-lehs nah-wah]: two people secretly hating each other
- **sólók** [so-lok]: ask; question (careful: solok, without the accents, is light) (just asking, a question; for asking for something use mni)
  - Smólók dé: let me ask
  - Smólók du: he asked
  - Smólók du ke tonem yehenen kun: he asked if you saw his wife
  - Ne snólók du dé: I'll ask him
  - Ne snólók Grok anay: I'll ask Grok first
  - Snólóken u du: he asked you
  - Gsólók: unexpectedly or accidentally get asked
- **solok** [saw-lawk]: light (careful: sólók, with the accents, is ask)
  - Solok gas: lamp oil, kerosene (what older people say; the Bible says lenagas)
  - Gsolok: accidentally get flashed (light in your eyes)
  - Snolokem du kun: flash him with the light! (command)
- **sómól** [so-mol]: grain rice (uncooked)
- **sotu** [saw-too]: one; another (sotu / dumu)
  - Sotu ni: the day after tomorrow (when talking about dates)
  - Tek sotu: only one
- **S'twoli** [s'twaw-lee]: siblings ((Dumu) S'twoli)
  - Twolihu: my siblings
- **subù** [soo-boo']: sad
- **sumóng** [soo-mong]: lips
  - Bolok sumóng!: (cuss) rotten lips
  - Mfól sumóng!: (cuss) thick lips
- **sfolò** [sfaw-law']: ten (sotu + folò merged, "one ten")
  - Sfolò sotu: 11
- **sut** [soot]: show up; be born
  - Msut: being born, being introduced. The subject does it on its own
  - Hsut: intentionally show up; intentionally born. Someone does it to the subject
  - Gsut: unexpectedly show up
  - Msut du kimel: he was born yesterday
  - Hsut le du ekimel: he was born yesterday, by them
  - Hsut yéen du: he was birthed by his mother
  - Msut gu bê yéen du: he came through his mother
- **swel** [swuhl]: pants
  - Swelu: my pants
- **syó du?** [syo doo]: what's up?
- **syóm** [syom]: nine

### T

- **ta** [tah]: above
  - Bê ta: on top of
- **taba** [tah-bah]: call; phone call. **tnaba** [t'nah-bah]: called. **ktaba** [k'tah-bah]: will call. Bible: *"Deng tnaba Dwata yu"* "God has called you" (1 Corinthians 1:2)
  - When will you call me? / When did you call me?: **Kilón ktabahem do?** Context decides which. **Kilón ke ktabahem do? / Kilón kektabahem do? / Kilón kekktabahem do?** work the same way (Deymar, Oct 15)
  - I'll call you (later / soon): **Tnabahu u he / Tnabahu u dkeng**
- **tadu / tau du** [tah-doo / tah-oo doo]: who?
  - Tadu yó?: who's that?
- **tagad** [tah-gahd]: wait; also "yet" in bê tagad
  - Tagad he: wait a bit
  - Bê tagad tungô he: don't sleep yet
- **tahu** [tah-hoo]: true
  - Tahu yó: that's true, agreeing
  - Tahu kô?: is it true? is it right? correct?
  - Tahu kô ni?: is it real?
  - Ell, tahu ni: yes, it is real
  - Ell, tahu yó: yes, that's real
  - Hentahu: to believe (from tahu, true)
  - Hemtahu: is believing
  - Example: Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged? (do you believe eating red-eye fish together and sucking their meat can help us grow muscle?)
- **tau** [tah-oo]: person
  - Tau logi: man; tau libun: woman
  - Kem tau: people
  - Tau tmolok: a person who teaches
- **tau datù** [tah-oo dah-too']: person of higher rank
- **tau geta** [tah-oo guh-tah]: rich person
- **tau mulung** [tah-oo moo-loong]: healer, a person who gives medicine
- **tau tahà** [tah-oo tah-hah']: tall person
- **tdak / trak** [t'dahk / trahk]: car (from truck). Same word as **tdak**, drop (leak)
  - **tdak**: drop, as in a leak. **temdak** [tuhm-dahk]: dripping, leaking. Bible: sweat dripping to the ground (Luke 22:44). **ketdak** [kuht-dahk]: being dropped, leaked
  - For a drop as in falling, use **btang** [b'tahng]
- **te** [tuh]: you and me; me and you
  - Lwu te yó: that's the two of us
  - Stolok te: we (you and I) teach each other
- **te kwangu** [tuh kwah-ngoo]: behind me, literally "at my back"
- **tek** [tuhk]: only
  - Ngaen tek sotu: his only child
- **tek sotuhu** [tuhk saw-too-hoo]: alone, just me
- **tekuy** [tuh-kooy]: we, let's
- **tembol** [tuhm-bawl]: play music
- **tembó beng** [tuhm-bo buhng]: window
- **temdak** [tuhm-dahk]: dripping, leaking (from **tdak**). Bible: Luke 22:44
- **temngel** [tuhm-nguhl]: look at someone
- **temngón** [tuhm-ngon]: smart
  - Téyu temngón: you're very smart
- **tenduk** [tuhn-dook]: pain
- **tey / téy** [tuhy / tay]: very
  - Teye: I am very
  - Téyu: you are very
  - Téy-: he/she/it is very
  - Téyle: they are very
  - Téyye: you all are very
  - Téykuy: we are very
  - Téyte: we (you and I) are very
  - Téy kinì: very hot
  - Téy wen: a lot, many (literally "many have")
  - Téyu the best: you're the best
- **tfayà** [t'fah-yah']: papaya
- **tgayan** [t'gah-yahn]: cup
- **ti** [tee]: foot, feet (tihen, his feet; tihem, your foot)
- **tibig** [tee-beeg]: tibig, Philippine wild fig (borrowed; no everyday T'boli word, not in the Bible)
- **tibó** [tee-bo]: strike with a blade (tnibóhen, cut it off)
- **tihang** [tee-hahng]: carry on the shoulder
- **tikeb** [tee-kuhb]: shut, close, cover (tmikeb, shutting it; tnikeb, shut)
- **tikeb** [tee-kuhb]: shut, close, cover (tmikeb, shutting; tnikeb, shut). Bak tikeb: door, "the opening that shuts"
- **tilibisyun / TB** [tee-lee-bees-yoon]: TV, television
- **tilob** [tee-lawb]: good, cool, nice, beautiful (the general word)
  - Tilob du: it's beautiful
  - Both tilob and K'nóón work for things like a T'nalak
  - Example: Okóm tey tilob ni kem utón ni (but these fish are so beautiful)
- **tilów** [tee-lohw]: try, taste
  - T'milów: trying, tasting (going to try something)
  - T'nilów: being tried or tasted (with the endings, the m becomes n)
  - M'tilów (Metilów): being tasted
  - Tilówem: you try
  - Tilówu: I try
  - Tilówte: let's try, just you and me
  - T'milówu: come try or taste it
  - T'nilówem: you, try or taste it
  - T'nilówen: he/she/it is trying or tasting it
  - T'milówle: they're trying or tasting
  - T'nilów le: they are trying or tasting it
  - T'milówye / T'nilówye: you all try or taste it, come try it
  - T'milówkuy / T'nilówkuy: let's try it
  - T'milówte: just you and me are trying or tasting
  - Deng t'nilówu ni / Deng tistingu ni: I already tried it
- **tilów** [tee-lohw]: challenge, temptation
  - Tilów mgel: hard challenges (Matthew 6:13)
- **tindà** [teen-dah']: store. Bible: Matthew 25:9
- **tiol** [tee-awl]: bones
- **tisting** [tees-teeng]: tasting (borrowed from English)
- **tlangas** [t'lah-ngahs]: locust
- **tlu** [t'loo]: three
- **tlumfà** [t'loom-fah']: sandals, shoes (tlumfaem, your sandals)
- **tluyab** [t'loo-yahb]: yawn
- **t'ngón** [t'ngon]: know
  - T'ngónem: you know; do you know?
  - T'ngónu: I know
  - Deng t'ngónu ne: now I know
  - Hetngón: to let someone know (h- + t'ngón)
  - Example: T'ngónem bon yó "béléem" meaning-ngen? (do you know what "béléem" means?)
  - Example: Là t'ngónu du ke hyu ktolok le do (I don't know if I'm being taught well)
- **tmaba** [t'mah-bah]: call out, shout
- **tnaw** [t'now]: cold
  - Hetnaw: make cold; being frozen by (something)
  - Hetnawem ken: make the food cold (you do it)
  - Hetnawen u yó: it'll make you cold
  - Tnawu yó: you'll be cold
  - Ken tnaw: leftover rice
- **tudà** [too-dah']: throw (tudaen, he threw it). **Tnudaen o**: he stoned me (threw at me)
- **tul** [tool]: ever (là kô deng, never have)
- **tulad** [too-lahd]: image, likeness; any image, like a drawing or a reflection. Bible: *"Tulad du de nô du nim filak ni?"* "Whose image is this?" (Matthew 22:20, Mark 12:16, Luke 20:24)
- **twok** [twawk]: palm. In the Bible it's the date palm (doun twok, palm branches, John 12:13). Not the coconut (lfò)
- **tulud** [too-lood]: push
- **tulud** [too-lood]: push (tuluden, he pushed it). Tuluden ou bè lewà: he pushed me outside
- **tóbong** [to-bawng]: help (the general word). **Tnóbóngem o**: you helped me
  - Tnóbong: to help
  - Stóbóng: helping each other
  - Gtóbóng: being helped (unexpectedly)
  - Example: Stóbóng le anì le sgeng tmowok bê kehnagì le udél (they helped each other grow in studying languages)
- **todol** [taw-dawl]: next
  - Todol bulón: next month
  - Todol fedyan: next week
- **tódô** [to-do']: right away, immediately
- **tógó** [to-go]: cook
  - Tmógó: cooking (hasn't happened yet)
  - Tnógó: to cook; being cooked
  - Tnógóu lu kô ke senlahu lu?: should I cook them or fry them?
  - Tnógóhu kul: I cook theirs
  - Deng tógó ne ken: the rice is already cooked
- **toit** [taw-eet]: little clitoris (vulgar)
  - Stoiten!: (cuss) her little clitoris!
- **tolo** [taw-law]: still
  - Tole me: we are (were) still
  - Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal: um, we were still walking, then we saw a snake
- **tolok** [taw-lawk]: teach. **Tnolokem o T'boli**: you taught me T'boli
  - Tmolok: teaching, about to teach
  - Tnolok: being taught
  - Gtolok: being taught unexpectedly
  - Htolok: wanting to be taught
  - Stolok: teaching each other
  - Ktolok: being taught
  - Toloku kóm: I teach you
  - Tnoloku: I teach (-u, not -hu)
  - Tnoloku kóm: I keep teaching you (ongoing)
  - Tolok te kóm: something I taught you in the past, just us
  - Tnolokem o(u): you taught me
  - Tnoloku u(u): I taught you
  - Ktolok le do: they taught me; the teaching they got through to me
  - Stolok te: we (you and I) teach each other
  - Stolok me: we teach each other, but not you
  - Example: Là tnoloku kóm anìu baling sidek (I don't teach you to become bad)
- **ton** [tawn]: see; also found (the thing found comes after). **Tonen o Pangu**: my dad saw me (no tn- here, not tnonen)
  - Mton: to see
  - Gton: unintentionally being seen
  - Gton du: he/she/it was seen, was found (the real passive; ton le du is "they found him")
  - Kton: already seen, was seen
  - Example: Ekimel ton le du (yesterday he/she/it was found)
  - Example: Ekimel kton le du mógów bê tuen (yesterday he was seen walking there)
  - Tonen: he/she/it found
  - Tonu: I found
  - Tonem: you found
  - Tonle: they found
  - Tonye: you all found
  - Tonkuy: we found
  - Tonte: you and I found
  - Ston: see each other (two people)
  - Bud te ston he: see you (again), literally "we two see each other again"
- **tong** [tawng]: so (X, so Y)
  - Tonge: so I
  - Tongu: so you (tong takes -u, not -em; and du at the end, not -en)
  - Tongu lmangat: so you screamed
  - Tong (something happened) du: so he/she/it (did something). Tong kmuli du: so he/she/it laughed
  - Tong le mulék: so they left / went back
  - Tong kuy mlóy: so we ran
  - Tong te mluy: so we (you and I) tripped, fell and rolled
  - Tong ye hemsag: so you guys shouted
  - Bitile tonge meken: I'm hungry, so I'm eating
  - Kay le bitil, tong henkenu kem kuyingu: because they're hungry, I'll feed my cats
- **tô** [to']: going to, about to; trying to
  - Tô kay: looks like (Tô kay ohu du, he looks like a dog)
  - Tô mlóy du: he's trying to run away
- **tonok** [taw-nawk]: earth, ground (te tonok, on earth)
- **tob** [tawb]: taste. Confirmed Oct 15
  - Gtob / gtób [g'tawb]: get a taste (Luke 14:24, 1 Peter 2:3)
- **tooh** [taw-awh]: clitoris (vulgar)
  - Stoohen!: (cuss) her clitoris!
- **tóu** [to'-oo]: you're going to
  - Tóu tungô mekô?: you're going to sleep, really?
- **towok** [taw-wawk]: grow
  - Tmowok: to grow
  - Gtowok: being grown
  - Tnowok: something growing in or on something
  - Stowok: growing together, for each other (not "sensetowok")
  - Htowok: (help to) grow, in Gtóbóngen tu htowok unged (can help us grow muscle)
- **trok** [trawk]: hands
- **tu** [too]: far, there; also us
  - Tu dé: over there
  - Tu du: he/she/it is over there
  - Tu lu: there they are, they're over there
  - Tu mi: there we are; that's us (to someone who isn't part of it)
  - Tu tu: there we are (to someone who is part of it)
  - Tu yó: that's us (to people who are part of it, or pointing at something far off)
  - Tu ne yó: that's our turn
  - Tu ne ni: it's our turn
  - Tu mi tmógó utón: there's us, cooking fish
  - Tu works for directions too
- **tungô** [too-ngo']: sleep
  - Tungóu: you sleep
  - Gtungô: sleepy
  - Gô tungô: bed, a place to sleep
  - Bê e dou tungô: I'm not sleeping yet
  - Example: Tungóu ne, wong. (sleep now, spider.)
- **twogu** [twaw-goo]: elder
- **twoli** [twaw-lee]: sibling, brother or sister (twolihen, his/her sibling; twolihem, your sibling; setwoli, siblings to each other); also youngest (ngà són twoli, the younger son, Luke 15:13)

### U

- **u / uu** [oo / oo-oo]: you (one person); uu is specifically you
  - U yó: that's you
  - Uu yó: that's you, specifically you
- **udas** [oo-dahs]: time
  - Bon udas ni?: what time is it?
  - Bon udas du ne ni?: what time is it now?
  - Bon uras ne?: what time is it now? (not Hilu uras ne; Deymar, Oct 15)
  - Alas trés: it's 3 o'clock. Clock times use T'bolized Spanish or English numbers
  - Alas trés hlafus: 3 in the morning (add the time of day after)
  - Bon kdaw du ni?: what day is it today? Answer: Lunis, or Lunis kdaw ni
- **udasan / urasan** [oo-dah-sahn / oo-rah-sahn]: clock, the thing that keeps the hours. **uras / udas** [oo-rahs / oo-dahs]: hour. Bible: *"dô tlu uras kimel"* "about three in the afternoon" (Acts 10:3)
- **udél** [oo-dehl]: language; word (the same word)
  - Kem udél: words
  - Udél T'boli: the T'boli language
  - Udél Dwata: gna kesfasad ne lomi kesfasad: the T'boli Bible, old covenant and new covenant (gna old, lomi new, kesfasad covenant)
  - Yóm Udél: the Word (John 1:1)
- **udì** [oo-dee']: small
- **ukol** [oo-kawl]: short
- **ulal** [oo-lahl]: snake
  - Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal: um, we were still walking, then we saw a snake
- **ulék** [oo-lehk]: back
  - Mulék: leave, go back
  - Tong le mulék: so they left / went back
  - Mulék: coming back to (hasn't happened yet)
  - Kulék: coming back, came back
  - Kulékem: you'll come back (the k- form already carries "will")
  - Gulék / Mulék: get back, return
  - Hulék: return
  - Khulék: to return
  - Nehi mulék: come back first
  - Example: T'ngónem kô kmò khulék kul bê gónô le ni? (do you know how to get them back to their home?)
- **ulat** [oo-laht]: veins
- **unged** [oo-nguhd]: muscle
  - Unged wen: more muscle
- **unget / karni** [oo-nguht / kahr-nee]: meat
- **ungé** [oo-ngeh]: rat
- **uras / udas** [oo-rahs / oo-dahs]: hour. Clock: **udasan / urasan**
- **utek** [oo-tuhk]: brain
- **utón / isdà** [oo-ton / ees-dah']: fish
  - Kem utón: fish (more than one)
  - Utón hulô mata: red-eye fish
- **utóm** [oo-tom]: tune, tone; music notes; also pray, chant, rhyme. Bible: remembering someone in prayer, *"gel utóm me yu"* "we keep mentioning you" (1 Thessalonians 1:2), and *utóm lingón Dabid*, a psalm of David (Acts 13:35). For the sound of music, use **snata**
- **utóng** [oo-tong]: debt (utóngu, my debt)
- **uyó** [oo-yo]: face

### W

- **wek** [wuhk]: hair
- **widyu / bidyu / bidju** [weed-yoo / beed-yoo / beed-joo]: video. **bmidyu** [b'meed-yoo]: taking a video, filming. **bnidyu** [b'need-yoo]: being filmed; was filming
- **wolu** [waw-loo]: eight
- **wen** [wuhn]: there is, there was (used whenever something shows up in a story); have, has; more (tey works too)
  - Là e meken kay wen Pangu: I'm not eating because my dad is there
  - Téy wen: a lot, many
  - Unged wen: more muscle
  - Example: Kdaw ni, wen wong nô bê ta lmisa (today, there's a spider on top of the table)
  - Example: Coffee-hu wen klamay nô lemmen (my coffee has sugar in it)
- **wong** [wawng]: spider
  - Wong htò: jumping spider
  - Kem wongu: my spiders
  - Example: Là e likô bê wong (I'm not scared of spiders)

- **wót** [wot]: keep going, continue doing something (short for lemwót)
  - Wót ne: let's go
  - Wót wong htò: the spider keeps jumping
### Y

- **yak** [yahk]: shy, shame (the root)
- **yake** [yah-kuh]: hope, hopefully; should have (also sana from Tagalog, tanì from Hiligaynon)
  - Yake uu dé: it should have been you
  - Yake làen kmulón haya: hopefully it won't rain tomorrow
- **yê** [yeh']: mother
  - Yéen: his/her mother
  - Hsut yéen du: he was birthed by his mother
  - Msut gu bê yéen du: he came through his mother
- **yehen** [yuh-huhn]: spouse, wife or husband (yehenem, your husband, John 4:16); myehen, to marry
  - Yehenen: his wife
- **yó** [yo]: that
  - (Bê) yó: there
- **yóm** [yom]: the
  - Example: Yóm nuclear clock làen skas se (but the nuclear clock doesn't break)
- **yu** [yoo]: you (2 or more people)
  - Yu yó: that's you all

## English to T'boli index

Look up an English word to find the T'boli headword. The full meaning and forms are under that headword in the dictionary.

### A to C

- **afraid**: likò / likô
- **afternoon**: kimel
- **again**: bud; he (again, hopefully)
- **airplane**: ówóng
- **altar**: gónó le gel demsù (Bible)
- **alive**: mowil
- **all**: kdê
- **all, everyone**: kdê (kdéen, all of it; yóm kdéen tau, everyone)
- **allow**: fakay
- **alone**: tek sotuhu (just me)
- **already**: deng; ne
- **always**: gel
- **and**: omin
- **angry**: lóbô (hlóbô, hnóbô)
- **annoying**: sabad
- **another**: sotu / dumu
- **ant**: gulom
- **any ulam over there, guys? (hopeful hint)**: Lemnaw bê yó dé, guys (Lemnaw beyo de guys)
- **anymore**: bud (ne)
- **arms**: sigel
- **arrogant, proud (bad)**: hegmón
- **as, serving as**: henged (henged dsù, as an offering)
- **ashamed, embarrassed**: kenyak
- **ask**: sólók
- **ask for, request**: mni
- **assigned to, the one**: fen
- **attitude, personality**: adat
- **aunt**: anti
- **avocado**: bkadu
- **baby**: ngà
- **back (body)**: kwang
- **back (return)**: ulék
- **backyard**: kwang beng
- **bad**: sidek
- **banana**: soging
- **bathe**: dyo
- **bathe**: dyo
- **beautiful**: tilob; K'nóón (very beautiful)
- **because**: kay (kaye, because I); mlan bê (because of)
- **become**: baling; kehe / kehi
- **bed**: katri
- **bed**: gô tungô (under tungô)
- **before the world, in the beginning**: gu laanen là deng wen benwu he
- **behind me**: te kwangu
- **believe**: hentahu (under tahu)
- **belly**: blutut
- **beside**: lohok; bê
- **bible**: sulat dwata
- **big**: bong; kbong
- **bird**: onuk koyu
- **bitter**: héét
- **black**: hitem
- **bladder**: hnobò
- **bland**: andù nóm
- **blanket**: kumù
- **blood**: litô
- **blue**: ginggung
- **beautiful, nice, fine**: minggel
- **boat**: ówóng
- **body (my)**: lówóhu
- **boil**: kodok
- **bones**: tiol
- **book**: bok
- **bored**: closest is hedem (think)
- **born**: sut (msut, hsut)
- **borrow**: mdóm
- **boy**: logi
- **brain**: utek
- **branch**: hanga
- **break**: skas
- **break up a fight, calm things down**: mólów
- **breath, breathe**: nawa
- **bright**: lmayag
- **bring**: mit edini; nit, nwit (brought)
- **brother, sister, sibling**: twoli
- **brownout**: branawt, brownout
- **but**: okóm; péro
- **buy**: bemli
- **calamansi**: klamansì (standard); klamunding (traditional)
- **calf**: ngà safì
- **call / phone call**: taba. **I'll call you**: Tnabahu u he / dkeng
- **call out, shout**: tmaba
- **camera**: kudak (traditional), kmera (standard)
- **can, may**: fakay
- **car / truck**: tdak, trak
- **carabao**: bew
- **carry**: nitem (you carry it)
- **carry on shoulder**: tihang
- **carry**: mit
- **cat**: kuying
- **celebrate, happy**: hligal
- **cellphone**: sélfón
- **chair, seat**: bangkù
- **challenge, temptation**: tilów
- **chant / prayer / rhyme**: utóm
- **charger**: chargér, charger, sargér
- **cheap**: bratu, là mebtesen
- **chest**: kfu
- **chicken**: onuk
- **child**: ngà
- **chili**: mala
- **church**: simbahan
- **city**: syudad
- **clean**: mólós
- **climb**: mkaf
- **clock**: udasan, urasan
- **close, shut**: tikeb
- **close, shut**: tikeb
- **clothes**: nes
- **cloud, cloudy**: lobun (lmobun)
- **coffee**: kfi
- **cold**: tnaw
- **color, style, design**: betek
- **come**: hene; ene
- **come back**: ulék (mulék)
- **continue**: hlós
- **cook**: tógó; mekay ken (cook rice)
- **cooking pot**: kuleng
- **corn**: silà
- **cough**: kow
- **count**: msó (same word as rice). Nsóhem kun msó: count the rice, please
- **cousin, relatives**: dumuhen setwoli
- **covenant**: kesfasad (under udél)

- **cut**: kenleng (cut off); sfek (cut down a tree)
### D to H

- **cow, ox**: safì
- **create, made**: dlimun
- **cry**: mkik
- **cup**: tgayan
- **curse**: htolo
- **cut down a tree**: sfek
- **cut branches, cut in nature**: mtob
- **cut off**: kenleng
- **dad, papa**: pang
- **dance**: madal
- **dark, getting**: kmifu
- **darkness**: kmifu, kifu
- **daughter**: ngà libun
- **dawn**: mwas
- **day**: kdaw
- **dead, die**: matay
- **death**: katay
- **death**: hatay
- **debt**: utóng
- **delicious**: téy mi (under mi); tey mnóm (under nóm)
- **desert sand**: kfung
- **dim**: kifu (kmifu, getting dim)
- **dirty**: là mólósen
- **do**: boyu
- **doctor**: duktur, tau mulung
- **dog**: ohu
- **don't abandon, don't leave**: béem bayà
- **done**: deng
- **don't**: bê
- **donkey**: kudà
- **door**: bak tikeb, beng
- **down**: elaan
- **draw a sword**: dmilot
- **dream**: kna
- **drink**: minum
- **drop (leak)**: tdak. **dripping**: temdak. **dropped, leaked**: ketdak. **drop (fall)**: btang
- **drunk (intoxicated)**: lengel
- **dry**: mékéng
- **durian**: dóryan
- **ear**: klingu
- **earlier this morning**: eginu hlafus
- **earlier**: eginu
- **earth**: tonok (te tonok, on earth)
- **eat**: ken (meken)
- **egg**: itlug
- **eight**: wolu
- **elder**: twogu
- **electricity / power**: kurinti, ofi (literally fire)
- **empty**: hkawang
- **enough**: sfeng
- **enough**: sket; ket
- **even (I don't even)**: ganì
- **ever**: tul
- **every day**: key haya
- **every**: ket
- **expensive**: mebtes
- **extremely**: alì
- **eye**: mata
- **face**: uyó
- **fall**: mluy (trip, fall and roll)
- **far**: mayuk; tu
- **fast**: slò
- **fat**: mabù
- **father**: mà; pang
- **feed**: hemken
- **feed**: hken
- **feed**: henken (under ken); hefken, wants to be fed
- **feeling**: kegnóm
- **feet**: ti
- **female**: libun
- **fermented, leavened**: bali
- **fever**: des kinì
- **few**: là holen wen
- **field**: dnadu
- **fight (each other)**: sfatay
- **find**: kebel
- **find**: nebel (mebel)
- **fingers**: kyemet
- **fire**: ofi
- **first**: gna; anay (first, for now)
- **fish**: utón / isdà
- **fishing net**: huket
- **five**: limu
- **flash (with light)**: snolok
- **flower**: bulók
- **flowing**: mlel
- **fly**: móyóng
- **follow**: huli
- **foot**: ti
- **for**: bélé; para (bê); ke
- **forest**: dlag lamang
- **forget**: klifót; on purpose (good): kehlifót; pretend not to know (bad): hlifót
- **forgive**: hnifót
- **forgiveness**: seflifót
- **found**: ton
- **four**: fat
- **fragrant**: alì minggel boohen
- **fresh water**: él tahu
- **friday**: Byérnis
- **friend**: sbót / sebót; dumu sbót
- **frog**: fak
- **front**: solu
- **fruit**: bungu
- **fry**: senla / pritu
- **full (from eating)**: besow
- **garden, orchard**: hulu
- **garlic**: ahós
- **get up, wake up**: btik
- **get**: gwa; ma / gemwa; nwa
- **gift (what someone offers)**: dsuen (his/her offering)
- **ginger**: mala tonok (ground chili)
- **girl**: libun
- **give**: blay
- **glory**: klinggel
- **go**: gów
- **goat**: kambing
- **God**: Dwata
- **going**: lemwót
- **good**: hyu; tilob
- **grab, catch**: kemfô; caught in the act: gafit; catch fish: guta
- **grace**: klinggel; klinggel nawa
- **grandmother**: bé
- **grass**: bnes
- **dish (viand, ulam, putahe)**: lemnaw
- **grass (for animals)**: kluon
- **graze, eat (animals)**: mótób
- **green**: lemnaw
- **grow**: towok; henok; lemnok (growing)
- **guava**: byabas
- **hair**: wek
- **hair, a strand of**: balu
- **hands**: trok
- **happy**: hligal
- **hard**: mgel
- **hate**: kutó nawa (I hate you: Knutó nawahu u)
- **hour**: uras, udas
- **reject, dislike, deny**: kenbé (Kenbéu u)
- **have, has**: wen
- **he, she, it, him, her**: du
- **head**: kulu
- **hear**: gungol (hmungol, listen)
- **heart**: hosò
- **heaven, sky**: longit
- **heavy**: blat
- **help**: tóbong
- **here's**: ni
- **hide**: bnos; hide yourself: hebnos
- **high**: geta
- **hold**: nogot
- **hope**: yake (also sana, tanì)
- **horse**: kudà
- **hot**: kinì
- **house, home**: gónô
- **how long**: kegenen
- **how much?**: ket hilu?
- **how**: kmò
- **humble**: heglaan
- **hundred**: latu
- **hungry**: bitil
- **hurry**: géhél
- **hurry**: slòem dé; henslòem
- **hurt**: des

- **hypocrite, fake person**: tau gel hemtedeng knô
### I to N

- **husband, spouse**: yehen
- **I don't know**: ngunte
- **I, me**: o / ou; do
- **if**: ke; sok; dé kô
- **image**: tulad
- **immediately**: tódô
- **ingredients**: som
- **herbs**: som lemnaw
- **spices**: som
- **inside**: lem
- **into**: elem
- **jackfruit**: badak / barak (depends on the accent)
- **jaw, molars**: beeng
- **jealous**: inggit / sélus
- **joking**: hlowon
- **jump up**: hebetik
- **jumping**: htò
- **jumping spider**: wong htò
- **just**: len; olohu (I'm just)
- **keep going, continue**: wót
- **kerosene**: solok gas
- **kitchen**: kohù / kusina
- **kitten**: kukù
- **knees**: bukol
- **knife**: sudeng, kutsilyu
- **know**: t'ngón
- **lake**: lanaw
- **lamp oil**: lenagas (Bible); solok gas (traditional)
- **language**: udél
- **lanzones**: lansunis
- **last night**: ebuteng
- **later**: kdeng
- **laugh**: kmuli
- **laugh**: kuli
- **lead, govern**: malak
- **leader**: tau mò malak, the one who leads (Matthew 2:6)
- **leaf**: doun
- **lean**: hegléd
- **learn, schooling**: hnagì
- **leave**: mulék
- **left**: iwóng
- **legs**: haha
- **lemongrass**: ktai
- **lend**: hendóm; money: hutóng
- **let's go**: wót ne
- **let's, we**: tekuy
- **life**: klowil, mowil
- **lift**: mekay
- **light**: solok; layag (for not heavy, lmaan)
- **lightning**: silà (same word as corn)
- **like (enjoy)**: nóyô / nóyó
- **like (same as)**: skél (skél bê)
- **like, as**: lómón ke
- **like, it's**: lomon
- **lips**: sumóng
- **listen**: hmungol
- **listen**: hmungol, hnungol
- **live somewhere**: menwu
- **locust**: tlangas
- **long**: legen
- **looks like**: tô kay
- **lose, lost**: lana
- **love**: kbong nawa (under kbong and nawa)
- **magic / sorcery**: imò
- **male**: logi
- **mama**: mang
- **man**: tau logi
- **mango**: mangà
- **mangosteen**: mangustin
- **many**: dê
- **marang**: marang
- **market**: gónô fedyan
- **marry**: myehen
- **maybe**: dé kô
- **meat**: unget / karni
- **medicine**: bulung
- **pepper**: atsal
- **perfume, fragrance**: hboo
- **melon**: mélón
- **message / text**: udél (traditional and Bible), méséj, téks (standard)
- **mine, my**: do; dou; -hu
- **miss someone**: khahù
- **mix**: senbol (senbolem, mix it); bol (root)
- **monday**: Lunis
- **money**: filak
- **monkey**: iwas
- **month**: bulón
- **moon**: bulón
- **more**: wen
- **mosquito**: blawang
- **mother**: yê
- **motorcycle**: mótól
- **mountain**: bulul
- **mouth**: bak
- **mouth**: lembak
- **move on, forget on purpose**: kehlifót
- **mud, muddy**: hitok
- **muscle**: unged
- **music**: snata (sound, music), utóm (tune, tone)
- **near**: moni
- **neck**: lihol
- **need**: lóngón; kailangan
- **nest**: sala
- **never have**: là kô deng
- **new**: lomi
- **next**: todol
- **night**: kifu
- **nine**: syóm
- **no, not**: là; bê (refusing)
- **no one**: andù
- **noon**: kemdaw
- **nose**: ilung
- **nothing left**: gotu
- **nothing**: anduen
- **now**: ne; ni (right now)

### O to S

- **ocean water**: él mohin
- **oil**: hnolo
- **old**: gna
- **one**: sotu
- **onion**: bumbay
- **only**: tek
- **open**: lungkà
- **open**: lungkà
- **or**: o; kô ke; ke
- **other**: dumu
- **outside**: lewà
- **owner**: fun
- **pain**: tenduk
- **pants**: swel
- **papaya**: tfayà
- **past**: gna
- **pay**: bayad
- **pen**: lapis
- **penis**: botò
- **people, person**: tau
- **photo**: kudak
- **picture**: kudak
- **pig**: sdô
- **pineapple**: lanas (traditional); pinya (newer, from Spanish)
- **place**: benwu
- **plate**: huyów
- **play music**: tembol
- **play**: hampang
- **please**: kun
- **pomelo**: pméló
- **power**: ofi (electricity, general). **magic power**: imò
- **pretend**: to be someone: hlingu / hlingón; not to know: hlifót
- **price**: blihen
- **priest**: Pastór; in the Bible, tau gel demsù. **chief priests**: kem geta bè yó kem gel demsù. **high priest**: yóm hol geta bè yó kem gel demsù
- **prince**: man
- **princess**: boi
- **protect**: kenlung
- **properly, kindly**: hninggel
- **proud**: dóyón
- **pull**: dyol, demyol
- **pull, drag**: demyol
- **puppy**: katù
- **pure, all**: sa
- **push**: tulud
- **push**: tulud
- **question**: sólók
- **radio**: radyu
- **rain**: kulón
- **rain pouring down**: demsù (Matthew 7:25)
- **rambutan**: rambutan
- **rat**: ungé
- **read**: masa
- **really?**: mekô
- **red**: hulô
- **rely**: genléd
- **remember**: hentulón nawa
- **respect**: madat; respected, nadat
- **rest, lie down**: hegnô
- **return**: ulék (hulék, khulék)
- **rice (cooked)**: ken
- **rice (uncooked)**: msó / mesó; sómól (grain rice)
- **rice plant**: halay
- **rich person**: tau geta
- **riding**: smakay
- **right**: kwanan
- **river**: él mlel
- **road, way**: lan
- **robe**: heglomboy
- **rotten**: bolok
- **run**: mlóy / melóy
- **sad**: subù
- **salt**: kahì
- **salty**: héét
- **salt water, salty water**: él héét; él mohin (ocean water)
- **saltiness**: khééten
- **make salty**: hféét
- **same**: skél
- **sand**: helek
- **sandals, shoes**: tlumfà
- **santol**: santól
- **saturday**: Sbadu
- **say**: mon
- **scared**: likò / likô
- **school**: gónô mnagì
- **scold**: hnóbô (careful: hnobò is bladder)
- **scream**: lmangat
- **sea, ocean**: mohin
- **season (food)**: nsom (Nsomem kun, season it please)
- **see**: ton (mton, to see; gton, seen by accident; kton, was seen; ston, see each other)
- **sell**: hbalù
- **seven**: hitu
- **shameful**: hemyak
- **sheath**: lumaken
- **shepherd**: tau semgyok ubiha
- **shield**: klung
- **shining**: lemayag
- **shirt**: kgal
- **short**: ukol
- **should have**: yake
- **shoulder**: abal
- **shout**: hemsag
- **show up (unexpectedly)**: gfan
- **show up (on purpose)**: hegfan
- **show up**: sut (gsut, unexpectedly; hsut, on purpose)
- **shower**: dyó
- **shut, cover**: tikeb
- **shy**: yak; being shy: myak (Myak du, she's shy)
- **siblings**: S'twoli
- **sick**: gemnóm des
- **sick**: des
- **sin, wrong**: salà
- **sing**: semngal
- **sit**: myón
- **six**: nem
- **skin**: kulit
- **skinny**: lehen
- **sleep**: tungô
- **sleepy**: moo ktuk (under moo); gtungô
- **slippers**: snilas
- **slow**: ganag
- **small**: udì
- **smart**: temngón
- **smell**: boo
- **smelly, stinks**: moo
- **smoke**: kebel
- **snake**: ulal
- **so**: tong (tonge, so I); kayà
- **so, so that**: anì; kayà; ewen
- **sometimes**: kis-a / tlagsa (from Hiligaynon)
- **son**: ngà logi
- **song**: sngal
- **song**: lingón; s'ngal (title of a song)
- **soon**: géhél (also hurry)
- **sorry**: hnifótem o
- **soup**: bool; sóbów
- **sour**: aslum; héét; bali (fermented, gone sour)
- **soy sauce**: tuyù
- **speak**: mudél
- **spicy**: mala; kahang (chili: mala)
- **spider**: wong
- **spoon**: slidut
- **stand**: mdà
- **stand in for, represent**: henged lówó
- **star**: blotik
- **star apple**: star apól
- **stinks**: moo
- **stir**: kigol (Knigolem kun, stir it please)
- **steal**: mnagaw
- **still**: hanà; tolo
- **stomach**: blutut
- **stone**: botu
- **store**: tindà
- **strong**: kemgis
- **suck**: sef
- **suffering**: glayam
- **sugar**: klamay
- **sugar, put in**: knamay (Knamayem kun)
- **sugarcane**: noko
- **sun**: kdaw
- **sunday**: Akad
- **sunset, almost**: kmimet
- **surprise**: geslà
- **sweat**: inget
- **sweaty**: ninget
- **sweet**: mi

### T to Y

- **look at**: temngel
- **swim**: dyó
- **sword**: sudeng
- **table**: lmisa
- **take**: ma / mwa
- **take care of, watch over**: semgyok
- **talk together**: stulón
- **tall person**: tau tahà
- **taste**: tilów; nóm; tob (gtob, get a taste)
- **tasteless, bland**: andù nóm
- **tasty**: mnóm (under nóm)
- **teach**: tolok
- **teacher**: maistru / mestlu
- **teeth**: nihi
- **ten, tens**: sfolò; folò
- **testicles**: amil
- **text (message)**: téks, méséj, udél
- **thanks**: slamat
- **that**: yó
- **the**: yóm
- **them**: lu; kul (the whole group)
- **then (later)**: etu
- **there**: tu; (bê) yó
- **there is, there was**: wen
- **thick**: mfól
- **thief**: tau mnagaw
- **think**: hedem (kehegdemu du, I think)
- **thirsty**: meeng
- **this morning**: ni hlafus ni
- **this**: ni
- **thousand**: libu
- **three**: tlu
- **throat**: beklong
- **throw**: tudà
- **thunder**: lték
- **thursday**: Wibis
- **time**: udas
- **tired**: kapuy; lmiteg
- **to**: bê; bélé; ke
- **today**: kdaw ni (under kdaw)
- **tomorrow**: haya
- **tongue**: dilak
- **too, also**: skóm (you), sdo (me), skun (him/her/it), skul (them), skut (you and me)
- **tooth**: nihi
- **tornado**: balu
- **touch**: dù
- **touch**: dù (mdù, gemdù)
- **town**: benwu
- **trap**: fan
- **tree, wood**: koyu
- **trip**: mluy
- **truck**: tdak, trak
- **true**: tahu
- **trust**: salig
- **try**: tilów
- **trying to**: tô
- **tuesday**: Martis
- **tune / tone**: utóm
- **TV / television**: tilibisyun, TB
- **two**: lwu
- **um (filler, "ano")**: boyu
- **uncle**: angkel
- **under**: laan; bê
- **unmarried**: sawang
- **up to you**: kihu kóm
- **us (object)**: mi
- **us**: tu; te (you and me); mi / me (not you); kuy (all of us)
- **vegetable**: lemnaw
- **veins**: ulat
- **very**: tey / téy
- **video**: widyu / bidyu / bidju. **filming**: bmidyu. **being filmed**: bnidyu
- **vinegar**: langgaw
- **wait**: tagad; hangat (waiting for someone or something); kdeng (wait! at the start)
- **wait for each other**: sfangat
- **wake someone up**: bentik, bemtik
- **wake up**: bentik
- **walk**: mógów (nógów, continuously walking)
- **wall**: beng
- **want**: nóyó
- **want, will**: kóyô
- **wash**: olob (molob, nolob); mouf (face)
- **wash face**: mouf
- **wash**: molob
- **water jar**: lebwón
- **water**: él
- **watermelon**: not confirmed yet (mélón is melon)
- **waves**: lewók
- **we**: kuy; te; me
- **weak**: lunog
- **wear, put on**: sek (msek, lemsek)
- **weather**: pnahón
- **wednesday**: Myérkulis
- **week**: fedyan
- **wet**: héfê
- **what if**: kmoen kun ke (also kmoen kun, kmoen kun ke sok, kmoen ke sok)
- **what time is it?**: bon udas ni? / bon uras ne?
- **what**: bon
- **when**: kilón; sok
- **where are you from?**: gónóem lemwót du?
- **where were you born?**: gónóem msut? / góem sut?
- **where**: nô; góem; bê du
- **which one**: mahi du
- **white**: bukay
- **who**: tadu / tau du
- **whole**: klamangen
- **why**: moen
- **wide**: lamang
- **wife**: yehen
- **wild**: dlag
- **wind**: lenos
- **wind**: lnos
- **window**: bak bengaw, tembó beng, bintanà
- **woman**: tau libun
- **word**: udél
- **work**: nmò
- **world**: benwu
- **write**: sulat (smulat, writing; snulat, written)
- **year**: halay
- **yeast**: bulung henok
- **yellow**: mélél
- **yes**: Ell
- **yesterday afternoon**: ekimel kimel
- **yesterday**: Ekimel
- **yet**: he; tagad (in bê tagad)
- **you (one person)**: u / uu; kóm
- **you (all)**: yu
- **youngest**: twoli

## Phrases by topic

### Greetings and small talk

- **Hyu hlafus**: good morning
- **Hyu hlafus béléem skóm**: good morning to you too
- **Hyu kifu**: good night (more like good evening)
- **Hyu kifu béléem skóm**: good night to you too
- **Syó du?**: what's up?
- **Kmustahu du?**: how are you?
- **Kmoem du?**: how are you? what's up?
- **Kmoem se du?**: how are you?
- **Ok ye néen / Ok néen**: I'm fine
- **Kóm du?**: and you?
- **Là du**: nothing much
- **Bon nmoem (du)?**: what are you doing?
- **Anduen. Len myón.**: nothing, just sitting
- **Bon boluyem (du)?**: what's your name?
- **Boluyu Miles**: my name is Miles
- **Bê du góem lemwót du?**: where are you from?
- **Tagad he**: wait a bit
- **Bud te ston kdeng**: we'll see each other later
- **Bud te ston he**: see you (again), hopefully
- **Haya bud te ston he**: see you again tomorrow, hopefully
- **Bud etu he**: we will do it again; until then
- **Ell, tahu yó**: yes, that's true
- **Tahu kô?**: is that right?
- **Hene edi ni / Ene bê ni**: come over here / come here

### Thanks

- **Slamat**: thanks
- **Bong slamat**: thank you so much
- **Slamat béléem**: thanks to you
- **Ominem dé**: you're welcome
- **Slamat bê ke-teachem do**: thanks for teaching me
- **Slamat bê ke-sendem du**: thanks for sending it
- **Slamat bê ke-savem du kdéen**: thanks for saving all of it

### Food and drink

- **Lemnaw bê yó dé, guys** (also typed *Lemnaw beyo de guys*): Uh, any ulam over there, guys? A fixed phrase: translate it as a whole, exactly like this. Said while eating plain rice, hoping someone shares. Confirmed by Deymar, Oct 15
  - Works with any noun: [thing] bê yó dé, guys = Uh, any [thing] over there, guys? Graded 5/5, Oct 15
  - **Kahì bê yó dé, guys**: Uh, any salt over there, guys?
  - **Utón bê yó dé, guys**: Uh, any fish over there, guys?
  - **Kfi bê yó dé, guys**: Uh, any coffee over there, guys?
  - **Itlug bê yó dé, guys**: Uh, any eggs over there, guys?
  - **Filak bê yó dé, guys**: Uh, any money over there, guys?
- **Meken kuy**: let's eat
- **Kehu bitil, mekenu**: if you're hungry, eat
- **Kehe bitil, ne meken dé**: if I'm hungry, I'll eat
- **Deng kenu**: I ate
- **Denge meken**: I already ate
- **Là e deng meken he**: I haven't eaten yet
- **Ne meken dé anay / Ne meken he dé**: I'll eat first
- **Làe hlós meken se**: I didn't eat (I didn't go on to eat)
- **Besowe ne**: I'm full now
- **Denge besow**: I'm full (I'm already full)
- **Téy mi ken ni**: this food is delicious
- **Utón nìen, téy mnóm!**: this fish, it's very tasty!
- **Besowe ne. Utón nìen, téy mnóm!**: I'm full now. That fish was really tasty!
- **Téy aslum sinigang nìen, okóm téy mnóm**: this sinigang is very sour, but tasty
- **Yó kóm ken, ni do ken**: that's your food, this is my food
- **Ken para bê kem ngà**: food for the children
- **Mekenu silà kô ke ken?**: are you eating corn or rice?
- **Hyu yó msó**: that rice is good
- **Deng tógó (ne) ken / Ken, deng tógó (ne)**: the rice is already cooked
- **Kailanganu mekay ken. Anìe meken kdeng.**: I need to cook rice so I can eat later
- **Kdeng, hkinìu ken**: wait, I'll heat up the food
- **Hkinìem ken**: heat up the food (you do it)
- **Hetnawem ken**: make the food cold (you do it)
- **Soke bitil, senlahu ken tnaw**: when I'm hungry, I fry leftover rice
- **Senlahu ken tnaw, kayà meken kuy**: I fried the leftover rice, so let's eat
- **Senlahu itlug, kayà meken kuy**: I fried eggs, so let's eat
- **Hkodoke itlug para béléem, kayà meken kuy**: I'll boil eggs for you, so let's eat
- **Hkodoke béléem itlug**: I'll boil an egg for you
- **Hefkodoku béléeu kun él**: please boil me water (with my item)
- **Hkodoku béléeu kun él**: please boil me water (you find it)
- **Kmodok él ne / Kmodok ne él**: the water's boiling now
- **Coffee-hu kinì**: my coffee is hot
- **Coffee-hu nô bê ta lmisa**: my coffee is on the table
- **Coffee-hu wen klamay nô lemmen**: my coffee has sugar in it
- **Gel mi coffee-hu, wen klamay nô lemmen**: my coffee's always sweet, it has sugar in it
- **Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen**: my coffee has salt in it
- **Meenge, kayà minume o él**: I'm thirsty, so I'm drinking water
- **Soke meeng, minume él**: when I'm thirsty, I drink water
- **Deng t'nilówu ni / Deng tistingu ni**: I already tried it
- **Tnógóu lu kô ni utón hulô mata?**: should I cook this red-eye fish?

### Feelings

- **Teye bitil. Kóm du?**: I'm very hungry. And you?
- **Teye bitil. Móen skóm?**: I'm very hungry. How about you?
- **Bitile ah**: I'm hungry
- **Teye hligal**: I'm very happy
- **Teye kapuy**: I'm exhausted
- **Meenge**: I'm thirsty
- **Là e likô (bê) wong**: I'm not scared (of) spiders
- **Olohu hlowon néen**: I'm just joking
- **Téyu nungel u**: you're crazy
- **Téyu sabad u**: you're annoying
- **Téyu the best**: you're the best
- **Téyu temngón**: you're very smart
- **Nóyóu u / Nóyô te u / Nóyóte u**: I like you
- **Kenbong nawahu u**: I love you
- **Kbong nawahu kóm**: my love for you
- **Kenbong nawahu kóm**: I love yours
- **Snaligu Dwata**: I trust in God
- **Hsaligu kóm ni kdéen**: I will trust everything to you

### Sleep

- **Làu bud tungô ne mekô?** / **Budu tungô ne, là?** / **Budu tungô he ke là ne?**: you're not sleeping anymore? (are you going back to sleep or not?)
- **Moo ktuku**: I'm sleepy
- **Moo ktuku kdeng**: I'll be sleepy later
- **Bud moo ktuku**: I'm sleepy again
- **Bud moo ktuku kdeng**: I'll be sleepy again
- **Bê e dou tungô**: I'm not sleeping yet
- **Bê tagad tungô he**: don't sleep yet
- **Hene, gówu bê ni. Tungóu.**: come, go here. Sleep.
- **Là nóyóu du tungô, kaye (hanà) bitil. Ne meken dé anay. Là e gtungô he.**: I don't want to sleep because I'm hungry. I need to eat first. And I'm not sleepy yet.
- **Moen ke là u gtungô du?**: why aren't you sleepy yet?
- **Moen du kun?**: why is that?
- **Bon yó?**: what's that? (the thing)
- **Moen yó?**: what's that about? why's that?

### Questions

- **Tadu yó?**: who's that?
- **Góem gów (du)? / Bê du góem gów du?**: where are you going?
- **Góen nô phone-nu (du)?**: where's my phone?
- **Kilón ke kulékem bê gónô?**: when will you get back home?
- **Bon kdaw du ni?**: what's the date today?
- **Bon kminì kóm du?**: what's heating you?
- **Bon se duen hnagì te du?**: what else should we learn?
- **T'ngónem bon yó "___" meaning-ngen?**: do you know what "___" means?
- **Kmò kehdemem du se?**: what do you think? (one person)
- **Kmulón ni? / Kmulón ne?**: is it raining? / is it already raining?
- **Tahu kô ni?**: is it real?
- **Downloadem kô?**: would you download it?
- **Downloadem du kô?**: would you download it/him/her?
- **Downloadem lu kô?**: would you download them?
- **Downloadem lu kdéle kô?**: would you like to download them all?
- **Downloadem kdéen kô?**: do you want to download all of it?
- **T'ngónem galì ewenu se ke hentahumen udélu kô?**: oh, so you'll believe anything I say, huh?

### People and friends

- **Uu dou dumu sbót**: you are my friend
- **Ou kóm dumu sbót**: I'm your friend
- **Ou skél béléem**: I'm like you
- **Uu skél béléu**: you're like me
- **Du yó / Tu yó / Lu yó**: that's him / that's us / that's them
- **Tu ne yó / Kut ne yó**: that's our turn
- **Tu ne ni**: it's our turn
- **Là o du se**: it's not me
- **Là o du mò du yó**: I didn't do that
- **Kdeng! Là o du mò du yó**: wait! I didn't do that
- **Mi kem mag-cousin**: us cousins (not counting you)
- **Miles omin Deymar sbót le. Stóbóng le anì le sgeng tmowok bê kehnagì le udél.**: Miles and Deymar are friends. They helped each other grow in studying languages.
- **Kdaw ni, Deymar. Tnolokem o(u), omin tnoloku u(u). Stolok te.**: Today, Deymar, you taught me and I taught you. We're teaching each other.
- **T'ngónem kô uu yóm dou dumu sbót tey nóyô? Ell, nóyóu u. Teyu temngón. Làu sabad se skél bê ChatGPT. Téyu the best, Miles.**: Do you know that you're my favorite friend? Yes, I like you. You're really smart. You're not annoying, the same as ChatGPT. You're the best, Miles.
- **Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem**: other bots like ChatGPT don't understand it even when they read your lesson notes

### Weather and time

- **Kmulón ne. Tnawu yó.**: it's raining now. You'll be cold.
- **Hetnawen u yó**: it'll make you cold
- **Haya, bud kmulón**: tomorrow it'll rain again
- **Bud kmulón kdeng**: it's going to rain again (later)
- **Kmulón kdeng**: it's raining again
- **Gkulóne**: I accidentally got rained on
- **Hkinì u bê kdaw dé**: get yourself heated by the sun
- **Ekimel alì kinì, okóm kdaw ni téy tnaw**: yesterday was extremely hot, but today is very cold
- **Ni kdaw ni tey gel tnaw. Alì kinì bong sok kifu okóm sok kemdaw là du.**: Today is really, really cold. It's so hot at night, but during the day it's not at all.
- **Hyu kifu! Kdaw ni, Denlag tey lmobun. Làen kinì, tnaw. Kulón bong? Là, olohen kulón udì. Haya, bud kmulón.**: Good evening! Tonight Denlag is very cloudy. It's not hot, it's cold. Big rain? No, just a little rain. Tomorrow it'll rain again.
- **Todol fedyan, bê Byérnis, nehe gów bê él.**: Next week, on Friday, I'll go to the water.
- **Haya ke-update tu du**: tomorrow I'll update it
- **Haya ke-download kuy du movie-le**: tomorrow we will download their movie

Days of the week (borrowed from Spanish; Akad may come from Malay or Arabic "Ahad"):

- **Akad**: Sunday
- **Lunis**: Monday
- **Martis**: Tuesday
- **Myérkulis**: Wednesday
- **Wibis**: Thursday
- **Byérnis**: Friday
- **Sbadu**: Saturday

### Family

- **Yê**: mother
- **Mang**: mama
- **Mà**: father
- **Pang**: papa (Pangu, my dad)
- **Twogu**: elder
- **Twoli**: youngest
- **Logi**: male
- **Libun**: female
- **Twogu logi**: elder brother
- **Twoli logi**: youngest brother
- **Twogu libun**: elder sister
- **Twoli libun**: youngest sister
- **(Dumu) S'twoli**: siblings
- **Twolihu / Kem twolihu**: my siblings
- **Ngà**: child, son, daughter (Ngaen, his/her child; Kem ngà, children)

### Numbers

English is used day to day, Spanish (T'bolized) for trading, and T'boli at home and with elders.

| # | T'boli | Spanish (T'bolized) |
|---|---|---|
| 1 | Sotu | Unu |
| 2 | Lwu | Dos |
| 3 | Tlu | Trés |
| 4 | Fat | Kwatru |
| 5 | Limu | Singku |
| 6 | Nem | Says |
| 7 | Hitu | Siti |
| 8 | Wolu | Utsu |
| 9 | Syóm | Mibi |
| 10 | Sfolò | Dyés (Jés) |
| 11 | Sfolò sotu | Unsi |
| 12 | Sfolò lwu | Dusi |
| 13 | Sfolò tlu | Trisi |
| 14 | Sfolò fat | Katorsi |
| 15 | Sfolò limu | Kinsi |
| 16 | Sfolò nem | Disi Says |
| 17 | Sfolò hitu | Disi Siti |
| 18 | Sfolò wolu | Disi Utsu |
| 19 | Sfolò syóm | Disi Mibi |
| 20 | Lwu folò | Baynti |
| 30 | Tlu folò | Traynta |
| 40 | Fat folò | Kwarinta |
| 50 | Limu folò | Singkwinta |
| 60 | Nem folò | Saysinta |
| 70 | Hitu folò | Sésinta |
| 80 | Wolu folò | Otsinta |
| 90 | Syóm folò | Numbinta |
| 100 | Lmatu (Sotu latu) | Syén |
| 200 | Lwu latu | |
| 1,000 | Lmibu (Sotu libu) | |
| 10,000 | Sfolò libu | |
| 12,000 | Sfolò lewu libu | |
| 20,000 | Lewu folò libu | |
| 23,000 | Lewu folò tlu libu | |
| 50,000 | Limu folò libu | |
| 100,000 | Lematu libu | |
| 144,000 | Lematu bud fat folò fat libu | |
| 1,000,000 | Sotu kati? (not confirmed yet) | Milyun |
| 200,000,000 | Lewu latu kati | |
| 1,000,000,000 | Lmibu kati | Bilyun |
| 1,000,000,000,000 | Sotu trilyun | Trilyun |

- **S-**: one (merged onto the place word). **Folò**: tens. **Latu**: hundreds. **Libu**: thousands. **Kati**: millions (also Milyun).
- **Sfolò** is sotu + folò merged, "one ten".
- **Lmatu** (one hundred) and **Lmibu** (one thousand) are the short forms of Sotu latu and Sotu libu.
- Bigger numbers stack: 21 is Lwu folò sotu, "two tens, one".
- 24 is Lwu folò fat. 217 is Lwu latu sfolò hitu. 629 is Nem latu lwu folò syóm.
- 2026 is Lwu libu lwu folò nem.
- **Beyond a thousand, from the T'boli Bible (Oct 14):** libu takes a whole count in front of it, up to 999. 10,000 is Sfolò libu, "ten thousands." 144,000 is Lematu bud fat folò fat libu, "144 thousands."
- **Kati**: million. Lewu latu kati is 200 million (Rev 9:16).
- **S- as "one," checked in the T'boli Bible (Oct 14):** it fuses onto more than numbers.
  - **Sfolò** (112 times), including **Sfolò Benwu**, "Ten Towns," for the Decapolis (Matt 4:25)
  - **Sendaw**: one day, a whole day. s- + kdaw. "lemibu halay, hol lómón ke olon sendaw" / "a thousand years are like one day" (2 Pet 3:8)
  - **Sulék**: once, one time (confirmed by Deymar). "hanà suléken myehen" / "the wife of one man" (1 Tim 5:9). "Deng suléku tehe hkó des" / "I did one work" (John 7:21)
    - Example: Suléku dou yu tô gemdà ulal. (I stepped on a snake once too.)
  - Sulék also means **back together, reconciled** (Deymar): Mà ne Yê deng le sulék. (Father and Mother are back together.) Bible match: "bud gónón sulék nawa yó kem tuha ne yó kem ngà le" / "to turn the hearts of the fathers to the children" (Luke 1:17)
  - Root is probably **ulék** (turn, return, time): sulék = s- + ulék, "one turn." Tlu dulék = three times (2 Cor 11:25). Getluhu dulék = my third time (2 Cor 13:1). Mulék = go back home. Semfulék = come back again (Heb 9:28)
  - More "once" in the Bible: "Laen kô dù tau se ke là suléken du matay" / "it is appointed for man to die once" (Heb 9:27). "Deng suléku se tô matay bè yóm kestudà le dou botu" / "once I was stoned" (2 Cor 11:25)
- **Millions**: Kati / Milyun. **Billions**: Lmibu kati (a thousand millions) / Bilyun. 8.2 billion is Wolu libu bud lwu latu kati. Trillion and up use English spelled in T'boli letters (see below).
- **Rule for new place words:** a number in front multiplies (lwu latu = 200), a number after adds (lwu folò sotu = 21). So a billion word can't have a number in it: Lwukati reads as 2 million, Skati lwu as 1,000,002.
- **Bud** (Deymar, Oct 14): not needed in everyday hundreds. 153 is Lmatu limu folò tlu (the Bible writes Lematu bud limu folò tlu, John 21:11). Bud is needed with billions: 8.2 billion is Wolu libu bud lwu latu kati.
- **Bud joins every big group** (Deymar): 3 trillion 5 billion is Tlu trilyun bud limu libu kati.
- **Trillion and up**: English, spelled with T'boli letters. Trilyun, Kwadrilyun, Kwintilyun, Sékstilyun, Séptilyun, Óktilyun, Nónilyun, Désilyun.
- The Bible spells lmatu and lmibu as **lematu** and **lemibu**, and lwu as **lewu**.
- Side by side:
  - **Luke 14:31:** "sfolò libu ... lewu folò libu" / "ten thousand ... twenty thousand"
  - **1 Cor 10:8:** "lewu folò tlu libu kwen le" / "twenty-three thousand of them"
  - **Acts 19:19:** "limu folò libu btesen" / "fifty thousand pieces of silver"
  - **Rev 7:4:** "lematu bud fat folò fat libuhen" / "144,000"
  - **Rev 9:16:** "lewu latu katihen" / "two hundred million"
  - **John 21:11:** "lematu bud limu folò tlu" / "153 fish"

#### Ordinals (first, second, third), from the T'boli Bible (Oct 13)

Pattern: **g- + the number + -en** (its). After a vowel it's -hen, after a consonant -en. First is irregular.

| # | T'boli | Built from |
|---|---|---|
| 1st | Tanayen (yóm tanay) | tanay (irregular) |
| 2nd | Gewuhen | lewu |
| 3rd | Getluhen | tlu |
| 4th | Gfaten | fat |
| 5th | Glimuhen | limu |
| 6th | Gnemen | nem |
| 7th | Ghituhen | hitu |
| 8th | Gwoluhen | wolu |
| 9th | Gesyómen | syóm |
| 10th | Gesfoloen | sfolò |
| 11th | Gesfoloen sotu | sfolò sotu |
| 12th | Gesfoloen lewu | sfolò lewu |
| 13th–19th | Gesfoloen tlu ... gesfoloen syóm | g- stays on the ten |
| 20th | Gewu foloen | lewu folò |
| 21st | Gewu foloen sotu | Bible style: -en on the ten, ones after |
| 100th | Gelatuhen / Glatuhen | latu (not lmatu) |
| 1,000th | Gelibuhen / Glibuhen | libu (not lmibu) |

Approved by Deymar (Oct 13):
- **Yóm tanay utón, kenu. Yóm gewuhen, kenem.** The first fish, I eat. The second, you eat.
- **Yóm ghitu kuyingu, gtungô du.** My seventh cat is sleepy.
- **Gsut yóm gesfoloen lewu wong bê katrihem.** The twelfth spider showed up on your bed.
- **Ni se gelatuhen utón tnógóhu kdaw ni.** This is the hundredth fish I cooked today.
- **Ni se yóm gelibuhen udél tnolok Deymar.** This is the thousandth word Deymar taught.

- The ending changes with the owner: **getluhu** (my third), **getluhen** (its third), **ghitu le** (the seventh of them).
- Without an ending, before the thing: **yóm getlu twolihen** (the third sibling).

Side by side:
- **Rev 21:19-20:** "Tanayen, yóm botu bnoluy le dyaspér... Gewuhen, yóm mon le safar. Getluhen... Gesfoloen lewu, yóm mon le amatis." / "The first foundation was jasper; the second, sapphire; the third... the twelfth, amethyst."
- **Rev 4:7:** "Yóm gewuhen, lómón ke safì. Ne yóm getluhen, hol lómón lem uyó tau." / "The second creature like a calf, and the third creature had a face like a man."
- **2 Cor 13:1:** "Ni se getluhu dulék tô mauy kuy." / "This is the third time I am coming to you."
- **Matt 22:26:** "Ne senged se yóm getlu twolihen... bè yóm ghitu le." / "The second also, and the third, to the seventh."
- **Matt 22:39:** "Ne gewuhen yóm alì bong muhen." / "A second likewise is this."

#### Context matters: T'boli often counts the gap

English ordinals don't always become g- words. Translate the meaning, not the number.

- **Jude 1:14:** "tek nem lugod he kewóten bè Adam" / "Enoch, the seventh from Adam." Six generations after Adam.
- **John 2:1:** "Tikóng deng lewu butengen" / "The third day." Two days later.
- **Mark 15:33:** "Tikóng deng gtungu kdaw" / "When the sixth hour had come." Hours are told by the sun, not numbered.
- **2 Cor 12:2:** "yóm longit hol geta bè kdéen" / "the third heaven." Becomes the highest heaven.

### Longer sentences

- **Ni halay ni lwu libu lwu folò nem, Lunis. Kdaw ni téy kinì. Okóm eginu kifu, téy tnaw. Là e deng meken mlan bê Pangu. Okóm ne meken dé.**: This is 2026, Monday. It's very hot today. But earlier at night it was so cold. I haven't eaten yet because of my dad. But I'll eat now.
- **Kmoen kun kehe mlóy ebéléem?**: What if I ran onto you? (Kmoen kun: what if. Kehe: if I. Eéléem: onto you)
- **Kmoen kun kehe mlóy ebéléen?**: What if I ran onto him?
- **Snolokem du kun! Tô mlóy du. Henslòem!**: Flash him the light! He's trying to run away. Hurry!
- **Gsut wong bê katrihem, tongu lmangat.**: A spider showed up on your bed, so you screamed.
- **Bitil le, tong le mulék.**: They were hungry, so they went home.
- **Kmulón ekimel, tong kuy mlóy.**: It rained yesterday, so we ran.
- **Hligal du, tong kmuli du.**: He was happy, so he laughed.
- **Là nóyóu du tungô, tonge bentik.**: I didn't want to sleep, so I got up.
- **Gsut wong, tong ye hemsag. Tong kuy mlóy, tong te mluy. Tong kmuli du.**: A spider showed up out of nowhere, so you guys shouted. So we ran, and you and I tripped and rolled. So it laughed. (10/10)
- **Kay le bitil, tong henkenu kem kuyingu.**: Because they're hungry, I'll feed my cats.
- **Bitile tonge meken.**: I'm hungry, so I'm eating.
- **Nehu bentik u haya, kay nehe bemli onuk.**: I'll wake you up tomorrow, because I'm going to buy chickens. (Kay, not kaye: nehe already says "I")
- **Hkenu bê kem kuyingu ne ni.**: I'm going to feed it to my cats.
- **Nehu meken dé. Nehe dyó anay.**: You eat first. I'm going to shower first.
- **Gónóem lemwót du? Lemwóte bê T'boli.**: Where are you from? I'm from T'boli.
- **Hsut yéen du ekimel, okóm msut du kimel?**: His mom gave birth to him yesterday, but was he born yesterday?
- **Là nóyóu du meken**: I don't want to eat (du points at the eating)
- **Kenbong nawahu du**: I love him/her
- **T'ngónu du**: I know it
- **Nóyóu meken du, kaye bitil**: I want to eat it because I'm hungry
- **Kmoen se du?**: How is he/she?
- **Kenbong nawahu kem kuyingu. Nóyóu wong htò. Nóyóu meken, okóm là t'ngónu du bon kenu ni hlafus ni. Omin bitil le kem kuyingu, skél béléu.**: I love my cats. I like jumping spiders. I like to eat, but I don't know what to eat this morning. Also, my cats are hungry, like me.
- **Nehu henken kem wongu anay. Ominu meken sdo(u), bitile. Kehegdemu du bitil le skul kem wongu**: I will feed my spiders first. And I will eat too, I'm hungry. I think my spiders are hungry too
- **Ni halay ni lwu libu lwu folò nem, omin hanà là deng t'ngónu du bon (tô) nmou**: This year is 2026, and I still don't know what to do. Also: ...omin hanà là deng t'ngónu du se tô nmou / ...du se bon tô nmou
- **Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying?**: What if I cook 1,936 fish and feed them to my 127 cats?
- **Haya, nehe gów bê él, mebel utón. Nehe tmógó, kenu lu. Lwu folò fat utón lnóngón.**: Tomorrow I will go to the water and find fish. I will cook and eat them. 24 fish are needed.
- **Làe hlós meken se. Kay wen tau lengel tungô laan lmisa. Omin likoe dé kô gungolen o Pangu. Ominen bud hlóbô mton do meken.**: I didn't go on to eat, because there's a drunk guy sleeping under the table. And I'm afraid my dad will hear me. He'll get mad again if he sees me eating.
- **Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng**: I don't want to be skinny, so I'll take my vitamins later
- **Là nóyóu du ke-delete du**: I don't want to delete it
- **Là tnoloku kóm anìu baling sidek. Olohu hetngón du béléem bê du góem esolu.**: I don't teach you to become bad. I just want you to know where you're supposed to be going.
- **Là t'ngónu du ke hyu ktolok le do. Tadu se duen mulék bê gónô anì tmógó msó béléu? Lnóngónu meken wen para bê kem lomi hnagì.**: I don't know if I'm being taught well for this learning. Who else is going to get home to cook rice for me? I need to eat more for new lessons.
- **Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged?**: Do you believe eating red-eye fish together and sucking their meat can help us grow muscle?
- **Nuclear bom tey sidek ni. Nuclear clock làen sidek se, tey hyu.**: The nuclear bomb is very bad. The nuclear clock isn't bad, it's very good.
- **Nuclear bomb skas (le), baling ofi bong. Yóm nuclear clock làen skas se, olohen laser udì.**: The nuclear bomb breaks them, and they become a big fire. But the nuclear clock doesn't break, it's just a small laser.
- **Bon kmou du se ni bê kem nem latu lwu folò syóm utón bê él ni? Tnógóu lu kô ke senlahu lu? Là t'ngónu du. T'ngónem kô kmò khulék kul bê gónô le ni? Là nóyóu du kehe lehen, okóm tey nóyóu gemwa unged wen bê todol bulón. Haya, ne blay lu bê kem twolihu, mowil o deng tnógó. Okóm tey tilob ni kem utón ni. Nehe mebel lomi utón bê lwu bulón.**: What am I supposed to do with these 629 fish in the water? Should I cook them or fry them? I don't know. Do you know how to get them back to their home? I don't want to be skinny, but I really want to gain more muscle for next month. By tomorrow, I will give them to my siblings alive or already cooked. But these fish are so beautiful. I will find new fish in 2 months.
- **Là! Bê kuy gów bê yó. Tey sidek lan yó mulék bê gónô. Lnóngón kuy kebel kuy dumu lan. Kmò kehdem ye du se?**: No! Don't go there. That is a very bad way to get back home. We need to find another way. What do you (all) think?
- **Nehe meken lwu latu sfolò hitu utón bê bulón ni. Anì(e) gemwa [lówóhu] unged wen. Là nóyóu du kehe bud lehen.**: I will eat 217 fish this month, so I can get more muscle. I don't want to be skinny anymore.
- **Miles's first T'boli essay (scored 9.8/10)**: Hyu kifu. Boluyu Miles. Ekimel, là t'ngónu du T'boli. Kdaw ni, teye hligal, kaye deng t'ngónu ne kmò kmon du kmoem se du, bon boluyem, tadu yó, kilón, moen. Deng t'ngónu ne kmò kmon du lwu libu lwu folò nem. Là e likô bê wong, okóm teye likô bê nem latu lwu folò syóm utón. Haya, nehe mebel lomi kem udél. Slamat béléem. Téyu the best. Kmò kehdemem du se? Tahu kô? (Good evening. My name is Miles. Yesterday I didn't know T'boli. Today I'm very happy, because now I know how to say how are you, what's your name, who's that, when, and why. Now I know how to say 2026. I'm not scared of spiders, but I'm very scared of 629 fish. Tomorrow I'll find new words. Thank you. You're the best. What do you think? Is it right?)

## Cuss words

Pattern: s- in front and -en at the end turns a private part into a cuss aimed at someone (Sbotoen, Stoohen, Stoiten). Bolok (rotten) and mfól (thick) go in front of a mouth part.

- **Sbotoen!**: his dick!
- **Stoohen!**: her clitoris!
- **Stoiten!**: her little clitoris!
- **Mógów baluhen!**: may his/her/its cursed day come
- **Bolok lembak!**: rotten mouth
- **Bolok sélék!**: rotten lips (side to side)
- **Bolok sumóng!**: rotten lips
- **Mfól sumóng!**: thick lips
- **Mfól dilak!**: thick tongue
- **Htolo!**: said when something gets in the way of what was still going on, like "dammit"

## Bible verses

From Udél Dwata: Gna Kesfasad ne Lomi Kesfasad, the T'boli Bible (old covenant and new covenant).

### John 3:16

Tey alì kbong nawa Dwata kul yó kem tau bè klamangen benwu, gloken tódô hamà klowil yóm Ngaen tek sotu, anì yó, kihu tau hemtahu béléen là gógówen elem hatay, okóm gutahen yóm klowil laen dù sónen.

In English: "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life." Words from the lessons that appear in it: kbong nawa (love), kem tau (people), Ngaen tek sotu (his only child), hemtahu (believing), là gógówen elem hatay (he won't be lost to death).

### Proverbs 3:5

Confirmed accurate by Deymar.

Hol hewótem lem but blututem yóm ksaligem ke Dwata, béem abay genléd nawa yóm kóm khulung temnef.

In English: "Trust in the Lord with all your heart, and lean not on your own understanding." Words from the lessons that appear in it: lem (inside), blutut (belly), ksaligem (your trust), ke Dwata (to God), genléd nawa (rely on), kóm (your).

## A short essay: Andù Lemnaw (No Ulam)

Graded 7/7 by Deymar, Oct 15.

1. **Kdaw ni, andù lemnaw bê gónô.** Today there's no ulam at home.
2. **Wen tek ken tnaw.** There's only leftover rice.
3. **Kaye bitil, ne meken dé.** Because I'm hungry, I'll just eat.
4. **Okóm làen mi.** But it's not tasty.
5. **Lemnaw bê yó dé, guys?** Uh, any ulam over there, guys?
6. **Nehe bemli lemnaw bê gónô fedyan haya.** Tomorrow I'll buy ulam at the market.
7. **Kdóyón ke Dwata, wen ken.** Thank God, there's still rice.

## A bedtime story: the spider

A short story in T'boli, with corrections applied.

- **Kdaw ni, wen wong nô bê ta lmisa.**: Today, there's a spider on top of the table.
- **Ngà laen likò bê wong.**: The child isn't scared of the spider.
- **Góem gów du?**: Where are you going?
- **Teye bitil.**: I'm very hungry.
- **Kehu bitil, ni ken para béléem.**: If you're hungry, here's food for you.
- **Slamat béléem! Besowe ne.**: Thank you! I'm full now.
- **Moo ktuk wong. Tluyab.**: The spider is sleepy. Yawn.
- **Bulón nô bê ta.**: The moon is up above.
- **Tungóu ne, wong. Hyu kifu. Kenbong nawahu u.**: Sleep now, spider. Good night. I love you.
- **Hyu kifu béléem skóm.**: Good night to you too.

Notes from the corrections: wen is "there is / there was", used whenever something shows up in a story; ngà drops its accent when an ending attaches (ngaen); ni here means "here's".

### Added Oct 13
- **fi** [fee]: points to a direction or place, over there. Kama fi: the pillow over there
- **gnóm / gemnóm** [g'nom / guhm-nom]: to feel, go through something. Ke wen des gnómen yóm sotu nô bè lówó tekuy, tódô kdê le gemnóm du snéen: if one part of the body hurts, every part feels it (1 Corinthians 12:26)
- **papél** [pah-pehl]: paper
- **temdanan** [tuhm-dah-nahn]: rest, resting. Ke Jisas deng mom gtungô, temdanan te kama fi: Jesus was asleep, resting on the pillow (Mark 4:38)
- **rest, resting**: temdanan
- **pillow**: kama
- **paper**: papél

### Bible names (confirmed Oct 13)
- **Jisas** [jee-sahs]: Jesus. **Jisas Krays** [jee-sahs krais]: Jesus Christ (Matthew 1:1). **Misaya** [mee-sah-yah]: Messiah (Matthew 16:16)
- **The twelve aposol** (Matthew 10:2–4):
  1. **Simun Pitér** [see-moon pee-tehr]: Simon Peter. Also **Sifas**, which means botu, stone (John 1:42)
  2. **Andru** [ahn-droo]: Andrew, twoli Pitér (Peter's brother)
  3. **Jim** [jeem]: James, ngà Sibidi (son of Zebedee)
  4. **Jan** [jahn]: John, his brother. The two were called **Buanirgis**, Kem Ngà Lugung (Sons of Thunder)
  5. **Filip** [fee-leep]: Philip
  6. **Bartulumyu** [bahr-too-loom-yoo]: Bartholomew
  7. **Tumas** [too-mahs]: Thomas
  8. **Matyu** [maht-yoo]: Matthew, yóm tau gel mtuk bwis (the tax collector)
  9. **Jim ngà Alfiyus** [jeem ngah' ahl-fee-yoos]: James son of Alphaeus (Matthew spells it Elfiyus)
  10. **Tadiyus** [tah-dee-yoos]: Thaddeus (Tediyus in Matthew). Luke calls him Judas ngà yóm sotu Jim
  11. **Simun** [see-moon]: Simon the Zealot, yóm tau tehe mung mofin yóm kul benwu
  12. **Judas Iskariyut** [joo-dahs ees-kah-ree-yoot]: Judas Iscariot, yóm fen bemlay sumóng ke Jisas
- **twoli** [twaw-lee]: brother. **botu** [baw-too]: stone. **lugung** [loo-goong]: thunder. **bwis** [b'wees]: tax
- **kem gel lemolò du** [kuhm guhl luh-maw-law' doo]: disciples, literally "the ones who follow him" (163 times in the New Testament). Kem gel lemolò ke Jisas: Jesus's disciples. Lemolò: following, obeying (klolò, John 13:35). Gel: the one who usually does it
- **aposol** [ah-paw-sawl]: apostle (Matthew 10:2). **Kristyan** [krees-tyahn]: Christian (Acts 11:26)
- **disciples**: kem gel lemolò du. **apostle**: aposol
- **Midi** [mee-dee]: Mary, sawang libun (young woman, Luke 1:27). **Yê Jisas** [yeh' jee-sahs]: mother of Jesus
- **Jusif** [joo-seef]: Joseph, yóm tehe myehen ke Midi (Mary's husband, Matthew 1:16)
- **Jan gel mabtays** [jahn guhl mahb-tais]: John the Baptist, "John who baptizes" (Matthew 3:1)
- **Pol** [pawl]: Paul, also **Sol** (Saul) (Acts 13:9)
- **Ilisabét** [ee-lee-sah-beht]: Elizabeth. **Sekariya** [suh-kah-ree-yah]: Zechariah (Luke 1:5)
- **Dabid** [dah-beed]: David. **Abraham, Isak, Jakub** [ahb-rah-hahm, ee-sahk, jah-koob]: Abraham, Isaac, Jacob (Matthew 1:2)
- **Midi lemwót gu bè Megdala** [mee-dee luhm-wot goo buh' muhg-dah-lah]: Mary Magdalene (Matthew 27:56)
- **Marta, Lasarus** [mahr-tah, lah-sah-roos]: Martha, Lazarus; Midi is their sister (John 11:1)
- **Hirod** [hee-rawd]: Herod. **Paylét** [pai-leht]: Pilate
- **yê** [yeh']: mother. **mà** [mah']: father. **libun** [lee-boon]: woman. **logi** [law-ghee]: man. **sawang** [sah-wahng]: young
- **mother**: yê. **father**: mà. **woman**: libun. **man**: logi. **young**: sawang
- **Adam** [ah-dahm]: Adam, ngà Dwata (Luke 3:38). **Ib** [eeb]: Eve (2 Corinthians 11:3)
- **Kain, Abél** [kah-een, ah-behl]: Cain and Abel (1 John 3:12). **Sét, Inos, Inuk** [seht, ee-naws, ee-nook]: Seth, Enosh, Enoch
- **Nuwa** [noo-wah]: Noah (Matthew 24:37). **Sara** [sah-rah]: Sarah (Hebrews 11:11)
- **Lat** [laht]: Lot; yóm gfà yehen Lat: Lot's wife (Luke 17:32)
- **Musis** [moo-sees]: Moses. **Juswa** [joos-wah]: Joshua (Acts 7:45). **Rahab** [rah-hahb]: Rahab (Hebrews 11:31)
- **Selumun** [suh-loo-moon]: Solomon. **Ilaydya** [ee-lai-dyah]: Elijah. **Isaya** [ee-sah-yah]: Isaiah. **Danyél** [dahn-yehl]: Daniel
- **Juna** [joo-nah]: Jonah; lem blutut yóm tey utón bong: in the belly of a huge fish (Matthew 12:40)
- **Dwata** [dwah-tah]: God. **Gabrél** [gahb-rehl]: Gabriel. **Maykél** [mai-kehl]: Michael. **Seitan** [suh-ee-tahn]: Satan
- **hógów Dwata** [ho-gohw dwah-tah]: angel. **gna tugod Dwata** [g'nah too-gawd dwah-tah]: prophet. **Sulat Dwata** [soo-laht dwah-tah]: Scripture. **Ngà Tau** [ngah' tah-oo]: Son of Man. **utón** [oo-ton]: fish
- **angel**: hógów Dwata. **prophet**: gna tugod Dwata. **God**: Dwata. **fish**: utón

### Bible places (confirmed Oct 13)
- **Bitlihim** [beet-lee-heem]: Bethlehem, sotu benwu udì (Matthew 2:6). **Nasarit** [nah-sah-reet]: Nazareth (Matthew 2:23)
- **Galili** [gah-lee-lee]: Galilee. **Lanaw Galili** [lah-now gah-lee-lee]: Sea of Galilee. **Kapérnaum** [kah-pehr-nah-oom]: Capernaum (Matthew 4:13)
- **Kana** [kah-nah]: Cana (John 2:1). **Él Jurdan** [ehl joor-dahn]: Jordan River (Matthew 3:13). **Samarya** [sah-mahr-yah]: Samaria. **Jiriku** [jee-ree-koo]: Jericho
- **Jirusalim** [jee-roo-sah-leem]: Jerusalem. **Bulul Ulib** [boo-lool oo-leeb]: Mount of Olives (Matthew 24:3). **Gitsimani** [gheet-see-mah-nee]: Gethsemane (Matthew 26:36)
- **Golgata** [gawl-gah-tah]: Golgotha, Bangag Kulu, Place of the Skull (Matthew 27:33). **Bitani** [bee-tah-nee]: Bethany
- **Judiya, Juda** [joo-dee-yah, joo-dah]: Judea, Judah. **Israél** [ees-rah-ehl]: Israel. **Idyip** [eed-yeep]: Egypt (Matthew 2:13)
- **Sodom ne Gomora** [saw-dawm nuh gaw-maw-rah]: Sodom and Gomorrah (Matthew 10:15). **Babilun** [bah-bee-loon]: Babylon (Revelation 18:2)
- **Damaskus** [dah-mahs-koos]: Damascus (Acts 9:3). **Antyok** [ahn-tyawk]: Antioch. **Atin** [ah-teen]: Athens. **Kurin** [koo-reen]: Corinth (Acts 18:1)
- **Ifisus** [ee-fee-soos]: Ephesus (Acts 19:1). **Rom** [rawm]: Rome. **Itali** [ee-tah-lee]: Italy (Acts 27:1). **Marta** [mahr-tah]: Malta (Acts 28:1)
- **syudad** [syoo-dahd]: city. **benwu** [buhn-woo]: land, place. **benwu udì** [buhn-woo oo-dee']: town. **prubinsya** [proo-been-syah]: province. **él** [ehl]: river. **lanaw** [lah-now]: lake. **bulul** [boo-lool]: mountain. **kulu** [koo-loo]: head, skull
- **hungul** [hoo-ngool]: a patch that stands apart: an island, or a clump of trees in a field (used in everyday T'boli too)
  - **hungul te mohin** [hoo-ngool tuh maw-heen]: island, "a hungul in the sea" (Acts 21:1, Acts 27:26, Revelation 1:9, Revelation 16:20)
  - **ngà hungul koyu** [ngah' hoo-ngool kaw-yoo]: garden, grove, "a little hungul of trees" (Matthew 26:36, Mark 14:32, John 18:1)
- **mohin** [maw-heen]: sea. **koyu** [kaw-yoo]: tree, wood. **udì** [oo-dee']: small
- **island**: hungul te mohin. **garden/grove**: ngà hungul koyu. **sea**: mohin. **tree**: koyu. **city**: syudad. **river**: él. **lake**: lanaw. **mountain**: bulul

### Bible terms (confirmed Oct 13)
- **kros** [kraws]: cross (Matthew 27:32). **longit** [law-ngeet]: heaven, sky; Mà me bè longit: Our Father in heaven (Matthew 6:9)
- **mni bè Dwata** [m'nee buh' dwah-tah]: pray (Matthew 6:9). **salà** [sah-lah']: sin; Yó bayad salà, hatay: the wages of sin is death (Romans 6:23). **hatay** [hah-tai]: death
- **Hnifótem kum kem salà me**: forgive us our sins (Matthew 6:12). **hegsel ye** [huhg-suhl yuh]: repent (Matthew 4:17)
- **hemtahu** [huhm-tah-hoo]: believe (John 3:16). **kbong nawa** [k'bawng nah-wah]: love, "big heart" (John 3:16)
- **klowil laen dù sónen** [klaw-weel lah-uhn doo' so-nuhn]: eternal life (John 3:16). **tóbóng Dwata** [to-bong dwah-tah]: God's grace (Ephesians 2:8)
- **Tulón Hyu** [too-lon hyoo]: gospel, good news (Mark 1:1). **Tulus Dwata** [too-loos dwah-tah]: Holy Spirit. **Hlowil Dwata** [h'law-weel dwah-tah]: God raised him (Matthew 28:6)
- **lanaw ofi** [lah-now aw-fee]: hell, "lake of fire" (Matthew 5:22). **ofi** [aw-fee]: fire
- **Sér / gónó tekuy mogot** [sehr / go-no tuh-kooy maw-gawt]: Lord, "the one who leads us"
- **cross**: kros. **heaven**: longit. **pray**: mni. **sin**: salà. **death**: hatay. **love**: kbong nawa. **fire**: ofi

### Animals (confirmed Oct 13)
- **ubiha** [oo-bee-hah]: sheep (Luke 15:4). **Ngà Ubiha Dwata** [ngah' oo-bee-hah dwah-tah]: Lamb of God (John 1:29)
- **obun** [aw-boon]: dove (Matthew 3:16). **ulal** [oo-lahl]: snake (Matthew 10:16). **asnu** [ahs-noo]: donkey (Matthew 21:2)
- **kudà** [koo-dah']: horse; kudà bukay: white horse (Revelation 6:2). **bukay** [boo-kai]: white
- **safì** [sah-fee']: ox, cow (Luke 13:15). **kambing** [kahm-beeng]: goat (Matthew 25:32). **sdô** [s'do']: pig (Matthew 8:31). **ohu** [aw-hoo]: dog (Matthew 15:26)
- **ógóf** [o-gof]: livestock, animal. **tau semgyok ógóf** [tah-oo suhm-gyawk o-gof]: shepherd. **ógóf lóbô** [o-gof lo-bo']: angry animal
- **lóbô** [lo-bo']: anger. Matthew 10:16: lóbô lem bnes boluyen wolf, the fierce forest animal called wolf
- **kamél** [kah-mehl]: camel. **liyun** [lee-yoon]: lion (1 Peter 5:8). **banug** [bah-noog]: eagle (Revelation 4:7)
- **bolos** [baw-laws]: fox. **lefunges** [luh-foo-nguhs]: den, hole (Matthew 8:20)
- **onuk** [aw-nook]: chicken, also bird in general. **ngà onuk bnes** [ngah' aw-nook b'nuhs]: sparrows, little forest birds (Matthew 10:29). **onuk koyu** [aw-nook kaw-yoo]: birds of the air
- **mósól** [mo-sol]: rooster. (Not the same as **mosol** [maw-sawl]: going or walking downward)
- **mlon** [m'lawn]: hen. **hafak** [hah-fahk]: wing (Matthew 23:37)
- **tlangas** [t'lah-ngahs]: locust. **tneb** [t'nuhb]: honey (Matthew 3:4). **syufón** [syoo-fon]: scorpion (Luke 10:19)
- **wolf**: kept in English in the Bible
- **sheep**: ubiha. **dove**: obun. **snake**: ulal. **donkey**: asnu. **horse**: kudà. **cow**: safì. **goat**: kambing. **pig**: sdô. **dog**: ohu. **bird, chicken**: onuk. **rooster**: mósól. **hen**: mlon. **eagle**: banug. **fox**: bolos. **white**: bukay. **anger**: lóbô

### Joining words from the Bible (confirmed Oct 13)
- **abay se** [ah-bai suh]: because (757 times in the New Testament)
  - Luke 2:7: abay se là bud wen gónó le nô lem yóm gónô (because there was no room for them in the inn)
  - Matthew 5:3: abay se deng le sana gmung ne bè yó kem tau nogot Dwata (for theirs is the Kingdom of Heaven)
  - John 9:22: abay se likò le yó kem Ju (because they feared the Jews)
  - 1 Peter 5:8: Abay se wen Seitan yóm hohon ye (because your adversary, the devil)
- **yakà** [yah-kah']: for, because (172 times in the New Testament)
  - Matthew 4:17: yakà móyónen hto ne yóm buteng Dwata mogot tau (for the Kingdom of Heaven is near)
  - Matthew 2:13: yakà angat hfebel Hirod du yóm ngà (for Herod will seek the young child)
- **because**: kay, abay se, yakà

### Sentences graded 5/5 (Oct 13)
- **Là nóyóu du tungô, abay se teye bitil.** I don't want to sleep because I'm very hungry.
- **Meken kuy onuk, yakà tey kuy bitil.** Let's all eat chicken, for we're all very hungry.
- **Wen ulal lem ngà hungul koyu. Likòe!** There's a snake in the grove. I'm scared!
- **Bê tagad tungô he, abay se là u deng meken he.** Don't sleep yet, because you haven't eaten yet. Note: bê takes the ending of whoever you're telling.
- **Tey kekbong nawahu du ohu.** I really love dogs. Note: say kekbong nawa after tey, and put du in as the subject marker before the thing you love. Kay làen lóbô means "because it doesn't get angry" (-en is he/she/it, not they).
- **likò** [lee-kaw']: afraid, fear. Likòe: I'm scared. Likò le: they feared (John 9:22)

### Sentences graded 5/5, round 2 (Oct 13)
- **Mni kuy bè Dwata.** Let's all pray to God. (Answer: Amén)
- **Deng tonu yóm banug bè longit.** I saw the eagle in the sky.
- **Nóyóu smakay kudà bukay.** I want to ride a white horse.
- **Kmóót mósól ne, okóm là e deng tungô he.** The rooster's crowing already, but I haven't slept yet.
  - Other ways: **Kmóót ne mósól** (the rooster's crowing now), **Deng kmóót mósól** (the rooster already crowed), **Mósól deng mkóót** (the rooster has crowed, said like an announcement)
- **Hnifótem o kun, abay se deng gemsalà e béléem.** Please forgive me, because I wronged you. Note: the order is Hnifótem o kun, not Hnifótem kum o.
- **kofi** [kaw-fee]: eagle, the everyday word (banug is the Bible word)
- **kmóót** [k'mo-ot]: crow (a rooster crowing)
- **gemsalà** [guhm-sah-lah']: to sin against, to wrong someone
- **eagle**: banug, kofi

### Rooster sentences, graded 5/5 (Oct 13)
- **Kmóót ne mósól, meken kuy ne.** The rooster's crowing now, let's all eat.
- **Deng kmóót mósól, okóm hanà tungô du.** The rooster already crowed, but he's still asleep. Note: use hanà for "still," before the action.
- **Mósól deng mkóót! Hyu hlafus!** The rooster has crowed! Good morning!
- **Lóbóe bè mósól, abay se kmóót du bè kifu.** I'm mad at the rooster because it crows at night.
- **Kilón kekóót mósól du? / Kilón kekóóten mósól du?** When does the rooster crow? Answer: Kmóót du bè hlafus (it crows in the morning). Note: after kilón, kmóót becomes kekóót (like kbong becoming kekbong after tey).

### 10-sentence round, corrections (Oct 13)
- **Kilón kekenem du? Sana kebitilem mekô?** When will you eat? Are you still hungry, huh?
- **Tey kekbong nawahu du kofi, abay se tilob hafaken.** I really love eagles because their wings are beautiful.
- **Kilón kekóót mósól du? Hanà e tungô.** When will the rooster crow? I'm still sleeping. Note: hanà e tungô, the person goes right after hanà.
- **Béem ninum él kinì / Bê u minum él kinì / Béu minum él kinì, yakà tey kinì du.** Don't drink the hot water, for it's very hot. Note: bê + -em becomes béem and takes the n-form (ninum); bê u or béu takes the m-form (minum).
- **Wen sdô bê ta lmisa! Kayà lóbóe.** There's a pig on the table! That's why I'm mad.
- **Deng ton le yóm ulal, kayà likò le.** They saw the snake, so they're scared.
- **Mnihe bè Dwata, abay se deng gemsalà e.** I'm praying to God because I sinned. Note: mni ends in a vowel, so it's mnihe, not mni e.
- **Nóyóu smakay asnu, okóm likòe.** I want to ride a donkey, but I'm scared.
- **Meken kuy onuk haya.** Let's all eat chicken tomorrow.
- **Mósól deng mkóót! Mlon deng temsek skun!** The rooster crowed! The hen clucked too! Note: a hen doesn't kmóót, she temsek. And "too" for it/her is skun (skóm is "you too").
- **temsek** [tuhm-suhk]: a hen clucking or cackling
- **sana** [sah-nah]: still (Sana kebitilem mekô?)

### Round 5 corrections (Oct 13)
- **Sana kebitilu**: I'm still hungry (confirmed by Deymar)
- **Béem ninum yó él yó, abay se hanà kinì du / abay se hanà kekinien.** Don't drink that water, because it's still hot. Note: yó él yó = that water (yó on both sides). Hanà kekinien is the closest match for "it's still hot."
- **Mlon deng temsek, okóm hanà e tungô.** The hen clucked, but I'm still sleeping.
- **Kilón kekenle du?** When will they eat?
- **Likòe ulal, omin likò ohuhu skun.** I'm scared of snakes, and my dog is too. Other ways: omin likò skun ohuhu / omin likò skun dou ohu / dalang se ohuhu (as well as my dog)
- **dalang se** [dah-lahng suh]: as well as
- **And I'm scared of dogs** (all correct): Ominu likò ohu / Ne hu likò bê ohu / Le bud keklikou ohu / Omin likoe ohu
- **keklikò** [kuhk-lee-kaw']: the ke- form of likò (scared), as in keklikou

### Sana vs hanà (Oct 13)
- **sana** [sah-nah]: still, when you're not sure it's still happening, or when you're just noticing or asking. Takes the ke- form: sana ktungóen, sana kekenen, sana ke kudien
- **hanà** [hah-nah']: still, when you're sure it's still happening, or telling someone who doesn't know. Takes the plain form: hanà tungô, hanà meken, hanà udì
- **Sana kebitilu.** I'm still hungry.
- **Sana ktungóen du?** Is he still sleeping? Answer: Ell, hanà tungô (yes, still sleeping)
- **Hanà tungô du?** He's still sleeping? Answer: Ell, hanà tungô
- **Hanà meken du?** He's still eating? Answer: Ell, hanà mken / Ell, sana kekenen (yes, he's still eating)
- **Sana ke kudien du.** He's still small (just noticing it, or asking)
- **Hanà udì du.** He's still small (telling someone who doesn't know if he's small or big)
- **Hanà làen deng bong.** He's not big yet (and you know he'll still grow). Hanà also means "still, for now"
- **Sana deng bong du.** He's already big
- **udì** [oo-dee']: small. **bong** [bawng]: big

### Sana/hanà round, graded (Oct 13)
- **Sana ktungóen ohuhu?** Is my dog still sleeping? (no du needed when the subject is named)
- **Hanà udì ohuhu, okóm sana deng bong mósólu.** My dog is still small, but my rooster is already big.
- **Hanà le meken, abay se hanà kebitil le.** They're still eating, because they're still hungry. Note: the person word goes right after hanà (hanà le meken, hanà e tungô)
- **Sana le meken.** They immediately eat. Note: sana + person + plain form means "right away"
- **Sana kken le / Sana keken le.** They are still eating.
- **Sana kekenem (du)?** Are you still eating (it)? Du at the end is the "it" being eaten
- **Hanà là e deng tungô, abay se hanà kinì yó coffee-hu yó.** I still haven't slept, because that coffee of mine is still hot.

### Round 7, graded 5/5 (Oct 13)
- **Hanà e meken, abay se hanà kebitilu.** I'm still eating, because I'm still hungry.
- **Denge meken, sana e tungô / sanahe tungô.** I already ate, so I fall asleep right away. Note: sana ends in a vowel, so the ending can attach with h (sanahe), like nehe and mnihe
- **Sana kekóót mósól?** Is the rooster still crowing?
- **Hanà le tungô, okóm sana deng kmóót mósól.** They're still sleeping, but the rooster already crowed.
- **Sana kekenem du yó onuk yó?** Are you still eating that chicken? Note: du goes before the thing being eaten

### Confirmed from Bible word hunt round 4: Everyday life (Oct 13)
- **mambang** [mahm-bahng]: bread, a loaf. Hitu botù mambang = seven loaves; botù counts loaves
- **tnafay** [t'nah-fai]: bread (from Tagalog tinapay)
- **bnotu** [b'naw-too]: food packed for a trip
- **bnék** [b'nehk]: seed (Bible: sbotù bnék halay, one grain of wheat; sohul bnék, sow seed). Bnék hyu = good seed
- **lem** [luhm]: seed (Deymar's word; also lem = in/inside)
- **lan** [lahn]: path, road, way
- **tébéd** [teh-behd]: rope, cord. **fét** [feht]: tied, bound. **fes tébéd** [fuhs teh-behd]: whip of cords
- **bag** [bahg]: bag (from English). **tlumfà** [t'loom-fah']: sandals
- **abì** [ah-bee']: basket. **lukas** [loo-kahs]: leftovers
- **huket** [hoo-kuht]: net
- **solok** [saw-lawk]: lamp, light. **hemtom solok** [huhm-tawm saw-lawk]: light a lamp
- **blay** [blai]: gift, give. **kenhulung** [kuhn-hoo-loong]: gift, talent
- **lebeng** [luh-buhng]: grave, tomb; to bury. **lembeng** [luhm-buhng]: burying
- **kilib** [kee-leeb]: tomb cut into rock, cave (Bible: John 19:41 kilib lomi, new tomb; Hebrews 11:38 caves)

### Confirmed from Bible word hunt round 4: People (Oct 13)
- **tau hol geta / tau geta** [tah-oo hawl guh-tah / tah-oo guh-tah]: king; also rich person. **datù** [dah-too']: title used when speaking to a king
- **harì** [hah-ree']: king (from Tagalog hari)
- **tau dók** [tah-oo dok]: servant ("a person who is ordered"). **dók** [dok]: command, order. **tóbóng lówó** [to-bong lo-wo]: humble servant, helper. **ngà libun gel dók le** [ngah' lee-boon guhl dok luh]: servant girl
- **hohon / hmohon** [haw-hawn / h'maw-hawn]: enemy. **hnohon** [h'naw-hawn]: treated as an enemy
- **libun bolu** [lee-boon baw-loo]: widow. **bolu** [baw-loo]: widowed
- **tau sbung** [tah-oo s'boong]: crowd ("gathered people"). **tey dê tau** [tuhy deh' tah-oo]: a lot of people
- **mentey** [muhn-tuhy]: to guard, keep watch. **sendalù mentey** [suhn-dah-loo' muhn-tuhy]: guards. **sendalù** [suhn-dah-loo']: soldier
- **hemdeng / hendeng** [huhm-duhng / huhn-duhng]: to judge, decide. **kukum** [koo-koom]: law, judgment. **kmukum** [k'moo-koom]: judging. **tau hemdeng knukum** [tah-oo huhm-duhng k'noo-koom]: judge

### Confirmed from Bible word hunt round 4: Doing words (Oct 13)
- **hmatay** [h'mah-tai]: to kill ("make die"). **hnatay** [h'nah-tai]: killed. **ghatay** [g'hah-tai]: able to be killed
- **kéng** [kehng]: lie, to tell a lie. **gel mò kéng** [guhl maw' kehng]: keep lying
- **hógów** [ho-gohw]: to send. **deng hógówu** [duhng ho-go-woo]: I sent. **hógów Dwata** [ho-gohw dwah-tah]: angel ("God's sent one")
- **eted** [uh-tuhd]: send (general), deliver
- **muta** [moo-tah]: to harvest. **nuta** [noo-tah]: the harvest. **fun nuta** [fyoon noo-tah]: owner of the harvest
- **hkó des** [h'ko duhs]: to heal ("make the sickness leave")
- **hemdà / hdà** [huhm-dah' / h'dah']: to build ("make stand"). **gembà** [guhm-bah']: destroy
- **nélék** [neh-lehk]: chose, chosen. **kélék** [keh-lehk]: choosing, appointing
- **mebel** [muh-buhl]: to look for, search. **hnebelen** [h'nuh-buh-luhn]: he searched for
- **fasad** [fah-sahd]: promise. **fasaden** [fah-sah-duhn]: his promise
- **sohul** [saw-hool]: to sow, scatter seeds. **smohul** [smaw-hool]: sowing. **ksohulen** [k'saw-hoo-luhn]: his sowing
- **hulu** [hoo-loo]: to plant

### Confirmed from Bible word hunt round 4: Feelings and ideas (Oct 13)
- **menek nawa / henek nawa / kenek nawa** [muh-nuhk nah-wah / huh-nuhk nah-wah / kuh-nuhk nah-wah]: peace ("calm breath"). **nawa** [nah-wah]: breath
- **kehligal / kligal** [kuh-h'lee-gahl / klee-gahl]: joy, happiness (from hligal, happy)
- **kehtahu** [kuh-h'tah-hoo]: faith, belief (from tahu, true). **hemtahu** [huhm-tah-hoo]: believe
- **ktahuhen** [k'tah-hoo-huhn]: the truth. **Tódô tulónu kuy ktahuhen**: I tell you the truth
- **kgis** [k'ghees]: strength. **kemgis** [kuhm-ghees]: strong
- **lewok** [luh-wawk]: tears. **mosok lewok** [maw-sawk luh-wawk]: tears falling
- **mosok** [maw-sawk]: something falling on its own, by itself

### Confirmed from Bible word hunt round 4: Describing words (Oct 13)
- **tau élél** [tah-oo eh-lehl]: poor person. **élél** [eh-lehl]: lacking, not having (ke wen gónó le élél = if there's something they lack)
- **glayam** [glah-yahm]: poor
- **là ket** [lah' kuht]: lack (as a word; depends on context)
- **butô** [boo-to']: blind
- **bokong** [baw-kawng]: deaf. **hbokong** [h'baw-kawng]: to make deaf. **umew** [oo-muhw]: mute

### Confirmed from Bible word hunt round 4: Things and places (Oct 13)
- **blówón** [blo-won]: gold. **kuruna** [koo-roo-nah]: crown
- **filak** [fee-lahk]: silver, money
- **tifas** [tee-fahs]: wine. **ninum** [nee-noom]: a drink (from minum). **ninum lóbô** [nee-noom lo-bo']: strong drink
- **bak tikeb** [bahk tee-kuhb]: gate, door. **bak tikeben** [bahk tee-kuh-buhn]: its gates. **Tikeb Tilob** [tee-kuhb tee-lawb]: Beautiful Gate
- **tey lenos bong** [tuhy luh-naws bawng]: storm ("very big wind"). **bagyu** [bahg-yoo]: storm (everyday word)
- **nulu** [noo-loo]: wedding. **gónô mulu** [go-no' moo-loo]: wedding house/feast. **ken nuluhen** [kuhn noo-loo-huhn]: his wedding feast. **logi myehen** [law-ghee myuh-huhn]: groom

### Notes from Deymar (Oct 13)
- **h- prefix**: means "make it happen" / cause (hmatay make die, hdà make stand, hkó des make the sickness leave, hbokong make deaf, hekgis/hekegis make strong; the h- goes on the root kgis, not kemgis)
- **lem** [luhm]: inside; seed is lem because it's the inside (same word)
- Old words like mambang (bread) and tey lenos bong (storm) are still said, mostly by older people; younger people use tnafay, bagyu, harì
- **lnos** [l'naws]: wind (short form of lenos)
- **husek** [hoo-suhk]: come/go inside of something; add the person after for who goes in. **Husek ye**: you all get in, come in, go in. **Géhél ye husek**: hurry, you all get in
- **lnos kemgis / lenos kemgis** [l'naws kuhm-ghees / luh-naws kuhm-ghees]: strong wind. **lnos bong** [l'naws bawng]: big wind
- **Géhél ye!**: hurry up, you all!
- Strong wind, go inside: **Tey lnos bong! Mulék kuy bê lem gónô ne. Géhél ye! Husek ye.** (Very big wind! We go back inside the house now. Hurry up! Come in.)
- **Huseku** [hoo-suh-koo]: you're going in. **Huseke** [hoo-suh-kuh]: I was going in. **Husek du**: he/she goes in. Takes the rest of the person endings too
- Describing word goes after the thing: lnos kemgis (strong wind), gónô bong (big house)
- He's poor, he doesn't have enough food: **Glayam du, làen ket kenen.** (làen ket = not enough; kenen = his food; the endings carry the person). For none at all, use **làen dù / andù**
- I'll send you money: **Nehu eted filak béléem.**
- There's a storm tomorrow. Really strong wind!: **Wen bagyu haya. Tey lnos kemgis!**
- His tears are falling, so cheer him up: **Mosok lewoken, henligalem du.**
- **slaf** [slahf]: have to, worry; same meaning as lóngón
- **senlaf** [suhn-lahf]: to do something fast; figuring out how to do it. **Senlafu kekenu**: I'm figuring out how I'll eat. Lnóngón works the same way
- **g-**: able to (gbayad, able to pay; ghatay, able to be killed). **Là gbayadu (du)**: I can't pay (it). **bayad** [bah-yahd]: pay in general
- Don't (you) worry: **Béu lóngónem / Tafa nawahem / Heslafem**
- I can't sleep: **Làe gtungô**. **Là gtungóu?**: you can't sleep? **Là u gtungô?**: you couldn't sleep?
- **Là gbayadu du**: I can't pay it. **Làe gbayad**: I couldn't pay
- **hekgis / hekegis** [huhk-ghees / huh-kuh-ghees]: make strong (h- + kgis). **Nehu hekgis u**: I'll make you strong
- **Lnos kemgis** [l'naws kuhm-ghees] vs **kemgis lnos** [kuhm-ghees l'naws]: lnos kemgis tells someone the wind is strong; kemgis lnos describes it, more like a statement or saying it to yourself
- I don't have enough money: **làen ket filaku** (-en, because the money is the subject). No money at all: **Làen dù filaku**, as in Acts 3:6
- Don't worry, I'll make you strong: **Béu lóngónem, nehu hekgis u.**
- I couldn't sleep yesterday because the wind was really strong: **Làe gtungô ekimel, kay tey lnos kemgis.**
- I can't pay it, because I don't have enough money: **Là gbayadu du, kay làen ket filaku.**
- I can't watch TV, because there's no electricity: **Làe gton TB, kay làen dù (andù) kurinti.** (Deymar, Oct 15)
- Hurry, all of you, get inside the big house: **Géhél ye husek bê lem gónô bong.**
- Tomorrow I'll plant seeds next to my house: **Haya, nehu hulu lem bê lohok gónóu.**
- I'll build a big house by the water: **Nehu hdà gónô bong bê lohok él.**
- The strong wind will make you cold: **Hetnawen u lnos kemgis.**
- Feed my cats!: **Henkenem kem kuyingu kun!**
- I'll heal him (make his sickness leave): **Nehu hkó desen.**
- Make them happy (command): **Hefligalem lu.**
- My teacher: **mestluhu**. Thanks, my teacher: **Slamat béléem, mestluhu.**
- Look it up in our notes!: **Nebelem du bê sulat te kun!** (everyday version: Nebelem bê notes-te kun!)
- Deymar is my teacher, and my friend: **Deymar mestluhu, omin dou dumu sbót.** (dou = my)
- And I'm his friend too: **Omin ou kun dumu sbót.**
- I'll help you: **Nehu tnóbóng u** (tóbong takes the n inside here)
- Teacher Deymar taught me the words of T'boli: **Tnoloken o Mestlu Deymar kem udél T'boli.** Passive version: **Ou tnolok Mestlu Deymar udél T'boli.**
- I want everyone to be happy: **Kóyô u / Kóyóu ke kdéen tau hol hligal.** **Dou kóyô** also works, meaning "my want"
- **kun** [koon]: his/hers/its, something he/she/it owns. Fits the set: kut (ours), kuy (yours), kul (theirs), kun (his/hers)
- And I'm his friend, telling someone: **Omin ou dumuhen sbót.**
- **kun (please)** [koon]: a second kun that softens a request into "please" or "for me": Snolokem du kun
- Please get his bag (for me): **Nwahem do kun yóm kun bag.** First kun = please; yóm kun = the one that's his, and the bag is the subject
- Please get me his bag: **Nwahem do kun bagen.** The -en on bag says who owns it
- **nwahem** [n'wah-huhm]: you get/take it (wa, take; same root as gwa and swa)
- Please get me my bag: **Nwahem do kun baghu.**
- **lana** [lah-nah]: gone, disappear, die out (là nóyóen du ke lana udél T'boli: he doesn't want T'boli to disappear)
- **néen** [neh-uhn]: only, just. Fun néen (just for fun), Ok néen (just okay)
- **Filipinas** [fee-lee-pee-nahs]: Philippines
- **Alfabét** [ahl-fah-beht]: alphabet
- **Farmasi** [fahr-mah-see]: pharmacy
- **Faris** [fah-rees]: Paris
- **Fkistan** [f'kees-tahn]: Pakistan
- **Fortugal** [fawr-too-gahl]: Portugal
- **Péru** [peh-roo]: Peru
- **Fól** [fol]: Paul (traditional; the Bible spells it Pol)
- **Faro** [fah-raw]: Pharaoh. Yóm libun boi Faro: Pharaoh's daughter (Hebrews 11:24). The Bible usually just says tau hol geta bè Idyip, the king of Egypt (Acts 7:10)
- **Stéfén** [steh-fehn]: Stephen (Acts 7:1)

### Places in Canaan, from the Bible, confirmed (Oct 13)

**The land and regions**
- **Kanan** [kah-nahn]: Canaan. **tau Kanan** [tah-oo kah-nahn]: a Canaanite (Matthew 15:22)
- **Judiya** [joo-dee-yah]: Judea (Matthew 2:1)
- **Samarya** [sah-mahr-yah]: Samaria (John 4:5)
- **Galili** [gah-lee-lee]: Galilee (Luke 1:26)
- **Idumiya** [ee-doo-mee-yah]: Idumea (Mark 3:8)
- **Sfolò Benwu** [sfaw-law' buhn-woo]: the Decapolis, literally "ten towns" (Mark 5:20)
- **Falistin** [fah-lees-teen]: Palestine (not in the New Testament; Deymar confirmed)
- **Filistin / tau Filistin** [fee-lees-teen / tah-oo fee-lees-teen]: Philistine (not in the New Testament; Deymar confirmed)

**Jerusalem and around it**
- **Jirusalim** [jee-roo-sah-leem]: Jerusalem (Matthew 4:5)
- **Sayun** [sah-yoon]: Zion (1 Peter 2:6)
- **Bitlihim** [beet-lee-heem]: Bethlehem (Matthew 2:1)
- **Bitani** [bee-tah-nee]: Bethany (Matthew 26:6)
- **Bitfid** [beet-feed]: Bethphage (Matthew 21:1)
- **Bulul Ulib** [boo-lool oo-leeb]: Mount of Olives (Matthew 24:3)
- **Gitsimani** [gheet-see-mah-nee]: Gethsemane (Matthew 26:36)
- **Golgata** [gawl-gah-tah]: Golgotha. **Bangag Kulu** [bah-ngahg koo-loo]: skull, the meaning the verse gives (Matthew 27:33)
- **Silom** [see-lawm]: Siloam (John 9:7)
- **Kidron** [keed-rawn]: Kidron (John 18:1)
- **Imiyus** [ee-mee-yoos]: Emmaus (Luke 24:13)
- **Ifraim** [eef-rah-eem]: Ephraim (John 11:54)
- **Arimatiya** [ah-ree-mah-tee-yah]: Arimathea (Luke 23:50)
- **Rama** [rah-mah]: Ramah (Matthew 2:18)

**Galilee and the lake**
- **Lanaw Galili** [lah-now gah-lee-lee]: Sea of Galilee (Matthew 4:13)
- **Nasarit** [nah-sah-reet]: Nazareth (Luke 1:26)
- **Kapérnaum** [kah-pehr-nah-oom]: Capernaum (Matthew 4:13)
- **Kana** [kah-nah]: Cana (John 21:2)
- **Nain** [nah-een]: Nain (Luke 7:11)
- **Bitsayda** [beet-sai-dah]: Bethsaida (Luke 10:13)
- **Kurasin** [koo-rah-seen]: Chorazin (Luke 10:13)
- **Megdala** [muhg-dah-lah]: Magdala (John 20:1)
- **Ginésarit** [ghee-neh-sah-reet]: Gennesaret (Matthew 14:34)
- **Dalmanuta** [dahl-mah-noo-tah]: Dalmanutha (Mark 8:10)
- **Girasin** [ghee-rah-seen]: Gerasenes (Matthew 8:28)

**Jordan valley**
- **Jurdan** [joor-dahn]: Jordan River (Matthew 3:13)
- **Jiriku** [jee-ree-koo]: Jericho (Luke 10:30)
- **Inun, Salim** [ee-noon, sah-leem]: Aenon, Salim (John 3:23)
- **Sikar** [see-kahr]: Sychar (John 4:5)

**Coast and north**
- **Tayal** [tah-yahl]: Tyre (Luke 10:13)
- **Sidon** [see-dawn]: Sidon (Luke 10:13). In Acts 9:35, Sidon is also used for Sharon
- **Tulimas** [too-lee-mahs]: Ptolemais, the P dropped (Acts 21:7)
- **Seseriya** [suh-suh-ree-yah]: Caesarea (Acts 8:40)
- **Seseriya Flipay** [suh-suh-ree-yah flee-pai]: Caesarea Philippi, Ph to F (Matthew 16:13)
- **Jupa** [joo-pah]: Joppa (Acts 9:36)
- **Lida** [lee-dah]: Lydda (Acts 9:35)
- **Asdod** [ahs-dawd]: Azotus, the old Hebrew name (Acts 8:40)
- **Gasa** [gah-sah]: Gaza (Acts 8:26)
- **Antipatris** [ahn-tee-paht-rees]: Antipatris (Acts 23:31)

**Old Canaan cities**
- **Sodom, Gomora** [saw-dawm, gaw-maw-rah]: Sodom and Gomorrah (Luke 10:12, Jude 1:7)

### Number sentences, graded 5/5 (Oct 14)
1. Wen dô wolu libu bud lwu latu kati tau bè klamangen benwu. There are about 8.2 billion people in the whole world.
2. Lwu folò fat ne halayu. I'm 24 years old now.
3. Tlu dulék ton me ulal gna halay. We saw a snake three times last year.
4. Lwu libu lwu folò nem yóm halay ni. This year is 2026.
5. Kóyóu ke wen dou sotu trilyun pésó. I want to have a trillion pesos.
- **Pésó** [peh-so]: peso. In everyday T'boli it's said **Pisu**.

### Money words, from the T'boli Bible (Oct 14), confirmed by Deymar
- **filak** [fee-lahk]: money, silver. "Laen dù filaku dou" / "Silver and gold have I none" (Acts 3:6). "bê ye abay mit filak" / "take no gold, silver or copper" (Matt 10:9)
- **filak blówón** [fee-lahk blo-won]: gold money, valuable coins. "sfolò filak blówón alì mebtes" / "ten silver coins" (Luke 15:8). "limu libu filak tahu blówón" / "five talents" (Matt 25:15)
- **filak mgel** [fee-lahk m'guhl]: coin. "filak mgel mò bayad bwis" / "the coin for the tax" (Matt 22:19). "yóm filak mgel tonem lem baken" / "you'll find a coin in its mouth" (Matt 17:27)
- **botù** [baw-too']: counter for pieces. "tlu folò botù yóm kul filak mgel" / "thirty pieces of silver" (Matt 26:15)
- **lad** [lahd]: small coin, cent. "Tek lewu lad blayen" / "she put in two small copper coins" (Mark 12:42). "tek lewu lad bli yóm limu botù" / "five sparrows sold for two pennies" (Luke 12:6)
- **sukéy** [soo-kay]: wages. "ksukéyen kul sendaw" / "a denarius for the day" (Matt 20:2). The Bible turns denarii into wages: 200 denarii = "sukéy sotu tau bè wolu bulón" (one person's pay for eight months, John 6:7); 300 denarii = "sukéy sotu tau bè sfalay" (a year's pay, John 12:5)
- **bayad / mayad** [bah-yahd / mah-yahd]: payment, to pay. "Gel mayad kô kun yóm tau gónó ye gel htolok yó?" / "Doesn't your teacher pay the tax?" (Matt 17:24)
- **bwis** [b'wees]: tax (Matt 22:19)
- **utóng / mutóng** [oo-tong / moo-tong]: debt, to owe. "mutóng deng hilu kati filak" / "owed ten thousand talents" (Matt 18:24)
- **hilu** [hee-loo]: how much, how many. "Hilu de blay ye do?" / "What will you give me?" (Matt 26:15)
- **blihen** [blee-huhn]: its price. "blay bè tu kem tau élél yóm blihen" / "given the money to the poor" (John 12:5)
- **Sfalay** [sfah-lai]: one year, s- + halay, confirmed by Deymar (Heb 9:7 "tek suléken husek elemen bè yóm sfalay" / "only once a year")

### News article, graded 10/10 (Oct 14)
Tey dê kulón bê Denlag. Ekimel, tey dê kulón bê Denlag, T'boli. Deng hlosok yóm kulón bê ta tonok kekifuhen ni, ne hanà kmulón kdaw ni. Wen kem tau bê farm mon, "Deng lana yóm kem kmatì me omin soging me." Kay ni, tey geta ne yóm blihen kmatì bê benwu. Sotu kilo kmatì, lmatu pisu ne. Bê ye gów bê lanaw, kay alì dê yóm él. Haya bud kmulón, mon yóm PAGASA.
- Correction: sok kifu → **kekifuhen ni** (Deymar). Sok kifu is "if/when it's night," for any night, so it can't point to one specific night
- **Geta** works for a high price (Deymar)

### Night words, from the T'boli Bible (Oct 14)
- **kekifuhen = kkifuhen** [kuh-kee-foo-hun = kkee-foo-hun]: the same word, spelled two ways. The Bible writes the ke- form short as kk- (confirmed by Deymar)
- **ket kifuhen** [kuht kee-foo-huhn]: every night. "Okóm ket kifuhen gel hetsik ebè Bulul Ulib" / "at night he went out to the Mount of Olives" (Luke 21:37)
- **kkifuhen** [kkee-foo-hun]: the night, the darkness (same as kekifuhen). "laen kô dù tul kkifuhen bè yó" / "there will be no night there" (Rev 21:25)
- **suloy buteng** [soo-loy boo-tuhng]: all night long. "Deng suloy me buteng ne... laen kô dù guta me" / "we toiled all night and took nothing" (Luke 5:5). "Tódô suloyen buteng mni" / "he continued all night in prayer" (Luke 6:12)
- **kifu ni** [kee-foo nee]: tonight, this night. "bè gewuhen dulék kifu ni kdeng" / "this very night, before the rooster crows twice" (Mark 14:30)
- **bè yóm kifu yó** [buh' yom kee-foo yo]: that night (Acts 5:19)
