import { createServerFn } from "@tanstack/react-start";
import { contextForTranslation, lookupPhrase } from "./dictionary";

export const translateToTboli = createServerFn({ method: "POST" })
  .validator((input: { q: string }) => ({
    q: String(input?.q ?? "").slice(0, 280),
  }))
  .handler(async ({ data }) => {
    const q = data.q.trim();
    if (!q) return { ok: false as const, error: "Type an English phrase first." };

    const phrase = lookupPhrase(q);
    if (phrase) {
      return { ok: true as const, text: phrase.tbl, source: "book" as const };
    }

    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return {
        ok: false as const,
        error: "That phrase isn't in Deymar's dictionary. Try good morning, child, or I love you.",
      };
    }

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.2,
        max_tokens: 160,
        messages: [
          {
            role: "system",
            content:
              "Translate English into T'boli as taught by native speaker Deymar. Copy spelling and accents exactly (ngà, bê, t'ngón). Build the meaning from the rules, not word by word. Use only words in the notes. If a word is missing, keep it in English inside [brackets]. Reply with ONLY the T'boli sentence.",
          },
          {
            role: "user",
            content: `${contextForTranslation(q)}\n\nEnglish:\n${q}`,
          },
        ],
      }),
    });

    if (!res.ok) {
      return { ok: false as const, error: "Translation is unavailable right now." };
    }

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = (body.choices?.[0]?.message?.content ?? "").trim();
    if (!text) {
      return { ok: false as const, error: "No translation returned." };
    }
    return { ok: true as const, text, source: "ai" as const };
  });
