import { createFileRoute } from "@tanstack/react-router";
import { WriteScreen } from "@/components/screens/write-screen";

export const Route = createFileRoute("/write")({ component: WriteScreen });
