import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { ImeKeyboard } from "@/components/ime-keyboard";
import { backspaceInto, insertInto, submitOrNewline, type ImeEl } from "@/lib/ime-edit";
import {
  loadPrefs,
  savePrefs,
  type KeyboardPrefs,
  type LayoutLang,
} from "@/lib/prefs";

type ImeContextValue = {
  ready: boolean;
  installed: boolean;
  selected: boolean;
  lang: LayoutLang;
  visible: boolean;
  setInstalled: (value: boolean) => void;
  setSelected: (value: boolean) => void;
  setLang: (lang: LayoutLang) => void;
  cycleLang: () => void;
  enable: () => void;
  disable: () => void;
  register: (el: ImeEl) => void;
  hide: () => void;
  insert: (chunk: string) => void;
  backspace: () => void;
  enter: () => void;
};

const ImeContext = createContext<ImeContextValue | null>(null);

export function useIme() {
  const ctx = useContext(ImeContext);
  if (!ctx) throw new Error("useIme must be used inside ImeProvider");
  return ctx;
}

export function ImeProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefs] = useState<KeyboardPrefs>({
    installed: false,
    selected: false,
    lang: "tbl",
  });
  const [ready, setReady] = useState(false);
  const [target, setTarget] = useState<ImeEl | null>(null);
  const holdRef = useRef(false);

  useEffect(() => {
    setPrefs(loadPrefs());
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    savePrefs(prefs);
  }, [prefs, ready]);

  const patch = useCallback((partial: Partial<KeyboardPrefs>) => {
    setPrefs((p) => ({ ...p, ...partial }));
  }, []);

  const register = useCallback((el: ImeEl) => {
    holdRef.current = true;
    setTarget(el);
  }, []);

  const hide = useCallback(() => {
    holdRef.current = false;
    window.setTimeout(() => {
      if (!holdRef.current) setTarget(null);
    }, 160);
  }, []);

  const insert = useCallback((chunk: string) => {
    if (!target) return;
    insertInto(target, chunk);
    target.focus();
  }, [target]);

  const backspace = useCallback(() => {
    if (!target) return;
    backspaceInto(target);
    target.focus();
  }, [target]);

  const enter = useCallback(() => {
    if (!target) return;
    submitOrNewline(target);
  }, [target]);

  const cycleLang = useCallback(() => {
    patch({ lang: prefs.lang === "tbl" ? "en" : "tbl" });
  }, [patch, prefs.lang]);

  const visible = Boolean(ready && prefs.installed && prefs.selected && target);

  const value = useMemo<ImeContextValue>(
    () => ({
      ready,
      installed: prefs.installed,
      selected: prefs.selected,
      lang: prefs.lang,
      visible,
      setInstalled: (installed) => patch({ installed, selected: installed ? prefs.selected : false }),
      setSelected: (selected) => patch({ selected: selected && prefs.installed }),
      setLang: (lang) => patch({ lang }),
      cycleLang,
      enable: () => patch({ installed: true, selected: true }),
      disable: () => patch({ installed: false, selected: false }),
      register,
      hide,
      insert,
      backspace,
      enter,
    }),
    [
      backspace,
      cycleLang,
      enter,
      hide,
      insert,
      patch,
      prefs.installed,
      prefs.lang,
      prefs.selected,
      ready,
      register,
      visible,
    ],
  );

  return (
    <ImeContext.Provider value={value}>
      {children}
      {visible ? <ImeKeyboard /> : null}
    </ImeContext.Provider>
  );
}
