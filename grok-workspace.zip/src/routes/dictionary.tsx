import { createFileRoute } from "@tanstack/react-router";
import { DictionaryScreen } from "@/components/screens/dictionary-screen";

export const Route = createFileRoute("/dictionary")({
  component: DictionaryScreen,
});
