import raw from "@/data/dictionary.json";

export type DictForm = { form: string; gloss: string };
export type DictExample = { tbl: string; en: string };
export type DictEntry = {
  head: string;
  letter: string;
  gloss: string;
  forms: DictForm[];
  examples: DictExample[];
};
export type EnIndex = { en: string; heads: string };
export type DictPhrase = { topic: string; tbl: string; en: string; lesson?: boolean };
export type GuideBlock = { kind: "p" | "li"; text: string };
export type GuideSection = { title: string; blocks: GuideBlock[] };

const data = raw as {
  entries: DictEntry[];
  index: EnIndex[];
  phrases: DictPhrase[];
  guide: GuideSection[];
};

export const ENTRIES = data.entries;
export const EN_INDEX = data.index;
export const PHRASES = data.phrases;
export const GUIDE = data.guide;

export const LETTERS = [...new Set(ENTRIES.map((e) => e.letter).filter(Boolean))];
export const TOPICS = [...new Set(PHRASES.map((p) => p.topic))];

export const QUICK_ENGLISH = [
  "good morning",
  "how are you?",
  "thank you so much",
  "I love you",
  "I'm very hungry",
  "let's eat",
] as const;

function norm(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[“”"']/g, "")
    .replace(/[?.!,;:]+/g, "")
    .replace(/\s+/g, " ");
}

function fold(value: string): string {
  return norm(value)
    .normalize("NFD")
    .replace(/\p{M}/gu, "");
}

const NO_WORD = new Set([
  "a",
  "an",
  "am",
  "is",
  "are",
  "was",
  "were",
  "be",
  "been",
  "being",
  "do",
  "does",
  "did",
  "of",
  "have",
  "has",
  "had",
  "will",
  "can",
  "let",
]);

const CONTRACTIONS: Record<string, string[]> = {
  "i'm": ["I", "am"],
  "you're": ["you", "are"],
  "we're": ["we", "are"],
  "they're": ["they", "are"],
  "he's": ["he", "is"],
  "she's": ["she", "is"],
  "it's": ["it", "is"],
  "that's": ["that", "is"],
  "what's": ["what", "is"],
  "where's": ["where", "is"],
  "who's": ["who", "is"],
  "there's": ["there", "is"],
  "i'll": ["I", "will"],
  "you'll": ["you", "will"],
  "we'll": ["we", "will"],
  "they'll": ["they", "will"],
  "i've": ["I", "have"],
  "we've": ["we", "have"],
  "don't": ["do", "not"],
  "can't": ["can", "not"],
  "won't": ["will", "not"],
  "didn't": ["did", "not"],
  "isn't": ["is", "not"],
  "aren't": ["are", "not"],
  "let's": ["let", "us"],
  "haven't": ["have", "not"],
  "hasn't": ["has", "not"],
};

function normLex(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[“”"']/g, "")
    .replace(/[?.!,;:()]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function soften(value: string): string {
  let s = value.trim().toLowerCase();
  s = s.replace(/\([^)]*\)/g, " ");
  const swaps: [RegExp, string][] = [
    [/\bi'm\b/g, "i am"],
    [/\byou're\b/g, "you are"],
    [/\bwe're\b/g, "we are"],
    [/\bthey're\b/g, "they are"],
    [/\bhe's\b/g, "he is"],
    [/\bshe's\b/g, "she is"],
    [/\bit's\b/g, "it is"],
    [/\bthat's\b/g, "that is"],
    [/\bwhat's\b/g, "what is"],
    [/\bwhere's\b/g, "where is"],
    [/\bwho's\b/g, "who is"],
    [/\bthere's\b/g, "there is"],
    [/\bi'll\b/g, "i will"],
    [/\byou'll\b/g, "you will"],
    [/\bwe'll\b/g, "we will"],
    [/\bthey'll\b/g, "they will"],
    [/\bi've\b/g, "i have"],
    [/\bdon't\b/g, "do not"],
    [/\bcan't\b/g, "cannot"],
    [/\bwon't\b/g, "will not"],
    [/\blet's\b/g, "let us"],
    [/\bhaven't\b/g, "have not"],
    [/\bisn't\b/g, "is not"],
    [/\baren't\b/g, "are not"],
    [/\bdidn't\b/g, "did not"],
  ];
  for (const [re, to] of swaps) s = s.replace(re, to);
  return normLex(s);
}

function compactGloss(heads: string): string {
  const parts = heads
    .split(";")
    .map((part) =>
      part
        .replace(/\s*\([^)]*\)/g, " ")
        .replace(/\s+under\s+.*/i, "")
        .replace(/\s+/g, " ")
        .trim(),
    )
    .filter(Boolean);
  const unique: string[] = [];
  for (const part of parts) {
    if (!unique.some((item) => item.toLowerCase() === part.toLowerCase())) unique.push(part);
  }
  const two = unique.slice(0, 2).join(" · ");
  if (two.length <= 32) return two;
  return unique[0] ?? "";
}

const LEX = new Map<string, string>();

function addLex(key: string, gloss: string) {
  const k = normLex(key);
  if (!k || k.length > 48 || NO_WORD.has(k) || LEX.has(k)) return;
  const g = gloss.trim();
  if (!g) return;
  LEX.set(k, g);
}

for (const item of EN_INDEX) {
  const gloss = compactGloss(item.heads);
  const exact = normLex(item.en);
  if (exact && gloss && !NO_WORD.has(exact)) LEX.set(exact, gloss);
}

for (const item of EN_INDEX) {
  const gloss = LEX.get(normLex(item.en));
  if (!gloss) continue;
  const spelled = item.en.replace(/\(([^)]+)\)/g, " $1 ").replace(/\s+/g, " ").trim();
  const beforeParen = item.en.replace(/\s*\([^)]*\)\s*$/, "").trim();
  const aliases = new Set<string>([spelled, beforeParen]);
  for (const bit of spelled.split(",")) aliases.add(bit.trim());
  for (const alias of aliases) addLex(alias, gloss);
}

type Pair = { en: string; tbl: string; rank: number };

function clauseSplit(value: string): string[] {
  const parts = value
    .split(/(?<=[.!?])\s+/)
    .map((part) => part.trim())
    .filter(Boolean);
  return parts.length ? parts : [value.trim()].filter(Boolean);
}

function pushPair(rows: Pair[], en: string, tbl: string, rank: number) {
  const english = en.replace(/\s*\([^)]*\)/g, " ").replace(/\s+/g, " ").trim();
  const tboli = tbl.trim();
  if (!english || !tboli) return;
  rows.push({ en: english, tbl: tboli, rank });
  const ec = clauseSplit(english);
  const tc = clauseSplit(tboli);
  if (ec.length < 2 || ec.length !== tc.length) return;
  for (let i = 0; i < ec.length; i++) {
    const left = ec[i];
    const right = tc[i];
    if (!left || !right) continue;
    if (soften(left) === soften(english)) continue;
    rows.push({ en: left, tbl: right, rank: rank + 1 });
  }
}

function collectPairs(): Pair[] {
  const rows: Pair[] = [];
  for (const phrase of PHRASES) {
    const rank = phrase.lesson
      ? 0
      : phrase.topic === "Stories and sentences"
        ? 3
        : phrase.topic === "Cuss words"
          ? 4
          : 1;
    pushPair(rows, phrase.en, phrase.tbl, rank);
  }
  for (const entry of ENTRIES) {
    for (const example of entry.examples) {
      if (example.en) pushPair(rows, example.en, example.tbl, 1);
    }
    for (const form of entry.forms) {
      if (!form.gloss || form.gloss.includes("(") || form.gloss.length > 90) continue;
      const words = soften(form.gloss).split(" ").filter(Boolean);
      if (words.length < 2 || words.length > 14) continue;
      pushPair(rows, form.gloss, form.form, 1);
    }
  }
  return rows;
}

const PAIRS = collectPairs();

function firstGloss(gloss: string): string {
  return (gloss.split("·")[0]?.split("/")[0] ?? gloss).trim();
}

for (const pair of PAIRS) {
  const en = soften(pair.en).split(" ").filter(Boolean);
  const tbl = pair.tbl
    .replace(/[?.!]+$/g, "")
    .split(/\s+/)
    .filter(Boolean);
  if (en.length !== 2 || tbl.length !== 2) continue;
  const g0 = LEX.get(en[0] ?? "");
  const g1 = LEX.get(en[1] ?? "");
  const same = (gloss: string | undefined, word: string) => !!gloss && fold(firstGloss(gloss)) === fold(word);
  if (same(g0, tbl[0] ?? "") && !g1) addLex(en[1] ?? "", tbl[1] ?? "");
  else if (same(g1, tbl[1] ?? "") && !g0) addLex(en[0] ?? "", tbl[0] ?? "");
  else if (same(g0, tbl[1] ?? "") && !g1) addLex(en[1] ?? "", tbl[0] ?? "");
  else if (same(g1, tbl[0] ?? "") && !g0) addLex(en[0] ?? "", tbl[1] ?? "");
}

export type GlossPiece = { en: string; tbl: string | null; gap: boolean };
export type PhraseHit = { tbl: string; alts: string[] };

function wordGloss(word: string): string | null {
  const key = normLex(word);
  if (!key || NO_WORD.has(key)) return null;
  const direct = LEX.get(key);
  if (direct) return direct;
  if (key.endsWith("s")) return LEX.get(key.slice(0, -1)) ?? null;
  return LEX.get(`${key}s`) ?? null;
}

export function primaryTboli(english: string): string | null {
  const gloss = wordGloss(english);
  if (!gloss) return null;
  const first = gloss.split("·")[0]?.split("/")[0]?.split(",")[0]?.trim() ?? "";
  return first || null;
}

const HEAD_BY_FOLD = new Map<string, DictEntry>();
for (const entry of ENTRIES) {
  const key = fold(entry.head);
  if (key && !HEAD_BY_FOLD.has(key)) HEAD_BY_FOLD.set(key, entry);
}

export function tboliVerb(english: string, ongoing: boolean): string {
  const root = primaryTboli(english)?.split(/\s+/)[0];
  if (!root) return `[${english}]`;
  if (!ongoing) return root;
  const entry = HEAD_BY_FOLD.get(fold(root));
  if (!entry) return root;
  for (const form of entry.forms) {
    const bit = form.form.split("/")[0]?.trim().split(/\s+/)[0] ?? "";
    if (/^m/i.test(bit) && bit.length < 18 && !/[[\]*]/.test(bit)) return bit;
  }
  return root;
}

type Suggestion = { head: string; gloss: string };
const SUGGESTIONS: { head: string; key: string; gloss: string }[] = [];
const SUGGEST_SEEN = new Set<string>();

function addSuggestion(head: string, gloss: string) {
  const cleanHead = head.trim();
  if (!cleanHead || /\s/.test(cleanHead) || cleanHead.length > 22 || /[[\]*]/.test(cleanHead)) return;
  const key = fold(cleanHead);
  if (!key || SUGGEST_SEEN.has(key)) return;
  SUGGEST_SEEN.add(key);
  const short = gloss
    .replace(/\s*\([^)]*\)/g, " ")
    .split(/[.;]/)[0]
    ?.replace(/\s+/g, " ")
    .trim()
    .slice(0, 28);
  SUGGESTIONS.push({ head: cleanHead, key, gloss: short || "" });
}

for (const entry of ENTRIES) {
  addSuggestion(entry.head, entry.gloss);
  for (const form of entry.forms) addSuggestion(form.form, form.gloss || entry.gloss);
}

export function suggestTboli(prefix: string, limit = 4): Suggestion[] {
  const key = fold(prefix);
  if (!key) return [];
  return SUGGESTIONS.filter((item) => item.key.startsWith(key))
    .sort((a, b) => {
      const exact = Number(a.key !== key) - Number(b.key !== key);
      return exact || a.key.length - b.key.length || a.head.localeCompare(b.head);
    })
    .slice(0, limit)
    .map((item) => ({ head: item.head, gloss: item.gloss }));
}

export function glossEnglish(text: string): GlossPiece[] {
  const rough = text.trim().split(/\s+/).filter(Boolean);
  const tokens: string[] = [];
  for (const piece of rough) {
    const bare = piece.replace(/^[("']+|[)"'.!?,;:]+$/g, "") || piece;
    const lower = bare.toLowerCase();
    const split = CONTRACTIONS[lower];
    if (!wordGloss(bare) && split) tokens.push(...split);
    else tokens.push(bare);
  }

  return tokens.map((label) => {
    if (NO_WORD.has(normLex(label))) return { en: label, tbl: null, gap: true };
    const tbl = wordGloss(label);
    return { en: label, tbl, gap: false };
  });
}

function matchExact(english: string): PhraseHit | null {
  const key = soften(english);
  if (key.split(" ").filter(Boolean).length < 2) return null;
  const hits = PAIRS.filter((pair) => soften(pair.en) === key);
  if (!hits.length) return null;
  const best = new Map<string, { tbl: string; rank: number }>();
  for (const hit of hits) {
    const id = normLex(hit.tbl);
    const prev = best.get(id);
    if (!prev || hit.rank < prev.rank) best.set(id, { tbl: hit.tbl, rank: hit.rank });
  }
  const ordered = [...best.values()].sort((a, b) => a.rank - b.rank || a.tbl.length - b.tbl.length);
  const [first, ...rest] = ordered;
  if (!first) return null;
  return { tbl: first.tbl, alts: rest.slice(0, 3).map((item) => item.tbl) };
}

function joinSentences(parts: string[]): string {
  return parts
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part, index, all) =>
      index < all.length - 1 && !/[.!?]$/.test(part) ? `${part}.` : part,
    )
    .join(" ");
}

export function lookupPhrase(english: string): PhraseHit | null {
  const whole = matchExact(english);
  if (whole) return whole;
  const parts = clauseSplit(english);
  if (parts.length < 2) return null;
  const hits = parts.map((part) => matchExact(part));
  if (hits.some((hit) => !hit)) return null;
  return { tbl: joinSentences(hits.map((hit) => hit?.tbl ?? "")), alts: [] };
}

export function lookupEnglish(english: string): { tbl: string; via: "phrase" | "word" } | null {
  const phrase = lookupPhrase(english);
  if (phrase) return { tbl: phrase.tbl, via: "phrase" };
  const word = LEX.get(normLex(english));
  if (word) return { tbl: word, via: "word" };
  const entry = ENTRIES.find((item) => norm(item.head) === norm(english) || fold(item.head) === fold(english));
  if (entry && norm(english) === norm(entry.head)) return { tbl: entry.head, via: "word" };
  return null;
}

export function entriesForLetter(letter: string): DictEntry[] {
  return ENTRIES.filter((e) => e.letter === letter);
}

export function searchEntries(query: string, limit = 40): DictEntry[] {
  const q = fold(query);
  if (!q) return [];
  const scored = ENTRIES.map((entry) => {
    const head = fold(entry.head);
    const gloss = fold(entry.gloss);
    const forms = entry.forms.map((f) => `${fold(f.form)} ${fold(f.gloss)}`).join(" ");
    let score = 0;
    if (head === q) score = 100;
    else if (head.startsWith(q)) score = 80;
    else if (gloss.startsWith(q)) score = 70;
    else if (head.includes(q) || gloss.includes(q)) score = 50;
    else if (forms.includes(q)) score = 30;
    return { entry, score };
  })
    .filter((row) => row.score > 0)
    .sort((a, b) => b.score - a.score || a.entry.head.localeCompare(b.entry.head));
  return scored.slice(0, limit).map((row) => row.entry);
}

export function searchEnglish(query: string, limit = 40): EnIndex[] {
  const q = fold(query);
  if (!q) return [];
  return EN_INDEX.filter((item) => fold(item.en).includes(q) || fold(item.heads).includes(q))
    .sort((a, b) => {
      const as = fold(a.en).startsWith(q) ? 0 : 1;
      const bs = fold(b.en).startsWith(q) ? 0 : 1;
      return as - bs || a.en.localeCompare(b.en);
    })
    .slice(0, limit);
}

export function searchPhrases(query: string, limit = 40): DictPhrase[] {
  const q = fold(query);
  if (!q) return [];
  return PHRASES.filter(
    (item) => fold(item.en).includes(q) || fold(item.tbl).includes(q) || fold(item.topic).includes(q),
  ).slice(0, limit);
}

export function phrasesByTopic(topic: string): DictPhrase[] {
  return PHRASES.filter((p) => p.topic === topic);
}

function tokens(query: string): string[] {
  return fold(query)
    .split(" ")
    .filter((w) => w.length > 2);
}

export function contextForTranslation(query: string): string {
  const words = tokens(query);
  const phraseHits = PHRASES.filter((p) => {
    const hay = fold(`${p.en} ${p.tbl}`);
    return words.some((w) => hay.includes(w));
  }).slice(0, 8);
  const wordHits = EN_INDEX.filter((item) => words.some((w) => fold(item.en) === w || fold(item.en).includes(w))).slice(
    0,
    14,
  );
  const rules = GUIDE.find((s) => s.title === "Core rules");
  const ruleText = (rules?.blocks ?? [])
    .map((b) => b.text)
    .join("\n")
    .slice(0, 2200);
  const lines = [
    "Use ONLY these T'boli words and sentence patterns from Deymar's lessons. If a word is missing, leave it in English inside [brackets]. Do not invent words and do not use Tagalog.",
    ruleText ? `Rules:\n${ruleText}` : "",
    phraseHits.length
      ? `Example sentences:\n${phraseHits.map((p) => `- ${p.en} → ${p.tbl}`).join("\n")}`
      : "",
    wordHits.length
      ? `Word list:\n${wordHits.map((w) => `- ${w.en}: ${w.heads}`).join("\n")}`
      : "",
  ];
  return lines.filter(Boolean).join("\n\n");
}
