import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { BookOpen, House, Languages, PenLine, Settings } from "lucide-react";
import { useIme } from "@/components/ime-provider";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/", label: "Home", icon: House },
  { to: "/dictionary", label: "Words", icon: BookOpen },
  { to: "/translate", label: "Translate", icon: Languages },
  { to: "/write", label: "Write", icon: PenLine },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const ime = useIme();
  const hideTabs = ime.visible;

  return (
    <div className="relative mx-auto flex h-dvh max-w-lg flex-col bg-bg text-fg">
      <div
        className={cn(
          "min-h-0 flex-1 overflow-y-auto",
          hideTabs ? "pb-2" : "pb-[calc(4.25rem+env(safe-area-inset-bottom))]",
          ime.visible && "pb-[min(52vh,24rem)]",
        )}
      >
        <Outlet />
      </div>
      {hideTabs ? null : (
        <nav
          className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)]"
          aria-label="App"
        >
          <ul className="mx-auto flex h-16 max-w-lg">
            {TABS.map((tab) => {
              const active =
                tab.to === "/"
                  ? pathname === "/"
                  : pathname === tab.to || pathname.startsWith(`${tab.to}/`);
              const Icon = tab.icon;
              return (
                <li key={tab.to} className="flex-1">
                  <Link
                    to={tab.to}
                    className={cn(
                      "flex h-full flex-col items-center justify-center gap-1 text-2xs font-medium",
                      active ? "text-fg" : "text-subtle",
                    )}
                  >
                    <Icon
                      className="size-5"
                      strokeWidth={active ? 2.25 : 1.75}
                    />
                    {tab.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </div>
  );
}
