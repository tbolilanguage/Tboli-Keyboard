import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Check, ChevronLeft } from "lucide-react";
import { useIme } from "@/components/ime-provider";
import { openSystemKeyboardSettings } from "@/lib/prefs";
import { cn } from "@/lib/utils";

type Step = 1 | 2 | 3;

export function EnableScreen() {
  const ime = useIme();
  const [step, setStep] = useState<Step | null>(null);
  const [osNote, setOsNote] = useState<string | null>(null);

  useEffect(() => {
    if (!ime.ready || step !== null) return;
    setStep(ime.installed ? (ime.selected ? 3 : 2) : 1);
  }, [ime.installed, ime.ready, ime.selected, step]);

  function openPhone() {
    const result = openSystemKeyboardSettings();
    if (result.platform === "android") {
      setOsNote("Opening Keyboard settings on this phone…");
    } else if (result.platform === "ios") {
      setOsNote("On iPhone: Settings → General → Keyboard → Keyboards → Add New Keyboard → Tboli.");
    } else {
      setOsNote("On a phone, this switch lives in Keyboard settings. Use the steps below here.");
    }
  }

  return (
    <div className="px-4 pt-4 pb-8">
      <Link
        to="/settings"
        className="inline-flex h-10 items-center gap-1 text-sm text-muted"
      >
        <ChevronLeft className="size-4" strokeWidth={2} />
        Settings
      </Link>
      <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight">
        Keyboard settings
      </h1>
      <p className="mt-1 text-sm text-muted">
        Add Tboli Keyboard, then choose it as the board that pops up when you type.
      </p>

      <ol className="mt-4 flex gap-2 text-2xs font-medium">
        {([1, 2, 3] as const).map((n) => (
          <li
            key={n}
            className={cn(
              "h-1 flex-1 rounded-full",
              step !== null && n <= step ? "bg-primary" : "bg-surface-2",
            )}
          />
        ))}
      </ol>

      {step === null ? (
        <p className="mt-5 text-sm text-subtle">Loading keyboard settings…</p>
      ) : null}

      {step === 1 ? (
        <section className="mt-5">
          <h2 className="text-sm font-medium">1. Manage keyboards</h2>
          <p className="mt-1 text-sm text-subtle">
            Same list as Android On-screen keyboard / iPhone Keyboards.
          </p>
          <ul className="mt-3 overflow-hidden rounded-xl bg-surface shadow-panel">
            <li className="flex items-center justify-between px-4 py-3.5 text-muted">
              <span>English (US)</span>
              <span className="text-xs text-subtle">System</span>
            </li>
            <li className="h-px bg-border" />
            <li className="flex items-center justify-between px-4 py-3.5">
              <div>
                <p className="font-medium">Tboli Keyboard</p>
                <p className="text-xs text-subtle">English · Tboli</p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={ime.installed}
                onClick={() => ime.setInstalled(!ime.installed)}
                className={cn(
                  "relative h-7 w-12 rounded-full transition-colors duration-150",
                  ime.installed ? "bg-primary" : "bg-key-mod",
                )}
              >
                <span
                  className={cn(
                    "absolute top-0.5 size-6 rounded-full bg-key transition-transform duration-150",
                    ime.installed ? "translate-x-5" : "translate-x-0.5",
                  )}
                />
              </button>
            </li>
          </ul>
          <button
            type="button"
            onClick={openPhone}
            className="mt-3 h-11 w-full rounded-md bg-key-mod text-sm font-medium text-key-mod-fg"
          >
            Open phone keyboard settings
          </button>
          {osNote ? <p className="mt-2 text-xs leading-relaxed text-subtle">{osNote}</p> : null}
          <button
            type="button"
            disabled={!ime.installed}
            onClick={() => setStep(2)}
            className="mt-4 h-11 w-full rounded-md bg-primary text-sm font-medium text-primary-fg disabled:opacity-40"
          >
            Next
          </button>
        </section>
      ) : null}

      {step === 2 ? (
        <section className="mt-5">
          <h2 className="text-sm font-medium">2. Choose input method</h2>
          <p className="mt-1 text-sm text-subtle">
            Pick which board pops up when a text field is focused.
          </p>
          <ul className="mt-3 overflow-hidden rounded-xl bg-surface shadow-panel">
            <li>
              <button
                type="button"
                onClick={() => ime.setSelected(false)}
                className="flex w-full items-center justify-between px-4 py-3.5 text-left"
              >
                <span>Phone keyboard</span>
                {ime.selected ? null : <Check className="size-5 text-primary" strokeWidth={2} />}
              </button>
            </li>
            <li className="h-px bg-border" />
            <li>
              <button
                type="button"
                onClick={() => ime.setSelected(true)}
                className="flex w-full items-center justify-between px-4 py-3.5 text-left"
              >
                <span className="font-medium">Tboli Keyboard</span>
                {ime.selected ? <Check className="size-5 text-primary" strokeWidth={2} /> : null}
              </button>
            </li>
          </ul>
          <div className="mt-4 flex gap-2">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="h-11 flex-1 rounded-md bg-key-mod text-sm font-medium text-key-mod-fg"
            >
              Back
            </button>
            <button
              type="button"
              disabled={!ime.selected}
              onClick={() => setStep(3)}
              className="h-11 flex-1 rounded-md bg-primary text-sm font-medium text-primary-fg disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </section>
      ) : null}

      {step === 3 ? (
        <section className="mt-5">
          <h2 className="text-sm font-medium">3. Ready to type</h2>
          <p className="mt-1 text-sm text-subtle">
            Tboli Keyboard is on. Tap a field and it slides up — globe key switches
            English and Tboli.
          </p>
          <div className="mt-3 rounded-xl bg-surface p-4 shadow-panel">
            <p className="text-sm font-medium">Current keyboard</p>
            <p className="mt-1 text-lg font-display">
              Tboli Keyboard · {ime.lang === "tbl" ? "Tboli" : "English"}
            </p>
          </div>
          <Link
            to="/try"
            className="mt-4 flex h-11 items-center justify-center rounded-md bg-primary text-sm font-medium text-primary-fg"
          >
            Try it in Messages
          </Link>
          <button
            type="button"
            onClick={() => setStep(2)}
            className="mt-2 h-11 w-full rounded-md bg-key-mod text-sm font-medium text-key-mod-fg"
          >
            Change keyboard
          </button>
          <button
            type="button"
            onClick={() => {
              ime.disable();
              setStep(1);
            }}
            className="mt-2 h-11 w-full rounded-md text-sm font-medium text-subtle"
          >
            Turn off Tboli Keyboard
          </button>
        </section>
      ) : null}
    </div>
  );
}
