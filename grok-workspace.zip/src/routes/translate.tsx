import { createFileRoute } from "@tanstack/react-router";
import { TranslateScreen } from "@/components/screens/translate-screen";

export const Route = createFileRoute("/translate")({
  validateSearch: (search: Record<string, unknown>) => ({
    en: typeof search.en === "string" ? search.en.slice(0, 280) : "",
  }),
  component: TranslateScreen,
});
