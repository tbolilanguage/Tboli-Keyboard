import { i as __toESM } from "../_runtime.mjs";
import { a as QUICK_ENGLISH, l as glossEnglish, u as lookupPhrase } from "./dictionary-D-_jSYMr.mjs";
import { C as require_jsx_runtime, X as require_react, b as getRouteApi } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ArrowRight, s as LoaderCircle, v as Check } from "../_libs/lucide-react.mjs";
import { t as ImeInput } from "./ime-field-WzsZTvOs.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/translate-CY7dElOS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var translateToTboli = createServerFn({ method: "POST" }).validator((input) => ({ q: String(input?.q ?? "").slice(0, 280) })).handler(createSsrRpc("c555f0eb5aa3c7b7d8bd924627e0c8b704423218ef965720e5bb219d1d6ca699"));
var translateRoute = getRouteApi("/translate");
function TranslateScreen() {
	const { en } = translateRoute.useSearch();
	const [english, setEnglish] = (0, import_react.useState)(en);
	const [aiText, setAiText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!en) return;
		setEnglish(en);
		setAiText("");
		setError(null);
	}, [en]);
	const gloss = (0, import_react.useMemo)(() => glossEnglish(english), [english]);
	const phrase = (0, import_react.useMemo)(() => lookupPhrase(english), [english]);
	const sentence = phrase?.tbl || aiText;
	function setQuery(next) {
		setEnglish(next);
		setAiText("");
		setError(null);
		setCopied(null);
	}
	async function translate() {
		const q = english.trim();
		if (!q || busy || phrase) return;
		setBusy(true);
		setError(null);
		try {
			const result = await translateToTboli({ data: { q } });
			if (result.ok) setAiText(result.text);
			else {
				setAiText("");
				setError(result.error);
			}
		} catch {
			setError("Translation is unavailable right now.");
		} finally {
			setBusy(false);
		}
	}
	async function copy(text) {
		if (!text) return;
		try {
			await navigator.clipboard.writeText(text);
			setCopied(text);
			window.setTimeout(() => setCopied((cur) => cur === text ? null : cur), 1400);
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold tracking-tight",
				children: "Translate"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Word for word as you type. A full phrase appears when the sentence is in Deymar's lessons."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center gap-2 text-sm font-medium text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "English" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
						className: "size-3.5 text-subtle",
						strokeWidth: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tboli" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeInput, {
				value: english,
				onChange: (e) => setQuery(e.target.value),
				onKeyDown: (e) => {
					if (e.key === "Enter") {
						e.preventDefault();
						translate();
					}
				},
				placeholder: "Type an English phrase",
				className: "mt-2 bg-surface",
				lang: "en"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1.5 overflow-x-auto",
				children: QUICK_ENGLISH.map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setQuery(label),
					className: "h-9 shrink-0 rounded-sm bg-surface px-2.5 text-xs text-muted",
					children: label
				}, label))
			}),
			gloss.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 overflow-hidden rounded-xl bg-surface shadow-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 pt-3 text-xs font-medium tracking-wide text-subtle",
					children: "Word for word"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1 max-h-56 overflow-y-auto px-2 pb-2",
					children: gloss.map((piece, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline gap-3 border-t border-border px-2 py-2 first:border-t-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-2/5 shrink-0 text-sm text-muted",
							children: piece.en
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 text-right font-display text-lg leading-tight",
							lang: "tbl",
							children: piece.gap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-subtle",
								children: "no word"
							}) : piece.tbl ? piece.tbl : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-subtle",
								children: [
									"[",
									piece.en,
									"]"
								]
							})
						})]
					}, `${piece.en}-${index}`))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-xl bg-surface p-4 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-subtle",
						children: phrase ? "Full phrase" : "Full sentence"
					}),
					phrase ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-snug",
							lang: "tbl",
							children: phrase.tbl
						}), phrase.alts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1",
							children: phrase.alts.map((alt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void copy(alt),
								className: "text-left text-base text-muted",
								lang: "tbl",
								children: ["Also ", alt]
							}) }, alt))
						}) : null]
					}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: error
					}) : aiText ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-snug",
							lang: "tbl",
							children: aiText
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-subtle",
							children: "Built from the lessons. Not a stored sentence."
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 min-h-12 text-sm text-subtle",
						children: english.trim() ? "No stored sentence for that yet. Word for word is above." : "The lesson sentence shows here when the whole phrase matches."
					}),
					sentence ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void copy(sentence),
						className: "mt-3 inline-flex h-10 items-center gap-1.5 rounded-md bg-key px-3 text-sm font-medium text-key-fg",
						children: [copied === sentence ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-4",
							strokeWidth: 2
						}) : null, copied === sentence ? "Copied" : "Copy Tboli"]
					}) : null,
					!phrase && english.trim().split(/\s+/).length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void translate(),
						disabled: busy,
						className: "mt-2 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-primary text-sm font-medium text-primary-fg transition-transform duration-150 ease-out active:scale-[0.98] disabled:opacity-40",
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							className: "size-4 animate-spin",
							strokeWidth: 2
						}) : null, "Build full sentence"]
					}) : null
				]
			})
		]
	});
}
var SplitComponent = TranslateScreen;
//#endregion
export { SplitComponent as component };
