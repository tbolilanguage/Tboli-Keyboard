import { useCallback, useRef, useState } from "react";
import {
  ArrowBigUp,
  ChevronsDown,
  CornerDownLeft,
  Delete,
  Globe,
  Smile,
} from "lucide-react";
import { EmojiPanel } from "@/components/emoji-panel";
import { useIme } from "@/components/ime-provider";
import {
  applyDeadKey,
  casedChar,
  DEAD_CHAR,
  getLayout,
  type DeadKey,
  type KeySpec,
} from "@/lib/tboli";
import { cn } from "@/lib/utils";

export function ImeKeyboard() {
  const ime = useIme();
  const [shift, setShift] = useState(false);
  const [caps, setCaps] = useState(false);
  const [symbols, setSymbols] = useState(false);
  const [dead, setDead] = useState<DeadKey | null>(null);
  const [pressed, setPressed] = useState<string | null>(null);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const lastShiftTap = useRef(0);

  const typeText = useCallback(
    (chunk: string) => {
      ime.insert(chunk);
    },
    [ime],
  );

  const commitChar = useCallback(
    (raw: string) => {
      const letter = casedChar(raw, shift, caps);
      if (dead && ime.lang === "tbl") {
        const mapped = applyDeadKey(dead, letter) ?? applyDeadKey(dead, raw);
        setDead(null);
        typeText(mapped ?? DEAD_CHAR[dead] + letter);
      } else {
        typeText(letter);
      }
      if (shift) setShift(false);
    },
    [caps, dead, ime.lang, shift, typeText],
  );

  const handleKey = useCallback(
    (spec: KeySpec) => {
      setPressed(spec.id);
      window.setTimeout(() => setPressed((id) => (id === spec.id ? null : id)), 120);

      switch (spec.kind) {
        case "char":
        case "ng":
          commitChar(spec.char ?? spec.label);
          break;
        case "space":
          typeText(" ");
          if (dead) setDead(null);
          break;
        case "enter":
          ime.enter();
          break;
        case "backspace":
          if (dead) {
            setDead(null);
            break;
          }
          ime.backspace();
          break;
        case "shift": {
          const now = Date.now();
          if (now - lastShiftTap.current < 400) {
            setCaps((c) => !c);
            setShift(false);
          } else {
            setShift((s) => !s);
          }
          lastShiftTap.current = now;
          break;
        }
        case "dead":
          setDead((current) => (current === spec.dead ? null : (spec.dead ?? null)));
          break;
        case "mode":
          setSymbols((s) => !s);
          setShift(false);
          setEmojiOpen(false);
          break;
        case "emoji":
          setEmojiOpen(true);
          setSymbols(false);
          break;
        case "lang":
          ime.cycleLang();
          setDead(null);
          setEmojiOpen(false);
          break;
      }
    },
    [commitChar, dead, ime, typeText],
  );

  const rows = getLayout(ime.lang, symbols);

  return (
    <div
      className="fixed inset-x-0 bottom-0 z-40 bg-ime pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1.5 shadow-panel"
      role="application"
      aria-label={`${ime.lang === "tbl" ? "Tboli" : "English"} keyboard`}
    >
      <div className="mx-auto max-w-lg px-1.5">
        <div className="mb-1.5 flex items-center justify-between px-1">
          <p className="text-2xs font-medium tracking-wide text-subtle">
            {ime.lang === "tbl" ? "Tboli" : "English"}
          </p>
          <button
            type="button"
            aria-label="Hide keyboard"
            onPointerDown={(e) => e.preventDefault()}
            onClick={() => ime.hide()}
            className="flex h-8 w-10 items-center justify-center rounded-sm text-subtle"
          >
            <ChevronsDown className="size-4" strokeWidth={2} />
          </button>
        </div>
        {emojiOpen ? (
          <EmojiPanel
            onPick={(glyph) => typeText(glyph)}
            onAbc={() => setEmojiOpen(false)}
          />
        ) : (
          <div className="flex flex-col gap-1">
            {rows.map((row, i) => (
              <div key={i} className="flex gap-1">
                {row.map((spec) => (
                  <KeyButton
                    key={spec.id}
                    spec={spec}
                    shift={shift}
                    caps={caps}
                    dead={dead}
                    lang={ime.lang}
                    pressed={pressed === spec.id}
                    onPress={handleKey}
                  />
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function KeyButton({
  spec,
  shift,
  caps,
  dead,
  lang,
  pressed,
  onPress,
}: {
  spec: KeySpec;
  shift: boolean;
  caps: boolean;
  dead: DeadKey | null;
  lang: "en" | "tbl";
  pressed: boolean;
  onPress: (spec: KeySpec) => void;
}) {
  const activeDead = spec.kind === "dead" && dead === spec.dead;
  const activeShift = spec.kind === "shift" && (shift || caps);
  const display =
    spec.kind === "char" || spec.kind === "ng"
      ? casedChar(spec.char ?? spec.label, shift, caps)
      : spec.kind === "space"
        ? lang === "tbl"
          ? "Tboli"
          : "English"
        : spec.label;

  const flexGrow =
    spec.wide === "xl" ? 4.2 : spec.wide === "md" ? 1.45 : spec.wide === "sm" ? 1.15 : 1;

  const special = Boolean(spec.special) || spec.kind === "dead";
  const modifier =
    spec.kind === "shift" ||
    spec.kind === "backspace" ||
    spec.kind === "enter" ||
    spec.kind === "mode" ||
    spec.kind === "emoji" ||
    spec.kind === "lang";

  return (
    <button
      type="button"
      aria-label={ariaLabel(spec, display, lang)}
      aria-pressed={
        spec.kind === "shift" || spec.kind === "dead" ? activeShift || activeDead : undefined
      }
      onPointerDown={(event) => {
        event.preventDefault();
        onPress(spec);
      }}
      style={{ flex: flexGrow }}
      className={cn(
        "relative flex h-11 min-w-0 items-center justify-center rounded-sm select-none",
        "text-base font-medium leading-none",
        "transition-[transform,filter] duration-150 ease-out",
        "active:scale-[0.96]",
        special && "bg-key-special text-key-special-fg shadow-key-special",
        modifier && "bg-key-mod text-key-mod-fg shadow-key-mod text-xs",
        spec.kind === "space" && "bg-key text-key-fg shadow-key text-xs tracking-wide",
        !special &&
          !modifier &&
          spec.kind !== "space" &&
          "bg-key text-key-fg shadow-key",
        (activeDead || (spec.kind === "shift" && caps)) && "ring-2 ring-ring",
        pressed && "translate-y-px brightness-90",
      )}
    >
      {spec.kind === "shift" ? (
        <ArrowBigUp className={cn("size-4", caps && "fill-current")} strokeWidth={2} />
      ) : spec.kind === "backspace" ? (
        <Delete className="size-4" strokeWidth={2} />
      ) : spec.kind === "enter" ? (
        <CornerDownLeft className="size-4" strokeWidth={2} />
      ) : spec.kind === "space" ? (
        <span className="text-2xs font-medium text-subtle">{display}</span>
      ) : spec.kind === "emoji" ? (
        <Smile className="size-4" strokeWidth={2} />
      ) : spec.kind === "lang" ? (
        <Globe className="size-4" strokeWidth={2} />
      ) : spec.kind === "dead" ? (
        <span className="font-display text-lg leading-none">{spec.label}</span>
      ) : (
        <span className="font-display">{display}</span>
      )}
    </button>
  );
}

function ariaLabel(spec: KeySpec, display: string, lang: "en" | "tbl"): string {
  switch (spec.kind) {
    case "space":
      return "Space";
    case "backspace":
      return "Delete";
    case "enter":
      return "Return";
    case "shift":
      return "Shift";
    case "mode":
      return spec.label === "123" ? "Numbers and punctuation" : "Letters";
    case "emoji":
      return "Emoji";
    case "lang":
      return lang === "tbl" ? "Switch to English" : "Switch to Tboli";
    case "dead":
      if (spec.dead === "grave") return "Glottal grave accent";
      if (spec.dead === "circumflex") return "Circumflex accent";
      return "Acute accent";
    default:
      return display;
  }
}
