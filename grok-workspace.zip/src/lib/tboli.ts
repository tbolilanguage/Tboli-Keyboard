export const STORAGE_KEY = "tboli-keyboard-draft";

export const VOWELS = [
  { letter: "a", ipa: "/a/", hint: "father" },
  { letter: "e", ipa: "/ə/", hint: "about" },
  { letter: "é", ipa: "/ɛ/", hint: "bed" },
  { letter: "i", ipa: "/i/", hint: "machine" },
  { letter: "o", ipa: "/ɔ/", hint: "thought" },
  { letter: "ó", ipa: "/o/", hint: "go" },
  { letter: "u", ipa: "/u/", hint: "food" },
] as const;

export const CONSONANTS = [
  "b",
  "d",
  "f",
  "g",
  "h",
  "k",
  "l",
  "m",
  "n",
  "ng",
  "s",
  "t",
  "w",
  "y",
] as const;

export const SAMPLES = [
  { tboli: "ngà", en: "child" },
  { tboli: "bê", en: "don't" },
  { tboli: "gawì", en: "serving spoon" },
  { tboli: "sdô", en: "pig" },
  { tboli: "tnalak", en: "sacred cloth" },
  { tboli: "Mulu le sfu soging.", en: "They planted banana shoots." },
] as const;

export type DeadKey = "acute" | "grave" | "circumflex";

const ACUTE: Record<string, string> = {
  a: "á",
  e: "é",
  i: "í",
  o: "ó",
  u: "ú",
  A: "Á",
  E: "É",
  I: "Í",
  O: "Ó",
  U: "Ú",
};

const GRAVE: Record<string, string> = {
  a: "à",
  e: "è",
  i: "ì",
  o: "ò",
  u: "ù",
  A: "À",
  E: "È",
  I: "Ì",
  O: "Ò",
  U: "Ù",
  é: "ê",
  É: "Ê",
  ó: "ô",
  Ó: "Ô",
};

const CIRCUMFLEX: Record<string, string> = {
  a: "â",
  e: "ê",
  i: "î",
  o: "ô",
  u: "û",
  A: "Â",
  E: "Ê",
  I: "Î",
  O: "Ô",
  U: "Û",
  é: "ê",
  É: "Ê",
  ó: "ô",
  Ó: "Ô",
};

const DEAD_MAP: Record<DeadKey, Record<string, string>> = {
  acute: ACUTE,
  grave: GRAVE,
  circumflex: CIRCUMFLEX,
};

export const DEAD_CHAR: Record<DeadKey, string> = {
  acute: "'",
  grave: "`",
  circumflex: "^",
};

export function applyDeadKey(dead: DeadKey, letter: string): string | null {
  return DEAD_MAP[dead][letter] ?? null;
}

export function isUpperCase(shift: boolean, caps: boolean): boolean {
  return shift !== caps;
}

export function casedChar(char: string, shift: boolean, caps: boolean): string {
  const upper = isUpperCase(shift, caps);
  if (char === "ng") {
    if (!upper) return "ng";
    if (caps && !shift) return "NG";
    return "Ng";
  }
  return upper ? char.toUpperCase() : char;
}

export type KeyKind =
  | "char"
  | "ng"
  | "shift"
  | "backspace"
  | "enter"
  | "space"
  | "dead"
  | "mode"
  | "emoji"
  | "lang";

export type KeySpec = {
  id: string;
  kind: KeyKind;
  label: string;
  char?: string;
  dead?: DeadKey;
  special?: boolean;
  wide?: "sm" | "md" | "lg" | "xl";
};

function ch(char: string, special = false): KeySpec {
  return {
    id: `c-${char}`,
    kind: char === "ng" ? "ng" : "char",
    label: char,
    char,
    special,
  };
}

const TBOLI_ROW: KeySpec[] = [
  ch("é", true),
  ch("ó", true),
  ch("ng", true),
  ch("à", true),
  ch("è", true),
  ch("ì", true),
  ch("ò", true),
  ch("ù", true),
  ch("ê", true),
  ch("ô", true),
];

const LETTER_1 = ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"].map((c) =>
  ch(c),
);
const LETTER_2 = ["a", "s", "d", "f", "g", "h", "j", "k", "l"].map((c) => ch(c));
const LETTER_3 = ["z", "x", "c", "v", "b", "n", "m"].map((c) => ch(c));

const SYMBOL_1: KeySpec[] = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"].map(
  (c) => ch(c),
);
const SYMBOL_2: KeySpec[] = [
  ch("-"),
  ch("/"),
  ch(":"),
  ch(";"),
  ch("("),
  ch(")"),
  ch("₱"),
  ch("&"),
  ch("@"),
];
const SYMBOL_EN_2: KeySpec[] = [
  ch("-"),
  ch("/"),
  ch(":"),
  ch(";"),
  ch("("),
  ch(")"),
  ch("$"),
  ch("&"),
  ch("@"),
];
const SYMBOL_3: KeySpec[] = [
  ch("."),
  ch(","),
  ch("?"),
  ch("!"),
  ch('"'),
  ch("'"),
  ch("`"),
  ch("^"),
];

const SHIFT: KeySpec = {
  id: "shift",
  kind: "shift",
  label: "Shift",
  wide: "md",
};
const BACKSPACE: KeySpec = {
  id: "backspace",
  kind: "backspace",
  label: "Delete",
  wide: "md",
};
const ENTER: KeySpec = {
  id: "enter",
  kind: "enter",
  label: "Return",
  wide: "md",
};

const EMOJI_KEY: KeySpec = {
  id: "emoji",
  kind: "emoji",
  label: "Emoji",
  wide: "sm",
};

const LANG_KEY: KeySpec = {
  id: "lang",
  kind: "lang",
  label: "lang",
  wide: "sm",
};

function modeKey(symbols: boolean): KeySpec {
  return {
    id: "mode",
    kind: "mode",
    label: symbols ? "ABC" : "123",
    wide: "sm",
  };
}

function spaceKey(lang: "en" | "tbl"): KeySpec {
  return {
    id: "space",
    kind: "space",
    label: lang === "tbl" ? "Tboli" : "English",
    wide: "xl",
  };
}

export function getLayout(
  lang: "en" | "tbl",
  symbols: boolean,
): KeySpec[][] {
  const symbolMid = lang === "tbl" ? SYMBOL_2 : SYMBOL_EN_2;
  const space = spaceKey(lang);
  const tboliTop = lang === "tbl" ? [TBOLI_ROW] : [];

  if (symbols) {
    return [
      ...tboliTop,
      SYMBOL_1,
      symbolMid,
      [modeKey(true), EMOJI_KEY, ...SYMBOL_3.slice(0, 5), BACKSPACE],
      [LANG_KEY, space, ENTER],
    ];
  }

  return [
    ...tboliTop,
    LETTER_1,
    LETTER_2,
    [SHIFT, ...LETTER_3, BACKSPACE],
    [modeKey(false), EMOJI_KEY, LANG_KEY, space, ENTER],
  ];
}

export function insertAt(
  value: string,
  start: number,
  end: number,
  insert: string,
): { value: string; caret: number } {
  const next = value.slice(0, start) + insert + value.slice(end);
  return { value: next, caret: start + insert.length };
}

function graphemes(value: string): string[] {
  if (typeof Intl !== "undefined" && "Segmenter" in Intl) {
    return [...new Intl.Segmenter("en", { granularity: "grapheme" }).segment(value)].map(
      (part) => part.segment,
    );
  }
  return [...value];
}

export function backspaceAt(
  value: string,
  start: number,
  end: number,
): { value: string; caret: number } {
  if (start !== end) {
    return insertAt(value, start, end, "");
  }
  if (start <= 0) return { value, caret: 0 };
  const prev = value.slice(0, start);
  const cut = graphemes(prev);
  cut.pop();
  const nextPrev = cut.join("");
  return {
    value: nextPrev + value.slice(end),
    caret: nextPrev.length,
  };
}

export const DEAD_HINT: Record<DeadKey, string> = {
  acute: "Next vowel gets ´  (é ó)",
  grave: "Next vowel gets `  (glottal à)",
  circumflex: "Next vowel gets ^  (glottal ê ô)",
};
