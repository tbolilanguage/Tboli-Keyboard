export type ImeEl = HTMLInputElement | HTMLTextAreaElement;

function nativeSet(el: ImeEl, value: string) {
  const proto =
    el instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
  const desc = Object.getOwnPropertyDescriptor(proto, "value");
  desc?.set?.call(el, value);
}

export function insertInto(el: ImeEl, chunk: string) {
  const start = el.selectionStart ?? el.value.length;
  const end = el.selectionEnd ?? el.value.length;
  const next = el.value.slice(0, start) + chunk + el.value.slice(end);
  nativeSet(el, next);
  const caret = start + chunk.length;
  el.setSelectionRange(caret, caret);
  el.dispatchEvent(new Event("input", { bubbles: true }));
}

export function backspaceInto(el: ImeEl) {
  const start = el.selectionStart ?? el.value.length;
  const end = el.selectionEnd ?? el.value.length;
  if (start !== end) {
    const next = el.value.slice(0, start) + el.value.slice(end);
    nativeSet(el, next);
    el.setSelectionRange(start, start);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    return;
  }
  if (start <= 0) return;
  const prev = el.value.slice(0, start);
  let cutLen = 1;
  if (typeof Intl !== "undefined" && "Segmenter" in Intl) {
    const parts = [
      ...new Intl.Segmenter("en", { granularity: "grapheme" }).segment(prev),
    ];
    cutLen = parts.at(-1)?.segment.length ?? 1;
  }
  const next = el.value.slice(0, start - cutLen) + el.value.slice(end);
  nativeSet(el, next);
  el.setSelectionRange(start - cutLen, start - cutLen);
  el.dispatchEvent(new Event("input", { bubbles: true }));
}

export function submitOrNewline(el: ImeEl) {
  if (el instanceof HTMLTextAreaElement) {
    insertInto(el, "\n");
    return;
  }
  const form = el.form;
  if (form) {
    if (typeof form.requestSubmit === "function") form.requestSubmit();
    else form.submit();
    return;
  }
  el.blur();
}
