import { createFileRoute } from "@tanstack/react-router";
import { EnableScreen } from "@/components/screens/enable-screen";

export const Route = createFileRoute("/enable")({ component: EnableScreen });
