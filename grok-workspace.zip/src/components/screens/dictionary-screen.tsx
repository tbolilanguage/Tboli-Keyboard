import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ImeInput } from "@/components/ime-field";
import {
  ENTRIES,
  EN_INDEX,
  GUIDE,
  LETTERS,
  TOPICS,
  entriesForLetter,
  phrasesByTopic,
  searchEnglish,
  searchEntries,
  searchPhrases,
  type DictEntry,
  type DictPhrase,
  type EnIndex,
} from "@/lib/dictionary";
import { cn } from "@/lib/utils";

type Tab = "words" | "english" | "phrases" | "guide";

const TABS: { id: Tab; label: string }[] = [
  { id: "words", label: "Tboli" },
  { id: "english", label: "English" },
  { id: "phrases", label: "Phrases" },
  { id: "guide", label: "Guide" },
];

export function DictionaryScreen() {
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<Tab>("words");
  const [letter, setLetter] = useState(LETTERS[0] ?? "A");
  const [topic, setTopic] = useState(TOPICS[0] ?? "");
  const [open, setOpen] = useState<string | null>(null);
  const [guideOpen, setGuideOpen] = useState(GUIDE[0]?.title ?? "");

  const q = query.trim();
  const words = useMemo(() => (q ? searchEntries(q) : entriesForLetter(letter)), [q, letter]);
  const english = useMemo(() => (q ? searchEnglish(q) : []), [q]);
  const phrases = useMemo(
    () => (q ? searchPhrases(q) : phrasesByTopic(topic)),
    [q, topic],
  );
  const guide = useMemo(() => {
    if (!q) return GUIDE;
    const n = q.toLowerCase();
    return GUIDE.map((section) => ({
      ...section,
      blocks: section.blocks.filter((b) => b.text.toLowerCase().includes(n)),
    })).filter((section) => section.blocks.length > 0 || section.title.toLowerCase().includes(n));
  }, [q]);

  return (
    <div className="px-4 pt-6 pb-8">
      <p className="text-sm font-medium tracking-wide text-primary">Deymar</p>
      <h1 className="mt-1 font-display text-3xl font-semibold tracking-tight">Dictionary</h1>
      <p className="mt-1 text-sm leading-relaxed text-muted">
        {ENTRIES.length} roots, taught one lesson at a time. Accents change the meaning.
      </p>

      <ImeInput
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search ngà, child, good morning"
        className="mt-4 bg-surface"
        aria-label="Search the dictionary"
      />

      <div className="mt-3 flex rounded-lg bg-surface p-1">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={cn(
              "h-9 flex-1 rounded-md text-xs font-medium",
              tab === item.id ? "bg-primary text-primary-fg" : "text-muted",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === "words" ? (
        <>
          {q ? null : (
            <div className="mt-3 flex gap-1 overflow-x-auto pb-1">
              {LETTERS.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setLetter(item)}
                  className={cn(
                    "h-8 w-8 shrink-0 rounded-sm text-xs font-medium",
                    letter === item ? "bg-primary text-primary-fg" : "bg-surface text-muted",
                  )}
                >
                  {item}
                </button>
              ))}
            </div>
          )}
          <ul className="mt-3 space-y-2">
            {words.map((entry) => {
              const id = `${entry.letter}:${entry.head}:${entry.gloss}`;
              return (
                <WordRow
                  key={id}
                  entry={entry}
                  open={open === id}
                  onToggle={() => setOpen((cur) => (cur === id ? null : id))}
                />
              );
            })}
            {words.length === 0 ? (
              <li>
                <Empty />
              </li>
            ) : null}
          </ul>
        </>
      ) : null}

      {tab === "english" ? (
        <ul className="mt-3 space-y-2">
          {(q ? english : []).map((item) => (
            <EnglishRow key={item.en} item={item} />
          ))}
          {!q ? (
            <li className="rounded-xl bg-surface px-4 py-3 text-sm text-subtle shadow-panel">
              Type an English word. The index has {EN_INDEX.length} entries.
            </li>
          ) : null}
          {q && english.length === 0 ? (
            <li>
              <Empty />
            </li>
          ) : null}
        </ul>
      ) : null}

      {tab === "phrases" ? (
        <>
          {q ? null : (
            <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1">
              {TOPICS.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setTopic(item)}
                  className={cn(
                    "h-8 shrink-0 rounded-sm px-2.5 text-xs font-medium",
                    topic === item ? "bg-primary text-primary-fg" : "bg-surface text-muted",
                  )}
                >
                  {item}
                </button>
              ))}
            </div>
          )}
          <ul className="mt-3 space-y-2">
            {phrases.map((item) => (
              <PhraseRow key={`${item.topic}-${item.tbl}`} item={item} />
            ))}
            {phrases.length === 0 ? (
              <li>
                <Empty />
              </li>
            ) : null}
          </ul>
        </>
      ) : null}

      {tab === "guide" ? (
        <div className="mt-3 space-y-2">
          {guide.map((section) => {
            const expanded = guideOpen === section.title || Boolean(q);
            return (
              <section key={section.title} className="rounded-xl bg-surface shadow-panel">
                <button
                  type="button"
                  onClick={() => setGuideOpen((cur) => (cur === section.title ? "" : section.title))}
                  className="flex w-full items-center justify-between px-4 py-3 text-left"
                >
                  <span className="font-medium">{section.title}</span>
                  <span className="text-xs text-subtle">{section.blocks.length}</span>
                </button>
                {expanded ? (
                  <div className="space-y-2 px-4 pb-4 text-sm leading-relaxed text-muted">
                    {section.blocks.map((block, i) =>
                      block.kind === "li" ? (
                        <p key={i} className="border-l-2 border-primary pl-3">
                          {block.text}
                        </p>
                      ) : (
                        <p key={i}>{block.text}</p>
                      ),
                    )}
                  </div>
                ) : null}
              </section>
            );
          })}
          {guide.length === 0 ? <Empty /> : null}
        </div>
      ) : null}
    </div>
  );
}

function Empty() {
  return (
    <p className="rounded-xl bg-surface px-4 py-3 text-sm text-subtle shadow-panel">
      Nothing matches. Try another spelling, or leave the English word in brackets.
    </p>
  );
}

function WordRow({
  entry,
  open,
  onToggle,
}: {
  entry: DictEntry;
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <li className="rounded-xl bg-surface shadow-panel">
      <button type="button" onClick={onToggle} className="w-full px-4 py-3 text-left">
        <span className="font-display text-xl leading-none">{entry.head}</span>
        <span className="mt-1 block text-sm text-muted">{entry.gloss || "See the forms below"}</span>
      </button>
      {open ? (
        <div className="space-y-2 px-4 pb-4 text-sm">
          {entry.forms.map((form) => (
            <p key={form.form}>
              <span className="font-medium text-fg">{form.form}</span>
              {form.gloss ? <span className="text-muted"> — {form.gloss}</span> : null}
            </p>
          ))}
          {entry.examples.map((ex) => (
            <p key={ex.tbl} className="border-l-2 border-primary pl-3 text-muted">
              <span className="text-fg">{ex.tbl}</span>
              {ex.en ? ` — ${ex.en}` : ""}
            </p>
          ))}
          <TranslateLink english={entry.gloss.split(",")[0]?.trim() ?? entry.head} />
        </div>
      ) : null}
    </li>
  );
}

function EnglishRow({ item }: { item: EnIndex }) {
  return (
    <li className="rounded-xl bg-surface px-4 py-3 shadow-panel">
      <p className="text-sm text-muted">{item.en}</p>
      <p className="mt-1 font-display text-xl">{item.heads}</p>
      <TranslateLink english={item.en} />
    </li>
  );
}

function PhraseRow({ item }: { item: DictPhrase }) {
  return (
    <li className="rounded-xl bg-surface px-4 py-3 shadow-panel">
      <p className="text-2xs tracking-wide text-subtle">{item.topic}</p>
      <p className="mt-1 font-display text-lg leading-snug" lang="tbl">
        {item.tbl}
      </p>
      <p className="mt-1 text-sm text-muted">{item.en}</p>
      <TranslateLink english={item.en} />
    </li>
  );
}

function TranslateLink({ english }: { english: string }) {
  if (!english) return null;
  return (
    <Link
      to="/translate"
      search={{ en: english }}
      className="mt-2 inline-flex h-8 items-center text-xs font-medium text-primary"
    >
      Translate this
    </Link>
  );
}
