//#region node_modules/.nitro/vite/services/ssr/assets/dictionary-D-_jSYMr.js
var data = {
	entries: [
		{
			"head": "abal",
			"letter": "A",
			"gloss": "shoulder",
			"forms": [],
			"examples": []
		},
		{
			"head": "adat",
			"letter": "A",
			"gloss": "attitude, personality",
			"forms": [{
				"form": "Madat",
				"gloss": "respect (kóyô me ke kdéen tau hol madat yóm kóm boluy, we want everyone to respect your name, Matthew 6:9)"
			}, {
				"form": "Nadat",
				"gloss": "respected"
			}],
			"examples": [
				{
					"tbl": "Nehu madat ke Mà",
					"en": "I also respect Father"
				},
				{
					"tbl": "Nadaten lu kem tau",
					"en": "he respects the people"
				},
				{
					"tbl": "Madat du bê kem tau",
					"en": "he shows respect to the people"
				},
				{
					"tbl": "Nadatu du",
					"en": "I respected him"
				},
				{
					"tbl": "Tey nadat yóm boluyem",
					"en": "your name is very respected"
				},
				{
					"tbl": "Kóyô me ke kdéen tau madat ke Dwata",
					"en": "we want everyone to respect God"
				}
			]
		},
		{
			"head": "akad",
			"letter": "A",
			"gloss": "Sunday (may come from Malay or Arabic \"Ahad\")",
			"forms": [],
			"examples": []
		},
		{
			"head": "alì",
			"letter": "A",
			"gloss": "extremely",
			"forms": [{
				"form": "Alì kinì",
				"gloss": "extremely hot"
			}],
			"examples": [{
				"tbl": "Ekimel alì kinì, okóm kdaw ni téy tnaw",
				"en": "yesterday was extremely hot, but today is very cold"
			}]
		},
		{
			"head": "amil",
			"letter": "A",
			"gloss": "testicles",
			"forms": [],
			"examples": []
		},
		{
			"head": "anay",
			"letter": "A",
			"gloss": "first, for now (borrowed from Hiligaynon, same as Tagalog \"muna\")",
			"forms": [],
			"examples": [{
				"tbl": "Ne meken dé anay",
				"en": "I'll eat first"
			}]
		},
		{
			"head": "andù",
			"letter": "A",
			"gloss": "no one (short for làen dù)",
			"forms": [],
			"examples": []
		},
		{
			"head": "anduen",
			"letter": "A",
			"gloss": "nothing",
			"forms": [],
			"examples": [{
				"tbl": "Anduen. Len myón.",
				"en": "nothing, just sitting"
			}]
		},
		{
			"head": "angkel",
			"letter": "A",
			"gloss": "uncle (borrowed from English)",
			"forms": [],
			"examples": []
		},
		{
			"head": "aprikan",
			"letter": "A",
			"gloss": "African oil palm (borrowed through Hiligaynon, from \"African\"). Its fruit, like tiny coconuts, grows tucked in at the klifak",
			"forms": [],
			"examples": []
		},
		{
			"head": "anì",
			"letter": "A",
			"gloss": "so, so that",
			"forms": [{
				"form": "Anìe",
				"gloss": "so I (the ending jumps onto anì)"
			}],
			"examples": [{
				"tbl": "Kailanganu mekay ken. Anìe meken kdeng.",
				"en": "I need to cook rice so I can eat later"
			}, {
				"tbl": "Anì le sgeng tmowok",
				"en": "so they grow together"
			}]
		},
		{
			"head": "anti",
			"letter": "A",
			"gloss": "aunt (borrowed from English)",
			"forms": [],
			"examples": []
		},
		{
			"head": "aslum",
			"letter": "A",
			"gloss": "sour (borrowed from Hiligaynon, used to make it clear something is sour and not salty)",
			"forms": [],
			"examples": [{
				"tbl": "Téy aslum sinigang nìen, okóm téy mnóm",
				"en": "this sinigang is very sour, but tasty"
			}]
		},
		{
			"head": "bak",
			"letter": "B",
			"gloss": "mouth, opening (baken, his mouth)",
			"forms": [],
			"examples": []
		},
		{
			"head": "bak bengaw",
			"letter": "B",
			"gloss": "window, the traditional word: the hole or entry in the wall",
			"forms": [],
			"examples": []
		},
		{
			"head": "bak tikeb",
			"letter": "B",
			"gloss": "door",
			"forms": [],
			"examples": []
		},
		{
			"head": "baling",
			"letter": "B",
			"gloss": "become",
			"forms": [],
			"examples": [{
				"tbl": "Nuclear bomb skas (le), baling ofi bong",
				"en": "the nuclear bomb breaks them, and they become a big fire"
			}]
		},
		{
			"head": "balu",
			"letter": "B",
			"gloss": "a strand of hair; tornado",
			"forms": [{
				"form": "Mógów baluhen!",
				"gloss": "(cuss) may his/her/its cursed day come"
			}],
			"examples": []
		},
		{
			"head": "bangkù",
			"letter": "B",
			"gloss": "seat, bench, chair",
			"forms": [],
			"examples": []
		},
		{
			"head": "bayad",
			"letter": "B",
			"gloss": "pay (bnayadu, I pay it; gbayad, able to pay)",
			"forms": [],
			"examples": []
		},
		{
			"head": "beeng",
			"letter": "B",
			"gloss": "molars, jaw (beeng le, gnashing their teeth, Acts 7:54)",
			"forms": [],
			"examples": []
		},
		{
			"head": "beng",
			"letter": "B",
			"gloss": "wall, door; the general word for the cover of a house",
			"forms": [],
			"examples": []
		},
		{
			"head": "benwu",
			"letter": "B",
			"gloss": "town, place, world",
			"forms": [],
			"examples": []
		},
		{
			"head": "betek",
			"letter": "B",
			"gloss": "color, style, design",
			"forms": [],
			"examples": []
		},
		{
			"head": "bintanà",
			"letter": "B",
			"gloss": "window (borrowed from Spanish ventana)",
			"forms": [],
			"examples": []
		},
		{
			"head": "blà",
			"letter": "B",
			"gloss": "stop (full stop word, so blaem, blau with no h)",
			"forms": [
				{
					"form": "Blau ne",
					"gloss": "I should stop. Blaem ne: stop what you're doing"
				},
				{
					"form": "**Blaem** also means \"unfortunately, turns out,\" when you find out something you didn't expect. It's like okóm (but), only with surprise",
					"gloss": ""
				},
				{
					"form": "Tô me meken tfayà, blaem andù bunguhen",
					"gloss": "we were going to eat papaya, but it turned out it had no fruit"
				},
				{
					"form": "Blaem hanà mowil ulal tu kimel",
					"gloss": "turns out the snake from yesterday was still alive"
				}
			],
			"examples": []
		},
		{
			"head": "blat",
			"letter": "B",
			"gloss": "heavy (keblaten, its heaviness)",
			"forms": [],
			"examples": []
		},
		{
			"head": "blawang",
			"letter": "B",
			"gloss": "mosquito",
			"forms": [],
			"examples": []
		},
		{
			"head": "blibóy",
			"letter": "B",
			"gloss": "betel nut palm (not in the Bible)",
			"forms": [],
			"examples": []
		},
		{
			"head": "blihen",
			"letter": "B",
			"gloss": "its price",
			"forms": [],
			"examples": []
		},
		{
			"head": "bnos",
			"letter": "B",
			"gloss": "hide something (bnosu, I hid it). Hebnos: hide yourself. Buni: hidden, secret",
			"forms": [],
			"examples": []
		},
		{
			"head": "bok",
			"letter": "B",
			"gloss": "book (boku, my books)",
			"forms": [],
			"examples": []
		},
		{
			"head": "bratu",
			"letter": "B",
			"gloss": "cheap (borrowed from Spanish barato)",
			"forms": [],
			"examples": []
		},
		{
			"head": "btik",
			"letter": "B",
			"gloss": "wake up, get up (Lomihe btik, I just woke up)",
			"forms": [],
			"examples": []
		},
		{
			"head": "btiki",
			"letter": "B",
			"gloss": "wake up! / get up! (to one person)",
			"forms": [],
			"examples": []
		},
		{
			"head": "bulung",
			"letter": "B",
			"gloss": "medicine (bulung mata, eye medicine; hbulung, being treated)",
			"forms": [],
			"examples": []
		},
		{
			"head": "bê",
			"letter": "B",
			"gloss": "one word for any place: to, at, on, in, under, above, below, beside. Also don't, no (refusing or declining), and of.",
			"forms": [
				{
					"form": "Bê ta",
					"gloss": "on top of"
				},
				{
					"form": "Bê laan",
					"gloss": "underneath (something)"
				},
				{
					"form": "Bê lem",
					"gloss": "inside"
				},
				{
					"form": "Bê lohok",
					"gloss": "beside"
				},
				{
					"form": "Bê Byérnis",
					"gloss": "on Friday (bê goes in front of a day)"
				},
				{
					"form": "Bê Miles",
					"gloss": "to Miles"
				},
				{
					"form": "(Bê) yó",
					"gloss": "there"
				},
				{
					"form": "Bê du?",
					"gloss": "to, on, in, or at where?"
				},
				{
					"form": "Bê?",
					"gloss": "where? (depends on context)"
				},
				{
					"form": "Skél bê",
					"gloss": "the same as, like"
				},
				{
					"form": "Para bê",
					"gloss": "for (see para)"
				},
				{
					"form": "Bê e dou tungô",
					"gloss": "I'm not sleeping yet"
				}
			],
			"examples": [{
				"tbl": "Bê tagad tungô he",
				"en": "don't sleep yet"
			}, {
				"tbl": "Là! Bê kuy gów bê yó.",
				"en": "No! Don't go there."
			}]
		},
		{
			"head": "bé",
			"letter": "B",
			"gloss": "grandmother (béhem, your grandmother, 2 Timothy 1:5)",
			"forms": [],
			"examples": []
		},
		{
			"head": "béem bayà",
			"letter": "B",
			"gloss": "don't abandon, don't leave (béem bayà mi, don't leave us, Matthew 6:13)",
			"forms": [],
			"examples": []
		},
		{
			"head": "beklong",
			"letter": "B",
			"gloss": "throat",
			"forms": [],
			"examples": []
		},
		{
			"head": "bélé",
			"letter": "B",
			"gloss": "to, for",
			"forms": [
				{
					"form": "Béléu / Béléeu",
					"gloss": "for me, to me"
				},
				{
					"form": "Béléem",
					"gloss": "to you, for you"
				},
				{
					"form": "Béléen",
					"gloss": "to him/her/it"
				},
				{
					"form": "Béléle",
					"gloss": "to them"
				},
				{
					"form": "Béléye",
					"gloss": "to you all"
				},
				{
					"form": "Bélékuy",
					"gloss": "to all of us"
				},
				{
					"form": "Béléte",
					"gloss": "to just you and me"
				},
				{
					"form": "Para béléem",
					"gloss": "for you (para makes it clear who it's for)"
				}
			],
			"examples": [{
				"tbl": "Hkodoke béléem itlug",
				"en": "I'll boil an egg for you"
			}]
		},
		{
			"head": "bemli",
			"letter": "B",
			"gloss": "buy, buying",
			"forms": [{
				"form": "Nehe bemli anay",
				"gloss": "I will buy first"
			}],
			"examples": []
		},
		{
			"head": "bentik",
			"letter": "B",
			"gloss": "wake up, wake someone up",
			"forms": [{
				"form": "Nehu bentik u anay",
				"gloss": "I will wake you up later"
			}, {
				"form": "Nehu bentik dé",
				"gloss": "just get up already"
			}],
			"examples": []
		},
		{
			"head": "benwu",
			"letter": "B",
			"gloss": "world, place",
			"forms": [{
				"form": "Gu laanen là deng wen benwu he",
				"gloss": "before there was any world yet, in the beginning (John 1:1)"
			}],
			"examples": []
		},
		{
			"head": "besow",
			"letter": "B",
			"gloss": "full (from eating)",
			"forms": [
				{
					"form": "Henok / Besow",
					"gloss": "full"
				},
				{
					"form": "Besowe / Besow",
					"gloss": "I'm full"
				},
				{
					"form": "Denge besow",
					"gloss": "I'm full (I'm already full)"
				}
			],
			"examples": [{
				"tbl": "Besowe ne",
				"en": "I'm full now"
			}]
		},
		{
			"head": "bew",
			"letter": "B",
			"gloss": "carabao, water buffalo",
			"forms": [],
			"examples": []
		},
		{
			"head": "bitil",
			"letter": "B",
			"gloss": "hungry",
			"forms": [
				{
					"form": "Bitile",
					"gloss": "I'm hungry (can also mean \"they're hungry\")"
				},
				{
					"form": "Bitile ah",
					"gloss": "I'm hungry"
				},
				{
					"form": "Bitilu",
					"gloss": "you're hungry"
				},
				{
					"form": "Bitile lu",
					"gloss": "they're hungry (clearer)"
				}
			],
			"examples": [{
				"tbl": "Teye bitil. Kóm du?",
				"en": "I'm very hungry. And you?"
			}]
		},
		{
			"head": "blay",
			"letter": "B",
			"gloss": "give",
			"forms": [{
				"form": "Ne blay",
				"gloss": "I will give"
			}],
			"examples": [{
				"tbl": "Haya, ne blay lu bê kem twolihu",
				"en": "tomorrow I'll give them to my siblings"
			}]
		},
		{
			"head": "blotik",
			"letter": "B",
			"gloss": "star",
			"forms": [],
			"examples": []
		},
		{
			"head": "blutut",
			"letter": "B",
			"gloss": "belly, stomach; also womb",
			"forms": [],
			"examples": []
		},
		{
			"head": "bnes",
			"letter": "B",
			"gloss": "grass",
			"forms": [],
			"examples": []
		},
		{
			"head": "boi",
			"letter": "B",
			"gloss": "princess (a title)",
			"forms": [],
			"examples": []
		},
		{
			"head": "bolok",
			"letter": "B",
			"gloss": "rotten",
			"forms": [
				{
					"form": "Bolok lembak!",
					"gloss": "(cuss) rotten mouth"
				},
				{
					"form": "Bolok sélék!",
					"gloss": "(cuss) rotten lips, side to side"
				},
				{
					"form": "Bolok sumóng!",
					"gloss": "(cuss) rotten lips"
				}
			],
			"examples": []
		},
		{
			"head": "bon",
			"letter": "B",
			"gloss": "what",
			"forms": [
				{
					"form": "Bon nmoem (du)?",
					"gloss": "what are you doing?"
				},
				{
					"form": "Bon nmoem ni?",
					"gloss": "what are you doing now?"
				},
				{
					"form": "Bon (tô) nmou",
					"gloss": "what I do, what to do"
				},
				{
					"form": "Bon boluyem (du)?",
					"gloss": "what's your name?"
				},
				{
					"form": "Bon kdaw du ni (kdaw ni)?",
					"gloss": "what's the date today?"
				},
				{
					"form": "Bon kminì kóm du?",
					"gloss": "what's heating you?"
				},
				{
					"form": "Bon se duen hnagì te du?",
					"gloss": "what else should we learn?"
				}
			],
			"examples": []
		},
		{
			"head": "bong",
			"letter": "B",
			"gloss": "big",
			"forms": [
				{
					"form": "Téy kinì bong",
					"gloss": "it's really, really hot"
				},
				{
					"form": "Bong slamat",
					"gloss": "thank you so much"
				},
				{
					"form": "See also kbong",
					"gloss": ""
				}
			],
			"examples": [{
				"tbl": "Kulón bong?",
				"en": "big rain?"
			}]
		},
		{
			"head": "botò",
			"letter": "B",
			"gloss": "penis",
			"forms": [],
			"examples": []
		},
		{
			"head": "boto",
			"letter": "B",
			"gloss": "dick (vulgar)",
			"forms": [{
				"form": "Sbotoen!",
				"gloss": "(cuss) his dick!"
			}],
			"examples": []
		},
		{
			"head": "botu",
			"letter": "B",
			"gloss": "stone",
			"forms": [],
			"examples": []
		},
		{
			"head": "boyu",
			"letter": "B",
			"gloss": "do; also a filler like Tagalog \"ano\" (um, you know)",
			"forms": [{
				"form": "Là boyu hu du ganì",
				"gloss": "I don't even do it"
			}, {
				"form": "Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal",
				"gloss": "um, we were still walking, then we saw a snake"
			}],
			"examples": []
		},
		{
			"head": "bud",
			"letter": "B",
			"gloss": "again (in front, for something that will happen)",
			"forms": [
				{
					"form": "Bud (ne)",
					"gloss": "anymore"
				},
				{
					"form": "Bud te",
					"gloss": "we will (again)"
				},
				{
					"form": "Bud etu he",
					"gloss": "we will do it again; until then"
				},
				{
					"form": "Bud kmulón",
					"gloss": "it'll rain again"
				},
				{
					"form": "Bud moo ktuku",
					"gloss": "I'm sleepy again"
				}
			],
			"examples": [{
				"tbl": "Bud te ston kdeng",
				"en": "we'll see each other later"
			}, {
				"tbl": "Là nóyóu du kehe bud lehen",
				"en": "I don't want to be skinny anymore"
			}]
		},
		{
			"head": "bukay",
			"letter": "B",
			"gloss": "white",
			"forms": [],
			"examples": []
		},
		{
			"head": "bukol",
			"letter": "B",
			"gloss": "knees",
			"forms": [],
			"examples": []
		},
		{
			"head": "bulók",
			"letter": "B",
			"gloss": "flower (bulók lem bnes, flowers in the grass, Luke 12:27)",
			"forms": [],
			"examples": []
		},
		{
			"head": "bulón",
			"letter": "B",
			"gloss": "moon; month (like kdaw is sun and day)",
			"forms": [{
				"form": "Todol bulón",
				"gloss": "next month"
			}],
			"examples": [{
				"tbl": "Bulón nô bê ta",
				"en": "the moon is up above"
			}]
		},
		{
			"head": "bulul",
			"letter": "B",
			"gloss": "mountain (Bulul Ulib, Mount of Olives)",
			"forms": [],
			"examples": []
		},
		{
			"head": "bungu",
			"letter": "B",
			"gloss": "fruit (kbunguhen, its fruit; bunguhen, its fruit)",
			"forms": [],
			"examples": []
		},
		{
			"head": "buri",
			"letter": "B",
			"gloss": "buri palm, the huge fan-leaf palm with a thick trunk (borrowed from Tagalog)",
			"forms": [],
			"examples": []
		},
		{
			"head": "Byérnis",
			"letter": "B",
			"gloss": "Friday (borrowed from Spanish)",
			"forms": [],
			"examples": []
		},
		{
			"head": "demyol",
			"letter": "D",
			"gloss": "pull, drag",
			"forms": [],
			"examples": []
		},
		{
			"head": "des kinì",
			"letter": "D",
			"gloss": "fever, literally \"hot sickness\" (kkinien, its heat)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dlag",
			"letter": "D",
			"gloss": "wild (ohu dlag, wild dogs)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dlag lamang",
			"letter": "D",
			"gloss": "forest (dlag, wild; lamang, wide)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dmilot",
			"letter": "D",
			"gloss": "draw a sword",
			"forms": [],
			"examples": []
		},
		{
			"head": "dnadu",
			"letter": "D",
			"gloss": "field for planting (dnaduhen, his field)",
			"forms": [],
			"examples": []
		},
		{
			"head": "do (me)",
			"letter": "D",
			"gloss": "(also dou): me, for me. Nitem do kun sélfónu: carry my phone for me",
			"forms": [],
			"examples": []
		},
		{
			"head": "doli beng",
			"letter": "D",
			"gloss": "the other side of the backyard",
			"forms": [],
			"examples": []
		},
		{
			"head": "duktur",
			"letter": "D",
			"gloss": "doctor (borrowed)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dyo",
			"letter": "D",
			"gloss": "bathe (whole body)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dyo",
			"letter": "D",
			"gloss": "bathe (whole body)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dyol",
			"letter": "D",
			"gloss": "pull, drag (demyol, pulling). Dyol le ówóng bê kilil: they pulled the boat to shore",
			"forms": [],
			"examples": []
		},
		{
			"head": "dé kô",
			"letter": "D",
			"gloss": "maybe, perhaps, I guess so, I think so; if (something happens), depending on context",
			"forms": [],
			"examples": [{
				"tbl": "Omin likoe dé kô gungolen o Pangu",
				"en": "and I'm afraid my dad will hear me"
			}]
		},
		{
			"head": "deng",
			"letter": "D",
			"gloss": "done, already",
			"forms": [
				{
					"form": "Denge",
					"gloss": "I'm done"
				},
				{
					"form": "Dengu",
					"gloss": "you're done"
				},
				{
					"form": "Dengi",
					"gloss": "you're done (formal)"
				},
				{
					"form": "Deng ye",
					"gloss": "you all are done"
				},
				{
					"form": "Deng le",
					"gloss": "they're all done"
				},
				{
					"form": "Deng kuy",
					"gloss": "we're done (including me)"
				},
				{
					"form": "Deng te",
					"gloss": "we're done (just you and me)"
				},
				{
					"form": "Deng me",
					"gloss": "we're done (me and others, not the person I'm talking to)"
				},
				{
					"form": "Deng (ne) du",
					"gloss": "he/she/it is done"
				},
				{
					"form": "Deng kenu",
					"gloss": "I ate"
				},
				{
					"form": "Denge meken",
					"gloss": "I already ate"
				},
				{
					"form": "Deng ne meken",
					"gloss": "I'm done eating"
				},
				{
					"form": "Deng t'ngónu ne",
					"gloss": "now I know"
				}
			],
			"examples": [{
				"tbl": "Deng tógó (ne) ken / Ken, deng tógó (ne)",
				"en": "the rice is already cooked"
			}]
		},
		{
			"head": "des",
			"letter": "D",
			"gloss": "hurt; sick",
			"forms": [],
			"examples": []
		},
		{
			"head": "dilak",
			"letter": "D",
			"gloss": "tongue",
			"forms": [{
				"form": "Mfól dilak!",
				"gloss": "(cuss) thick tongue"
			}],
			"examples": []
		},
		{
			"head": "dlimun",
			"letter": "D",
			"gloss": "made, created",
			"forms": [{
				"form": "Kedlimunen",
				"gloss": "what he made, his creation (John 1:3)"
			}],
			"examples": []
		},
		{
			"head": "do",
			"letter": "D",
			"gloss": "mine; me, when I'm the one something happens to (from dou)",
			"forms": [{
				"form": "Do u ni",
				"gloss": "this is mine"
			}, {
				"form": "Do ken",
				"gloss": "my food"
			}],
			"examples": [{
				"tbl": "Yó kóm ken, ni do ken",
				"en": "that's your food, this is my food"
			}, {
				"tbl": "Ktolok le do",
				"en": "they taught me"
			}]
		},
		{
			"head": "dou",
			"letter": "D",
			"gloss": "I own; mine; my",
			"forms": [{
				"form": "Dou wong",
				"gloss": "(it's) my spider"
			}, {
				"form": "Do wong / wongu",
				"gloss": "my spider. -u on the end is for something that belongs to you"
			}],
			"examples": [{
				"tbl": "Uu dou dumu sbót",
				"en": "you are my friend"
			}]
		},
		{
			"head": "doun",
			"letter": "D",
			"gloss": "leaf (dounen, its leaves)",
			"forms": [],
			"examples": []
		},
		{
			"head": "du",
			"letter": "D",
			"gloss": "him, her, it (used everywhere for he/she/it); in questions like Kmoem du it means \"it\" or \"something\"; in kmon du it points to the thing being said",
			"forms": [
				{
					"form": "Du yó",
					"gloss": "that's him"
				},
				{
					"form": "Meken du",
					"gloss": "he's eating"
				},
				{
					"form": "Mebel du",
					"gloss": "he/she/it finds (something)"
				}
			],
			"examples": []
		},
		{
			"head": "dumu",
			"letter": "D",
			"gloss": "other; another (sotu / dumu)",
			"forms": [
				{
					"form": "Dumuhu",
					"gloss": "my other"
				},
				{
					"form": "Dumu sbót",
					"gloss": "a friend"
				},
				{
					"form": "Dumuhu sbót",
					"gloss": "my friend (telling someone else)"
				},
				{
					"form": "Kem dumuhu sbót",
					"gloss": "my (other) friends"
				},
				{
					"form": "Kem dumu bots",
					"gloss": "the other bots"
				}
			],
			"examples": [{
				"tbl": "Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem",
				"en": "other bots like ChatGPT don't understand it even when they read your lesson notes"
			}]
		},
		{
			"head": "dumuhen setwoli",
			"letter": "D",
			"gloss": "relatives, kin, cousin (Colossians 4:10, Luke 1:58)",
			"forms": [],
			"examples": []
		},
		{
			"head": "Dwata",
			"letter": "D",
			"gloss": "God",
			"forms": [
				{
					"form": "Ke Dwata",
					"gloss": "to God, or God's"
				},
				{
					"form": "Ke Dwata yó",
					"gloss": "that's God's"
				},
				{
					"form": "Udél Dwata",
					"gloss": "the T'boli Bible (see udél)"
				}
			],
			"examples": []
		},
		{
			"head": "dyó",
			"letter": "D",
			"gloss": "swim; take a shower",
			"forms": [{
				"form": "Nehe dyó dé",
				"gloss": "I'm going to swim / take a shower"
			}],
			"examples": []
		},
		{
			"head": "dê",
			"letter": "D",
			"gloss": "many (tey dê, very many; là holen wen, few)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dóyón",
			"letter": "D",
			"gloss": "proud",
			"forms": [],
			"examples": []
		},
		{
			"head": "dù",
			"letter": "D",
			"gloss": "touch (mdù, touching; nduen, he touched it; béem ndù, don't touch)",
			"forms": [],
			"examples": []
		},
		{
			"head": "dù (touch)",
			"letter": "D",
			"gloss": "touch (mdù, touching; gemdù, touch). Béem ndù sélfónu: don't touch my phone",
			"forms": [],
			"examples": []
		},
		{
			"head": "ebuteng",
			"letter": "E",
			"gloss": "last night",
			"forms": [{
				"form": "Henslòu mlóy ebuteng",
				"gloss": "I was running fast last night"
			}, {
				"form": "Nógówu u ebuteng",
				"gloss": "I went to you last night"
			}],
			"examples": []
		},
		{
			"head": "eginu",
			"letter": "E",
			"gloss": "earlier",
			"forms": [{
				"form": "Eginu hlafus",
				"gloss": "earlier this morning"
			}, {
				"form": "Eginu kifu",
				"gloss": "earlier at night, last night"
			}],
			"examples": []
		},
		{
			"head": "Ekimel",
			"letter": "E",
			"gloss": "yesterday",
			"forms": [],
			"examples": []
		},
		{
			"head": "Ekimel kimel",
			"letter": "E",
			"gloss": "yesterday afternoon",
			"forms": [{
				"form": "Ekimel kimel téy kinì",
				"gloss": "yesterday afternoon was so hot"
			}],
			"examples": []
		},
		{
			"head": "Ekuloy",
			"letter": "E",
			"gloss": "the day before yesterday",
			"forms": [],
			"examples": []
		},
		{
			"head": "elaan",
			"letter": "E",
			"gloss": "down, downward",
			"forms": [],
			"examples": []
		},
		{
			"head": "elem",
			"letter": "E",
			"gloss": "into, up to (elem mohin, into the sea; elem bulul, up the mountain)",
			"forms": [],
			"examples": []
		},
		{
			"head": "enahaw",
			"letter": "E",
			"gloss": "anahaw, the round fan-leaf palm (borrowed from Tagalog anahaw)",
			"forms": [],
			"examples": []
		},
		{
			"head": "él",
			"letter": "E",
			"gloss": "water",
			"forms": [{
				"form": "Minum él",
				"gloss": "drink water"
			}],
			"examples": [{
				"tbl": "Haya, nehe gów bê él, mebel utón",
				"en": "tomorrow I will go to the water and find fish"
			}]
		},
		{
			"head": "él alah",
			"letter": "E",
			"gloss": "the Allah River, in Allah Valley, what Deymar's place calls the river",
			"forms": [],
			"examples": []
		},
		{
			"head": "él mlel",
			"letter": "E",
			"gloss": "river, literally flowing water",
			"forms": [],
			"examples": []
		},
		{
			"head": "Ell",
			"letter": "E",
			"gloss": "yes (said like \"Ull\")",
			"forms": [{
				"form": "Ell, tahu yó",
				"gloss": "yes, that's true"
			}, {
				"form": "Ell, tahu ni",
				"gloss": "yes, it is real"
			}],
			"examples": []
		},
		{
			"head": "ene",
			"letter": "E",
			"gloss": "come",
			"forms": [{
				"form": "Ene bê ni",
				"gloss": "come here"
			}],
			"examples": []
		},
		{
			"head": "esolu",
			"letter": "E",
			"gloss": "(where) will be going",
			"forms": [],
			"examples": [{
				"tbl": "Olohu hetngón du béléem bê du gôem esolu",
				"en": "I just want you to know where you're supposed to be going"
			}]
		},
		{
			"head": "etu",
			"letter": "E",
			"gloss": "then (sometime in the future)",
			"forms": [{
				"form": "Bud etu he",
				"gloss": "we will do it again; until then"
			}],
			"examples": []
		},
		{
			"head": "ewen",
			"letter": "E",
			"gloss": "so",
			"forms": [],
			"examples": [{
				"tbl": "T'ngónem galì ewenu se ke hentahumen udélu kô?",
				"en": "oh, so you'll believe anything I say, huh?"
			}]
		},
		{
			"head": "fak",
			"letter": "F",
			"gloss": "frog",
			"forms": [],
			"examples": []
		},
		{
			"head": "fro",
			"letter": "F",
			"gloss": "thought (it was), assumed, and it turned out wrong. Takes the person: fro kum (we thought)",
			"forms": [
				{
					"form": "Fro ke du",
					"gloss": "I thought it was him"
				},
				{
					"form": "Fro ke Deadpool character",
					"gloss": "I thought it was the Deadpool character"
				},
				{
					"form": "Ekuloy tô me mwa kmatì bê farm, fro kum ke wen blaem anduen",
					"gloss": "the day before yesterday we were going to get tomatoes at the farm, we thought there were some, but there were none"
				}
			],
			"examples": []
		},
		{
			"head": "fakay",
			"letter": "F",
			"gloss": "can, may; allow",
			"forms": [
				{
					"form": "Fakay kô?",
					"gloss": "is it allowed? can I?"
				},
				{
					"form": "Fakay ke",
					"gloss": "can I..."
				},
				{
					"form": "Fakay kô ke...?",
					"gloss": "can we / is it allowed to...? (ke is the \"if\" that links fakay kô to the action)"
				}
			],
			"examples": []
		},
		{
			"head": "fan",
			"letter": "F",
			"gloss": "trap",
			"forms": [{
				"form": "Fanen",
				"gloss": "his/her/its trap"
			}, {
				"form": "Gfan, hegfan, segfan (showing up) are built from this root",
				"gloss": ""
			}],
			"examples": [{
				"tbl": "Nmoem fanen dé",
				"en": "put a trap on it"
			}]
		},
		{
			"head": "fat",
			"letter": "F",
			"gloss": "four",
			"forms": [],
			"examples": []
		},
		{
			"head": "fedyan",
			"letter": "F",
			"gloss": "week",
			"forms": [{
				"form": "Todol fedyan",
				"gloss": "next week"
			}],
			"examples": []
		},
		{
			"head": "filak",
			"letter": "F",
			"gloss": "money, silver",
			"forms": [],
			"examples": []
		},
		{
			"head": "fishtail palm",
			"letter": "F",
			"gloss": "placeholder, borrowed from English until the T'boli name is found (Tagalog: pugahan)",
			"forms": [],
			"examples": []
		},
		{
			"head": "fig",
			"letter": "F",
			"gloss": "fig (borrowed from English; no everyday T'boli word). Koyu fig, fig tree (Matthew 21:19, Matthew 24:32); bungu fig, figs (James 3:12). The sycamore-fig Zacchaeus climbs is **sikamor** (Luke 19:4)",
			"forms": [],
			"examples": []
		},
		{
			"head": "folò",
			"letter": "F",
			"gloss": "tens (Lwu folò, 20)",
			"forms": [],
			"examples": []
		},
		{
			"head": "fun",
			"letter": "F",
			"gloss": "owner (the u like in uniform)",
			"forms": [
				{
					"form": "Funu",
					"gloss": "my owner"
				},
				{
					"form": "Funem",
					"gloss": "your owner"
				},
				{
					"form": "Funen",
					"gloss": "his/her/its owner"
				},
				{
					"form": "Funle",
					"gloss": "their owner (people not in the conversation)"
				},
				{
					"form": "Funye",
					"gloss": "you all's owner (speaker not included)"
				},
				{
					"form": "Funkuy",
					"gloss": "our owner (me and 2 or more people)"
				},
				{
					"form": "Funte",
					"gloss": "our owner (just me and one other person)"
				}
			],
			"examples": []
		},
		{
			"head": "gafit",
			"letter": "G",
			"gloss": "caught in the act",
			"forms": [],
			"examples": []
		},
		{
			"head": "galì",
			"letter": "G",
			"gloss": "oh, so that's why (Tagalog \"kaya pala\")",
			"forms": [],
			"examples": []
		},
		{
			"head": "ganag",
			"letter": "G",
			"gloss": "slow",
			"forms": [{
				"form": "Hen-ganagem",
				"gloss": "slow down (you). The hyphen keeps n and g apart, so it isn't read as the ng in mango"
			}],
			"examples": []
		},
		{
			"head": "ganì",
			"letter": "G",
			"gloss": "even, really; backs up that something is true",
			"forms": [{
				"form": "Là t'ngónu du ganì do",
				"gloss": "I don't even know (it)"
			}, {
				"form": "Là boyu hu du ganì",
				"gloss": "I don't even do it"
			}],
			"examples": []
		},
		{
			"head": "gebtik",
			"letter": "G",
			"gloss": "woken up suddenly",
			"forms": [],
			"examples": []
		},
		{
			"head": "gemnóm des",
			"letter": "G",
			"gloss": "being sick (desen, his sickness)",
			"forms": [],
			"examples": []
		},
		{
			"head": "geta",
			"letter": "G",
			"gloss": "high, for status or the height of something (tau geta, rich person)",
			"forms": [],
			"examples": []
		},
		{
			"head": "ginggung",
			"letter": "G",
			"gloss": "blue",
			"forms": [],
			"examples": []
		},
		{
			"head": "glayam",
			"letter": "G",
			"gloss": "suffering (tey keglayamu, I am in anguish)",
			"forms": [],
			"examples": []
		},
		{
			"head": "gotu",
			"letter": "G",
			"gloss": "nothing left, all gone (gotu le yóm ken, they left no rice)",
			"forms": [],
			"examples": []
		},
		{
			"head": "gulom",
			"letter": "G",
			"gloss": "ant",
			"forms": [],
			"examples": []
		},
		{
			"head": "grép",
			"letter": "G",
			"gloss": "grape (borrowed from English; bungu grép, grapes)",
			"forms": [],
			"examples": []
		},
		{
			"head": "gungol",
			"letter": "G",
			"gloss": "hear (gungolen o, he hears/heard me). Gungolen o Pangu: my dad hears/heard me. **Gegungolem o / Gel gungolem o**: you always hear me (gel = always, also shown by doubling ge-)",
			"forms": [],
			"examples": []
		},
		{
			"head": "guta",
			"letter": "G",
			"gloss": "catch, get something (like fish)",
			"forms": [],
			"examples": []
		},
		{
			"head": "géhél",
			"letter": "G",
			"gloss": "hurry; also soon",
			"forms": [],
			"examples": []
		},
		{
			"head": "ge / gel",
			"letter": "G",
			"gloss": "always, usually; the one who does it (ge is everyday speech, gel is the Bible spelling). Dumu udél gel hnagì Deymar: other languages Deymar studies",
			"forms": [],
			"examples": [{
				"tbl": "Gel mi coffee-hu, wen klamay nô lemmen",
				"en": "my coffee's always sweet, it has sugar in it"
			}, {
				"tbl": "Ni kdaw ni tey gel tnaw",
				"en": "today is really, really cold"
			}]
		},
		{
			"head": "gfan",
			"letter": "G",
			"gloss": "show up unexpectedly",
			"forms": [
				{
					"form": "Hegfan",
					"gloss": "show up intentionally, walking into the fan (trap or event) someone set, on purpose"
				},
				{
					"form": "Segfan",
					"gloss": "show up to each other"
				},
				{
					"form": "Built from fan (trap)",
					"gloss": "gfan is getting caught by it, showing up by surprise"
				}
			],
			"examples": [{
				"tbl": "Haya gfan yó du",
				"en": "tomorrow he will show up"
			}]
		},
		{
			"head": "genléd",
			"letter": "G",
			"gloss": "rely",
			"forms": [{
				"form": "Genléd nawa",
				"gloss": "rely on (putting your own breath, your self, onto something)"
			}],
			"examples": []
		},
		{
			"head": "geslà",
			"letter": "G",
			"gloss": "a surprise, something you didn't expect",
			"forms": [{
				"form": "Geslàu wong / Gebele wong",
				"gloss": "I stumbled on a spider"
			}, {
				"form": "Not the same as gesla (no accent)",
				"gloss": "(being) fried"
			}],
			"examples": []
		},
		{
			"head": "gna",
			"letter": "G",
			"gloss": "first (the general word); past; old",
			"forms": [{
				"form": "Gna halay",
				"gloss": "last year"
			}, {
				"form": "Gna kesfasad",
				"gloss": "old covenant"
			}],
			"examples": []
		},
		{
			"head": "góem",
			"letter": "G",
			"gloss": "where? where to? (said short like this, it means \"where\" and stops meaning \"your house\")",
			"forms": [{
				"form": "Góem gów (du)?",
				"gloss": "where are you going?"
			}, {
				"form": "Góen nô phone-nu (du)?",
				"gloss": "where's my phone?"
			}],
			"examples": []
		},
		{
			"head": "gónô",
			"letter": "G",
			"gloss": "house; home",
			"forms": [
				{
					"form": "Gónôem lemwót du?",
					"gloss": "where are you from?"
				},
				{
					"form": "Gónôem gu du? / Gôem gu?",
					"gloss": "where did you go? where have you been? (like Tagalog \"saan ka galing?\")"
				},
				{
					"form": "Gónôem msut? / Gôem sut?",
					"gloss": "where were you born?"
				},
				{
					"form": "Gónóem",
					"gloss": "your house, your place"
				},
				{
					"form": "Gónô le",
					"gloss": "their home"
				},
				{
					"form": "Gónô mnô",
					"gloss": "home"
				}
			],
			"examples": [{
				"tbl": "Kilón ke kulékem bê gónô?",
				"en": "when will you get back home?"
			}]
		},
		{
			"head": "gónô fedyan",
			"letter": "G",
			"gloss": "market (the place); fedyan alone is week or market day",
			"forms": [],
			"examples": []
		},
		{
			"head": "gów",
			"letter": "G",
			"gloss": "go",
			"forms": [{
				"form": "Gówu",
				"gloss": "you go"
			}, {
				"form": "Nehe gów",
				"gloss": "I will go"
			}],
			"examples": [{
				"tbl": "Bê du gôem gów du?",
				"en": "where are you going? the full way"
			}, {
				"tbl": "Hene, gówu bê ni. Tungôu.",
				"en": "come, go here. Sleep."
			}]
		},
		{
			"head": "gwa",
			"letter": "G",
			"gloss": "get; accidentally taken (see ma)",
			"forms": [],
			"examples": []
		},
		{
			"head": "haha",
			"letter": "H",
			"gloss": "legs",
			"forms": [],
			"examples": []
		},
		{
			"head": "halay",
			"letter": "H",
			"gloss": "year; also living rice, the rice plant",
			"forms": [{
				"form": "Gna halay",
				"gloss": "last year"
			}],
			"examples": []
		},
		{
			"head": "hampang",
			"letter": "H",
			"gloss": "play, like kids playing (borrowed from Hiligaynon)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hangat",
			"letter": "H",
			"gloss": "wait, wait for (the subject is the one waiting)",
			"forms": [
				{
					"form": "Hangat ye o dé!",
					"gloss": "wait for me!"
				},
				{
					"form": "Hangatu kkól Yê",
					"gloss": "I'm waiting for Mother to come back"
				},
				{
					"form": "Tagad dé, Mà. Ne hangat ken",
					"gloss": "wait, Father. I'm still waiting for the food"
				}
			],
			"examples": []
		},
		{
			"head": "hanà",
			"letter": "H",
			"gloss": "still",
			"forms": [{
				"form": "Hanà là deng t'ngónu du bon nmou",
				"gloss": "I still don't know what to do"
			}],
			"examples": [{
				"tbl": "Là nóyóu du tungô, kaye (hanà) bitil (I don't want to sleep because I'm",
				"en": "still) hungry"
			}]
		},
		{
			"head": "hatay",
			"letter": "H",
			"gloss": "death, dying",
			"forms": [{
				"form": "Là gógówen elem hatay",
				"gloss": "he won't be lost to death"
			}],
			"examples": []
		},
		{
			"head": "haya",
			"letter": "H",
			"gloss": "tomorrow",
			"forms": [{
				"form": "Key haya",
				"gloss": "every day (written ket haya in Matthew 6:11)"
			}],
			"examples": [{
				"tbl": "Haya, bud kmulón",
				"en": "tomorrow it'll rain again"
			}]
		},
		{
			"head": "hbalù",
			"letter": "H",
			"gloss": "sell (hbaluen, he sold it)",
			"forms": [],
			"examples": []
		},
		{
			"head": "he",
			"letter": "H",
			"gloss": "at the end of a sentence: yet; again, with a hope in it",
			"forms": [
				{
					"form": "Tagad he",
					"gloss": "wait a bit"
				},
				{
					"form": "Là e deng meken he",
					"gloss": "I haven't eaten yet"
				},
				{
					"form": "Bud te ston he",
					"gloss": "we'll see each other again, hopefully"
				}
			],
			"examples": []
		},
		{
			"head": "hebetik",
			"letter": "H",
			"gloss": "jump up, leap to your feet",
			"forms": [],
			"examples": []
		},
		{
			"head": "hedem",
			"letter": "H",
			"gloss": "think; also the closest word for bored",
			"forms": [
				{
					"form": "Kehedem",
					"gloss": "to think"
				},
				{
					"form": "Kehdem",
					"gloss": "to be thinking"
				},
				{
					"form": "Kmò kehdemem du se?",
					"gloss": "what do you think? (one person)"
				},
				{
					"form": "Kmò kehdem u du se?",
					"gloss": "what do I think?"
				},
				{
					"form": "Kmò kehdem ye du se?",
					"gloss": "what do you all think?"
				},
				{
					"form": "Kehegdemu du",
					"gloss": "I think"
				},
				{
					"form": "Kehegdemem du",
					"gloss": "you think"
				},
				{
					"form": "Kehegdem le du",
					"gloss": "they think"
				}
			],
			"examples": []
		},
		{
			"head": "heglaan",
			"letter": "H",
			"gloss": "humble",
			"forms": [],
			"examples": []
		},
		{
			"head": "heglomboy",
			"letter": "H",
			"gloss": "long robe",
			"forms": [],
			"examples": []
		},
		{
			"head": "hegmón",
			"letter": "H",
			"gloss": "proud in a bad way, arrogant. Kehegmón: pride",
			"forms": [],
			"examples": []
		},
		{
			"head": "hegnô",
			"letter": "H",
			"gloss": "rest, lie down",
			"forms": [],
			"examples": []
		},
		{
			"head": "helek",
			"letter": "H",
			"gloss": "sand (helek bè kilil mohin, sand on the seashore)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hemken",
			"letter": "H",
			"gloss": "to feed (from ken)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hemsag",
			"letter": "H",
			"gloss": "shouted",
			"forms": [{
				"form": "Tong ye hemsag",
				"gloss": "so you guys shouted"
			}],
			"examples": []
		},
		{
			"head": "hemtedeng knô",
			"letter": "H",
			"gloss": "acting righteous, fake. Tau gel hemtedeng knô: a hypocrite (Acts 23:3)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hemyak",
			"letter": "H",
			"gloss": "shameful",
			"forms": [],
			"examples": []
		},
		{
			"head": "hendóm",
			"letter": "H",
			"gloss": "lend, let someone borrow",
			"forms": [],
			"examples": []
		},
		{
			"head": "hentulón nawa",
			"letter": "H",
			"gloss": "remember (keep in mind on purpose). Gtulón bè nawa: it came back to mind",
			"forms": [],
			"examples": []
		},
		{
			"head": "hitok",
			"letter": "H",
			"gloss": "muddy, mud",
			"forms": [],
			"examples": []
		},
		{
			"head": "hkawang",
			"letter": "H",
			"gloss": "empty, empty-handed",
			"forms": [],
			"examples": []
		},
		{
			"head": "hlifót",
			"letter": "H",
			"gloss": "pretend not to know something (in a bad way). Compare hlingu (pretend to be someone)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hlingu / hlingón",
			"letter": "H",
			"gloss": "pretend to be someone, disguise yourself as. Hlingu le tau hemtahu: they pretend to be believers (Galatians 2:4)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hmungol",
			"letter": "H",
			"gloss": "listen (hnungol ye, you all listen)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hmungol",
			"letter": "H",
			"gloss": "listen (hnungol, listen to it). Hnungol ye o dé: listen to me, all of you",
			"forms": [],
			"examples": []
		},
		{
			"head": "hnas",
			"letter": "H",
			"gloss": "opened up, uncovered",
			"forms": [],
			"examples": []
		},
		{
			"head": "hnifót",
			"letter": "H",
			"gloss": "forgive (hnifótem, you forgive) (Matthew 6:12)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hnifótem du kun",
			"letter": "H",
			"gloss": "forgive him, please",
			"forms": [],
			"examples": []
		},
		{
			"head": "hnifótem o",
			"letter": "H",
			"gloss": "sorry, forgive me (the everyday apology)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hnolo",
			"letter": "H",
			"gloss": "oil",
			"forms": [],
			"examples": []
		},
		{
			"head": "htò",
			"letter": "H",
			"gloss": "jumping, jump, jumped (same form for now and past)",
			"forms": [{
				"form": "Wong htò / Htò wong",
				"gloss": "the spider is jumping; the spider jumped; jumping spider"
			}, {
				"form": "Wót wong htò",
				"gloss": "the spider keeps jumping"
			}],
			"examples": []
		},
		{
			"head": "huket",
			"letter": "H",
			"gloss": "fishing net",
			"forms": [],
			"examples": []
		},
		{
			"head": "huli",
			"letter": "H",
			"gloss": "following, coming after",
			"forms": [],
			"examples": []
		},
		{
			"head": "hulu",
			"letter": "H",
			"gloss": "planted garden, orchard",
			"forms": [],
			"examples": []
		},
		{
			"head": "hutóng",
			"letter": "H",
			"gloss": "lend (money), from utóng (debt)",
			"forms": [],
			"examples": []
		},
		{
			"head": "huyów",
			"letter": "H",
			"gloss": "plate, platter",
			"forms": [],
			"examples": []
		},
		{
			"head": "héfê",
			"letter": "H",
			"gloss": "wet",
			"forms": [],
			"examples": []
		},
		{
			"head": "héét",
			"letter": "H",
			"gloss": "salty, sour, and bitter",
			"forms": [],
			"examples": []
		},
		{
			"head": "hegléd",
			"letter": "H",
			"gloss": "lean, leaning, leaned",
			"forms": [],
			"examples": []
		},
		{
			"head": "hene",
			"letter": "H",
			"gloss": "come (here)",
			"forms": [{
				"form": "Hene edi ni",
				"gloss": "come over here"
			}, {
				"form": "Hene, gówu bê ni. Tungôu.",
				"gloss": "come, go here. Sleep."
			}],
			"examples": []
		},
		{
			"head": "hitem",
			"letter": "H",
			"gloss": "black",
			"forms": [],
			"examples": []
		},
		{
			"head": "hitu",
			"letter": "H",
			"gloss": "seven",
			"forms": [],
			"examples": []
		},
		{
			"head": "hligal",
			"letter": "H",
			"gloss": "happy, celebrate",
			"forms": [{
				"form": "Hligale",
				"gloss": "I'm happy"
			}, {
				"form": "Teye hligal",
				"gloss": "I'm very happy"
			}],
			"examples": []
		},
		{
			"head": "hlós",
			"letter": "H",
			"gloss": "continue",
			"forms": [{
				"form": "Làe hlós meken se",
				"gloss": "I didn't eat (I didn't go on to eat)"
			}],
			"examples": []
		},
		{
			"head": "hlowon",
			"letter": "H",
			"gloss": "joking",
			"forms": [{
				"form": "Olohu hlowon néen",
				"gloss": "I'm just joking"
			}],
			"examples": []
		},
		{
			"head": "hnagì",
			"letter": "H",
			"gloss": "learn, schooling; lessons",
			"forms": [
				{
					"form": "Hemnagì",
					"gloss": "to study something"
				},
				{
					"form": "Kehnagì",
					"gloss": "still studying something (ongoing)"
				},
				{
					"form": "Mnagì",
					"gloss": "studying"
				}
			],
			"examples": [{
				"tbl": "Bon se duen hnagì te du?",
				"en": "what else should we learn?"
			}, {
				"tbl": "Lnóngónu meken wen para bê kem lomi hnagì",
				"en": "I need to eat more for new lessons"
			}]
		},
		{
			"head": "hnobò",
			"letter": "H",
			"gloss": "bladder (careful, one accent off from hnóbô)",
			"forms": [],
			"examples": []
		},
		{
			"head": "hosò",
			"letter": "H",
			"gloss": "heart",
			"forms": [],
			"examples": []
		},
		{
			"head": "htolo",
			"letter": "H",
			"gloss": "curse; what you say when something gets in the way of what was still going on, like \"dammit\"",
			"forms": [],
			"examples": []
		},
		{
			"head": "hulô",
			"letter": "H",
			"gloss": "red",
			"forms": [{
				"form": "Utón hulô mata",
				"gloss": "red-eye fish"
			}],
			"examples": []
		},
		{
			"head": "hyu",
			"letter": "H",
			"gloss": "good",
			"forms": [
				{
					"form": "Hyu hlafus",
					"gloss": "good morning"
				},
				{
					"form": "Hyu kifu",
					"gloss": "good night (more like good evening)"
				},
				{
					"form": "Hyu se yó",
					"gloss": "that's good (hyu good, se is, yó that)"
				},
				{
					"form": "Hyu yó msó",
					"gloss": "that rice is good"
				}
			],
			"examples": []
		},
		{
			"head": "hólólen",
			"letter": "H",
			"gloss": "his/her hands",
			"forms": [],
			"examples": []
		},
		{
			"head": "ilung",
			"letter": "I",
			"gloss": "nose",
			"forms": [],
			"examples": []
		},
		{
			"head": "inget",
			"letter": "I",
			"gloss": "sweat",
			"forms": [{
				"form": "Ninget",
				"gloss": "sweaty"
			}, {
				"form": "Sa inget ganì o",
				"gloss": "I'm all sweat"
			}],
			"examples": []
		},
		{
			"head": "inggit / sélus",
			"letter": "I",
			"gloss": "jealous (borrowed)",
			"forms": [],
			"examples": []
		},
		{
			"head": "itlug",
			"letter": "I",
			"gloss": "egg",
			"forms": [],
			"examples": [{
				"tbl": "Senlahu itlug, kayà meken kuy",
				"en": "I fried eggs, so let's eat"
			}]
		},
		{
			"head": "iwas",
			"letter": "I",
			"gloss": "monkey",
			"forms": [],
			"examples": []
		},
		{
			"head": "iwóng",
			"letter": "I",
			"gloss": "left",
			"forms": [],
			"examples": []
		},
		{
			"head": "kahang",
			"letter": "K",
			"gloss": "spicy (borrowed from Hiligaynon)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kahì",
			"letter": "K",
			"gloss": "salt",
			"forms": [],
			"examples": [{
				"tbl": "Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen",
				"en": "my coffee has salt in it"
			}]
		},
		{
			"head": "kailangan",
			"letter": "K",
			"gloss": "need (borrowed from Tagalog)",
			"forms": [{
				"form": "Kailanganu",
				"gloss": "I need"
			}],
			"examples": [{
				"tbl": "Kailanganu mekay ken.",
				"en": "I need to cook rice."
			}]
		},
		{
			"head": "kambing",
			"letter": "K",
			"gloss": "goat",
			"forms": [],
			"examples": []
		},
		{
			"head": "kaong",
			"letter": "K",
			"gloss": "sugar palm (borrowed from Tagalog). Its fruit hangs in long strings; not the same as aprikan",
			"forms": [],
			"examples": []
		},
		{
			"head": "kapuy",
			"letter": "K",
			"gloss": "tired",
			"forms": [{
				"form": "Kapuye",
				"gloss": "I'm tired"
			}, {
				"form": "Teye kapuy",
				"gloss": "I'm exhausted"
			}],
			"examples": []
		},
		{
			"head": "katay",
			"letter": "K",
			"gloss": "death (katayen, his death)",
			"forms": [],
			"examples": []
		},
		{
			"head": "katri",
			"letter": "K",
			"gloss": "bed",
			"forms": [
				{
					"form": "Katrihu",
					"gloss": "my bed"
				},
				{
					"form": "Katrihem",
					"gloss": "your bed (katri ends in a vowel, so h goes in before -em)"
				},
				{
					"form": "Mógówu bê ta katri kun",
					"gloss": "go to bed"
				}
			],
			"examples": []
		},
		{
			"head": "katù",
			"letter": "K",
			"gloss": "puppy",
			"forms": [],
			"examples": []
		},
		{
			"head": "kay",
			"letter": "K",
			"gloss": "because; so",
			"forms": [
				{
					"form": "Kaye",
					"gloss": "because I; so I (the -e from bitile jumps to kay): Kaye bitil, because I'm hungry"
				},
				{
					"form": "Kaye bemli onuk",
					"gloss": "because I buy chicken"
				},
				{
					"form": "Kay nehe bemli onuk",
					"gloss": "because I will buy chicken (nehe already carries the \"I,\" so kay stays bare)"
				},
				{
					"form": "Kay bitil le / Kay le bitil",
					"gloss": "because they are hungry (both orders work)"
				},
				{
					"form": "Careful",
					"gloss": "Bitile kaye meken means \"I'm hungry because I ate,\" not \"so I'm eating.\" For \"X, so Y,\" use tong"
				}
			],
			"examples": []
		},
		{
			"head": "kayà",
			"letter": "K",
			"gloss": "so, that's why (borrowed from Tagalog)",
			"forms": [],
			"examples": [{
				"tbl": "Meenge, kayà minume o él",
				"en": "I'm thirsty, so I'm drinking water"
			}]
		},
		{
			"head": "kbong",
			"letter": "K",
			"gloss": "big",
			"forms": [
				{
					"form": "Kbong nawa",
					"gloss": "love (literally \"big breath\"; Blaan has a close version, kanbong nawa)"
				},
				{
					"form": "Kbong nawahu kóm",
					"gloss": "my love for you"
				},
				{
					"form": "Kenbong (with -n-)",
					"gloss": "already happening, continuously; kbong is still going"
				},
				{
					"form": "Kenbong nawahu u",
					"gloss": "I love you (literally \"my breath for you is big\": you are their breath)"
				},
				{
					"form": "Kenbong nawahu kóm",
					"gloss": "I love yours"
				}
			],
			"examples": []
		},
		{
			"head": "kdaw",
			"letter": "K",
			"gloss": "sun; day",
			"forms": [{
				"form": "Kdaw ni",
				"gloss": "today (or just Ni when the context makes it clear)"
			}, {
				"form": "Sok kemdaw",
				"gloss": "during the day"
			}],
			"examples": [{
				"tbl": "Hkinì u bê kdaw dé",
				"en": "get yourself heated by the sun"
			}]
		},
		{
			"head": "kdê",
			"letter": "K",
			"gloss": "all (general word)",
			"forms": [
				{
					"form": "Kdéen",
					"gloss": "all of it"
				},
				{
					"form": "Kdéle",
					"gloss": "all of them"
				},
				{
					"form": "Yóm kdéen tau",
					"gloss": "all people, everyone (John 1:4)"
				}
			],
			"examples": [{
				"tbl": "Slamat bê ke-savem du kdéen",
				"en": "thanks for saving all of it"
			}]
		},
		{
			"head": "kdeng",
			"letter": "K",
			"gloss": "later (at the end of a sentence); wait! (on its own at the start)",
			"forms": [
				{
					"form": "Kdeng, hkinìu ken",
					"gloss": "wait, I'll heat up the food"
				},
				{
					"form": "Kdeng! Là o du mò du yó",
					"gloss": "wait! I didn't do that"
				},
				{
					"form": "Kmulón kdeng",
					"gloss": "it's raining again"
				},
				{
					"form": "Moo ktuku kdeng",
					"gloss": "I'll be sleepy later"
				},
				{
					"form": "Bud moo ktuku kdeng",
					"gloss": "I'll be sleepy again"
				},
				{
					"form": "Bud kmulón kdeng",
					"gloss": "it's going to rain again (later)"
				}
			],
			"examples": []
		},
		{
			"head": "ke",
			"letter": "K",
			"gloss": "if; to, for, or, and possession",
			"forms": [
				{
					"form": "Kehe",
					"gloss": "if I; also to be, to become (when it's \"I\")"
				},
				{
					"form": "Kehi",
					"gloss": "you become"
				},
				{
					"form": "Kehu bitil, mekenu",
					"gloss": "if you're hungry, eat"
				},
				{
					"form": "Kehe bitil, ne meken dé",
					"gloss": "if I'm hungry, I'll eat"
				},
				{
					"form": "Ke Dwata",
					"gloss": "to God, or God's"
				},
				{
					"form": "Ke Miles",
					"gloss": "or Miles / Miles' belongings / for Miles"
				},
				{
					"form": "Ke- (on borrowed verbs)",
					"gloss": "if, or for doing it (ke-savem, ke-downloadem, ke-sendem)"
				},
				{
					"form": "Kilón ke / Moen ke",
					"gloss": "ke always follows when and why"
				},
				{
					"form": "Kô ke",
					"gloss": "or, pick one"
				}
			],
			"examples": [{
				"tbl": "Là nóyóu du kehe lehen",
				"en": "I don't want to be skinny"
			}]
		},
		{
			"head": "kebel",
			"letter": "K",
			"gloss": "smoke; also to find (same word, both meanings)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kebtik",
			"letter": "K",
			"gloss": "the waking up (bang kebtik tekuy, time for us to wake up)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kama",
			"letter": "K",
			"gloss": "pillow. Temdanan te kama fi: resting on the pillow (Mark 4:38)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kegnóm",
			"letter": "K",
			"gloss": "feeling; also opinion. Bè kegnómu du: in my opinion (1 Corinthians 7:40). Root gnóm: to feel, go through something. Gemnóm: feeling it. Hol lómón kegnóm ye du: feel it as if it were yours (Hebrews 13:3)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kehlifót",
			"letter": "K",
			"gloss": "to forget on purpose in a good way, to move on; forgiving in the Bible (Matthew 6:12). Compare hlifót (pretend not to know, in a bad way) and klifót (forget, forgot)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kem",
			"letter": "K",
			"gloss": "plural marker before a noun; these",
			"forms": [],
			"examples": []
		},
		{
			"head": "kemdaw",
			"letter": "K",
			"gloss": "noon",
			"forms": [],
			"examples": []
		},
		{
			"head": "kemfô",
			"letter": "K",
			"gloss": "grab, catch hold of",
			"forms": [],
			"examples": []
		},
		{
			"head": "kemgis",
			"letter": "K",
			"gloss": "strong (kgis, strength)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kenleng",
			"letter": "K",
			"gloss": "cut off",
			"forms": [],
			"examples": []
		},
		{
			"head": "kenleng",
			"letter": "K",
			"gloss": "cut off (kenlengem, you cut it off)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kenyak",
			"letter": "K",
			"gloss": "to be shy or ashamed, embarrassed of someone (\"nakakahiya\"). Miles, tey kenyaken Màen: Miles is ashamed of his father. Mô kóm kenyak: your own shame, your own regret",
			"forms": [],
			"examples": []
		},
		{
			"head": "ket",
			"letter": "K",
			"gloss": "enough; every",
			"forms": [
				{
					"form": "Ket tonu kuying bê lan ket knwahu",
					"gloss": "every cat I see in the street, I take"
				},
				{
					"form": "Ket me lwu me. Wen kun, wen sdo",
					"gloss": "we're even. He has his, I have mine"
				},
				{
					"form": "Kem utón",
					"gloss": "fish (more than one)"
				},
				{
					"form": "Kem ngà",
					"gloss": "children"
				},
				{
					"form": "Kem tau",
					"gloss": "people"
				},
				{
					"form": "Kem twolihu",
					"gloss": "my siblings"
				},
				{
					"form": "Kem udél",
					"gloss": "words"
				},
				{
					"form": "Kem dumu bots",
					"gloss": "the other bots"
				}
			],
			"examples": []
		},
		{
			"head": "ken",
			"letter": "K",
			"gloss": "food in general; cooked rice; eat",
			"forms": [
				{
					"form": "Meken / Mken",
					"gloss": "eating, to eat (same word, just said faster)"
				},
				{
					"form": "Henken",
					"gloss": "feeding (someone)"
				},
				{
					"form": "Nehu henken kem kuyingu, kay le bitil",
					"gloss": "I'm going to feed my cats because they're hungry"
				},
				{
					"form": "Hken",
					"gloss": "feed something to something"
				},
				{
					"form": "Hkenu bê wongu ne ni",
					"gloss": "I'm going to feed it to my spider"
				},
				{
					"form": "Mekene",
					"gloss": "I am eating"
				},
				{
					"form": "Mekenu",
					"gloss": "you are eating; also \"eat!\""
				},
				{
					"form": "Meken du",
					"gloss": "he/she/it is eating right now"
				},
				{
					"form": "Meken kuy",
					"gloss": "we are going to eat, let's eat"
				},
				{
					"form": "Kenu",
					"gloss": "I eat (it)"
				},
				{
					"form": "Kenem",
					"gloss": "you eat"
				},
				{
					"form": "Kenen",
					"gloss": "he/she/it eats or ate (general)"
				},
				{
					"form": "Kenle",
					"gloss": "they eat"
				},
				{
					"form": "Kenye",
					"gloss": "you all eat"
				},
				{
					"form": "Kenkuy",
					"gloss": "we eat"
				},
				{
					"form": "Kente",
					"gloss": "just you and me eat"
				},
				{
					"form": "Deng kenu",
					"gloss": "I ate"
				},
				{
					"form": "Denge meken",
					"gloss": "I already ate"
				},
				{
					"form": "Deng ne meken",
					"gloss": "I'm done eating"
				},
				{
					"form": "Meken he (kdeng)",
					"gloss": "I'll eat (later)"
				},
				{
					"form": "Ne meken dé",
					"gloss": "I'm going to eat"
				},
				{
					"form": "Ne meken he dé",
					"gloss": "I'll eat first"
				},
				{
					"form": "Nehe meken",
					"gloss": "I will be eating"
				},
				{
					"form": "Là e deng meken (he)",
					"gloss": "I haven't eaten (yet)"
				},
				{
					"form": "Kken",
					"gloss": "ate together (past)"
				},
				{
					"form": "Henken",
					"gloss": "feed"
				},
				{
					"form": "Henkenu ohu",
					"gloss": "I feed the dog"
				},
				{
					"form": "Hefken",
					"gloss": "wants to be fed"
				},
				{
					"form": "Hefkenu bê ohu",
					"gloss": "I fed it to the dog"
				},
				{
					"form": "Nehu henken kem wongu anay",
					"gloss": "I will feed my spiders first"
				},
				{
					"form": "Hefkene bê ohu",
					"gloss": "I fed myself to the dog"
				},
				{
					"form": "Henken do",
					"gloss": "feed it for me (asking someone to feed something of yours, like your dog)"
				},
				{
					"form": "Henken o",
					"gloss": "feed me"
				},
				{
					"form": "Kenken",
					"gloss": "be fed"
				},
				{
					"form": "Ohu nóyóen ke kenken (du)",
					"gloss": "the dog wants to be fed"
				},
				{
					"form": "Sken",
					"gloss": "eat each other"
				},
				{
					"form": "Senseken",
					"gloss": "eating together (still going)"
				},
				{
					"form": "Ken tnaw",
					"gloss": "leftover rice (literally \"cold rice\")"
				},
				{
					"form": "Mekay ken",
					"gloss": "to cook rice"
				}
			],
			"examples": [{
				"tbl": "Téy mi ken ni",
				"en": "this food is delicious"
			}, {
				"tbl": "Mekenu silà kô ke ken?",
				"en": "are you eating corn or rice?"
			}]
		},
		{
			"head": "ket hilu?",
			"letter": "K",
			"gloss": "how much?",
			"forms": [],
			"examples": []
		},
		{
			"head": "kfi",
			"letter": "K",
			"gloss": "coffee",
			"forms": [],
			"examples": []
		},
		{
			"head": "kfu",
			"letter": "K",
			"gloss": "chest",
			"forms": [],
			"examples": []
		},
		{
			"head": "kfung",
			"letter": "K",
			"gloss": "dry desert sand",
			"forms": [],
			"examples": []
		},
		{
			"head": "kgal",
			"letter": "K",
			"gloss": "shirt, tunic",
			"forms": [],
			"examples": []
		},
		{
			"head": "khahù",
			"letter": "K",
			"gloss": "miss someone, long for someone",
			"forms": [],
			"examples": []
		},
		{
			"head": "kifu",
			"letter": "K",
			"gloss": "night (sok kifu, at night); also dim",
			"forms": [
				{
					"form": "Kekifuhen",
					"gloss": "if it turns dark, when it gets dark (ke + kifu + h + -en)"
				},
				{
					"form": "The ke- + word + ending form usually names an event, \"the time/the way it happened,\" often with yóm in front and a time word. It doesn't work as a plain \"if\" (Kekulónen, ne tungô dé was wrong):",
					"gloss": ""
				},
				{
					"form": "Kmifu",
					"gloss": "getting dark, getting dim; darkness (lem gónón kmifu, in the darkness, John 1:5)"
				},
				{
					"form": "Eginu kifu",
					"gloss": "earlier at night, last night"
				},
				{
					"form": "Hyu kifu",
					"gloss": "good night (more like good evening)"
				}
			],
			"examples": []
		},
		{
			"head": "kihu",
			"letter": "K",
			"gloss": "whoever, whatever",
			"forms": [{
				"form": "Kihu kóm",
				"gloss": "up to you (whatever is yours)"
			}, {
				"form": "Kihu tau hemtahu béléen",
				"gloss": "whoever believes in him (John 3:16)"
			}],
			"examples": []
		},
		{
			"head": "kilil beng",
			"letter": "K",
			"gloss": "side of the backyard",
			"forms": [],
			"examples": []
		},
		{
			"head": "kilón",
			"letter": "K",
			"gloss": "when?",
			"forms": [],
			"examples": [{
				"tbl": "Kilón ke kulékem bê gónô?",
				"en": "when will you get back home?"
			}]
		},
		{
			"head": "kimel",
			"letter": "K",
			"gloss": "afternoon",
			"forms": [],
			"examples": []
		},
		{
			"head": "kimoy",
			"letter": "K",
			"gloss": "withered (a hand)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kinì",
			"letter": "K",
			"gloss": "hot",
			"forms": [
				{
					"form": "Kminì",
					"gloss": "being heated by (something)"
				},
				{
					"form": "Hkinì",
					"gloss": "make hot"
				},
				{
					"form": "Hkinìem ken",
					"gloss": "heat up the food (you do it)"
				},
				{
					"form": "Hkinìu ken",
					"gloss": "I heat the food"
				},
				{
					"form": "Hkinì u bê kdaw dé",
					"gloss": "get yourself heated by the sun"
				},
				{
					"form": "Bon kminì kóm du?",
					"gloss": "what's heating you?"
				}
			],
			"examples": [{
				"tbl": "Coffee-hu kinì",
				"en": "my coffee is hot"
			}]
		},
		{
			"head": "kis-a / tlagsa",
			"letter": "K",
			"gloss": "sometimes (from Hiligaynon)",
			"forms": [],
			"examples": []
		},
		{
			"head": "klamangen",
			"letter": "K",
			"gloss": "it's whole, all of it (géhél nogotem yóm klamangen, Matthew 6:10)",
			"forms": [],
			"examples": []
		},
		{
			"head": "klamay",
			"letter": "K",
			"gloss": "sugar",
			"forms": [],
			"examples": []
		},
		{
			"head": "klifak",
			"letter": "K",
			"gloss": "the base of a palm frond, where the leaf stalk meets the trunk",
			"forms": [],
			"examples": []
		},
		{
			"head": "klifót",
			"letter": "K",
			"gloss": "forget, forgot (by accident)",
			"forms": [],
			"examples": []
		},
		{
			"head": "klingu",
			"letter": "K",
			"gloss": "ear",
			"forms": [],
			"examples": []
		},
		{
			"head": "klung",
			"letter": "K",
			"gloss": "shield",
			"forms": [{
				"form": "Kenlung",
				"gloss": "protect"
			}, {
				"form": "Kenlungem",
				"gloss": "you protect (hol kenlungem mi bè Seitan, protect us from Satan, Matthew 6:13)"
			}],
			"examples": []
		},
		{
			"head": "kmimet",
			"letter": "K",
			"gloss": "when the sun is almost setting",
			"forms": [],
			"examples": []
		},
		{
			"head": "kmatì",
			"letter": "K",
			"gloss": "tomato (confirmed; Matthew 7:16 and Luke 6:44 use it in place of figs/grapes)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kmò",
			"letter": "K",
			"gloss": "how",
			"forms": [
				{
					"form": "Kmou du",
					"gloss": "how am I going to do it? what am I going to do?"
				},
				{
					"form": "Kmou se do(u)",
					"gloss": "how am I? what about me?"
				},
				{
					"form": "Kmou du se?",
					"gloss": "how or what am I supposed to do?"
				},
				{
					"form": "Kmoem du?",
					"gloss": "what or how would you do? what's up to you? also how are you? what's up?"
				},
				{
					"form": "Kmoem se du?",
					"gloss": "how are you?"
				},
				{
					"form": "Kmoem du se?",
					"gloss": "what or how did you do? how would you do it?"
				},
				{
					"form": "Móen",
					"gloss": "short for Kmoem (Teye bitil. Móen skóm? I'm very hungry. How about you?)"
				},
				{
					"form": "Kmoen du?",
					"gloss": "how was it?"
				},
				{
					"form": "Kmoen se du?",
					"gloss": "how is he/she/it?"
				},
				{
					"form": "Kmoen du se du?",
					"gloss": "what or how did he/she/it do (to something)?"
				},
				{
					"form": "Kmò le du?",
					"gloss": "how are they? how did they do it?"
				},
				{
					"form": "Kmò le se lu?",
					"gloss": "how are they?"
				},
				{
					"form": "Kmò le du se?",
					"gloss": "what did they do? how would they do it?"
				},
				{
					"form": "Kmò ye du?",
					"gloss": "how are you all? how did you all do it?"
				},
				{
					"form": "Kmò ye du du?",
					"gloss": "what did you all do to him/her/it?"
				},
				{
					"form": "Kmò ye du se?",
					"gloss": "how would you do it? how did you do it?"
				},
				{
					"form": "Kmò kuy du?",
					"gloss": "what do we do? how about you all?"
				},
				{
					"form": "Kmò kuy du se du?",
					"gloss": "what are we supposed to do to him/her/it?"
				},
				{
					"form": "Kmò kuy?",
					"gloss": "how about you all?"
				},
				{
					"form": "Kmò te du?",
					"gloss": "what about us (you and me)? what do we do?"
				},
				{
					"form": "Kmò me du",
					"gloss": "the same with me (we, not you)"
				},
				{
					"form": "Kmò kmon (du)",
					"gloss": "how to say (it)"
				},
				{
					"form": "Use Kmoem when asking someone directly, Kmoen when it's indirect",
					"gloss": ""
				}
			],
			"examples": []
		},
		{
			"head": "kmoen kun ke...",
			"letter": "K",
			"gloss": "what if...",
			"forms": [{
				"form": "Also said",
				"gloss": "Kmoen kun..., Kmoen kun ke sok..., Kmoen ke sok..."
			}],
			"examples": [{
				"tbl": "Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying?",
				"en": "What if I cook 1,936 fish and feed them to my 127 cats?"
			}]
		},
		{
			"head": "kmuli",
			"letter": "K",
			"gloss": "laughed",
			"forms": [{
				"form": "Tong kmuli du",
				"gloss": "so he/she/it laughed"
			}],
			"examples": []
		},
		{
			"head": "kmustahu du?",
			"letter": "K",
			"gloss": "how are you?",
			"forms": [],
			"examples": []
		},
		{
			"head": "kna",
			"letter": "K",
			"gloss": "dream (knahen, his dream)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kohù / kusina",
			"letter": "K",
			"gloss": "kitchen",
			"forms": [],
			"examples": []
		},
		{
			"head": "kow",
			"letter": "K",
			"gloss": "cough",
			"forms": [],
			"examples": []
		},
		{
			"head": "kti",
			"letter": "K",
			"gloss": "dried up, for water",
			"forms": [],
			"examples": []
		},
		{
			"head": "kuleng",
			"letter": "K",
			"gloss": "cooking pot",
			"forms": [],
			"examples": []
		},
		{
			"head": "kumù",
			"letter": "K",
			"gloss": "blanket",
			"forms": [],
			"examples": []
		},
		{
			"head": "kutsilyu",
			"letter": "K",
			"gloss": "knife (borrowed, from Spanish cuchillo)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kutó nawa",
			"letter": "K",
			"gloss": "hate. Opposite of kenbong nawa (love). Takes the n inside because it lands on someone: **knutó nawa** (hated, hates someone), **kmutó nawa** (hating). **Knutó nawahu u**: I hate you (confirmed by Deymar). Matt 5:43: knutó nawahem yó kem hmohon kóm, you hate your enemy. 1 John 2:9: knutó nawahen yóm dumuhen, he hates his brother",
			"forms": [],
			"examples": []
		},
		{
			"head": "kenbé",
			"letter": "K",
			"gloss": "reject, dislike, deny. **Kenbéu u**: I reject you, I dislike you. Rom 9:13: kenbéu Iso, Esau I rejected. John 3:20: kenbéen yóm layag, he rejects the light",
			"forms": [],
			"examples": []
		},
		{
			"head": "kwanan",
			"letter": "K",
			"gloss": "right (kwananen, his right side)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kwang beng",
			"letter": "K",
			"gloss": "backyard",
			"forms": [],
			"examples": []
		},
		{
			"head": "kô",
			"letter": "K",
			"gloss": "turns a sentence into a yes or no question",
			"forms": [{
				"form": "Tahu kô?",
				"gloss": "is it true? is it right? correct?"
			}, {
				"form": "Kô ke",
				"gloss": "or, when suggesting someone pick one"
			}],
			"examples": [{
				"tbl": "Downloadem kô?",
				"en": "would you download it?"
			}]
		},
		{
			"head": "kodok",
			"letter": "K",
			"gloss": "boil",
			"forms": [
				{
					"form": "Kmodok",
					"gloss": "boiling"
				},
				{
					"form": "Hkodok",
					"gloss": "asking for it to be boiled"
				},
				{
					"form": "Hkodoku",
					"gloss": "I'm boiling it (now or later, depending on context)"
				},
				{
					"form": "Hkodokem",
					"gloss": "you're boiling it"
				},
				{
					"form": "Hkodoke béléem itlug",
					"gloss": "I'll boil an egg for you"
				},
				{
					"form": "Henkodok",
					"gloss": "being boiled"
				},
				{
					"form": "Hefkodok",
					"gloss": "asking someone to boil something (hef- is asking; you hand over your own item)"
				},
				{
					"form": "Hefkodoku béléeu kun él",
					"gloss": "please boil me water (I gave you my item, you do the work)"
				},
				{
					"form": "Hkodoku béléeu kun él",
					"gloss": "please boil me water (I don't have the item, you find it and do it)"
				},
				{
					"form": "Hefkodoku béléem itlug",
					"gloss": "I'm asking you to boil the eggs"
				},
				{
					"form": "Hefkodoke béléem itlug",
					"gloss": "boiling an egg for you"
				},
				{
					"form": "Hefkodoku béléeu itlug",
					"gloss": "please boil an egg for me (my egg, you do the work)"
				},
				{
					"form": "Kmodok él ne / Kmodok ne él",
					"gloss": "the water's boiling now"
				},
				{
					"form": "Él deng kmodok",
					"gloss": "the water is already boiling"
				}
			],
			"examples": []
		},
		{
			"head": "kóm",
			"letter": "K",
			"gloss": "yours, you own; you",
			"forms": [{
				"form": "Kóm du?",
				"gloss": "and you?"
			}, {
				"form": "Kóm ken",
				"gloss": "your food"
			}],
			"examples": [{
				"tbl": "Ou kóm dumu sbót",
				"en": "I'm your friend"
			}]
		},
		{
			"head": "kóyô",
			"letter": "K",
			"gloss": "want, will (kóyô me, we want; yóm kóm kóyô, your will) (Matthew 6:10)",
			"forms": [],
			"examples": []
		},
		{
			"head": "koyu",
			"letter": "K",
			"gloss": "tree, wood (Matthew 7:17)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kudà",
			"letter": "K",
			"gloss": "horse, donkey",
			"forms": [],
			"examples": []
		},
		{
			"head": "kuli",
			"letter": "K",
			"gloss": "laugh",
			"forms": [],
			"examples": []
		},
		{
			"head": "kulit",
			"letter": "K",
			"gloss": "skin",
			"forms": [],
			"examples": []
		},
		{
			"head": "kulón",
			"letter": "K",
			"gloss": "rain",
			"forms": [
				{
					"form": "Kmulón",
					"gloss": "raining, to rain"
				},
				{
					"form": "Knulón",
					"gloss": "(being) rained on"
				},
				{
					"form": "Kmulón ne?",
					"gloss": "is it already raining?"
				},
				{
					"form": "Kmulón ni?",
					"gloss": "is it raining?"
				},
				{
					"form": "Gkulóne",
					"gloss": "I accidentally got rained on"
				},
				{
					"form": "Haya làen kmulón he",
					"gloss": "tomorrow it won't rain yet"
				},
				{
					"form": "Knulóne",
					"gloss": "I got rained on (on purpose)"
				}
			],
			"examples": [{
				"tbl": "Kmulón ne. Tnawu yó.",
				"en": "it's raining now. You'll be cold."
			}, {
				"tbl": "Haya bud kmulón",
				"en": "tomorrow it'll rain again; no kdeng, since haya already says when"
			}]
		},
		{
			"head": "kulu",
			"letter": "K",
			"gloss": "head",
			"forms": [{
				"form": "Kuluhu",
				"gloss": "my head"
			}],
			"examples": []
		},
		{
			"head": "kul",
			"letter": "K",
			"gloss": "they own, theirs; them, the whole group as the object",
			"forms": [
				{
					"form": "Kul yó",
					"gloss": "that's theirs"
				},
				{
					"form": "Khulék kul",
					"gloss": "return them all"
				},
				{
					"form": "Tnógóhu kul",
					"gloss": "I cook theirs"
				},
				{
					"form": "Tnógóhu kul he",
					"gloss": "I'll cook them all (a threat)"
				}
			],
			"examples": []
		},
		{
			"head": "kum",
			"letter": "K",
			"gloss": "we (3 or more) own",
			"forms": [],
			"examples": []
		},
		{
			"head": "kukù",
			"letter": "K",
			"gloss": "kitten",
			"forms": [],
			"examples": []
		},
		{
			"head": "kun",
			"letter": "K",
			"gloss": "he/she/it owns; allegedly; in a request it works as \"please\"",
			"forms": [{
				"form": "Kun él",
				"gloss": "on its own, his/her/its water"
			}],
			"examples": []
		},
		{
			"head": "kut",
			"letter": "K",
			"gloss": "we (me and you) own; ours",
			"forms": [{
				"form": "Kut yó",
				"gloss": "that's ours (me and you, or me and my people)"
			}, {
				"form": "Kut ne yó",
				"gloss": "that's our turn"
			}],
			"examples": []
		},
		{
			"head": "kuy",
			"letter": "K",
			"gloss": "we, us (3 or more); all of us",
			"forms": [
				{
					"form": "Meken kuy",
					"gloss": "let's eat"
				},
				{
					"form": "Kuy yó",
					"gloss": "that's yours; also that's you all"
				},
				{
					"form": "Tnógóhu kuy he",
					"gloss": "I'll cook all of you (a threat)"
				}
			],
			"examples": []
		},
		{
			"head": "kuying",
			"letter": "K",
			"gloss": "cat",
			"forms": [{
				"form": "Kuying bê ta lmisa",
				"gloss": "the cat is on the table"
			}],
			"examples": []
		},
		{
			"head": "kwang",
			"letter": "K",
			"gloss": "back (body)",
			"forms": [],
			"examples": []
		},
		{
			"head": "kyemet",
			"letter": "K",
			"gloss": "fingers",
			"forms": [],
			"examples": []
		},
		{
			"head": "K'nóón",
			"letter": "K",
			"gloss": "very good, very cool, very nice, very beautiful (an earlier lesson wrote it K'nôón, beautiful)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lamang",
			"letter": "L",
			"gloss": "wide",
			"forms": [],
			"examples": []
		},
		{
			"head": "lana",
			"letter": "L",
			"gloss": "lost, gone. Lana béléen: he lost it, it's gone from him",
			"forms": [],
			"examples": []
		},
		{
			"head": "lapis",
			"letter": "L",
			"gloss": "pen",
			"forms": [],
			"examples": []
		},
		{
			"head": "lebwón",
			"letter": "L",
			"gloss": "water jar, water pot",
			"forms": [],
			"examples": []
		},
		{
			"head": "legen",
			"letter": "L",
			"gloss": "long, for time (kegenen, how long)",
			"forms": [],
			"examples": []
		},
		{
			"head": "leteng",
			"letter": "L",
			"gloss": "messy, tangled plants on the ground; also a very toxic plant that makes you itchy if it touches you. Stands in for \"thistle\" in Matthew 7:16 and Luke 6:44",
			"forms": [],
			"examples": []
		},
		{
			"head": "lemnaw",
			"letter": "L",
			"gloss": "green; vegetables",
			"forms": [],
			"examples": []
		},
		{
			"head": "lewà",
			"letter": "L",
			"gloss": "outside (bè lewà, out there)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lmaan",
			"letter": "L",
			"gloss": "light, not heavy",
			"forms": [],
			"examples": []
		},
		{
			"head": "lumaken",
			"letter": "L",
			"gloss": "its sheath",
			"forms": [],
			"examples": []
		},
		{
			"head": "lfò",
			"letter": "L",
			"gloss": "coconut, coconut palm",
			"forms": [],
			"examples": []
		},
		{
			"head": "lungkà",
			"letter": "L",
			"gloss": "open (lemungkà, opening it; lenungkà, opened it)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lungkà",
			"letter": "L",
			"gloss": "open something (lemungkà, opening it; lenungkà, opened it)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lunog",
			"letter": "L",
			"gloss": "weak",
			"forms": [],
			"examples": []
		},
		{
			"head": "là",
			"letter": "L",
			"gloss": "no (general); not",
			"forms": [
				{
					"form": "Làe / Là e",
					"gloss": "I am not (literally \"no I\")"
				},
				{
					"form": "Làu / Là u",
					"gloss": "you are not"
				},
				{
					"form": "Lài",
					"gloss": "you (the one specific person I'm talking to) are not"
				},
				{
					"form": "Làen",
					"gloss": "he/she/it is not"
				},
				{
					"form": "Là le",
					"gloss": "they are not"
				},
				{
					"form": "Là te",
					"gloss": "we (you and me) are not"
				},
				{
					"form": "Là ye",
					"gloss": "you all are not"
				},
				{
					"form": "Là kuy",
					"gloss": "we all are not"
				},
				{
					"form": "Là me",
					"gloss": "we are not (not counting the person I'm talking to)"
				},
				{
					"form": "Là du du",
					"gloss": "he/she/it did not (do something)"
				},
				{
					"form": "Là du",
					"gloss": "never mind; nothing much"
				},
				{
					"form": "Là sdu",
					"gloss": "of course not"
				},
				{
					"form": "Làen dù (andù)",
					"gloss": "no one"
				},
				{
					"form": "Là o du se / Là ou du (se)",
					"gloss": "it's not me (when someone accuses you)"
				},
				{
					"form": "Là o du mò du yó",
					"gloss": "I didn't do that"
				},
				{
					"form": "Là ou du mò du yó",
					"gloss": "I'm not the one who did that"
				}
			],
			"examples": [{
				"tbl": "Là e deng meken he",
				"en": "I haven't eaten yet"
			}]
		},
		{
			"head": "laan",
			"letter": "L",
			"gloss": "under; also \"before\" in time",
			"forms": [
				{
					"form": "Laanen",
					"gloss": "underneath it, her or him (-en is it/him/her)"
				},
				{
					"form": "Laanu",
					"gloss": "underneath me; laanem: underneath you"
				},
				{
					"form": "Gu laanen",
					"gloss": "before it (literally from underneath it)"
				},
				{
					"form": "Laan lmisa",
					"gloss": "under the table"
				},
				{
					"form": "Bê laan",
					"gloss": "underneath (something)"
				}
			],
			"examples": []
		},
		{
			"head": "lan",
			"letter": "L",
			"gloss": "way, road",
			"forms": [],
			"examples": [{
				"tbl": "Tey sidek lan yó mulék bê gónô",
				"en": "that is a very bad way to get back home"
			}]
		},
		{
			"head": "lanaw",
			"letter": "L",
			"gloss": "lake (Lanaw Galili, Sea of Galilee)",
			"forms": [],
			"examples": []
		},
		{
			"head": "latu",
			"letter": "L",
			"gloss": "hundreds",
			"forms": [{
				"form": "Lmatu (Sotu latu)",
				"gloss": "one hundred"
			}, {
				"form": "Lwu latu",
				"gloss": "200"
			}],
			"examples": []
		},
		{
			"head": "layag",
			"letter": "L",
			"gloss": "light",
			"forms": [{
				"form": "Lmayag",
				"gloss": "bright"
			}, {
				"form": "Lemayag",
				"gloss": "shining, giving light; hlayag: lighting up (John 1:4-5)"
			}],
			"examples": []
		},
		{
			"head": "lehen",
			"letter": "L",
			"gloss": "skinny",
			"forms": [],
			"examples": []
		},
		{
			"head": "lem",
			"letter": "L",
			"gloss": "inside",
			"forms": [{
				"form": "Lemmen",
				"gloss": "inside of something or someone"
			}, {
				"form": "Bê lem",
				"gloss": "inside"
			}],
			"examples": [{
				"tbl": "Coffee-hu wen klamay nô lemmen",
				"en": "my coffee has sugar in it"
			}]
		},
		{
			"head": "lembak",
			"letter": "L",
			"gloss": "mouth",
			"forms": [{
				"form": "Bolok lembak!",
				"gloss": "(cuss) rotten mouth"
			}],
			"examples": []
		},
		{
			"head": "lemwót",
			"letter": "L",
			"gloss": "going; coming from",
			"forms": [
				{
					"form": "Lemwótu bê él?",
					"gloss": "are you from the water?"
				},
				{
					"form": "Gónôem lemwót du?",
					"gloss": "where are you from?"
				},
				{
					"form": "Lemwót te?",
					"gloss": "are we going?"
				},
				{
					"form": "Lemwót te ne?",
					"gloss": "are we going now/already?"
				},
				{
					"form": "Lemwót ye ne?",
					"gloss": "are you all going now/already?"
				},
				{
					"form": "Lemwót tu?",
					"gloss": "are you going?"
				},
				{
					"form": "Lemwót le?",
					"gloss": "are they going?"
				},
				{
					"form": "Lemwót kuy?",
					"gloss": "are we going? (all of us, me included)"
				}
			],
			"examples": []
		},
		{
			"head": "len",
			"letter": "L",
			"gloss": "just",
			"forms": [{
				"form": "Anduen. Len myón.",
				"gloss": "nothing, just sitting"
			}],
			"examples": []
		},
		{
			"head": "lemnok",
			"letter": "L",
			"gloss": "growing",
			"forms": [],
			"examples": []
		},
		{
			"head": "lengel",
			"letter": "L",
			"gloss": "drunk",
			"forms": [],
			"examples": [{
				"tbl": "Kay wen tau lengel tungô laan lmisa",
				"en": "because there's a drunk guy sleeping under the table"
			}]
		},
		{
			"head": "lenibun",
			"letter": "L",
			"gloss": "what you call a girl or woman, like \"daughter\" (Luke 8:48)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lenos",
			"letter": "L",
			"gloss": "wind",
			"forms": [],
			"examples": []
		},
		{
			"head": "lewók",
			"letter": "L",
			"gloss": "waves",
			"forms": [],
			"examples": []
		},
		{
			"head": "libu",
			"letter": "L",
			"gloss": "thousands",
			"forms": [{
				"form": "Lmibu (Sotu libu)",
				"gloss": "one thousand"
			}],
			"examples": []
		},
		{
			"head": "libun",
			"letter": "L",
			"gloss": "female",
			"forms": [{
				"form": "Tau libun",
				"gloss": "woman"
			}, {
				"form": "Libun",
				"gloss": "girl"
			}],
			"examples": []
		},
		{
			"head": "lihol",
			"letter": "L",
			"gloss": "neck",
			"forms": [],
			"examples": []
		},
		{
			"head": "likò / likô",
			"letter": "L",
			"gloss": "afraid, scared (both spellings appear in the lessons)",
			"forms": [{
				"form": "Likoe",
				"gloss": "I'm afraid"
			}],
			"examples": [{
				"tbl": "Là e likô (bê) wong (I'm not scared",
				"en": "of) spiders"
			}, {
				"tbl": "Ngà laen likò bê wong",
				"en": "the child isn't scared of the spider"
			}]
		},
		{
			"head": "limu",
			"letter": "L",
			"gloss": "five",
			"forms": [],
			"examples": []
		},
		{
			"head": "lingón",
			"letter": "L",
			"gloss": "song",
			"forms": [],
			"examples": []
		},
		{
			"head": "litô",
			"letter": "L",
			"gloss": "blood",
			"forms": [],
			"examples": []
		},
		{
			"head": "lmangat",
			"letter": "L",
			"gloss": "screamed",
			"forms": [{
				"form": "Tongu lmangat",
				"gloss": "so you screamed"
			}],
			"examples": []
		},
		{
			"head": "lmisa",
			"letter": "L",
			"gloss": "table",
			"forms": [{
				"form": "Bê ta lmisa",
				"gloss": "on top of the table"
			}],
			"examples": []
		},
		{
			"head": "lmiteg",
			"letter": "L",
			"gloss": "tired (the more T'boli way to say it)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lnos",
			"letter": "L",
			"gloss": "wind",
			"forms": [],
			"examples": []
		},
		{
			"head": "lobun",
			"letter": "L",
			"gloss": "cloud",
			"forms": [{
				"form": "Lmobun",
				"gloss": "cloudy, getting cloudy"
			}, {
				"form": "Kdaw lmobun",
				"gloss": "a cloudy day"
			}],
			"examples": [{
				"tbl": "Kdaw ni, Denlag tey lmobun",
				"en": "tonight Denlag is very cloudy"
			}]
		},
		{
			"head": "là mebtesen",
			"letter": "L",
			"gloss": "cheap, literally \"not expensive\"",
			"forms": [],
			"examples": []
		},
		{
			"head": "lóbô",
			"letter": "L",
			"gloss": "angry (in general)",
			"forms": [{
				"form": "Hlóbô",
				"gloss": "angry, mad"
			}, {
				"form": "Hnóbô",
				"gloss": "scold, get angry at someone (not hnobò, bladder)"
			}],
			"examples": [{
				"tbl": "Ominen bud hlóbô mton do meken",
				"en": "he'll get mad again if he sees me eating"
			}]
		},
		{
			"head": "logi",
			"letter": "L",
			"gloss": "male",
			"forms": [{
				"form": "Tau logi",
				"gloss": "man"
			}, {
				"form": "Logi",
				"gloss": "boy"
			}],
			"examples": []
		},
		{
			"head": "lohok",
			"letter": "L",
			"gloss": "beside",
			"forms": [{
				"form": "Bê lohok",
				"gloss": "beside"
			}],
			"examples": []
		},
		{
			"head": "lomi",
			"letter": "L",
			"gloss": "new",
			"forms": [{
				"form": "Lomi kesfasad",
				"gloss": "new covenant"
			}],
			"examples": []
		},
		{
			"head": "lomon",
			"letter": "L",
			"gloss": "(also lómón): it's like",
			"forms": [{
				"form": "Mlóy du lómón ke ohu",
				"gloss": "he runs like a dog"
			}, {
				"form": "Ke làen mlan béléem, làen lomon ni se ke t'ngónu T'boli",
				"gloss": "if it weren't for you, I wouldn't know T'boli like this"
			}],
			"examples": []
		},
		{
			"head": "longit",
			"letter": "L",
			"gloss": "heaven, sky (bè longit, in heaven)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lómón ke",
			"letter": "L",
			"gloss": "like, as (lómón ke bnes, like grass)",
			"forms": [],
			"examples": []
		},
		{
			"head": "lóngón",
			"letter": "L",
			"gloss": "need, have to; also worry. **Lnóngóu**: I have to, I worry about (something)",
			"forms": [{
				"form": "Lnóngón",
				"gloss": "to need (to)"
			}],
			"examples": [{
				"tbl": "Lwu folò fat utón lnóngón",
				"en": "24 fish are needed"
			}, {
				"tbl": "Lnóngón kuy kebel kuy dumu lan",
				"en": "we need to find another way"
			}]
		},
		{
			"head": "lówóhu",
			"letter": "L",
			"gloss": "my body",
			"forms": [{
				"form": "Lówóhem",
				"gloss": "your body"
			}],
			"examples": []
		},
		{
			"head": "lték",
			"letter": "L",
			"gloss": "thunder",
			"forms": [],
			"examples": []
		},
		{
			"head": "lu",
			"letter": "L",
			"gloss": "them",
			"forms": [{
				"form": "Lu yó",
				"gloss": "that's them"
			}],
			"examples": []
		},
		{
			"head": "lwu",
			"letter": "L",
			"gloss": "two",
			"forms": [{
				"form": "Lwu te yó",
				"gloss": "that's the two of us"
			}],
			"examples": []
		},
		{
			"head": "msó",
			"letter": "M",
			"gloss": "rice; also to count. Nsóhem kun msó: count the rice, please. Wót Miles nsóhen msó: Miles was counting rice (back then, still going). Wót Miles msó msó: Miles counted rice (telling someone). Msó nsó Miles: the rice was counted by Miles",
			"forms": [],
			"examples": []
		},
		{
			"head": "ma / mwa",
			"letter": "M",
			"gloss": "take",
			"forms": [
				{
					"form": "Ma / Gemwa",
					"gloss": "to get"
				},
				{
					"form": "Nwa",
					"gloss": "taken; get (nwahu, I get)"
				},
				{
					"form": "Gwa",
					"gloss": "get; accidentally taken"
				},
				{
					"form": "Swa",
					"gloss": "taking from each other"
				}
			],
			"examples": [{
				"tbl": "Anì(e) gemwa [lówóhu] unged wen",
				"en": "so I can get more muscle"
			}]
		},
		{
			"head": "madal",
			"letter": "M",
			"gloss": "dance",
			"forms": [],
			"examples": []
		},
		{
			"head": "mahi du",
			"letter": "M",
			"gloss": "which one",
			"forms": [],
			"examples": []
		},
		{
			"head": "matay",
			"letter": "M",
			"gloss": "die, dead",
			"forms": [],
			"examples": []
		},
		{
			"head": "mayuk",
			"letter": "M",
			"gloss": "far (keslayuk, distance)",
			"forms": [],
			"examples": []
		},
		{
			"head": "mdà",
			"letter": "M",
			"gloss": "stand, standing",
			"forms": [],
			"examples": []
		},
		{
			"head": "mdóm",
			"letter": "M",
			"gloss": "borrow",
			"forms": [],
			"examples": []
		},
		{
			"head": "mebtes",
			"letter": "M",
			"gloss": "expensive, valuable (alì mebtes, very expensive)",
			"forms": [],
			"examples": []
		},
		{
			"head": "menes",
			"letter": "M",
			"gloss": "wilted (plants)",
			"forms": [],
			"examples": []
		},
		{
			"head": "menwu",
			"letter": "M",
			"gloss": "living somewhere (from benwu)",
			"forms": [],
			"examples": []
		},
		{
			"head": "mit",
			"letter": "M",
			"gloss": "carry, take",
			"forms": [],
			"examples": []
		},
		{
			"head": "mit edini",
			"letter": "M",
			"gloss": "bring here (nit, nwit, brought)",
			"forms": [],
			"examples": []
		},
		{
			"head": "mkaf",
			"letter": "M",
			"gloss": "climb",
			"forms": [],
			"examples": []
		},
		{
			"head": "mkik",
			"letter": "M",
			"gloss": "cry, weep",
			"forms": [],
			"examples": []
		},
		{
			"head": "mnagaw",
			"letter": "M",
			"gloss": "steal. Tau mnagaw: thief. Knagaw: stealing",
			"forms": [],
			"examples": []
		},
		{
			"head": "mni",
			"letter": "M",
			"gloss": "to ask for something, request (Mnihe seflifót béléem, I ask you forgiveness) Ends in a vowel? Add h before e for I: Lomihe, Mnihe.",
			"forms": [],
			"examples": []
		},
		{
			"head": "moni",
			"letter": "M",
			"gloss": "near",
			"forms": [],
			"examples": []
		},
		{
			"head": "mouf",
			"letter": "M",
			"gloss": "wash your face",
			"forms": [],
			"examples": []
		},
		{
			"head": "mouf",
			"letter": "M",
			"gloss": "wash your face",
			"forms": [],
			"examples": []
		},
		{
			"head": "mudél",
			"letter": "M",
			"gloss": "speak (from udél, word)",
			"forms": [],
			"examples": []
		},
		{
			"head": "myak",
			"letter": "M",
			"gloss": "being shy. Myak du: she's shy",
			"forms": [],
			"examples": []
		},
		{
			"head": "myón",
			"letter": "M",
			"gloss": "sitting (myón tahen, sitting on it)",
			"forms": [],
			"examples": []
		},
		{
			"head": "mà",
			"letter": "M",
			"gloss": "father",
			"forms": [{
				"form": "Mà me bè longit",
				"gloss": "our Father in heaven (Matthew 6:9)"
			}],
			"examples": []
		},
		{
			"head": "mabù",
			"letter": "M",
			"gloss": "fat",
			"forms": [],
			"examples": []
		},
		{
			"head": "maistru / mestlu",
			"letter": "M",
			"gloss": "teacher (borrowed from Spanish maestro; mestlu is how it's actually said)",
			"forms": [{
				"form": "Deymar Mestlu / Mestlu Deymar",
				"gloss": "both work. The first is like \"Deymar the teacher\", the second like \"Teacher Deymar\", a title"
			}, {
				"form": "Tau tmolok",
				"gloss": "a person who teaches"
			}],
			"examples": []
		},
		{
			"head": "mala",
			"letter": "M",
			"gloss": "spicy",
			"forms": [],
			"examples": []
		},
		{
			"head": "man",
			"letter": "M",
			"gloss": "prince (a title)",
			"forms": [],
			"examples": []
		},
		{
			"head": "mang",
			"letter": "M",
			"gloss": "mama",
			"forms": [],
			"examples": []
		},
		{
			"head": "masa",
			"letter": "M",
			"gloss": "read",
			"forms": [],
			"examples": []
		},
		{
			"head": "mata",
			"letter": "M",
			"gloss": "eye",
			"forms": [{
				"form": "Matahu",
				"gloss": "my eyes"
			}, {
				"form": "The color goes before mata",
				"gloss": "Tnógóu lu kô ni utón hulô mata? (should I cook this red-eye fish?)"
			}],
			"examples": []
		},
		{
			"head": "me",
			"letter": "M",
			"gloss": "we, I'm part of it but the person I'm talking to isn't (see the three kinds of \"we\")",
			"forms": [],
			"examples": [{
				"tbl": "Tmógó me utón",
				"en": "we're cooking fish, not you"
			}]
		},
		{
			"head": "meeng",
			"letter": "M",
			"gloss": "thirsty",
			"forms": [{
				"form": "Meenge",
				"gloss": "I'm thirsty"
			}],
			"examples": [{
				"tbl": "Soke meeng, minume él",
				"en": "when I'm thirsty, I drink water"
			}]
		},
		{
			"head": "mekay",
			"letter": "M",
			"gloss": "to lift something",
			"forms": [{
				"form": "Mekay ken",
				"gloss": "to cook rice (literally lifting the rice)"
			}],
			"examples": []
		},
		{
			"head": "mekô",
			"letter": "M",
			"gloss": "really? huh? (kô plus surprise, at the end of a question). Làu bud tungô ne mekô?: you're not going back to sleep, huh?",
			"forms": [{
				"form": "Tôu tungô mekô?",
				"gloss": "you're going to sleep, really?"
			}],
			"examples": []
		},
		{
			"head": "mfól",
			"letter": "M",
			"gloss": "thick",
			"forms": [{
				"form": "Mfól sumóng!",
				"gloss": "(cuss) thick lips"
			}, {
				"form": "Mfól dilak!",
				"gloss": "(cuss) thick tongue"
			}],
			"examples": []
		},
		{
			"head": "mgel",
			"letter": "M",
			"gloss": "hard",
			"forms": [],
			"examples": []
		},
		{
			"head": "mi",
			"letter": "M",
			"gloss": "sweet",
			"forms": [{
				"form": "Téy mi",
				"gloss": "delicious (literally \"very sweet\")"
			}],
			"examples": []
		},
		{
			"head": "mi",
			"letter": "M",
			"gloss": "us, we (I'm included but not the person I'm talking to); sounds exactly like mi, sweet",
			"forms": [{
				"form": "Mi kem mag-cousin",
				"gloss": "us cousins (not counting you)"
			}, {
				"form": "Tu mi",
				"gloss": "there we are; that's us (to people who aren't part of it)"
			}],
			"examples": []
		},
		{
			"head": "minum",
			"letter": "M",
			"gloss": "drink (still happening)",
			"forms": [
				{
					"form": "Ninum",
					"gloss": "drunk by something"
				},
				{
					"form": "Minume",
					"gloss": "I'm drinking or we're drinking, depending on context"
				},
				{
					"form": "Minume o él",
					"gloss": "I was drinking water"
				},
				{
					"form": "Minume mi él",
					"gloss": "we were drinking water"
				},
				{
					"form": "Ninumu él",
					"gloss": "I drank the water"
				},
				{
					"form": "Ninume él",
					"gloss": "we drank the water"
				},
				{
					"form": "Miles ninumen él",
					"gloss": "Miles drank the water"
				},
				{
					"form": "Él ninum Miles",
					"gloss": "the water being drunk by Miles"
				},
				{
					"form": "Él ninumen Miles",
					"gloss": "the water drank Miles"
				}
			],
			"examples": [{
				"tbl": "Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng",
				"en": "I don't want to be skinny, so I'll take my vitamins later"
			}]
		},
		{
			"head": "mlan bê",
			"letter": "M",
			"gloss": "because of (someone or something)",
			"forms": [{
				"form": "Là e deng meken mlan bê Pangu",
				"gloss": "I haven't eaten yet because of my dad"
			}],
			"examples": []
		},
		{
			"head": "mlel",
			"letter": "M",
			"gloss": "flowing",
			"forms": [],
			"examples": []
		},
		{
			"head": "mlóy",
			"letter": "M",
			"gloss": "ran",
			"forms": [{
				"form": "Tong kuy mlóy",
				"gloss": "so we ran"
			}],
			"examples": []
		},
		{
			"head": "mluy",
			"letter": "M",
			"gloss": "tripped, fell and rolled",
			"forms": [{
				"form": "Tong te mluy",
				"gloss": "so we (you and I) tripped, fell and rolled"
			}],
			"examples": []
		},
		{
			"head": "moen",
			"letter": "M",
			"gloss": "why? (its own word, not Móen)",
			"forms": [],
			"examples": [{
				"tbl": "Moen ke là u gtungô du?",
				"en": "why aren't you sleepy yet?"
			}]
		},
		{
			"head": "mékéng",
			"letter": "M",
			"gloss": "dry, dried out (kti: dry up, evaporate, something making it dry)",
			"forms": [{
				"form": "Deng mékéng kilil él",
				"gloss": "the edge of the water is dry"
			}, {
				"form": "Deng kti él",
				"gloss": "the water has evaporated, dried up"
			}],
			"examples": []
		},
		{
			"head": "mélél",
			"letter": "M",
			"gloss": "yellow",
			"forms": [],
			"examples": []
		},
		{
			"head": "mógów",
			"letter": "M",
			"gloss": "walk, walking, walked",
			"forms": [
				{
					"form": "Mógówu bê él? Nehe mógów sdo",
					"gloss": "are you going to the water? I'll go too"
				},
				{
					"form": "Nógów",
					"gloss": "continuously walking"
				},
				{
					"form": "Mógówe",
					"gloss": "I went"
				},
				{
					"form": "Mógówu",
					"gloss": "you went; (you) go there"
				},
				{
					"form": "Nógówem",
					"gloss": "(you) go there"
				},
				{
					"form": "Mógówu bê ta katri kun",
					"gloss": "go to bed (kun makes it a command)"
				},
				{
					"form": "Nógówu u ebuteng",
					"gloss": "I went to you last night"
				},
				{
					"form": "Mógówe béléem ebuteng",
					"gloss": "I went for you last night"
				}
			],
			"examples": []
		},
		{
			"head": "mohin",
			"letter": "M",
			"gloss": "sea, ocean",
			"forms": [],
			"examples": []
		},
		{
			"head": "mon",
			"letter": "M",
			"gloss": "say",
			"forms": [{
				"form": "Kmon",
				"gloss": "mon with the m infix"
			}, {
				"form": "Kmò kmon (du)",
				"gloss": "how to say (it)"
			}],
			"examples": []
		},
		{
			"head": "moo",
			"letter": "M",
			"gloss": "smell",
			"forms": [{
				"form": "Moo ktuk",
				"gloss": "sleepy (literally \"smells sleepy\")"
			}, {
				"form": "Moo ktuku",
				"gloss": "I'm sleepy"
			}],
			"examples": [{
				"tbl": "Moo ktuk wong. Tluyab.",
				"en": "the spider is sleepy. Yawn."
			}]
		},
		{
			"head": "mowil",
			"letter": "M",
			"gloss": "alive",
			"forms": [{
				"form": "Klowil",
				"gloss": "life (John 1:4)"
			}],
			"examples": []
		},
		{
			"head": "msó / mesó",
			"letter": "M",
			"gloss": "rice (uncooked). Msó is the fast way to say mesó. Cooked rice is ken. **Msó** also means count: same spelling, same accent, different meaning.",
			"forms": [{
				"form": "Hyu yó msó",
				"gloss": "that rice is good"
			}],
			"examples": [{
				"tbl": "Tadu se duen mulék bê gónô anì tmógó msó béléu?",
				"en": "who else is going to get home to cook rice for me?"
			}]
		},
		{
			"head": "mwas",
			"letter": "M",
			"gloss": "dawn",
			"forms": [],
			"examples": []
		},
		{
			"head": "myehen",
			"letter": "M",
			"gloss": "to marry (from yehen, spouse)",
			"forms": [],
			"examples": []
		},
		{
			"head": "mólós",
			"letter": "M",
			"gloss": "clean; also pure, holy (là mólósen, dirty)",
			"forms": [],
			"examples": []
		},
		{
			"head": "mólów",
			"letter": "M",
			"gloss": "to step in, calm things down, break up a fight; also correct/rebuke someone. Mólów is the name of the action; in real sentences use bnólów (Ne bnólów lu, I'll step in now; Bnólów kuy lu, let's all step in). Bnólówu lu anì là le sfatay: I stepped in between them so they don't fight",
			"forms": [],
			"examples": []
		},
		{
			"head": "móyóng",
			"letter": "M",
			"gloss": "fly. Hafak: wings",
			"forms": [],
			"examples": []
		},
		{
			"head": "nawa",
			"letter": "N",
			"gloss": "breath, to breathe",
			"forms": [
				{
					"form": "Nawahu",
					"gloss": "my breath (not the same as nwahu, \"I get\")"
				},
				{
					"form": "Kbong nawa",
					"gloss": "love (see kbong)"
				},
				{
					"form": "Kenbong nawahu u",
					"gloss": "I love you"
				},
				{
					"form": "Genléd nawa",
					"gloss": "rely on"
				}
			],
			"examples": []
		},
		{
			"head": "ne",
			"letter": "N",
			"gloss": "now, already, a change happening (like Tagalog \"na\"); about to",
			"forms": [
				{
					"form": "Ne + h + ending",
					"gloss": "ne ends in a vowel, so an h goes in before the ending (ne + -e = nehe, ne + -u = nehu). Endings that start with a consonant don't need it (nele)"
				},
				{
					"form": "Nehe / Ne(he)",
					"gloss": "I will (do something), on your own, no object"
				},
				{
					"form": "Nehu",
					"gloss": "I will do something to something; also telling someone to do something"
				},
				{
					"form": "Nehu bentik u anay",
					"gloss": "I will wake you up later"
				},
				{
					"form": "Nehu bentik dé",
					"gloss": "just get up already"
				},
				{
					"form": "Nehu henken onuku haya",
					"gloss": "I will feed my chickens tomorrow"
				},
				{
					"form": "Nehu meken dé",
					"gloss": "(you) eat first"
				},
				{
					"form": "Nehe meken dé",
					"gloss": "I'm going to eat"
				},
				{
					"form": "Nehe bemli anay",
					"gloss": "I will buy first"
				},
				{
					"form": "Nehe dyó dé",
					"gloss": "I'm going to swim / take a shower"
				},
				{
					"form": "Nehi",
					"gloss": "you will (nehu works too, but it can also mean \"I will\")"
				},
				{
					"form": "Nele",
					"gloss": "they will"
				},
				{
					"form": "Nehi mulék",
					"gloss": "come back first"
				},
				{
					"form": "Ni vs ne",
					"gloss": "ni = right now, ne = already"
				}
			],
			"examples": [{
				"tbl": "Tu ne ni",
				"en": "it's our turn"
			}, {
				"tbl": "Ne meken dé",
				"en": "I'm going to eat"
			}]
		},
		{
			"head": "nebel",
			"letter": "N",
			"gloss": "find",
			"forms": [{
				"form": "Mebel",
				"gloss": "to find"
			}, {
				"form": "Mebel du",
				"gloss": "he/she/it finds (something)"
			}],
			"examples": [{
				"tbl": "Nehe mebel lomi utón bê lwu bulón",
				"en": "I will find new fish in 2 months"
			}]
		},
		{
			"head": "nem",
			"letter": "N",
			"gloss": "six",
			"forms": [],
			"examples": []
		},
		{
			"head": "nes",
			"letter": "N",
			"gloss": "clothes",
			"forms": [{
				"form": "Nesem",
				"gloss": "your clothes"
			}, {
				"form": "Henslòem lemsek du nesem",
				"gloss": "put your clothes on faster"
			}],
			"examples": []
		},
		{
			"head": "ngà",
			"letter": "N",
			"gloss": "child, kid, son, daughter, offspring, baby (ngà libun, daughter; ngà logi, son)",
			"forms": [
				{
					"form": "Ngaen",
					"gloss": "his/her child (the accent drops when an ending is attached)"
				},
				{
					"form": "Ngaen tek sotu",
					"gloss": "his only child"
				},
				{
					"form": "Kem ngà",
					"gloss": "children"
				}
			],
			"examples": []
		},
		{
			"head": "ngà libun",
			"letter": "N",
			"gloss": "daughter",
			"forms": [],
			"examples": []
		},
		{
			"head": "ngà logi",
			"letter": "N",
			"gloss": "son",
			"forms": [],
			"examples": []
		},
		{
			"head": "ngunte",
			"letter": "N",
			"gloss": "I don't know (general, straightforward, the quick shrug; Là t'ngónu is the full \"I don't know it\")",
			"forms": [],
			"examples": []
		},
		{
			"head": "ni",
			"letter": "N",
			"gloss": "it, this; here's; right now; at the end, points to something right here",
			"forms": [
				{
					"form": "Nìen",
					"gloss": "this one, it (ni plus -en)"
				},
				{
					"form": "Kdaw ni / Ni",
					"gloss": "today"
				},
				{
					"form": "Sotu ni",
					"gloss": "the day after tomorrow"
				}
			],
			"examples": [{
				"tbl": "Kehu bitil, ni ken para béléem",
				"en": "if you're hungry, here's food for you"
			}]
		},
		{
			"head": "nihi",
			"letter": "N",
			"gloss": "tooth, teeth (written ngihi in Matthew 5:38)",
			"forms": [],
			"examples": []
		},
		{
			"head": "nitem",
			"letter": "N",
			"gloss": "carry, bring it (you). Nitem do kun sélfónu: carry my phone, please",
			"forms": [],
			"examples": []
		},
		{
			"head": "nmò",
			"letter": "N",
			"gloss": "work (mò nmò, go to work)",
			"forms": [],
			"examples": []
		},
		{
			"head": "nô",
			"letter": "N",
			"gloss": "where?; also the \"is\" for where something is",
			"forms": [{
				"form": "Nô (bê)?",
				"gloss": "at, on, in, or to where?"
			}, {
				"form": "Nô (se)?",
				"gloss": "where is it?"
			}],
			"examples": [{
				"tbl": "Coffee-hu nô bê ta lmisa",
				"en": "my coffee is on the table"
			}]
		},
		{
			"head": "nogot",
			"letter": "N",
			"gloss": "hold",
			"forms": [{
				"form": "Nogotem",
				"gloss": "you hold"
			}],
			"examples": []
		},
		{
			"head": "nóm",
			"letter": "N",
			"gloss": "taste",
			"forms": [{
				"form": "Mnóm",
				"gloss": "tasty"
			}, {
				"form": "Tey mnóm",
				"gloss": "delicious"
			}],
			"examples": [{
				"tbl": "Utón nìen, téy mnóm!",
				"en": "this fish, it's very tasty!"
			}]
		},
		{
			"head": "nóyó / nóyô",
			"letter": "N",
			"gloss": "want; like; liked, loved",
			"forms": [
				{
					"form": "Nóyóu meken",
					"gloss": "I want to eat, I like to eat"
				},
				{
					"form": "Nóyóu meken du",
					"gloss": "I want to eat it/him/her"
				},
				{
					"form": "Nóyóu wong htò",
					"gloss": "I like jumping spiders"
				},
				{
					"form": "Nóyóu",
					"gloss": "I want (to)"
				},
				{
					"form": "Là nóyóu (du)",
					"gloss": "I don't want (to)"
				},
				{
					"form": "Nóyóe",
					"gloss": "I am liked"
				},
				{
					"form": "Nóyóu u / Nóyô te u",
					"gloss": "I like you"
				},
				{
					"form": "Nóyóte u",
					"gloss": "I like you (the poetic way)"
				}
			],
			"examples": [{
				"tbl": "Là nóyóu du ke-delete du",
				"en": "I don't want to delete it"
			}]
		},
		{
			"head": "o / ou",
			"letter": "O",
			"gloss": "me, I (ou is specifically me)",
			"forms": [{
				"form": "O yó",
				"gloss": "that's me"
			}, {
				"form": "Ou yó",
				"gloss": "that's me, specifically me"
			}],
			"examples": []
		},
		{
			"head": "o",
			"letter": "O",
			"gloss": "or (borrowed from English)",
			"forms": [],
			"examples": []
		},
		{
			"head": "ofi",
			"letter": "O",
			"gloss": "fire",
			"forms": [],
			"examples": []
		},
		{
			"head": "ohu",
			"letter": "O",
			"gloss": "dog",
			"forms": [
				{
					"form": "Mlóy du lómón ke ohu",
					"gloss": "he runs like a dog"
				},
				{
					"form": "Tô kay ohu du",
					"gloss": "he looks like a dog"
				},
				{
					"form": "Skél le ohu",
					"gloss": "he and the dog are the same (skél le, they are the same)"
				},
				{
					"form": "Skél du ohu",
					"gloss": "the dog looks like him"
				}
			],
			"examples": []
		},
		{
			"head": "ok ye néen / ok néen",
			"letter": "O",
			"gloss": "I'm fine",
			"forms": [],
			"examples": []
		},
		{
			"head": "okóm",
			"letter": "O",
			"gloss": "but",
			"forms": [{
				"form": "Okóm close",
				"gloss": "but close"
			}],
			"examples": []
		},
		{
			"head": "olob",
			"letter": "O",
			"gloss": "wash (molob, washing hands, feet or things; nolob, washed; molob tdok, wash hands)",
			"forms": [],
			"examples": []
		},
		{
			"head": "olob",
			"letter": "O",
			"gloss": "wash (molob, washing; nolob, washed). Molob tdok: wash hands",
			"forms": [],
			"examples": []
		},
		{
			"head": "olohu",
			"letter": "O",
			"gloss": "I'm just",
			"forms": [
				{
					"form": "Olohem",
					"gloss": "you are just"
				},
				{
					"form": "Olohen",
					"gloss": "it's just"
				},
				{
					"form": "Olohu hlowon néen",
					"gloss": "I'm just joking"
				}
			],
			"examples": [{
				"tbl": "Là, olohen kulón udì",
				"en": "no, just a little rain"
			}]
		},
		{
			"head": "omin",
			"letter": "O",
			"gloss": "and",
			"forms": [{
				"form": "Ominen",
				"gloss": "and maybe he/she/it"
			}, {
				"form": "Ominem dé",
				"gloss": "you're welcome"
			}],
			"examples": []
		},
		{
			"head": "onuk",
			"letter": "O",
			"gloss": "chicken",
			"forms": [{
				"form": "Onuku",
				"gloss": "my chickens"
			}],
			"examples": []
		},
		{
			"head": "onuk koyu",
			"letter": "O",
			"gloss": "bird, literally tree chicken",
			"forms": [],
			"examples": []
		},
		{
			"head": "ówóng",
			"letter": "O",
			"gloss": "boat; also airplane",
			"forms": [],
			"examples": []
		},
		{
			"head": "pang",
			"letter": "P",
			"gloss": "dad, papa",
			"forms": [{
				"form": "Pangu",
				"gloss": "my dad"
			}],
			"examples": []
		},
		{
			"head": "para",
			"letter": "P",
			"gloss": "for (borrowed from Spanish)",
			"forms": [{
				"form": "Para bê",
				"gloss": "for something or someone (being given to them): Ken para bê kem ngà, food for the children"
			}, {
				"form": "Para béléem",
				"gloss": "for you"
			}],
			"examples": []
		},
		{
			"head": "péro",
			"letter": "P",
			"gloss": "but (borrowed from Spanish)",
			"forms": [],
			"examples": []
		},
		{
			"head": "pnahón",
			"letter": "P",
			"gloss": "weather",
			"forms": [],
			"examples": []
		},
		{
			"head": "sa",
			"letter": "S",
			"gloss": "pure, all",
			"forms": [{
				"form": "Sa mata etahu",
				"gloss": "all eyes on me"
			}, {
				"form": "Sa inget ganì o",
				"gloss": "I'm all sweat"
			}],
			"examples": []
		},
		{
			"head": "sabad",
			"letter": "S",
			"gloss": "annoying",
			"forms": [{
				"form": "Téyu sabad u",
				"gloss": "you're annoying"
			}],
			"examples": []
		},
		{
			"head": "safì",
			"letter": "S",
			"gloss": "cow, ox (ngà safì, calf)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sala",
			"letter": "S",
			"gloss": "nest (not salà, sin; the accent changes the word)",
			"forms": [],
			"examples": []
		},
		{
			"head": "salà",
			"letter": "S",
			"gloss": "sin, wrong (kem salà me, our sins); gemsalà: who wronged",
			"forms": [],
			"examples": []
		},
		{
			"head": "salig",
			"letter": "S",
			"gloss": "trust",
			"forms": [
				{
					"form": "Ksalig",
					"gloss": "to trust"
				},
				{
					"form": "Gsalig",
					"gloss": "unintentionally trust"
				},
				{
					"form": "Hsalig",
					"gloss": "letting something trust something"
				},
				{
					"form": "Snalig",
					"gloss": "trust that's actively happening (salig with the -n- infix)"
				},
				{
					"form": "Ksaligem",
					"gloss": "your trust"
				},
				{
					"form": "Ksaligu ke Dwata",
					"gloss": "the trust I have for God"
				},
				{
					"form": "Snaligu Dwata",
					"gloss": "I trust in God"
				},
				{
					"form": "Hsaligu kóm ni kdéen",
					"gloss": "I will trust everything to you"
				}
			],
			"examples": []
		},
		{
			"head": "sargér",
			"letter": "S",
			"gloss": "phone charger; also chargér, charger",
			"forms": [],
			"examples": []
		},
		{
			"head": "sawang",
			"letter": "S",
			"gloss": "unmarried (Acts 21:9)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sbót / sebót",
			"letter": "S",
			"gloss": "friend (general word)",
			"forms": [
				{
					"form": "Dumu sbót",
					"gloss": "a friend"
				},
				{
					"form": "Uu dou dumu sbót",
					"gloss": "you are my friend (dou: my)"
				},
				{
					"form": "Ou kóm dumu sbót",
					"gloss": "I'm your friend"
				},
				{
					"form": "Dumuhu sbót",
					"gloss": "my friend (telling someone else)"
				}
			],
			"examples": [{
				"tbl": "Miles omin Deymar sbót le",
				"en": "Miles and Deymar are friends"
			}]
		},
		{
			"head": "sdô",
			"letter": "S",
			"gloss": "pig",
			"forms": [],
			"examples": []
		},
		{
			"head": "se",
			"letter": "S",
			"gloss": "is, am, are (goes in the middle); the \"be\" word for how someone is",
			"forms": [],
			"examples": [{
				"tbl": "Kmoem se du?",
				"en": "how are you?"
			}]
		},
		{
			"head": "sef",
			"letter": "S",
			"gloss": "suck",
			"forms": [
				{
					"form": "Nsef",
					"gloss": "sucked (the n infix for something already done)"
				},
				{
					"form": "Hsef",
					"gloss": "to let someone (not me) suck"
				},
				{
					"form": "Ssef",
					"gloss": "both sucking"
				},
				{
					"form": "Msef",
					"gloss": "sucking"
				},
				{
					"form": "Sensesef",
					"gloss": "sucking together"
				}
			],
			"examples": []
		},
		{
			"head": "seflifót",
			"letter": "S",
			"gloss": "forgiveness given or asked of each other (Deng le seflifót lu lwu le, they already forgave each other)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sek",
			"letter": "S",
			"gloss": "put on, wear (clothes)",
			"forms": [
				{
					"form": "Msek",
					"gloss": "wore, put on"
				},
				{
					"form": "Lemsek",
					"gloss": "putting on"
				},
				{
					"form": "Henslòu msek du swelu eginu hlafus",
					"gloss": "I put my pants on fast earlier this morning"
				}
			],
			"examples": []
		},
		{
			"head": "semngal",
			"letter": "S",
			"gloss": "sing (from sngal, song)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sfangat",
			"letter": "S",
			"gloss": "wait for each other (Sfangat le bê gónô fedyan, they wait for each other at the market)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sfatay",
			"letter": "S",
			"gloss": "fight each other (là le sfatay, so they don't fight)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sfek",
			"letter": "S",
			"gloss": "cut down a tree (senfeken, is cut down)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sfek",
			"letter": "S",
			"gloss": "cut down a tree",
			"forms": [],
			"examples": []
		},
		{
			"head": "simbahan",
			"letter": "S",
			"gloss": "church (borrowed from Tagalog); kem tau hemtahu, the believers",
			"forms": [],
			"examples": []
		},
		{
			"head": "slidut",
			"letter": "S",
			"gloss": "spoon",
			"forms": [],
			"examples": []
		},
		{
			"head": "sngal",
			"letter": "S",
			"gloss": "song (kesngalen, his singing)",
			"forms": [],
			"examples": []
		},
		{
			"head": "snilas",
			"letter": "S",
			"gloss": "slippers (borrowed, like Tagalog tsinelas)",
			"forms": [],
			"examples": []
		},
		{
			"head": "solu",
			"letter": "S",
			"gloss": "front (bè soluhen, in front of him)",
			"forms": [],
			"examples": []
		},
		{
			"head": "ston te kdeng",
			"letter": "S",
			"gloss": "we'll see each other later (Ston te anay is \"we'll see each other first\")",
			"forms": [],
			"examples": []
		},
		{
			"head": "stulón",
			"letter": "S",
			"gloss": "talk together (from tulón, tell)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tulón",
			"letter": "S",
			"gloss": "tell. **Tulónem do**: you told me. Not tnulónem o, which is about being said or talked about (like tnudaen o, he stoned me)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sudeng",
			"letter": "S",
			"gloss": "sword, knife, long blade",
			"forms": [],
			"examples": []
		},
		{
			"head": "sual",
			"letter": "S",
			"gloss": "thorn",
			"forms": [
				{
					"form": "**semual / smual**",
					"gloss": "grows thorns. Ni bulók nien tey alì smual: this flower here has so many thorns"
				},
				{
					"form": "**semnual**",
					"gloss": "grows thorns by itself (koyu semnual, a thorny tree, Matthew 7:16)"
				},
				{
					"form": "**snual**",
					"gloss": "kulitis, spiny amaranth. A thorny weed people cook and eat as a vegetable"
				}
			],
			"examples": []
		},
		{
			"head": "sulat",
			"letter": "S",
			"gloss": "writing, a letter (smulat, writing it; snulat, written; hsulat boluy, sign up)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sulat dwata",
			"letter": "S",
			"gloss": "the Bible, literally \"God's writing\"",
			"forms": [],
			"examples": []
		},
		{
			"head": "syudad",
			"letter": "S",
			"gloss": "city",
			"forms": [],
			"examples": []
		},
		{
			"head": "sélfón",
			"letter": "S",
			"gloss": "cellphone (borrowed, spelled how it sounds)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sélék",
			"letter": "S",
			"gloss": "lips, side to side (corners of the mouth)",
			"forms": [{
				"form": "Bolok sélék!",
				"gloss": "(cuss) rotten lips"
			}],
			"examples": []
		},
		{
			"head": "senla / pritu",
			"letter": "S",
			"gloss": "fry",
			"forms": [{
				"form": "Senlakuy",
				"gloss": "we fry"
			}, {
				"form": "Senlahu lu",
				"gloss": "I fry them"
			}],
			"examples": [
				{
					"tbl": "Fakay kô ke senlakuy lu ni kem utón, lwu libu wolu latu sfolò syóm?",
					"en": "can we fry these 2,819 fish?"
				},
				{
					"tbl": "Soke bitil, senlahu ken tnaw",
					"en": "when I'm hungry, I fry leftover rice"
				},
				{
					"tbl": "Senlahu ken tnaw, kayà meken kuy",
					"en": "I fried the leftover rice, so let's eat"
				}
			]
		},
		{
			"head": "sfeng",
			"letter": "S",
			"gloss": "enough (sfeng ken me, enough food for us, Matthew 6:11)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sgeng",
			"letter": "S",
			"gloss": "at the same time (Tagalog \"sabay\")",
			"forms": [{
				"form": "Anì le sgeng tmowok",
				"gloss": "so they grow together"
			}],
			"examples": []
		},
		{
			"head": "sidek",
			"letter": "S",
			"gloss": "bad",
			"forms": [],
			"examples": [{
				"tbl": "Nuclear bom tey sidek ni.",
				"en": "the nuclear bomb is very bad"
			}]
		},
		{
			"head": "sigel",
			"letter": "S",
			"gloss": "arms",
			"forms": [],
			"examples": []
		},
		{
			"head": "silà",
			"letter": "S",
			"gloss": "corn; also lightning (same spelling, same accent, different meaning)",
			"forms": [{
				"form": "Silaem",
				"gloss": "your corn (the accent drops when an ending attaches)"
			}, {
				"form": "Silà le",
				"gloss": "their corn (never silale)"
			}],
			"examples": []
		},
		{
			"head": "skas",
			"letter": "S",
			"gloss": "break",
			"forms": [],
			"examples": []
		},
		{
			"head": "skél",
			"letter": "S",
			"gloss": "same",
			"forms": [
				{
					"form": "Skél le ohu",
					"gloss": "he and the dog are the same (skél le, they are the same)"
				},
				{
					"form": "Skél du ohu",
					"gloss": "the dog looks like him"
				},
				{
					"form": "Skél bê",
					"gloss": "the same as, like (before a thing: skél bê ChatGPT)"
				},
				{
					"form": "Ou skél béléem",
					"gloss": "I'm like you, I'm the same as you"
				},
				{
					"form": "Uu skél béléu",
					"gloss": "you're like me"
				},
				{
					"form": "Skél + owner word merges into the \"too\" words",
					"gloss": "skél kóm becomes skóm (you too)"
				}
			],
			"examples": []
		},
		{
			"head": "skóm",
			"letter": "S",
			"gloss": "you too, as well as you (from skél kóm)",
			"forms": [{
				"form": "Hyu hlafus béléem skóm",
				"gloss": "good morning to you too"
			}],
			"examples": []
		},
		{
			"head": "sdo / sdou",
			"letter": "S",
			"gloss": "me too, as well as me",
			"forms": [{
				"form": "Ominu meken sdo(u)",
				"gloss": "and I'll eat too"
			}],
			"examples": []
		},
		{
			"head": "skun",
			"letter": "S",
			"gloss": "him/her/it too, as well as him/her/it",
			"forms": [],
			"examples": []
		},
		{
			"head": "skul",
			"letter": "S",
			"gloss": "them too, also them",
			"forms": [{
				"form": "Kehegdemu du bitil le skul kem wongu",
				"gloss": "I think my spiders are hungry too"
			}],
			"examples": []
		},
		{
			"head": "skut",
			"letter": "S",
			"gloss": "us too, same as us (you and me)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sket",
			"letter": "S",
			"gloss": "enough",
			"forms": [
				{
					"form": "Sket ne ni",
					"gloss": "this is enough"
				},
				{
					"form": "Sket kut",
					"gloss": "we're the same"
				},
				{
					"form": "Sket kut nê",
					"gloss": "we're just the same"
				},
				{
					"form": "Sket kul",
					"gloss": "they're just the same"
				},
				{
					"form": "Sket te",
					"gloss": "you and I are the same"
				}
			],
			"examples": []
		},
		{
			"head": "slamat",
			"letter": "S",
			"gloss": "thanks",
			"forms": [
				{
					"form": "Bong slamat",
					"gloss": "thank you so much"
				},
				{
					"form": "Slamat béléu",
					"gloss": "thanks to me"
				},
				{
					"form": "Slamat béléem",
					"gloss": "thanks to you"
				},
				{
					"form": "Slamat béléen",
					"gloss": "thanks to him/her/it"
				},
				{
					"form": "Slamat béléle",
					"gloss": "thanks to them"
				},
				{
					"form": "Slamat béléye",
					"gloss": "thanks to you all"
				},
				{
					"form": "Slamat bélékuy",
					"gloss": "thanks to all of us"
				},
				{
					"form": "Slamat béléte",
					"gloss": "thanks to just you and me"
				}
			],
			"examples": []
		},
		{
			"head": "s'ngal",
			"letter": "S",
			"gloss": "title of a song",
			"forms": [],
			"examples": []
		},
		{
			"head": "slò",
			"letter": "S",
			"gloss": "fast",
			"forms": [
				{
					"form": "Slòem dé",
					"gloss": "hurry up!"
				},
				{
					"form": "Henslòem (dé)",
					"gloss": "(you) hurry! make it fast"
				},
				{
					"form": "Henslòu",
					"gloss": "I (do it) fast"
				},
				{
					"form": "Henslòu mlóy ebuteng",
					"gloss": "I was running fast last night"
				},
				{
					"form": "Henslòu msek du swelu eginu hlafus",
					"gloss": "I put my pants on fast earlier this morning"
				},
				{
					"form": "Henslòem lemsek du nesem",
					"gloss": "put your clothes on faster"
				}
			],
			"examples": []
		},
		{
			"head": "smakay",
			"letter": "S",
			"gloss": "riding",
			"forms": [],
			"examples": []
		},
		{
			"head": "snata / utóm",
			"letter": "S",
			"gloss": "music",
			"forms": [],
			"examples": []
		},
		{
			"head": "soging",
			"letter": "S",
			"gloss": "banana",
			"forms": [],
			"examples": []
		},
		{
			"head": "sok",
			"letter": "S",
			"gloss": "if, when (another word for ke)",
			"forms": [
				{
					"form": "Soke bitil",
					"gloss": "when I'm hungry (the person ending goes on sok)"
				},
				{
					"form": "Sok kifu",
					"gloss": "at night"
				},
				{
					"form": "Sok kemdaw",
					"gloss": "during the day"
				}
			],
			"examples": []
		},
		{
			"head": "sélés nawa",
			"letter": "S",
			"gloss": "two people secretly hating each other",
			"forms": [],
			"examples": []
		},
		{
			"head": "sólók",
			"letter": "S",
			"gloss": "ask; question (careful: solok, without the accents, is light) (just asking, a question; for asking for something use mni)",
			"forms": [
				{
					"form": "Smólók dé",
					"gloss": "let me ask"
				},
				{
					"form": "Smólók du",
					"gloss": "he asked"
				},
				{
					"form": "Smólók du ke tonem yehenen kun",
					"gloss": "he asked if you saw his wife"
				},
				{
					"form": "Ne snólók du dé",
					"gloss": "I'll ask him"
				},
				{
					"form": "Ne snólók Grok anay",
					"gloss": "I'll ask Grok first"
				},
				{
					"form": "Snólóken u du",
					"gloss": "he asked you"
				},
				{
					"form": "Gsólók",
					"gloss": "unexpectedly or accidentally get asked"
				}
			],
			"examples": []
		},
		{
			"head": "solok",
			"letter": "S",
			"gloss": "light (careful: sólók, with the accents, is ask)",
			"forms": [{
				"form": "Gsolok",
				"gloss": "accidentally get flashed (light in your eyes)"
			}, {
				"form": "Snolokem du kun",
				"gloss": "flash him with the light! (command)"
			}],
			"examples": []
		},
		{
			"head": "sómól",
			"letter": "S",
			"gloss": "grain rice (uncooked)",
			"forms": [],
			"examples": []
		},
		{
			"head": "sotu",
			"letter": "S",
			"gloss": "one; another (sotu / dumu)",
			"forms": [{
				"form": "Sotu ni",
				"gloss": "the day after tomorrow (when talking about dates)"
			}, {
				"form": "Tek sotu",
				"gloss": "only one"
			}],
			"examples": []
		},
		{
			"head": "S'twoli",
			"letter": "S",
			"gloss": "siblings ((Dumu) S'twoli)",
			"forms": [{
				"form": "Twolihu",
				"gloss": "my siblings"
			}],
			"examples": []
		},
		{
			"head": "subù",
			"letter": "S",
			"gloss": "sad",
			"forms": [],
			"examples": []
		},
		{
			"head": "sumóng",
			"letter": "S",
			"gloss": "lips",
			"forms": [{
				"form": "Bolok sumóng!",
				"gloss": "(cuss) rotten lips"
			}, {
				"form": "Mfól sumóng!",
				"gloss": "(cuss) thick lips"
			}],
			"examples": []
		},
		{
			"head": "sfolò",
			"letter": "S",
			"gloss": "ten (sotu + folò merged, \"one ten\")",
			"forms": [{
				"form": "Sfolò sotu",
				"gloss": "11"
			}],
			"examples": []
		},
		{
			"head": "sut",
			"letter": "S",
			"gloss": "show up; be born",
			"forms": [
				{
					"form": "Msut",
					"gloss": "being born, being introduced. The subject does it on its own"
				},
				{
					"form": "Hsut",
					"gloss": "intentionally show up; intentionally born. Someone does it to the subject"
				},
				{
					"form": "Gsut",
					"gloss": "unexpectedly show up"
				},
				{
					"form": "Msut du kimel",
					"gloss": "he was born yesterday"
				},
				{
					"form": "Hsut le du ekimel",
					"gloss": "he was born yesterday, by them"
				},
				{
					"form": "Hsut yéen du",
					"gloss": "he was birthed by his mother"
				},
				{
					"form": "Msut gu bê yéen du",
					"gloss": "he came through his mother"
				}
			],
			"examples": []
		},
		{
			"head": "swel",
			"letter": "S",
			"gloss": "pants",
			"forms": [{
				"form": "Swelu",
				"gloss": "my pants"
			}],
			"examples": []
		},
		{
			"head": "syó du?",
			"letter": "S",
			"gloss": "what's up?",
			"forms": [],
			"examples": []
		},
		{
			"head": "syóm",
			"letter": "S",
			"gloss": "nine",
			"forms": [],
			"examples": []
		},
		{
			"head": "ta",
			"letter": "T",
			"gloss": "above",
			"forms": [{
				"form": "Bê ta",
				"gloss": "on top of"
			}],
			"examples": []
		},
		{
			"head": "tadu / tau du",
			"letter": "T",
			"gloss": "who?",
			"forms": [{
				"form": "Tadu yó?",
				"gloss": "who's that?"
			}],
			"examples": []
		},
		{
			"head": "tagad",
			"letter": "T",
			"gloss": "wait; also \"yet\" in bê tagad",
			"forms": [{
				"form": "Tagad he",
				"gloss": "wait a bit"
			}, {
				"form": "Bê tagad tungô he",
				"gloss": "don't sleep yet"
			}],
			"examples": []
		},
		{
			"head": "tahu",
			"letter": "T",
			"gloss": "true",
			"forms": [
				{
					"form": "Tahu yó",
					"gloss": "that's true, agreeing"
				},
				{
					"form": "Tahu kô?",
					"gloss": "is it true? is it right? correct?"
				},
				{
					"form": "Tahu kô ni?",
					"gloss": "is it real?"
				},
				{
					"form": "Ell, tahu ni",
					"gloss": "yes, it is real"
				},
				{
					"form": "Ell, tahu yó",
					"gloss": "yes, that's real"
				},
				{
					"form": "Hentahu",
					"gloss": "to believe (from tahu, true)"
				},
				{
					"form": "Hemtahu",
					"gloss": "is believing"
				}
			],
			"examples": [{
				"tbl": "Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged?",
				"en": "do you believe eating red-eye fish together and sucking their meat can help us grow muscle?"
			}]
		},
		{
			"head": "tau",
			"letter": "T",
			"gloss": "person",
			"forms": [
				{
					"form": "Tau logi",
					"gloss": "man; tau libun: woman"
				},
				{
					"form": "Kem tau",
					"gloss": "people"
				},
				{
					"form": "Tau tmolok",
					"gloss": "a person who teaches"
				}
			],
			"examples": []
		},
		{
			"head": "tau datù",
			"letter": "T",
			"gloss": "person of higher rank",
			"forms": [],
			"examples": []
		},
		{
			"head": "tau geta",
			"letter": "T",
			"gloss": "rich person",
			"forms": [],
			"examples": []
		},
		{
			"head": "tau mulung",
			"letter": "T",
			"gloss": "healer, a person who gives medicine",
			"forms": [],
			"examples": []
		},
		{
			"head": "tau tahà",
			"letter": "T",
			"gloss": "tall person",
			"forms": [],
			"examples": []
		},
		{
			"head": "te",
			"letter": "T",
			"gloss": "you and me; me and you",
			"forms": [{
				"form": "Lwu te yó",
				"gloss": "that's the two of us"
			}, {
				"form": "Stolok te",
				"gloss": "we (you and I) teach each other"
			}],
			"examples": []
		},
		{
			"head": "te kwangu",
			"letter": "T",
			"gloss": "behind me, literally \"at my back\"",
			"forms": [],
			"examples": []
		},
		{
			"head": "tek",
			"letter": "T",
			"gloss": "only",
			"forms": [{
				"form": "Ngaen tek sotu",
				"gloss": "his only child"
			}],
			"examples": []
		},
		{
			"head": "tek sotuhu",
			"letter": "T",
			"gloss": "alone, just me",
			"forms": [],
			"examples": []
		},
		{
			"head": "tekuy",
			"letter": "T",
			"gloss": "we, let's",
			"forms": [],
			"examples": []
		},
		{
			"head": "tembol",
			"letter": "T",
			"gloss": "play music",
			"forms": [],
			"examples": []
		},
		{
			"head": "tembó beng",
			"letter": "T",
			"gloss": "window",
			"forms": [],
			"examples": []
		},
		{
			"head": "temngel",
			"letter": "T",
			"gloss": "look at someone",
			"forms": [],
			"examples": []
		},
		{
			"head": "temngón",
			"letter": "T",
			"gloss": "smart",
			"forms": [{
				"form": "Téyu temngón",
				"gloss": "you're very smart"
			}],
			"examples": []
		},
		{
			"head": "tenduk",
			"letter": "T",
			"gloss": "pain",
			"forms": [],
			"examples": []
		},
		{
			"head": "tey / téy",
			"letter": "T",
			"gloss": "very",
			"forms": [
				{
					"form": "Teye",
					"gloss": "I am very"
				},
				{
					"form": "Téyu",
					"gloss": "you are very"
				},
				{
					"form": "Téy-",
					"gloss": "he/she/it is very"
				},
				{
					"form": "Téyle",
					"gloss": "they are very"
				},
				{
					"form": "Téyye",
					"gloss": "you all are very"
				},
				{
					"form": "Téykuy",
					"gloss": "we are very"
				},
				{
					"form": "Téyte",
					"gloss": "we (you and I) are very"
				},
				{
					"form": "Téy kinì",
					"gloss": "very hot"
				},
				{
					"form": "Téy wen",
					"gloss": "a lot, many (literally \"many have\")"
				},
				{
					"form": "Téyu the best",
					"gloss": "you're the best"
				}
			],
			"examples": []
		},
		{
			"head": "tgayan",
			"letter": "T",
			"gloss": "cup",
			"forms": [],
			"examples": []
		},
		{
			"head": "ti",
			"letter": "T",
			"gloss": "foot, feet (tihen, his feet; tihem, your foot)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tibig",
			"letter": "T",
			"gloss": "tibig, Philippine wild fig (borrowed; no everyday T'boli word, not in the Bible)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tibó",
			"letter": "T",
			"gloss": "strike with a blade (tnibóhen, cut it off)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tihang",
			"letter": "T",
			"gloss": "carry on the shoulder",
			"forms": [],
			"examples": []
		},
		{
			"head": "tikeb",
			"letter": "T",
			"gloss": "shut, close, cover (tmikeb, shutting it; tnikeb, shut)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tikeb",
			"letter": "T",
			"gloss": "shut, close, cover (tmikeb, shutting; tnikeb, shut). Bak tikeb: door, \"the opening that shuts\"",
			"forms": [],
			"examples": []
		},
		{
			"head": "tilob",
			"letter": "T",
			"gloss": "good, cool, nice, beautiful (the general word)",
			"forms": [{
				"form": "Tilob du",
				"gloss": "it's beautiful"
			}, {
				"form": "Both tilob and K'nóón work for things like a T'nalak",
				"gloss": ""
			}],
			"examples": [{
				"tbl": "Okóm tey tilob ni kem utón ni",
				"en": "but these fish are so beautiful"
			}]
		},
		{
			"head": "tilów",
			"letter": "T",
			"gloss": "try, taste",
			"forms": [
				{
					"form": "T'milów",
					"gloss": "trying, tasting (going to try something)"
				},
				{
					"form": "T'nilów",
					"gloss": "being tried or tasted (with the endings, the m becomes n)"
				},
				{
					"form": "M'tilów (Metilów)",
					"gloss": "being tasted"
				},
				{
					"form": "Tilówem",
					"gloss": "you try"
				},
				{
					"form": "Tilówu",
					"gloss": "I try"
				},
				{
					"form": "Tilówte",
					"gloss": "let's try, just you and me"
				},
				{
					"form": "T'milówu",
					"gloss": "come try or taste it"
				},
				{
					"form": "T'nilówem",
					"gloss": "you, try or taste it"
				},
				{
					"form": "T'nilówen",
					"gloss": "he/she/it is trying or tasting it"
				},
				{
					"form": "T'milówle",
					"gloss": "they're trying or tasting"
				},
				{
					"form": "T'nilów le",
					"gloss": "they are trying or tasting it"
				},
				{
					"form": "T'milówye / T'nilówye",
					"gloss": "you all try or taste it, come try it"
				},
				{
					"form": "T'milówkuy / T'nilówkuy",
					"gloss": "let's try it"
				},
				{
					"form": "T'milówte",
					"gloss": "just you and me are trying or tasting"
				},
				{
					"form": "Deng t'nilówu ni / Deng tistingu ni",
					"gloss": "I already tried it"
				}
			],
			"examples": []
		},
		{
			"head": "tilów",
			"letter": "T",
			"gloss": "challenge, temptation",
			"forms": [{
				"form": "Tilów mgel",
				"gloss": "hard challenges (Matthew 6:13)"
			}],
			"examples": []
		},
		{
			"head": "tiol",
			"letter": "T",
			"gloss": "bones",
			"forms": [],
			"examples": []
		},
		{
			"head": "tisting",
			"letter": "T",
			"gloss": "tasting (borrowed from English)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tlangas",
			"letter": "T",
			"gloss": "locust",
			"forms": [],
			"examples": []
		},
		{
			"head": "tlu",
			"letter": "T",
			"gloss": "three",
			"forms": [],
			"examples": []
		},
		{
			"head": "tlumfà",
			"letter": "T",
			"gloss": "sandals, shoes (tlumfaem, your sandals)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tluyab",
			"letter": "T",
			"gloss": "yawn",
			"forms": [],
			"examples": []
		},
		{
			"head": "t'ngón",
			"letter": "T",
			"gloss": "know",
			"forms": [
				{
					"form": "T'ngónem",
					"gloss": "you know; do you know?"
				},
				{
					"form": "T'ngónu",
					"gloss": "I know"
				},
				{
					"form": "Deng t'ngónu ne",
					"gloss": "now I know"
				},
				{
					"form": "Hetngón",
					"gloss": "to let someone know (h- + t'ngón)"
				}
			],
			"examples": [{
				"tbl": "T'ngónem bon yó \"béléem\" meaning-ngen?",
				"en": "do you know what \"béléem\" means?"
			}, {
				"tbl": "Là t'ngónu du ke hyu ktolok le do",
				"en": "I don't know if I'm being taught well"
			}]
		},
		{
			"head": "tmaba",
			"letter": "T",
			"gloss": "call out, shout",
			"forms": [],
			"examples": []
		},
		{
			"head": "tnaw",
			"letter": "T",
			"gloss": "cold",
			"forms": [
				{
					"form": "Hetnaw",
					"gloss": "make cold; being frozen by (something)"
				},
				{
					"form": "Hetnawem ken",
					"gloss": "make the food cold (you do it)"
				},
				{
					"form": "Hetnawen u yó",
					"gloss": "it'll make you cold"
				},
				{
					"form": "Tnawu yó",
					"gloss": "you'll be cold"
				},
				{
					"form": "Ken tnaw",
					"gloss": "leftover rice"
				}
			],
			"examples": []
		},
		{
			"head": "tudà",
			"letter": "T",
			"gloss": "throw (tudaen, he threw it). **Tnudaen o**: he stoned me (threw at me)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tul",
			"letter": "T",
			"gloss": "ever (là kô deng, never have)",
			"forms": [],
			"examples": []
		},
		{
			"head": "twok",
			"letter": "T",
			"gloss": "palm. In the Bible it's the date palm (doun twok, palm branches, John 12:13). Not the coconut (lfò)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tulud",
			"letter": "T",
			"gloss": "push",
			"forms": [],
			"examples": []
		},
		{
			"head": "tulud",
			"letter": "T",
			"gloss": "push (tuluden, he pushed it). Tuluden ou bè lewà: he pushed me outside",
			"forms": [],
			"examples": []
		},
		{
			"head": "tóbong",
			"letter": "T",
			"gloss": "help (the general word). **Tnóbóngem o**: you helped me",
			"forms": [
				{
					"form": "Tnóbong",
					"gloss": "to help"
				},
				{
					"form": "Stóbóng",
					"gloss": "helping each other"
				},
				{
					"form": "Gtóbóng",
					"gloss": "being helped (unexpectedly)"
				}
			],
			"examples": [{
				"tbl": "Stóbóng le anì le sgeng tmowok bê kehnagì le udél",
				"en": "they helped each other grow in studying languages"
			}]
		},
		{
			"head": "todol",
			"letter": "T",
			"gloss": "next",
			"forms": [{
				"form": "Todol bulón",
				"gloss": "next month"
			}, {
				"form": "Todol fedyan",
				"gloss": "next week"
			}],
			"examples": []
		},
		{
			"head": "tódô",
			"letter": "T",
			"gloss": "right away, immediately",
			"forms": [],
			"examples": []
		},
		{
			"head": "tógó",
			"letter": "T",
			"gloss": "cook",
			"forms": [
				{
					"form": "Tmógó",
					"gloss": "cooking (hasn't happened yet)"
				},
				{
					"form": "Tnógó",
					"gloss": "to cook; being cooked"
				},
				{
					"form": "Tnógóu lu kô ke senlahu lu?",
					"gloss": "should I cook them or fry them?"
				},
				{
					"form": "Tnógóhu kul",
					"gloss": "I cook theirs"
				},
				{
					"form": "Deng tógó ne ken",
					"gloss": "the rice is already cooked"
				}
			],
			"examples": []
		},
		{
			"head": "toit",
			"letter": "T",
			"gloss": "little clitoris (vulgar)",
			"forms": [{
				"form": "Stoiten!",
				"gloss": "(cuss) her little clitoris!"
			}],
			"examples": []
		},
		{
			"head": "tolo",
			"letter": "T",
			"gloss": "still",
			"forms": [{
				"form": "Tole me",
				"gloss": "we are (were) still"
			}, {
				"form": "Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal",
				"gloss": "um, we were still walking, then we saw a snake"
			}],
			"examples": []
		},
		{
			"head": "tolok",
			"letter": "T",
			"gloss": "teach. **Tnolokem o T'boli**: you taught me T'boli",
			"forms": [
				{
					"form": "Tmolok",
					"gloss": "teaching, about to teach"
				},
				{
					"form": "Tnolok",
					"gloss": "being taught"
				},
				{
					"form": "Gtolok",
					"gloss": "being taught unexpectedly"
				},
				{
					"form": "Htolok",
					"gloss": "wanting to be taught"
				},
				{
					"form": "Stolok",
					"gloss": "teaching each other"
				},
				{
					"form": "Ktolok",
					"gloss": "being taught"
				},
				{
					"form": "Toloku kóm",
					"gloss": "I teach you"
				},
				{
					"form": "Tnoloku",
					"gloss": "I teach (-u, not -hu)"
				},
				{
					"form": "Tnoloku kóm",
					"gloss": "I keep teaching you (ongoing)"
				},
				{
					"form": "Tolok te kóm",
					"gloss": "something I taught you in the past, just us"
				},
				{
					"form": "Tnolokem o(u)",
					"gloss": "you taught me"
				},
				{
					"form": "Tnoloku u(u)",
					"gloss": "I taught you"
				},
				{
					"form": "Ktolok le do",
					"gloss": "they taught me; the teaching they got through to me"
				},
				{
					"form": "Stolok te",
					"gloss": "we (you and I) teach each other"
				},
				{
					"form": "Stolok me",
					"gloss": "we teach each other, but not you"
				}
			],
			"examples": [{
				"tbl": "Là tnoloku kóm anìu baling sidek",
				"en": "I don't teach you to become bad"
			}]
		},
		{
			"head": "ton",
			"letter": "T",
			"gloss": "see; also found (the thing found comes after). **Tonen o Pangu**: my dad saw me (no tn- here, not tnonen)",
			"forms": [
				{
					"form": "Mton",
					"gloss": "to see"
				},
				{
					"form": "Gton",
					"gloss": "unintentionally being seen"
				},
				{
					"form": "Gton du",
					"gloss": "he/she/it was seen, was found (the real passive; ton le du is \"they found him\")"
				},
				{
					"form": "Kton",
					"gloss": "already seen, was seen"
				},
				{
					"form": "Tonen",
					"gloss": "he/she/it found"
				},
				{
					"form": "Tonu",
					"gloss": "I found"
				},
				{
					"form": "Tonem",
					"gloss": "you found"
				},
				{
					"form": "Tonle",
					"gloss": "they found"
				},
				{
					"form": "Tonye",
					"gloss": "you all found"
				},
				{
					"form": "Tonkuy",
					"gloss": "we found"
				},
				{
					"form": "Tonte",
					"gloss": "you and I found"
				},
				{
					"form": "Ston",
					"gloss": "see each other (two people)"
				},
				{
					"form": "Bud te ston he",
					"gloss": "see you (again), literally \"we two see each other again\""
				}
			],
			"examples": [{
				"tbl": "Ekimel ton le du",
				"en": "yesterday he/she/it was found"
			}, {
				"tbl": "Ekimel kton le du mógów bê tuen",
				"en": "yesterday he was seen walking there"
			}]
		},
		{
			"head": "tong",
			"letter": "T",
			"gloss": "so (X, so Y)",
			"forms": [
				{
					"form": "Tonge",
					"gloss": "so I"
				},
				{
					"form": "Tongu",
					"gloss": "so you (tong takes -u, not -em; and du at the end, not -en)"
				},
				{
					"form": "Tongu lmangat",
					"gloss": "so you screamed"
				},
				{
					"form": "Tong (something happened) du",
					"gloss": "so he/she/it (did something). Tong kmuli du: so he/she/it laughed"
				},
				{
					"form": "Tong le mulék",
					"gloss": "so they left / went back"
				},
				{
					"form": "Tong kuy mlóy",
					"gloss": "so we ran"
				},
				{
					"form": "Tong te mluy",
					"gloss": "so we (you and I) tripped, fell and rolled"
				},
				{
					"form": "Tong ye hemsag",
					"gloss": "so you guys shouted"
				},
				{
					"form": "Bitile tonge meken",
					"gloss": "I'm hungry, so I'm eating"
				},
				{
					"form": "Kay le bitil, tong henkenu kem kuyingu",
					"gloss": "because they're hungry, I'll feed my cats"
				}
			],
			"examples": []
		},
		{
			"head": "tô",
			"letter": "T",
			"gloss": "going to, about to; trying to",
			"forms": [{
				"form": "Tô kay",
				"gloss": "looks like (Tô kay ohu du, he looks like a dog)"
			}, {
				"form": "Tô mlóy du",
				"gloss": "he's trying to run away"
			}],
			"examples": []
		},
		{
			"head": "tonok",
			"letter": "T",
			"gloss": "earth, ground (te tonok, on earth)",
			"forms": [],
			"examples": []
		},
		{
			"head": "tooh",
			"letter": "T",
			"gloss": "clitoris (vulgar)",
			"forms": [{
				"form": "Stoohen!",
				"gloss": "(cuss) her clitoris!"
			}],
			"examples": []
		},
		{
			"head": "tôu",
			"letter": "T",
			"gloss": "you're going to",
			"forms": [{
				"form": "Tôu tungô mekô?",
				"gloss": "you're going to sleep, really?"
			}],
			"examples": []
		},
		{
			"head": "towok",
			"letter": "T",
			"gloss": "grow",
			"forms": [
				{
					"form": "Tmowok",
					"gloss": "to grow"
				},
				{
					"form": "Gtowok",
					"gloss": "being grown"
				},
				{
					"form": "Tnowok",
					"gloss": "something growing in or on something"
				},
				{
					"form": "Stowok",
					"gloss": "growing together, for each other (not \"sensetowok\")"
				},
				{
					"form": "Htowok",
					"gloss": "(help to) grow, in Gtóbóngen tu htowok unged (can help us grow muscle)"
				}
			],
			"examples": []
		},
		{
			"head": "trok",
			"letter": "T",
			"gloss": "hands",
			"forms": [],
			"examples": []
		},
		{
			"head": "tu",
			"letter": "T",
			"gloss": "far, there; also us",
			"forms": [
				{
					"form": "Tu dé",
					"gloss": "over there"
				},
				{
					"form": "Tu du",
					"gloss": "he/she/it is over there"
				},
				{
					"form": "Tu lu",
					"gloss": "there they are, they're over there"
				},
				{
					"form": "Tu mi",
					"gloss": "there we are; that's us (to someone who isn't part of it)"
				},
				{
					"form": "Tu tu",
					"gloss": "there we are (to someone who is part of it)"
				},
				{
					"form": "Tu yó",
					"gloss": "that's us (to people who are part of it, or pointing at something far off)"
				},
				{
					"form": "Tu ne yó",
					"gloss": "that's our turn"
				},
				{
					"form": "Tu ne ni",
					"gloss": "it's our turn"
				},
				{
					"form": "Tu mi tmógó utón",
					"gloss": "there's us, cooking fish"
				},
				{
					"form": "Tu works for directions too",
					"gloss": ""
				}
			],
			"examples": []
		},
		{
			"head": "tungô",
			"letter": "T",
			"gloss": "sleep",
			"forms": [
				{
					"form": "Tungôu",
					"gloss": "you sleep"
				},
				{
					"form": "Gtungô",
					"gloss": "sleepy"
				},
				{
					"form": "Gô tungô",
					"gloss": "bed, a place to sleep"
				},
				{
					"form": "Bê e dou tungô",
					"gloss": "I'm not sleeping yet"
				}
			],
			"examples": [{
				"tbl": "Tungôu ne, wong.",
				"en": "sleep now, spider."
			}]
		},
		{
			"head": "twogu",
			"letter": "T",
			"gloss": "elder",
			"forms": [],
			"examples": []
		},
		{
			"head": "twoli",
			"letter": "T",
			"gloss": "sibling, brother or sister (twolihen, his/her sibling; twolihem, your sibling; setwoli, siblings to each other); also youngest (ngà són twoli, the younger son, Luke 15:13)",
			"forms": [],
			"examples": []
		},
		{
			"head": "u / uu",
			"letter": "U",
			"gloss": "you (one person); uu is specifically you",
			"forms": [{
				"form": "U yó",
				"gloss": "that's you"
			}, {
				"form": "Uu yó",
				"gloss": "that's you, specifically you"
			}],
			"examples": []
		},
		{
			"head": "udas",
			"letter": "U",
			"gloss": "time",
			"forms": [
				{
					"form": "Bon udas ni?",
					"gloss": "what time is it?"
				},
				{
					"form": "Bon udas du ne ni?",
					"gloss": "what time is it now?"
				},
				{
					"form": "Alas trés",
					"gloss": "it's 3 o'clock. Clock times use T'bolized Spanish or English numbers"
				},
				{
					"form": "Alas trés hlafus",
					"gloss": "3 in the morning (add the time of day after)"
				},
				{
					"form": "Bon kdaw du ni?",
					"gloss": "what day is it today? Answer: Lunis, or Lunis kdaw ni"
				}
			],
			"examples": []
		},
		{
			"head": "udél",
			"letter": "U",
			"gloss": "language; word (the same word)",
			"forms": [
				{
					"form": "Kem udél",
					"gloss": "words"
				},
				{
					"form": "Udél T'boli",
					"gloss": "the T'boli language"
				},
				{
					"form": "Udél Dwata",
					"gloss": "gna kesfasad ne lomi kesfasad: the T'boli Bible, old covenant and new covenant (gna old, lomi new, kesfasad covenant)"
				},
				{
					"form": "Yóm Udél",
					"gloss": "the Word (John 1:1)"
				}
			],
			"examples": []
		},
		{
			"head": "udì",
			"letter": "U",
			"gloss": "small",
			"forms": [],
			"examples": []
		},
		{
			"head": "ukol",
			"letter": "U",
			"gloss": "short",
			"forms": [],
			"examples": []
		},
		{
			"head": "ulal",
			"letter": "U",
			"gloss": "snake",
			"forms": [{
				"form": "Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal",
				"gloss": "um, we were still walking, then we saw a snake"
			}],
			"examples": []
		},
		{
			"head": "ulék",
			"letter": "U",
			"gloss": "back",
			"forms": [
				{
					"form": "Mulék",
					"gloss": "leave, go back"
				},
				{
					"form": "Tong le mulék",
					"gloss": "so they left / went back"
				},
				{
					"form": "Mulék",
					"gloss": "coming back to (hasn't happened yet)"
				},
				{
					"form": "Kulék",
					"gloss": "coming back, came back"
				},
				{
					"form": "Kulékem",
					"gloss": "you'll come back (the k- form already carries \"will\")"
				},
				{
					"form": "Gulék / Mulék",
					"gloss": "get back, return"
				},
				{
					"form": "Hulék",
					"gloss": "return"
				},
				{
					"form": "Khulék",
					"gloss": "to return"
				},
				{
					"form": "Nehi mulék",
					"gloss": "come back first"
				}
			],
			"examples": [{
				"tbl": "T'ngónem kô kmò khulék kul bê gónô le ni?",
				"en": "do you know how to get them back to their home?"
			}]
		},
		{
			"head": "ulat",
			"letter": "U",
			"gloss": "veins",
			"forms": [],
			"examples": []
		},
		{
			"head": "unged",
			"letter": "U",
			"gloss": "muscle",
			"forms": [{
				"form": "Unged wen",
				"gloss": "more muscle"
			}],
			"examples": []
		},
		{
			"head": "unget / karni",
			"letter": "U",
			"gloss": "meat",
			"forms": [],
			"examples": []
		},
		{
			"head": "ungé",
			"letter": "U",
			"gloss": "rat",
			"forms": [],
			"examples": []
		},
		{
			"head": "utek",
			"letter": "U",
			"gloss": "brain",
			"forms": [],
			"examples": []
		},
		{
			"head": "utón / isdà",
			"letter": "U",
			"gloss": "fish",
			"forms": [{
				"form": "Kem utón",
				"gloss": "fish (more than one)"
			}, {
				"form": "Utón hulô mata",
				"gloss": "red-eye fish"
			}],
			"examples": []
		},
		{
			"head": "utóm",
			"letter": "U",
			"gloss": "music; notes (music)",
			"forms": [],
			"examples": []
		},
		{
			"head": "utóng",
			"letter": "U",
			"gloss": "debt (utóngu, my debt)",
			"forms": [],
			"examples": []
		},
		{
			"head": "uyó",
			"letter": "U",
			"gloss": "face",
			"forms": [],
			"examples": []
		},
		{
			"head": "wek",
			"letter": "W",
			"gloss": "hair",
			"forms": [],
			"examples": []
		},
		{
			"head": "wolu",
			"letter": "W",
			"gloss": "eight",
			"forms": [],
			"examples": []
		},
		{
			"head": "wen",
			"letter": "W",
			"gloss": "there is, there was (used whenever something shows up in a story); have, has; more (tey works too)",
			"forms": [
				{
					"form": "Là e meken kay wen Pangu",
					"gloss": "I'm not eating because my dad is there"
				},
				{
					"form": "Téy wen",
					"gloss": "a lot, many"
				},
				{
					"form": "Unged wen",
					"gloss": "more muscle"
				}
			],
			"examples": [{
				"tbl": "Kdaw ni, wen wong nô bê ta lmisa",
				"en": "today, there's a spider on top of the table"
			}, {
				"tbl": "Coffee-hu wen klamay nô lemmen",
				"en": "my coffee has sugar in it"
			}]
		},
		{
			"head": "wong",
			"letter": "W",
			"gloss": "spider",
			"forms": [{
				"form": "Wong htò",
				"gloss": "jumping spider"
			}, {
				"form": "Kem wongu",
				"gloss": "my spiders"
			}],
			"examples": [{
				"tbl": "Là e likô bê wong",
				"en": "I'm not scared of spiders"
			}]
		},
		{
			"head": "wót",
			"letter": "W",
			"gloss": "keep going, continue doing something (short for lemwót)",
			"forms": [{
				"form": "Wót ne",
				"gloss": "let's go"
			}, {
				"form": "Wót wong htò",
				"gloss": "the spider keeps jumping"
			}],
			"examples": []
		},
		{
			"head": "yak",
			"letter": "Y",
			"gloss": "shy, shame (the root)",
			"forms": [],
			"examples": []
		},
		{
			"head": "yake",
			"letter": "Y",
			"gloss": "hope, hopefully; should have (also sana from Tagalog, tanì from Hiligaynon)",
			"forms": [{
				"form": "Yake uu dé",
				"gloss": "it should have been you"
			}, {
				"form": "Yake làen kmulón haya",
				"gloss": "hopefully it won't rain tomorrow"
			}],
			"examples": []
		},
		{
			"head": "yê",
			"letter": "Y",
			"gloss": "mother",
			"forms": [
				{
					"form": "Yéen",
					"gloss": "his/her mother"
				},
				{
					"form": "Hsut yéen du",
					"gloss": "he was birthed by his mother"
				},
				{
					"form": "Msut gu bê yéen du",
					"gloss": "he came through his mother"
				}
			],
			"examples": []
		},
		{
			"head": "yehen",
			"letter": "Y",
			"gloss": "spouse, wife or husband (yehenem, your husband, John 4:16); myehen, to marry",
			"forms": [{
				"form": "Yehenen",
				"gloss": "his wife"
			}],
			"examples": []
		},
		{
			"head": "yó",
			"letter": "Y",
			"gloss": "that",
			"forms": [{
				"form": "(Bê) yó",
				"gloss": "there"
			}],
			"examples": []
		},
		{
			"head": "yóm",
			"letter": "Y",
			"gloss": "the",
			"forms": [],
			"examples": [{
				"tbl": "Yóm nuclear clock làen skas se",
				"en": "but the nuclear clock doesn't break"
			}]
		},
		{
			"head": "yu",
			"letter": "Y",
			"gloss": "you (2 or more people)",
			"forms": [{
				"form": "Yu yó",
				"gloss": "that's you all"
			}],
			"examples": []
		}
	],
	index: [
		{
			"en": "afraid",
			"heads": "likò / likô"
		},
		{
			"en": "afternoon",
			"heads": "kimel"
		},
		{
			"en": "again",
			"heads": "bud; he (again, hopefully)"
		},
		{
			"en": "airplane",
			"heads": "ówóng"
		},
		{
			"en": "alive",
			"heads": "mowil"
		},
		{
			"en": "all",
			"heads": "kdê"
		},
		{
			"en": "all, everyone",
			"heads": "kdê (kdéen, all of it; yóm kdéen tau, everyone)"
		},
		{
			"en": "allow",
			"heads": "fakay"
		},
		{
			"en": "alone",
			"heads": "tek sotuhu (just me)"
		},
		{
			"en": "already",
			"heads": "deng; ne"
		},
		{
			"en": "always",
			"heads": "gel"
		},
		{
			"en": "and",
			"heads": "omin"
		},
		{
			"en": "angry",
			"heads": "lóbô (hlóbô, hnóbô)"
		},
		{
			"en": "annoying",
			"heads": "sabad"
		},
		{
			"en": "another",
			"heads": "sotu / dumu"
		},
		{
			"en": "ant",
			"heads": "gulom"
		},
		{
			"en": "anymore",
			"heads": "bud (ne)"
		},
		{
			"en": "arms",
			"heads": "sigel"
		},
		{
			"en": "arrogant, proud (bad)",
			"heads": "hegmón"
		},
		{
			"en": "ashamed, embarrassed",
			"heads": "kenyak"
		},
		{
			"en": "ask",
			"heads": "sólók"
		},
		{
			"en": "ask for, request",
			"heads": "mni"
		},
		{
			"en": "attitude, personality",
			"heads": "adat"
		},
		{
			"en": "aunt",
			"heads": "anti"
		},
		{
			"en": "baby",
			"heads": "ngà"
		},
		{
			"en": "back (body)",
			"heads": "kwang"
		},
		{
			"en": "back (return)",
			"heads": "ulék"
		},
		{
			"en": "backyard",
			"heads": "kwang beng"
		},
		{
			"en": "bad",
			"heads": "sidek"
		},
		{
			"en": "banana",
			"heads": "soging"
		},
		{
			"en": "bathe",
			"heads": "dyo"
		},
		{
			"en": "bathe",
			"heads": "dyo"
		},
		{
			"en": "beautiful",
			"heads": "tilob; K'nóón (very beautiful)"
		},
		{
			"en": "because",
			"heads": "kay (kaye, because I); mlan bê (because of)"
		},
		{
			"en": "become",
			"heads": "baling; kehe / kehi"
		},
		{
			"en": "bed",
			"heads": "katri"
		},
		{
			"en": "bed",
			"heads": "gô tungô (under tungô)"
		},
		{
			"en": "before the world, in the beginning",
			"heads": "gu laanen là deng wen benwu he"
		},
		{
			"en": "behind me",
			"heads": "te kwangu"
		},
		{
			"en": "believe",
			"heads": "hentahu (under tahu)"
		},
		{
			"en": "belly",
			"heads": "blutut"
		},
		{
			"en": "beside",
			"heads": "lohok; bê"
		},
		{
			"en": "bible",
			"heads": "sulat dwata"
		},
		{
			"en": "big",
			"heads": "bong; kbong"
		},
		{
			"en": "bird",
			"heads": "onuk koyu"
		},
		{
			"en": "bitter",
			"heads": "héét"
		},
		{
			"en": "black",
			"heads": "hitem"
		},
		{
			"en": "bladder",
			"heads": "hnobò"
		},
		{
			"en": "blanket",
			"heads": "kumù"
		},
		{
			"en": "blood",
			"heads": "litô"
		},
		{
			"en": "blue",
			"heads": "ginggung"
		},
		{
			"en": "boat",
			"heads": "ówóng"
		},
		{
			"en": "body (my)",
			"heads": "lówóhu"
		},
		{
			"en": "boil",
			"heads": "kodok"
		},
		{
			"en": "bones",
			"heads": "tiol"
		},
		{
			"en": "book",
			"heads": "bok"
		},
		{
			"en": "bored",
			"heads": "closest is hedem (think)"
		},
		{
			"en": "born",
			"heads": "sut (msut, hsut)"
		},
		{
			"en": "borrow",
			"heads": "mdóm"
		},
		{
			"en": "boy",
			"heads": "logi"
		},
		{
			"en": "brain",
			"heads": "utek"
		},
		{
			"en": "break",
			"heads": "skas"
		},
		{
			"en": "break up a fight, calm things down",
			"heads": "mólów"
		},
		{
			"en": "breath, breathe",
			"heads": "nawa"
		},
		{
			"en": "bright",
			"heads": "lmayag"
		},
		{
			"en": "bring",
			"heads": "mit edini; nit, nwit (brought)"
		},
		{
			"en": "brother, sister, sibling",
			"heads": "twoli"
		},
		{
			"en": "but",
			"heads": "okóm; péro"
		},
		{
			"en": "buy",
			"heads": "bemli"
		},
		{
			"en": "calf",
			"heads": "ngà safì"
		},
		{
			"en": "call out, shout",
			"heads": "tmaba"
		},
		{
			"en": "can, may",
			"heads": "fakay"
		},
		{
			"en": "carabao",
			"heads": "bew"
		},
		{
			"en": "carry",
			"heads": "nitem (you carry it)"
		},
		{
			"en": "carry on shoulder",
			"heads": "tihang"
		},
		{
			"en": "carry",
			"heads": "mit"
		},
		{
			"en": "cat",
			"heads": "kuying"
		},
		{
			"en": "celebrate, happy",
			"heads": "hligal"
		},
		{
			"en": "cellphone",
			"heads": "sélfón"
		},
		{
			"en": "chair, seat",
			"heads": "bangkù"
		},
		{
			"en": "challenge, temptation",
			"heads": "tilów"
		},
		{
			"en": "charger",
			"heads": "chargér, charger, sargér"
		},
		{
			"en": "cheap",
			"heads": "bratu, là mebtesen"
		},
		{
			"en": "chest",
			"heads": "kfu"
		},
		{
			"en": "chicken",
			"heads": "onuk"
		},
		{
			"en": "child",
			"heads": "ngà"
		},
		{
			"en": "church",
			"heads": "simbahan"
		},
		{
			"en": "city",
			"heads": "syudad"
		},
		{
			"en": "clean",
			"heads": "mólós"
		},
		{
			"en": "climb",
			"heads": "mkaf"
		},
		{
			"en": "close, shut",
			"heads": "tikeb"
		},
		{
			"en": "close, shut",
			"heads": "tikeb"
		},
		{
			"en": "clothes",
			"heads": "nes"
		},
		{
			"en": "cloud, cloudy",
			"heads": "lobun (lmobun)"
		},
		{
			"en": "coffee",
			"heads": "kfi"
		},
		{
			"en": "cold",
			"heads": "tnaw"
		},
		{
			"en": "color, style, design",
			"heads": "betek"
		},
		{
			"en": "come",
			"heads": "hene; ene"
		},
		{
			"en": "come back",
			"heads": "ulék (mulék)"
		},
		{
			"en": "continue",
			"heads": "hlós"
		},
		{
			"en": "cook",
			"heads": "tógó; mekay ken (cook rice)"
		},
		{
			"en": "cooking pot",
			"heads": "kuleng"
		},
		{
			"en": "corn",
			"heads": "silà"
		},
		{
			"en": "cough",
			"heads": "kow"
		},
		{
			"en": "count",
			"heads": "msó (same word as rice). Nsóhem kun msó: count the rice, please"
		},
		{
			"en": "cousin, relatives",
			"heads": "dumuhen setwoli"
		},
		{
			"en": "covenant",
			"heads": "kesfasad (under udél)"
		},
		{
			"en": "cut",
			"heads": "kenleng (cut off); sfek (cut down a tree)"
		},
		{
			"en": "cow, ox",
			"heads": "safì"
		},
		{
			"en": "create, made",
			"heads": "dlimun"
		},
		{
			"en": "cry",
			"heads": "mkik"
		},
		{
			"en": "cup",
			"heads": "tgayan"
		},
		{
			"en": "curse",
			"heads": "htolo"
		},
		{
			"en": "cut down a tree",
			"heads": "sfek"
		},
		{
			"en": "cut off",
			"heads": "kenleng"
		},
		{
			"en": "dad, papa",
			"heads": "pang"
		},
		{
			"en": "dance",
			"heads": "madal"
		},
		{
			"en": "dark, getting",
			"heads": "kmifu"
		},
		{
			"en": "darkness",
			"heads": "kmifu, kifu"
		},
		{
			"en": "daughter",
			"heads": "ngà libun"
		},
		{
			"en": "dawn",
			"heads": "mwas"
		},
		{
			"en": "day",
			"heads": "kdaw"
		},
		{
			"en": "dead, die",
			"heads": "matay"
		},
		{
			"en": "death",
			"heads": "katay"
		},
		{
			"en": "death",
			"heads": "hatay"
		},
		{
			"en": "debt",
			"heads": "utóng"
		},
		{
			"en": "delicious",
			"heads": "téy mi (under mi); tey mnóm (under nóm)"
		},
		{
			"en": "desert sand",
			"heads": "kfung"
		},
		{
			"en": "dim",
			"heads": "kifu (kmifu, getting dim)"
		},
		{
			"en": "dirty",
			"heads": "là mólósen"
		},
		{
			"en": "do",
			"heads": "boyu"
		},
		{
			"en": "doctor",
			"heads": "duktur, tau mulung"
		},
		{
			"en": "dog",
			"heads": "ohu"
		},
		{
			"en": "don't abandon, don't leave",
			"heads": "béem bayà"
		},
		{
			"en": "done",
			"heads": "deng"
		},
		{
			"en": "don't",
			"heads": "bê"
		},
		{
			"en": "donkey",
			"heads": "kudà"
		},
		{
			"en": "door",
			"heads": "bak tikeb, beng"
		},
		{
			"en": "down",
			"heads": "elaan"
		},
		{
			"en": "draw a sword",
			"heads": "dmilot"
		},
		{
			"en": "dream",
			"heads": "kna"
		},
		{
			"en": "drink",
			"heads": "minum"
		},
		{
			"en": "drunk (intoxicated)",
			"heads": "lengel"
		},
		{
			"en": "dry",
			"heads": "mékéng"
		},
		{
			"en": "ear",
			"heads": "klingu"
		},
		{
			"en": "earlier this morning",
			"heads": "eginu hlafus"
		},
		{
			"en": "earlier",
			"heads": "eginu"
		},
		{
			"en": "earth",
			"heads": "tonok (te tonok, on earth)"
		},
		{
			"en": "eat",
			"heads": "ken (meken)"
		},
		{
			"en": "egg",
			"heads": "itlug"
		},
		{
			"en": "eight",
			"heads": "wolu"
		},
		{
			"en": "elder",
			"heads": "twogu"
		},
		{
			"en": "empty",
			"heads": "hkawang"
		},
		{
			"en": "enough",
			"heads": "sfeng"
		},
		{
			"en": "enough",
			"heads": "sket; ket"
		},
		{
			"en": "even (I don't even)",
			"heads": "ganì"
		},
		{
			"en": "ever",
			"heads": "tul"
		},
		{
			"en": "every day",
			"heads": "key haya"
		},
		{
			"en": "every",
			"heads": "ket"
		},
		{
			"en": "expensive",
			"heads": "mebtes"
		},
		{
			"en": "extremely",
			"heads": "alì"
		},
		{
			"en": "eye",
			"heads": "mata"
		},
		{
			"en": "face",
			"heads": "uyó"
		},
		{
			"en": "fall",
			"heads": "mluy (trip, fall and roll)"
		},
		{
			"en": "far",
			"heads": "mayuk; tu"
		},
		{
			"en": "fast",
			"heads": "slò"
		},
		{
			"en": "fat",
			"heads": "mabù"
		},
		{
			"en": "father",
			"heads": "mà; pang"
		},
		{
			"en": "feed",
			"heads": "hemken"
		},
		{
			"en": "feed",
			"heads": "hken"
		},
		{
			"en": "feed",
			"heads": "henken (under ken); hefken, wants to be fed"
		},
		{
			"en": "feeling",
			"heads": "kegnóm"
		},
		{
			"en": "feet",
			"heads": "ti"
		},
		{
			"en": "female",
			"heads": "libun"
		},
		{
			"en": "fever",
			"heads": "des kinì"
		},
		{
			"en": "few",
			"heads": "là holen wen"
		},
		{
			"en": "field",
			"heads": "dnadu"
		},
		{
			"en": "fight (each other)",
			"heads": "sfatay"
		},
		{
			"en": "find",
			"heads": "kebel"
		},
		{
			"en": "find",
			"heads": "nebel (mebel)"
		},
		{
			"en": "fingers",
			"heads": "kyemet"
		},
		{
			"en": "fire",
			"heads": "ofi"
		},
		{
			"en": "first",
			"heads": "gna; anay (first, for now)"
		},
		{
			"en": "fish",
			"heads": "utón / isdà"
		},
		{
			"en": "fishing net",
			"heads": "huket"
		},
		{
			"en": "five",
			"heads": "limu"
		},
		{
			"en": "flash (with light)",
			"heads": "snolok"
		},
		{
			"en": "flower",
			"heads": "bulók"
		},
		{
			"en": "flowing",
			"heads": "mlel"
		},
		{
			"en": "fly",
			"heads": "móyóng"
		},
		{
			"en": "follow",
			"heads": "huli"
		},
		{
			"en": "foot",
			"heads": "ti"
		},
		{
			"en": "for",
			"heads": "bélé; para (bê); ke"
		},
		{
			"en": "forest",
			"heads": "dlag lamang"
		},
		{
			"en": "forget",
			"heads": "klifót; on purpose (good): kehlifót; pretend not to know (bad): hlifót"
		},
		{
			"en": "forgive",
			"heads": "hnifót"
		},
		{
			"en": "forgiveness",
			"heads": "seflifót"
		},
		{
			"en": "found",
			"heads": "ton"
		},
		{
			"en": "four",
			"heads": "fat"
		},
		{
			"en": "friday",
			"heads": "Byérnis"
		},
		{
			"en": "friend",
			"heads": "sbót / sebót; dumu sbót"
		},
		{
			"en": "frog",
			"heads": "fak"
		},
		{
			"en": "front",
			"heads": "solu"
		},
		{
			"en": "fruit",
			"heads": "bungu"
		},
		{
			"en": "fry",
			"heads": "senla / pritu"
		},
		{
			"en": "full (from eating)",
			"heads": "besow"
		},
		{
			"en": "garden, orchard",
			"heads": "hulu"
		},
		{
			"en": "get up, wake up",
			"heads": "btik"
		},
		{
			"en": "get",
			"heads": "gwa; ma / gemwa; nwa"
		},
		{
			"en": "girl",
			"heads": "libun"
		},
		{
			"en": "give",
			"heads": "blay"
		},
		{
			"en": "go",
			"heads": "gów"
		},
		{
			"en": "goat",
			"heads": "kambing"
		},
		{
			"en": "God",
			"heads": "Dwata"
		},
		{
			"en": "going",
			"heads": "lemwót"
		},
		{
			"en": "good",
			"heads": "hyu; tilob"
		},
		{
			"en": "grab, catch",
			"heads": "kemfô; caught in the act: gafit; catch fish: guta"
		},
		{
			"en": "grandmother",
			"heads": "bé"
		},
		{
			"en": "grass",
			"heads": "bnes"
		},
		{
			"en": "green",
			"heads": "lemnaw"
		},
		{
			"en": "grow",
			"heads": "towok; lemnok (growing)"
		},
		{
			"en": "hair",
			"heads": "wek"
		},
		{
			"en": "hair, a strand of",
			"heads": "balu"
		},
		{
			"en": "hands",
			"heads": "trok"
		},
		{
			"en": "happy",
			"heads": "hligal"
		},
		{
			"en": "hard",
			"heads": "mgel"
		},
		{
			"en": "hate",
			"heads": "kutó nawa (I hate you: Knutó nawahu u)"
		},
		{
			"en": "reject, dislike, deny",
			"heads": "kenbé (Kenbéu u)"
		},
		{
			"en": "have, has",
			"heads": "wen"
		},
		{
			"en": "he, she, it, him, her",
			"heads": "du"
		},
		{
			"en": "head",
			"heads": "kulu"
		},
		{
			"en": "hear",
			"heads": "gungol (hmungol, listen)"
		},
		{
			"en": "heart",
			"heads": "hosò"
		},
		{
			"en": "heaven, sky",
			"heads": "longit"
		},
		{
			"en": "heavy",
			"heads": "blat"
		},
		{
			"en": "help",
			"heads": "tóbong"
		},
		{
			"en": "here's",
			"heads": "ni"
		},
		{
			"en": "hide",
			"heads": "bnos; hide yourself: hebnos"
		},
		{
			"en": "high",
			"heads": "geta"
		},
		{
			"en": "hold",
			"heads": "nogot"
		},
		{
			"en": "hope",
			"heads": "yake (also sana, tanì)"
		},
		{
			"en": "horse",
			"heads": "kudà"
		},
		{
			"en": "hot",
			"heads": "kinì"
		},
		{
			"en": "house, home",
			"heads": "gónô"
		},
		{
			"en": "how long",
			"heads": "kegenen"
		},
		{
			"en": "how much?",
			"heads": "ket hilu?"
		},
		{
			"en": "how",
			"heads": "kmò"
		},
		{
			"en": "humble",
			"heads": "heglaan"
		},
		{
			"en": "hundred",
			"heads": "latu"
		},
		{
			"en": "hungry",
			"heads": "bitil"
		},
		{
			"en": "hurry",
			"heads": "géhél"
		},
		{
			"en": "hurry",
			"heads": "slòem dé; henslòem"
		},
		{
			"en": "hurt",
			"heads": "des"
		},
		{
			"en": "hypocrite, fake person",
			"heads": "tau gel hemtedeng knô"
		},
		{
			"en": "husband, spouse",
			"heads": "yehen"
		},
		{
			"en": "I don't know",
			"heads": "ngunte"
		},
		{
			"en": "I, me",
			"heads": "o / ou; do"
		},
		{
			"en": "if",
			"heads": "ke; sok; dé kô"
		},
		{
			"en": "immediately",
			"heads": "tódô"
		},
		{
			"en": "inside",
			"heads": "lem"
		},
		{
			"en": "into",
			"heads": "elem"
		},
		{
			"en": "jaw, molars",
			"heads": "beeng"
		},
		{
			"en": "jealous",
			"heads": "inggit / sélus"
		},
		{
			"en": "joking",
			"heads": "hlowon"
		},
		{
			"en": "jump up",
			"heads": "hebetik"
		},
		{
			"en": "jumping",
			"heads": "htò"
		},
		{
			"en": "jumping spider",
			"heads": "wong htò"
		},
		{
			"en": "just",
			"heads": "len; olohu (I'm just)"
		},
		{
			"en": "keep going, continue",
			"heads": "wót"
		},
		{
			"en": "kitchen",
			"heads": "kohù / kusina"
		},
		{
			"en": "kitten",
			"heads": "kukù"
		},
		{
			"en": "knees",
			"heads": "bukol"
		},
		{
			"en": "knife",
			"heads": "sudeng, kutsilyu"
		},
		{
			"en": "know",
			"heads": "t'ngón"
		},
		{
			"en": "lake",
			"heads": "lanaw"
		},
		{
			"en": "language",
			"heads": "udél"
		},
		{
			"en": "last night",
			"heads": "ebuteng"
		},
		{
			"en": "later",
			"heads": "kdeng"
		},
		{
			"en": "laugh",
			"heads": "kmuli"
		},
		{
			"en": "laugh",
			"heads": "kuli"
		},
		{
			"en": "leaf",
			"heads": "doun"
		},
		{
			"en": "lean",
			"heads": "hegléd"
		},
		{
			"en": "learn, schooling",
			"heads": "hnagì"
		},
		{
			"en": "leave",
			"heads": "mulék"
		},
		{
			"en": "left",
			"heads": "iwóng"
		},
		{
			"en": "legs",
			"heads": "haha"
		},
		{
			"en": "lend",
			"heads": "hendóm; money: hutóng"
		},
		{
			"en": "let's go",
			"heads": "wót ne"
		},
		{
			"en": "let's, we",
			"heads": "tekuy"
		},
		{
			"en": "life",
			"heads": "klowil, mowil"
		},
		{
			"en": "lift",
			"heads": "mekay"
		},
		{
			"en": "light",
			"heads": "solok; layag (for not heavy, lmaan)"
		},
		{
			"en": "lightning",
			"heads": "silà (same word as corn)"
		},
		{
			"en": "like (enjoy)",
			"heads": "nóyô / nóyó"
		},
		{
			"en": "like (same as)",
			"heads": "skél (skél bê)"
		},
		{
			"en": "like, as",
			"heads": "lómón ke"
		},
		{
			"en": "like, it's",
			"heads": "lomon"
		},
		{
			"en": "lips",
			"heads": "sumóng"
		},
		{
			"en": "listen",
			"heads": "hmungol"
		},
		{
			"en": "listen",
			"heads": "hmungol, hnungol"
		},
		{
			"en": "live somewhere",
			"heads": "menwu"
		},
		{
			"en": "locust",
			"heads": "tlangas"
		},
		{
			"en": "long",
			"heads": "legen"
		},
		{
			"en": "looks like",
			"heads": "tô kay"
		},
		{
			"en": "lose, lost",
			"heads": "lana"
		},
		{
			"en": "love",
			"heads": "kbong nawa (under kbong and nawa)"
		},
		{
			"en": "male",
			"heads": "logi"
		},
		{
			"en": "mama",
			"heads": "mang"
		},
		{
			"en": "man",
			"heads": "tau logi"
		},
		{
			"en": "many",
			"heads": "dê"
		},
		{
			"en": "market",
			"heads": "gónô fedyan"
		},
		{
			"en": "marry",
			"heads": "myehen"
		},
		{
			"en": "maybe",
			"heads": "dé kô"
		},
		{
			"en": "meat",
			"heads": "unget / karni"
		},
		{
			"en": "medicine",
			"heads": "bulung"
		},
		{
			"en": "mine, my",
			"heads": "do; dou; -hu"
		},
		{
			"en": "miss someone",
			"heads": "khahù"
		},
		{
			"en": "monday",
			"heads": "Lunis"
		},
		{
			"en": "money",
			"heads": "filak"
		},
		{
			"en": "monkey",
			"heads": "iwas"
		},
		{
			"en": "month",
			"heads": "bulón"
		},
		{
			"en": "moon",
			"heads": "bulón"
		},
		{
			"en": "more",
			"heads": "wen"
		},
		{
			"en": "mosquito",
			"heads": "blawang"
		},
		{
			"en": "mother",
			"heads": "yê"
		},
		{
			"en": "mountain",
			"heads": "bulul"
		},
		{
			"en": "mouth",
			"heads": "bak"
		},
		{
			"en": "mouth",
			"heads": "lembak"
		},
		{
			"en": "move on, forget on purpose",
			"heads": "kehlifót"
		},
		{
			"en": "mud, muddy",
			"heads": "hitok"
		},
		{
			"en": "muscle",
			"heads": "unged"
		},
		{
			"en": "music",
			"heads": "snata / utóm"
		},
		{
			"en": "near",
			"heads": "moni"
		},
		{
			"en": "neck",
			"heads": "lihol"
		},
		{
			"en": "need",
			"heads": "lóngón; kailangan"
		},
		{
			"en": "nest",
			"heads": "sala"
		},
		{
			"en": "never have",
			"heads": "là kô deng"
		},
		{
			"en": "new",
			"heads": "lomi"
		},
		{
			"en": "next",
			"heads": "todol"
		},
		{
			"en": "night",
			"heads": "kifu"
		},
		{
			"en": "nine",
			"heads": "syóm"
		},
		{
			"en": "no, not",
			"heads": "là; bê (refusing)"
		},
		{
			"en": "no one",
			"heads": "andù"
		},
		{
			"en": "noon",
			"heads": "kemdaw"
		},
		{
			"en": "nose",
			"heads": "ilung"
		},
		{
			"en": "nothing left",
			"heads": "gotu"
		},
		{
			"en": "nothing",
			"heads": "anduen"
		},
		{
			"en": "now",
			"heads": "ne; ni (right now)"
		},
		{
			"en": "oil",
			"heads": "hnolo"
		},
		{
			"en": "old",
			"heads": "gna"
		},
		{
			"en": "one",
			"heads": "sotu"
		},
		{
			"en": "only",
			"heads": "tek"
		},
		{
			"en": "open",
			"heads": "lungkà"
		},
		{
			"en": "open",
			"heads": "lungkà"
		},
		{
			"en": "or",
			"heads": "o; kô ke; ke"
		},
		{
			"en": "other",
			"heads": "dumu"
		},
		{
			"en": "outside",
			"heads": "lewà"
		},
		{
			"en": "owner",
			"heads": "fun"
		},
		{
			"en": "pain",
			"heads": "tenduk"
		},
		{
			"en": "pants",
			"heads": "swel"
		},
		{
			"en": "past",
			"heads": "gna"
		},
		{
			"en": "pay",
			"heads": "bayad"
		},
		{
			"en": "pen",
			"heads": "lapis"
		},
		{
			"en": "penis",
			"heads": "botò"
		},
		{
			"en": "people, person",
			"heads": "tau"
		},
		{
			"en": "pig",
			"heads": "sdô"
		},
		{
			"en": "place",
			"heads": "benwu"
		},
		{
			"en": "plate",
			"heads": "huyów"
		},
		{
			"en": "play music",
			"heads": "tembol"
		},
		{
			"en": "play",
			"heads": "hampang"
		},
		{
			"en": "please",
			"heads": "kun"
		},
		{
			"en": "pretend",
			"heads": "to be someone: hlingu / hlingón; not to know: hlifót"
		},
		{
			"en": "price",
			"heads": "blihen"
		},
		{
			"en": "prince",
			"heads": "man"
		},
		{
			"en": "princess",
			"heads": "boi"
		},
		{
			"en": "protect",
			"heads": "kenlung"
		},
		{
			"en": "proud",
			"heads": "dóyón"
		},
		{
			"en": "pull",
			"heads": "dyol, demyol"
		},
		{
			"en": "pull, drag",
			"heads": "demyol"
		},
		{
			"en": "puppy",
			"heads": "katù"
		},
		{
			"en": "pure, all",
			"heads": "sa"
		},
		{
			"en": "push",
			"heads": "tulud"
		},
		{
			"en": "push",
			"heads": "tulud"
		},
		{
			"en": "question",
			"heads": "sólók"
		},
		{
			"en": "rain",
			"heads": "kulón"
		},
		{
			"en": "rat",
			"heads": "ungé"
		},
		{
			"en": "read",
			"heads": "masa"
		},
		{
			"en": "really?",
			"heads": "mekô"
		},
		{
			"en": "red",
			"heads": "hulô"
		},
		{
			"en": "rely",
			"heads": "genléd"
		},
		{
			"en": "remember",
			"heads": "hentulón nawa"
		},
		{
			"en": "respect",
			"heads": "madat; respected, nadat"
		},
		{
			"en": "rest, lie down",
			"heads": "hegnô"
		},
		{
			"en": "return",
			"heads": "ulék (hulék, khulék)"
		},
		{
			"en": "rice (cooked)",
			"heads": "ken"
		},
		{
			"en": "rice (uncooked)",
			"heads": "msó / mesó; sómól (grain rice)"
		},
		{
			"en": "rice plant",
			"heads": "halay"
		},
		{
			"en": "rich person",
			"heads": "tau geta"
		},
		{
			"en": "riding",
			"heads": "smakay"
		},
		{
			"en": "right",
			"heads": "kwanan"
		},
		{
			"en": "river",
			"heads": "él mlel"
		},
		{
			"en": "road, way",
			"heads": "lan"
		},
		{
			"en": "robe",
			"heads": "heglomboy"
		},
		{
			"en": "rotten",
			"heads": "bolok"
		},
		{
			"en": "run",
			"heads": "mlóy"
		},
		{
			"en": "sad",
			"heads": "subù"
		},
		{
			"en": "salt",
			"heads": "kahì"
		},
		{
			"en": "salty",
			"heads": "héét"
		},
		{
			"en": "same",
			"heads": "skél"
		},
		{
			"en": "sand",
			"heads": "helek"
		},
		{
			"en": "sandals, shoes",
			"heads": "tlumfà"
		},
		{
			"en": "saturday",
			"heads": "Sbadu"
		},
		{
			"en": "say",
			"heads": "mon"
		},
		{
			"en": "scared",
			"heads": "likò / likô"
		},
		{
			"en": "scold",
			"heads": "hnóbô (careful: hnobò is bladder)"
		},
		{
			"en": "scream",
			"heads": "lmangat"
		},
		{
			"en": "sea, ocean",
			"heads": "mohin"
		},
		{
			"en": "see",
			"heads": "ton (mton, to see; gton, seen by accident; kton, was seen; ston, see each other)"
		},
		{
			"en": "sell",
			"heads": "hbalù"
		},
		{
			"en": "seven",
			"heads": "hitu"
		},
		{
			"en": "shameful",
			"heads": "hemyak"
		},
		{
			"en": "sheath",
			"heads": "lumaken"
		},
		{
			"en": "shield",
			"heads": "klung"
		},
		{
			"en": "shining",
			"heads": "lemayag"
		},
		{
			"en": "shirt",
			"heads": "kgal"
		},
		{
			"en": "short",
			"heads": "ukol"
		},
		{
			"en": "should have",
			"heads": "yake"
		},
		{
			"en": "shoulder",
			"heads": "abal"
		},
		{
			"en": "shout",
			"heads": "hemsag"
		},
		{
			"en": "show up (unexpectedly)",
			"heads": "gfan"
		},
		{
			"en": "show up (on purpose)",
			"heads": "hegfan"
		},
		{
			"en": "show up",
			"heads": "sut (gsut, unexpectedly; hsut, on purpose)"
		},
		{
			"en": "shower",
			"heads": "dyó"
		},
		{
			"en": "shut, cover",
			"heads": "tikeb"
		},
		{
			"en": "shy",
			"heads": "yak; being shy: myak (Myak du, she's shy)"
		},
		{
			"en": "siblings",
			"heads": "S'twoli"
		},
		{
			"en": "sick",
			"heads": "gemnóm des"
		},
		{
			"en": "sick",
			"heads": "des"
		},
		{
			"en": "sin, wrong",
			"heads": "salà"
		},
		{
			"en": "sing",
			"heads": "semngal"
		},
		{
			"en": "sit",
			"heads": "myón"
		},
		{
			"en": "six",
			"heads": "nem"
		},
		{
			"en": "skin",
			"heads": "kulit"
		},
		{
			"en": "skinny",
			"heads": "lehen"
		},
		{
			"en": "sleep",
			"heads": "tungô"
		},
		{
			"en": "sleepy",
			"heads": "moo ktuk (under moo); gtungô"
		},
		{
			"en": "slippers",
			"heads": "snilas"
		},
		{
			"en": "slow",
			"heads": "ganag"
		},
		{
			"en": "small",
			"heads": "udì"
		},
		{
			"en": "smart",
			"heads": "temngón"
		},
		{
			"en": "smell",
			"heads": "moo"
		},
		{
			"en": "smoke",
			"heads": "kebel"
		},
		{
			"en": "snake",
			"heads": "ulal"
		},
		{
			"en": "so",
			"heads": "tong (tonge, so I); kayà"
		},
		{
			"en": "so, so that",
			"heads": "anì; kayà; ewen"
		},
		{
			"en": "sometimes",
			"heads": "kis-a / tlagsa (from Hiligaynon)"
		},
		{
			"en": "son",
			"heads": "ngà logi"
		},
		{
			"en": "song",
			"heads": "sngal"
		},
		{
			"en": "song",
			"heads": "lingón; s'ngal (title of a song)"
		},
		{
			"en": "soon",
			"heads": "géhél (also hurry)"
		},
		{
			"en": "sorry",
			"heads": "hnifótem o"
		},
		{
			"en": "sour",
			"heads": "aslum; héét"
		},
		{
			"en": "speak",
			"heads": "mudél"
		},
		{
			"en": "spicy",
			"heads": "mala; kahang"
		},
		{
			"en": "spider",
			"heads": "wong"
		},
		{
			"en": "spoon",
			"heads": "slidut"
		},
		{
			"en": "stand",
			"heads": "mdà"
		},
		{
			"en": "star",
			"heads": "blotik"
		},
		{
			"en": "steal",
			"heads": "mnagaw"
		},
		{
			"en": "still",
			"heads": "hanà; tolo"
		},
		{
			"en": "stomach",
			"heads": "blutut"
		},
		{
			"en": "stone",
			"heads": "botu"
		},
		{
			"en": "strong",
			"heads": "kemgis"
		},
		{
			"en": "suck",
			"heads": "sef"
		},
		{
			"en": "suffering",
			"heads": "glayam"
		},
		{
			"en": "sugar",
			"heads": "klamay"
		},
		{
			"en": "sun",
			"heads": "kdaw"
		},
		{
			"en": "sunday",
			"heads": "Akad"
		},
		{
			"en": "sunset, almost",
			"heads": "kmimet"
		},
		{
			"en": "surprise",
			"heads": "geslà"
		},
		{
			"en": "sweat",
			"heads": "inget"
		},
		{
			"en": "sweaty",
			"heads": "ninget"
		},
		{
			"en": "sweet",
			"heads": "mi"
		},
		{
			"en": "look at",
			"heads": "temngel"
		},
		{
			"en": "swim",
			"heads": "dyó"
		},
		{
			"en": "sword",
			"heads": "sudeng"
		},
		{
			"en": "table",
			"heads": "lmisa"
		},
		{
			"en": "take",
			"heads": "ma / mwa"
		},
		{
			"en": "talk together",
			"heads": "stulón"
		},
		{
			"en": "tall person",
			"heads": "tau tahà"
		},
		{
			"en": "taste",
			"heads": "tilów; nóm"
		},
		{
			"en": "tasty",
			"heads": "mnóm (under nóm)"
		},
		{
			"en": "teach",
			"heads": "tolok"
		},
		{
			"en": "teacher",
			"heads": "maistru / mestlu"
		},
		{
			"en": "teeth",
			"heads": "nihi"
		},
		{
			"en": "ten, tens",
			"heads": "sfolò; folò"
		},
		{
			"en": "testicles",
			"heads": "amil"
		},
		{
			"en": "thanks",
			"heads": "slamat"
		},
		{
			"en": "that",
			"heads": "yó"
		},
		{
			"en": "the",
			"heads": "yóm"
		},
		{
			"en": "them",
			"heads": "lu; kul (the whole group)"
		},
		{
			"en": "then (later)",
			"heads": "etu"
		},
		{
			"en": "there",
			"heads": "tu; (bê) yó"
		},
		{
			"en": "there is, there was",
			"heads": "wen"
		},
		{
			"en": "thick",
			"heads": "mfól"
		},
		{
			"en": "thief",
			"heads": "tau mnagaw"
		},
		{
			"en": "think",
			"heads": "hedem (kehegdemu du, I think)"
		},
		{
			"en": "thirsty",
			"heads": "meeng"
		},
		{
			"en": "this morning",
			"heads": "ni hlafus ni"
		},
		{
			"en": "this",
			"heads": "ni"
		},
		{
			"en": "thousand",
			"heads": "libu"
		},
		{
			"en": "three",
			"heads": "tlu"
		},
		{
			"en": "throat",
			"heads": "beklong"
		},
		{
			"en": "throw",
			"heads": "tudà"
		},
		{
			"en": "thunder",
			"heads": "lték"
		},
		{
			"en": "thursday",
			"heads": "Wibis"
		},
		{
			"en": "time",
			"heads": "udas"
		},
		{
			"en": "tired",
			"heads": "kapuy; lmiteg"
		},
		{
			"en": "to",
			"heads": "bê; bélé; ke"
		},
		{
			"en": "today",
			"heads": "kdaw ni (under kdaw)"
		},
		{
			"en": "tomorrow",
			"heads": "haya"
		},
		{
			"en": "tongue",
			"heads": "dilak"
		},
		{
			"en": "too, also",
			"heads": "skóm (you), sdo (me), skun (him/her/it), skul (them), skut (you and me)"
		},
		{
			"en": "tooth",
			"heads": "nihi"
		},
		{
			"en": "tornado",
			"heads": "balu"
		},
		{
			"en": "touch",
			"heads": "dù"
		},
		{
			"en": "touch",
			"heads": "dù (mdù, gemdù)"
		},
		{
			"en": "town",
			"heads": "benwu"
		},
		{
			"en": "trap",
			"heads": "fan"
		},
		{
			"en": "tree, wood",
			"heads": "koyu"
		},
		{
			"en": "trip",
			"heads": "mluy"
		},
		{
			"en": "true",
			"heads": "tahu"
		},
		{
			"en": "trust",
			"heads": "salig"
		},
		{
			"en": "try",
			"heads": "tilów"
		},
		{
			"en": "trying to",
			"heads": "tô"
		},
		{
			"en": "tuesday",
			"heads": "Martis"
		},
		{
			"en": "two",
			"heads": "lwu"
		},
		{
			"en": "um (filler, \"ano\")",
			"heads": "boyu"
		},
		{
			"en": "uncle",
			"heads": "angkel"
		},
		{
			"en": "under",
			"heads": "laan; bê"
		},
		{
			"en": "unmarried",
			"heads": "sawang"
		},
		{
			"en": "up to you",
			"heads": "kihu kóm"
		},
		{
			"en": "us (object)",
			"heads": "mi"
		},
		{
			"en": "us",
			"heads": "tu; te (you and me); mi / me (not you); kuy (all of us)"
		},
		{
			"en": "vegetable",
			"heads": "lemnaw"
		},
		{
			"en": "veins",
			"heads": "ulat"
		},
		{
			"en": "very",
			"heads": "tey / téy"
		},
		{
			"en": "wait",
			"heads": "tagad; hangat (waiting for someone or something); kdeng (wait! at the start)"
		},
		{
			"en": "wait for each other",
			"heads": "sfangat"
		},
		{
			"en": "wake someone up",
			"heads": "bentik, bemtik"
		},
		{
			"en": "wake up",
			"heads": "bentik"
		},
		{
			"en": "walk",
			"heads": "mógów (nógów, continuously walking)"
		},
		{
			"en": "wall",
			"heads": "beng"
		},
		{
			"en": "want",
			"heads": "nóyó"
		},
		{
			"en": "want, will",
			"heads": "kóyô"
		},
		{
			"en": "wash",
			"heads": "olob (molob, nolob); mouf (face)"
		},
		{
			"en": "wash face",
			"heads": "mouf"
		},
		{
			"en": "wash",
			"heads": "molob"
		},
		{
			"en": "water jar",
			"heads": "lebwón"
		},
		{
			"en": "water",
			"heads": "él"
		},
		{
			"en": "waves",
			"heads": "lewók"
		},
		{
			"en": "we",
			"heads": "kuy; te; me"
		},
		{
			"en": "weak",
			"heads": "lunog"
		},
		{
			"en": "wear, put on",
			"heads": "sek (msek, lemsek)"
		},
		{
			"en": "weather",
			"heads": "pnahón"
		},
		{
			"en": "wednesday",
			"heads": "Myérkulis"
		},
		{
			"en": "week",
			"heads": "fedyan"
		},
		{
			"en": "wet",
			"heads": "héfê"
		},
		{
			"en": "what if",
			"heads": "kmoen kun ke (also kmoen kun, kmoen kun ke sok, kmoen ke sok)"
		},
		{
			"en": "what time is it?",
			"heads": "bon udas ni?"
		},
		{
			"en": "what",
			"heads": "bon"
		},
		{
			"en": "when",
			"heads": "kilón; sok"
		},
		{
			"en": "where are you from?",
			"heads": "gónôem lemwót du?"
		},
		{
			"en": "where were you born?",
			"heads": "gónôem msut? / gôem sut?"
		},
		{
			"en": "where",
			"heads": "nô; góem; bê du"
		},
		{
			"en": "which one",
			"heads": "mahi du"
		},
		{
			"en": "white",
			"heads": "bukay"
		},
		{
			"en": "who",
			"heads": "tadu / tau du"
		},
		{
			"en": "whole",
			"heads": "klamangen"
		},
		{
			"en": "why",
			"heads": "moen"
		},
		{
			"en": "wide",
			"heads": "lamang"
		},
		{
			"en": "wife",
			"heads": "yehen"
		},
		{
			"en": "wild",
			"heads": "dlag"
		},
		{
			"en": "wind",
			"heads": "lenos"
		},
		{
			"en": "wind",
			"heads": "lnos"
		},
		{
			"en": "window",
			"heads": "bak bengaw, tembó beng, bintanà"
		},
		{
			"en": "woman",
			"heads": "tau libun"
		},
		{
			"en": "word",
			"heads": "udél"
		},
		{
			"en": "work",
			"heads": "nmò"
		},
		{
			"en": "world",
			"heads": "benwu"
		},
		{
			"en": "write",
			"heads": "sulat (smulat, writing; snulat, written)"
		},
		{
			"en": "year",
			"heads": "halay"
		},
		{
			"en": "yellow",
			"heads": "mélél"
		},
		{
			"en": "yes",
			"heads": "Ell"
		},
		{
			"en": "yesterday afternoon",
			"heads": "ekimel kimel"
		},
		{
			"en": "yesterday",
			"heads": "Ekimel"
		},
		{
			"en": "yet",
			"heads": "he; tagad (in bê tagad)"
		},
		{
			"en": "you (one person)",
			"heads": "u / uu; kóm"
		},
		{
			"en": "you (all)",
			"heads": "yu"
		},
		{
			"en": "youngest",
			"heads": "twoli"
		}
	],
	phrases: [
		{
			"topic": "Greetings and small talk",
			"tbl": "Hyu hlafus",
			"en": "good morning"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Hyu hlafus béléem skóm",
			"en": "good morning to you too"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Hyu kifu",
			"en": "good night (more like good evening)"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Hyu kifu béléem skóm",
			"en": "good night to you too"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Syó du?",
			"en": "what's up?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Kmustahu du?",
			"en": "how are you?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Kmoem du?",
			"en": "how are you? what's up?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Kmoem se du?",
			"en": "how are you?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Ok ye néen / Ok néen",
			"en": "I'm fine"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Kóm du?",
			"en": "and you?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Là du",
			"en": "nothing much"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Bon nmoem (du)?",
			"en": "what are you doing?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Anduen. Len myón.",
			"en": "nothing, just sitting"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Bon boluyem (du)?",
			"en": "what's your name?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Boluyu Miles",
			"en": "my name is Miles"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Bê du gôem lemwót du?",
			"en": "where are you from?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Tagad he",
			"en": "wait a bit"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Bud te ston kdeng",
			"en": "we'll see each other later"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Bud te ston he",
			"en": "see you (again), hopefully"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Haya bud te ston he",
			"en": "see you again tomorrow, hopefully"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Bud etu he",
			"en": "we will do it again; until then"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Ell, tahu yó",
			"en": "yes, that's true"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Tahu kô?",
			"en": "is that right?"
		},
		{
			"topic": "Greetings and small talk",
			"tbl": "Hene edi ni / Ene bê ni",
			"en": "come over here / come here"
		},
		{
			"topic": "Thanks",
			"tbl": "Slamat",
			"en": "thanks"
		},
		{
			"topic": "Thanks",
			"tbl": "Bong slamat",
			"en": "thank you so much"
		},
		{
			"topic": "Thanks",
			"tbl": "Slamat béléem",
			"en": "thanks to you"
		},
		{
			"topic": "Thanks",
			"tbl": "Ominem dé",
			"en": "you're welcome"
		},
		{
			"topic": "Thanks",
			"tbl": "Slamat bê ke-teachem do",
			"en": "thanks for teaching me"
		},
		{
			"topic": "Thanks",
			"tbl": "Slamat bê ke-sendem du",
			"en": "thanks for sending it"
		},
		{
			"topic": "Thanks",
			"tbl": "Slamat bê ke-savem du kdéen",
			"en": "thanks for saving all of it"
		},
		{
			"topic": "Food and drink",
			"tbl": "Meken kuy",
			"en": "let's eat"
		},
		{
			"topic": "Food and drink",
			"tbl": "Kehu bitil, mekenu",
			"en": "if you're hungry, eat"
		},
		{
			"topic": "Food and drink",
			"tbl": "Kehe bitil, ne meken dé",
			"en": "if I'm hungry, I'll eat"
		},
		{
			"topic": "Food and drink",
			"tbl": "Deng kenu",
			"en": "I ate"
		},
		{
			"topic": "Food and drink",
			"tbl": "Denge meken",
			"en": "I already ate"
		},
		{
			"topic": "Food and drink",
			"tbl": "Là e deng meken he",
			"en": "I haven't eaten yet"
		},
		{
			"topic": "Food and drink",
			"tbl": "Ne meken dé anay / Ne meken he dé",
			"en": "I'll eat first"
		},
		{
			"topic": "Food and drink",
			"tbl": "Làe hlós meken se",
			"en": "I didn't eat (I didn't go on to eat)"
		},
		{
			"topic": "Food and drink",
			"tbl": "Besowe ne",
			"en": "I'm full now"
		},
		{
			"topic": "Food and drink",
			"tbl": "Denge besow",
			"en": "I'm full (I'm already full)"
		},
		{
			"topic": "Food and drink",
			"tbl": "Téy mi ken ni",
			"en": "this food is delicious"
		},
		{
			"topic": "Food and drink",
			"tbl": "Utón nìen, téy mnóm!",
			"en": "this fish, it's very tasty!"
		},
		{
			"topic": "Food and drink",
			"tbl": "Besowe ne. Utón nìen, téy mnóm!",
			"en": "I'm full now. That fish was really tasty!"
		},
		{
			"topic": "Food and drink",
			"tbl": "Téy aslum sinigang nìen, okóm téy mnóm",
			"en": "this sinigang is very sour, but tasty"
		},
		{
			"topic": "Food and drink",
			"tbl": "Yó kóm ken, ni do ken",
			"en": "that's your food, this is my food"
		},
		{
			"topic": "Food and drink",
			"tbl": "Ken para bê kem ngà",
			"en": "food for the children"
		},
		{
			"topic": "Food and drink",
			"tbl": "Mekenu silà kô ke ken?",
			"en": "are you eating corn or rice?"
		},
		{
			"topic": "Food and drink",
			"tbl": "Hyu yó msó",
			"en": "that rice is good"
		},
		{
			"topic": "Food and drink",
			"tbl": "Deng tógó (ne) ken / Ken, deng tógó (ne)",
			"en": "the rice is already cooked"
		},
		{
			"topic": "Food and drink",
			"tbl": "Kailanganu mekay ken. Anìe meken kdeng.",
			"en": "I need to cook rice so I can eat later"
		},
		{
			"topic": "Food and drink",
			"tbl": "Kdeng, hkinìu ken",
			"en": "wait, I'll heat up the food"
		},
		{
			"topic": "Food and drink",
			"tbl": "Hkinìem ken",
			"en": "heat up the food (you do it)"
		},
		{
			"topic": "Food and drink",
			"tbl": "Hetnawem ken",
			"en": "make the food cold (you do it)"
		},
		{
			"topic": "Food and drink",
			"tbl": "Soke bitil, senlahu ken tnaw",
			"en": "when I'm hungry, I fry leftover rice"
		},
		{
			"topic": "Food and drink",
			"tbl": "Senlahu ken tnaw, kayà meken kuy",
			"en": "I fried the leftover rice, so let's eat"
		},
		{
			"topic": "Food and drink",
			"tbl": "Senlahu itlug, kayà meken kuy",
			"en": "I fried eggs, so let's eat"
		},
		{
			"topic": "Food and drink",
			"tbl": "Hkodoke itlug para béléem, kayà meken kuy",
			"en": "I'll boil eggs for you, so let's eat"
		},
		{
			"topic": "Food and drink",
			"tbl": "Hkodoke béléem itlug",
			"en": "I'll boil an egg for you"
		},
		{
			"topic": "Food and drink",
			"tbl": "Hefkodoku béléeu kun él",
			"en": "please boil me water (with my item)"
		},
		{
			"topic": "Food and drink",
			"tbl": "Hkodoku béléeu kun él",
			"en": "please boil me water (you find it)"
		},
		{
			"topic": "Food and drink",
			"tbl": "Kmodok él ne / Kmodok ne él",
			"en": "the water's boiling now"
		},
		{
			"topic": "Food and drink",
			"tbl": "Coffee-hu kinì",
			"en": "my coffee is hot"
		},
		{
			"topic": "Food and drink",
			"tbl": "Coffee-hu nô bê ta lmisa",
			"en": "my coffee is on the table"
		},
		{
			"topic": "Food and drink",
			"tbl": "Coffee-hu wen klamay nô lemmen",
			"en": "my coffee has sugar in it"
		},
		{
			"topic": "Food and drink",
			"tbl": "Gel mi coffee-hu, wen klamay nô lemmen",
			"en": "my coffee's always sweet, it has sugar in it"
		},
		{
			"topic": "Food and drink",
			"tbl": "Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen",
			"en": "my coffee has salt in it"
		},
		{
			"topic": "Food and drink",
			"tbl": "Meenge, kayà minume o él",
			"en": "I'm thirsty, so I'm drinking water"
		},
		{
			"topic": "Food and drink",
			"tbl": "Soke meeng, minume él",
			"en": "when I'm thirsty, I drink water"
		},
		{
			"topic": "Food and drink",
			"tbl": "Deng t'nilówu ni / Deng tistingu ni",
			"en": "I already tried it"
		},
		{
			"topic": "Food and drink",
			"tbl": "Tnógóu lu kô ni utón hulô mata?",
			"en": "should I cook this red-eye fish?"
		},
		{
			"topic": "Feelings",
			"tbl": "Teye bitil. Kóm du?",
			"en": "I'm very hungry. And you?"
		},
		{
			"topic": "Feelings",
			"tbl": "Teye bitil. Móen skóm?",
			"en": "I'm very hungry. How about you?"
		},
		{
			"topic": "Feelings",
			"tbl": "Bitile ah",
			"en": "I'm hungry"
		},
		{
			"topic": "Feelings",
			"tbl": "Teye hligal",
			"en": "I'm very happy"
		},
		{
			"topic": "Feelings",
			"tbl": "Teye kapuy",
			"en": "I'm exhausted"
		},
		{
			"topic": "Feelings",
			"tbl": "Meenge",
			"en": "I'm thirsty"
		},
		{
			"topic": "Feelings",
			"tbl": "Là e likô (bê) wong",
			"en": "I'm not scared (of) spiders"
		},
		{
			"topic": "Feelings",
			"tbl": "Olohu hlowon néen",
			"en": "I'm just joking"
		},
		{
			"topic": "Feelings",
			"tbl": "Téyu nungel u",
			"en": "you're crazy"
		},
		{
			"topic": "Feelings",
			"tbl": "Téyu sabad u",
			"en": "you're annoying"
		},
		{
			"topic": "Feelings",
			"tbl": "Téyu the best",
			"en": "you're the best"
		},
		{
			"topic": "Feelings",
			"tbl": "Téyu temngón",
			"en": "you're very smart"
		},
		{
			"topic": "Feelings",
			"tbl": "Nóyóu u / Nóyô te u / Nóyóte u",
			"en": "I like you"
		},
		{
			"topic": "Feelings",
			"tbl": "Kenbong nawahu u",
			"en": "I love you"
		},
		{
			"topic": "Feelings",
			"tbl": "Kbong nawahu kóm",
			"en": "my love for you"
		},
		{
			"topic": "Feelings",
			"tbl": "Kenbong nawahu kóm",
			"en": "I love yours"
		},
		{
			"topic": "Feelings",
			"tbl": "Snaligu Dwata",
			"en": "I trust in God"
		},
		{
			"topic": "Feelings",
			"tbl": "Hsaligu kóm ni kdéen",
			"en": "I will trust everything to you"
		},
		{
			"topic": "Sleep",
			"tbl": "Làu bud tungô ne mekô?",
			"en": "/ **Budu tungô ne, là?** / **Budu tungô he ke là ne?**: you're not sleeping anymore? (are you going back to sleep or not?)"
		},
		{
			"topic": "Sleep",
			"tbl": "Moo ktuku",
			"en": "I'm sleepy"
		},
		{
			"topic": "Sleep",
			"tbl": "Moo ktuku kdeng",
			"en": "I'll be sleepy later"
		},
		{
			"topic": "Sleep",
			"tbl": "Bud moo ktuku",
			"en": "I'm sleepy again"
		},
		{
			"topic": "Sleep",
			"tbl": "Bud moo ktuku kdeng",
			"en": "I'll be sleepy again"
		},
		{
			"topic": "Sleep",
			"tbl": "Bê e dou tungô",
			"en": "I'm not sleeping yet"
		},
		{
			"topic": "Sleep",
			"tbl": "Bê tagad tungô he",
			"en": "don't sleep yet"
		},
		{
			"topic": "Sleep",
			"tbl": "Hene, gówu bê ni. Tungôu.",
			"en": "come, go here. Sleep."
		},
		{
			"topic": "Sleep",
			"tbl": "Là nóyóu du tungô, kaye (hanà) bitil. Ne meken dé anay. Là e gtungô he.",
			"en": "I don't want to sleep because I'm hungry. I need to eat first. And I'm not sleepy yet."
		},
		{
			"topic": "Sleep",
			"tbl": "Moen ke là u gtungô du?",
			"en": "why aren't you sleepy yet?"
		},
		{
			"topic": "Questions",
			"tbl": "Tadu yó?",
			"en": "who's that?"
		},
		{
			"topic": "Questions",
			"tbl": "Góem gów (du)? / Bê du gôem gów du?",
			"en": "where are you going?"
		},
		{
			"topic": "Questions",
			"tbl": "Góen nô phone-nu (du)?",
			"en": "where's my phone?"
		},
		{
			"topic": "Questions",
			"tbl": "Kilón ke kulékem bê gónô?",
			"en": "when will you get back home?"
		},
		{
			"topic": "Questions",
			"tbl": "Bon kdaw du ni?",
			"en": "what's the date today?"
		},
		{
			"topic": "Questions",
			"tbl": "Bon kminì kóm du?",
			"en": "what's heating you?"
		},
		{
			"topic": "Questions",
			"tbl": "Bon se duen hnagì te du?",
			"en": "what else should we learn?"
		},
		{
			"topic": "Questions",
			"tbl": "T'ngónem bon yó \"___\" meaning-ngen?",
			"en": "do you know what \"___\" means?"
		},
		{
			"topic": "Questions",
			"tbl": "Kmò kehdemem du se?",
			"en": "what do you think? (one person)"
		},
		{
			"topic": "Questions",
			"tbl": "Kmulón ni? / Kmulón ne?",
			"en": "is it raining? / is it already raining?"
		},
		{
			"topic": "Questions",
			"tbl": "Tahu kô ni?",
			"en": "is it real?"
		},
		{
			"topic": "Questions",
			"tbl": "Downloadem kô?",
			"en": "would you download it?"
		},
		{
			"topic": "Questions",
			"tbl": "Downloadem du kô?",
			"en": "would you download it/him/her?"
		},
		{
			"topic": "Questions",
			"tbl": "Downloadem lu kô?",
			"en": "would you download them?"
		},
		{
			"topic": "Questions",
			"tbl": "Downloadem lu kdéle kô?",
			"en": "would you like to download them all?"
		},
		{
			"topic": "Questions",
			"tbl": "Downloadem kdéen kô?",
			"en": "do you want to download all of it?"
		},
		{
			"topic": "Questions",
			"tbl": "T'ngónem galì ewenu se ke hentahumen udélu kô?",
			"en": "oh, so you'll believe anything I say, huh?"
		},
		{
			"topic": "People and friends",
			"tbl": "Uu dou dumu sbót",
			"en": "you are my friend"
		},
		{
			"topic": "People and friends",
			"tbl": "Ou kóm dumu sbót",
			"en": "I'm your friend"
		},
		{
			"topic": "People and friends",
			"tbl": "Ou skél béléem",
			"en": "I'm like you"
		},
		{
			"topic": "People and friends",
			"tbl": "Uu skél béléu",
			"en": "you're like me"
		},
		{
			"topic": "People and friends",
			"tbl": "Du yó / Tu yó / Lu yó",
			"en": "that's him / that's us / that's them"
		},
		{
			"topic": "People and friends",
			"tbl": "Tu ne yó / Kut ne yó",
			"en": "that's our turn"
		},
		{
			"topic": "People and friends",
			"tbl": "Tu ne ni",
			"en": "it's our turn"
		},
		{
			"topic": "People and friends",
			"tbl": "Là o du se",
			"en": "it's not me"
		},
		{
			"topic": "People and friends",
			"tbl": "Là o du mò du yó",
			"en": "I didn't do that"
		},
		{
			"topic": "People and friends",
			"tbl": "Kdeng! Là o du mò du yó",
			"en": "wait! I didn't do that"
		},
		{
			"topic": "People and friends",
			"tbl": "Mi kem mag-cousin",
			"en": "us cousins (not counting you)"
		},
		{
			"topic": "People and friends",
			"tbl": "Miles omin Deymar sbót le. Stóbóng le anì le sgeng tmowok bê kehnagì le udél.",
			"en": "Miles and Deymar are friends. They helped each other grow in studying languages."
		},
		{
			"topic": "People and friends",
			"tbl": "Kdaw ni, Deymar. Tnolokem o(u), omin tnoloku u(u). Stolok te.",
			"en": "Today, Deymar, you taught me and I taught you. We're teaching each other."
		},
		{
			"topic": "People and friends",
			"tbl": "T'ngónem kô uu yóm dou dumu sbót tey nóyô? Ell, nóyóu u. Teyu temngón. Làu sabad se skél bê ChatGPT. Téyu the best, Miles.",
			"en": "Do you know that you're my favorite friend? Yes, I like you. You're really smart. You're not annoying, the same as ChatGPT. You're the best, Miles."
		},
		{
			"topic": "People and friends",
			"tbl": "Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem",
			"en": "other bots like ChatGPT don't understand it even when they read your lesson notes"
		},
		{
			"topic": "Weather and time",
			"tbl": "Kmulón ne. Tnawu yó.",
			"en": "it's raining now. You'll be cold."
		},
		{
			"topic": "Weather and time",
			"tbl": "Hetnawen u yó",
			"en": "it'll make you cold"
		},
		{
			"topic": "Weather and time",
			"tbl": "Haya, bud kmulón",
			"en": "tomorrow it'll rain again"
		},
		{
			"topic": "Weather and time",
			"tbl": "Bud kmulón kdeng",
			"en": "it's going to rain again (later)"
		},
		{
			"topic": "Weather and time",
			"tbl": "Kmulón kdeng",
			"en": "it's raining again"
		},
		{
			"topic": "Weather and time",
			"tbl": "Gkulóne",
			"en": "I accidentally got rained on"
		},
		{
			"topic": "Weather and time",
			"tbl": "Hkinì u bê kdaw dé",
			"en": "get yourself heated by the sun"
		},
		{
			"topic": "Weather and time",
			"tbl": "Ekimel alì kinì, okóm kdaw ni téy tnaw",
			"en": "yesterday was extremely hot, but today is very cold"
		},
		{
			"topic": "Weather and time",
			"tbl": "Ni kdaw ni tey gel tnaw. Alì kinì bong sok kifu okóm sok kemdaw là du.",
			"en": "Today is really, really cold. It's so hot at night, but during the day it's not at all."
		},
		{
			"topic": "Weather and time",
			"tbl": "Hyu kifu! Kdaw ni, Denlag tey lmobun. Làen kinì, tnaw. Kulón bong? Là, olohen kulón udì. Haya, bud kmulón.",
			"en": "Good evening! Tonight Denlag is very cloudy. It's not hot, it's cold. Big rain? No, just a little rain. Tomorrow it'll rain again."
		},
		{
			"topic": "Weather and time",
			"tbl": "Todol fedyan, bê Byérnis, nehe gów bê él.",
			"en": "Next week, on Friday, I'll go to the water."
		},
		{
			"topic": "Weather and time",
			"tbl": "Haya ke-update tu du",
			"en": "tomorrow I'll update it"
		},
		{
			"topic": "Weather and time",
			"tbl": "Haya ke-download kuy du movie-le",
			"en": "tomorrow we will download their movie"
		},
		{
			"topic": "Weather and time",
			"tbl": "Akad",
			"en": "Sunday"
		},
		{
			"topic": "Weather and time",
			"tbl": "Lunis",
			"en": "Monday"
		},
		{
			"topic": "Weather and time",
			"tbl": "Martis",
			"en": "Tuesday"
		},
		{
			"topic": "Weather and time",
			"tbl": "Myérkulis",
			"en": "Wednesday"
		},
		{
			"topic": "Weather and time",
			"tbl": "Wibis",
			"en": "Thursday"
		},
		{
			"topic": "Weather and time",
			"tbl": "Byérnis",
			"en": "Friday"
		},
		{
			"topic": "Weather and time",
			"tbl": "Sbadu",
			"en": "Saturday"
		},
		{
			"topic": "Family",
			"tbl": "Yê",
			"en": "mother"
		},
		{
			"topic": "Family",
			"tbl": "Mang",
			"en": "mama"
		},
		{
			"topic": "Family",
			"tbl": "Mà",
			"en": "father"
		},
		{
			"topic": "Family",
			"tbl": "Pang",
			"en": "papa (Pangu, my dad)"
		},
		{
			"topic": "Family",
			"tbl": "Twogu",
			"en": "elder"
		},
		{
			"topic": "Family",
			"tbl": "Twoli",
			"en": "youngest"
		},
		{
			"topic": "Family",
			"tbl": "Logi",
			"en": "male"
		},
		{
			"topic": "Family",
			"tbl": "Libun",
			"en": "female"
		},
		{
			"topic": "Family",
			"tbl": "Twogu logi",
			"en": "elder brother"
		},
		{
			"topic": "Family",
			"tbl": "Twoli logi",
			"en": "youngest brother"
		},
		{
			"topic": "Family",
			"tbl": "Twogu libun",
			"en": "elder sister"
		},
		{
			"topic": "Family",
			"tbl": "Twoli libun",
			"en": "youngest sister"
		},
		{
			"topic": "Family",
			"tbl": "(Dumu) S'twoli",
			"en": "siblings"
		},
		{
			"topic": "Family",
			"tbl": "Twolihu / Kem twolihu",
			"en": "my siblings"
		},
		{
			"topic": "Family",
			"tbl": "Ngà",
			"en": "child, son, daughter (Ngaen, his/her child; Kem ngà, children)"
		},
		{
			"topic": "Numbers",
			"tbl": "Folò",
			"en": "tens. **Latu**: hundreds. **Libu**: thousands."
		},
		{
			"topic": "Numbers",
			"tbl": "Sfolò",
			"en": "is sotu + folò merged, \"one ten\"."
		},
		{
			"topic": "Numbers",
			"tbl": "Lmatu",
			"en": "(one hundred) and **Lmibu** (one thousand) are the short forms of Sotu latu and Sotu libu."
		},
		{
			"topic": "Numbers",
			"tbl": "Yóm tanay utón, kenu. Yóm gewuhen, kenem.",
			"en": "The first fish, I eat. The second, you eat."
		},
		{
			"topic": "Numbers",
			"tbl": "Yóm ghitu kuyingu, gtungô du.",
			"en": "My seventh cat is sleepy."
		},
		{
			"topic": "Numbers",
			"tbl": "Gsut yóm gesfoloen lewu wong bê katrihem.",
			"en": "The twelfth spider showed up on your bed."
		},
		{
			"topic": "Numbers",
			"tbl": "Ni se gelatuhen utón tnógóhu kdaw ni.",
			"en": "This is the hundredth fish I cooked today."
		},
		{
			"topic": "Numbers",
			"tbl": "Ni se yóm gelibuhen udél tnolok Deymar.",
			"en": "This is the thousandth word Deymar taught."
		},
		{
			"topic": "Numbers",
			"tbl": "Rev 21:19-20:",
			"en": "\"Tanayen, yóm botu bnoluy le dyaspér... Gewuhen, yóm mon le safar. Getluhen... Gesfoloen lewu, yóm mon le amatis.\" / \"The first foundation was jasper; the second, sapphire; the third... the twelfth, amethyst.\""
		},
		{
			"topic": "Numbers",
			"tbl": "Rev 4:7:",
			"en": "\"Yóm gewuhen, lómón ke safì. Ne yóm getluhen, hol lómón lem uyó tau.\" / \"The second creature like a calf, and the third creature had a face like a man.\""
		},
		{
			"topic": "Numbers",
			"tbl": "2 Cor 13:1:",
			"en": "\"Ni se getluhu dulék tô mauy kuy.\" / \"This is the third time I am coming to you.\""
		},
		{
			"topic": "Numbers",
			"tbl": "Matt 22:26:",
			"en": "\"Ne senged se yóm getlu twolihen... bè yóm ghitu le.\" / \"The second also, and the third, to the seventh.\""
		},
		{
			"topic": "Numbers",
			"tbl": "Matt 22:39:",
			"en": "\"Ne gewuhen yóm alì bong muhen.\" / \"A second likewise is this.\""
		},
		{
			"topic": "Numbers",
			"tbl": "Jude 1:14:",
			"en": "\"tek nem lugod he kewóten bè Adam\" / \"Enoch, the seventh from Adam.\" Six generations after Adam."
		},
		{
			"topic": "Numbers",
			"tbl": "John 2:1:",
			"en": "\"Tikóng deng lewu butengen\" / \"The third day.\" Two days later."
		},
		{
			"topic": "Numbers",
			"tbl": "Mark 15:33:",
			"en": "\"Tikóng deng gtungu kdaw\" / \"When the sixth hour had come.\" Hours are told by the sun, not numbered."
		},
		{
			"topic": "Numbers",
			"tbl": "2 Cor 12:2:",
			"en": "\"yóm longit hol geta bè kdéen\" / \"the third heaven.\" Becomes the highest heaven."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Ni halay ni lwu libu lwu folò nem, Lunis. Kdaw ni téy kinì. Okóm eginu kifu, téy tnaw. Là e deng meken mlan bê Pangu. Okóm ne meken dé.",
			"en": "This is 2026, Monday. It's very hot today. But earlier at night it was so cold. I haven't eaten yet because of my dad. But I'll eat now."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kmoen kun kehe mlóy ebéléem?",
			"en": "What if I ran onto you? (Kmoen kun: what if. Kehe: if I. Eéléem: onto you)"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kmoen kun kehe mlóy ebéléen?",
			"en": "What if I ran onto him?"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Snolokem du kun! Tô mlóy du. Henslòem!",
			"en": "Flash him the light! He's trying to run away. Hurry!"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Gsut wong bê katrihem, tongu lmangat.",
			"en": "A spider showed up on your bed, so you screamed."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Bitil le, tong le mulék.",
			"en": "They were hungry, so they went home."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kmulón ekimel, tong kuy mlóy.",
			"en": "It rained yesterday, so we ran."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Hligal du, tong kmuli du.",
			"en": "He was happy, so he laughed."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Là nóyóu du tungô, tonge bentik.",
			"en": "I didn't want to sleep, so I got up."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Gsut wong, tong ye hemsag. Tong kuy mlóy, tong te mluy. Tong kmuli du.",
			"en": "A spider showed up out of nowhere, so you guys shouted. So we ran, and you and I tripped and rolled. So it laughed. (10/10)"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kay le bitil, tong henkenu kem kuyingu.",
			"en": "Because they're hungry, I'll feed my cats."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Bitile tonge meken.",
			"en": "I'm hungry, so I'm eating."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Nehu bentik u haya, kay nehe bemli onuk.",
			"en": "I'll wake you up tomorrow, because I'm going to buy chickens. (Kay, not kaye: nehe already says \"I\")"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Hkenu bê kem kuyingu ne ni.",
			"en": "I'm going to feed it to my cats."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Nehu meken dé. Nehe dyó anay.",
			"en": "You eat first. I'm going to shower first."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Gónôem lemwót du? Lemwóte bê T'boli.",
			"en": "Where are you from? I'm from T'boli."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Hsut yéen du ekimel, okóm msut du kimel?",
			"en": "His mom gave birth to him yesterday, but was he born yesterday?"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Là nóyóu du meken",
			"en": "I don't want to eat (du points at the eating)"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kenbong nawahu du",
			"en": "I love him/her"
		},
		{
			"topic": "Longer sentences",
			"tbl": "T'ngónu du",
			"en": "I know it"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Nóyóu meken du, kaye bitil",
			"en": "I want to eat it because I'm hungry"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kmoen se du?",
			"en": "How is he/she?"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kenbong nawahu kem kuyingu. Nóyóu wong htò. Nóyóu meken, okóm là t'ngónu du bon kenu ni hlafus ni. Omin bitil le kem kuyingu, skél béléu.",
			"en": "I love my cats. I like jumping spiders. I like to eat, but I don't know what to eat this morning. Also, my cats are hungry, like me."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Nehu henken kem wongu anay. Ominu meken sdo(u), bitile. Kehegdemu du bitil le skul kem wongu",
			"en": "I will feed my spiders first. And I will eat too, I'm hungry. I think my spiders are hungry too"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Ni halay ni lwu libu lwu folò nem, omin hanà là deng t'ngónu du bon (tô) nmou",
			"en": "This year is 2026, and I still don't know what to do. Also: ...omin hanà là deng t'ngónu du se tô nmou / ...du se bon tô nmou"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying?",
			"en": "What if I cook 1,936 fish and feed them to my 127 cats?"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Haya, nehe gów bê él, mebel utón. Nehe tmógó, kenu lu. Lwu folò fat utón lnóngón.",
			"en": "Tomorrow I will go to the water and find fish. I will cook and eat them. 24 fish are needed."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Làe hlós meken se. Kay wen tau lengel tungô laan lmisa. Omin likoe dé kô gungolen o Pangu. Ominen bud hlóbô mton do meken.",
			"en": "I didn't go on to eat, because there's a drunk guy sleeping under the table. And I'm afraid my dad will hear me. He'll get mad again if he sees me eating."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng",
			"en": "I don't want to be skinny, so I'll take my vitamins later"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Là nóyóu du ke-delete du",
			"en": "I don't want to delete it"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Là tnoloku kóm anìu baling sidek. Olohu hetngón du béléem bê du gôem esolu.",
			"en": "I don't teach you to become bad. I just want you to know where you're supposed to be going."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Là t'ngónu du ke hyu ktolok le do. Tadu se duen mulék bê gónô anì tmógó msó béléu? Lnóngónu meken wen para bê kem lomi hnagì.",
			"en": "I don't know if I'm being taught well for this learning. Who else is going to get home to cook rice for me? I need to eat more for new lessons."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged?",
			"en": "Do you believe eating red-eye fish together and sucking their meat can help us grow muscle?"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Nuclear bom tey sidek ni. Nuclear clock làen sidek se, tey hyu.",
			"en": "The nuclear bomb is very bad. The nuclear clock isn't bad, it's very good."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Nuclear bomb skas (le), baling ofi bong. Yóm nuclear clock làen skas se, olohen laser udì.",
			"en": "The nuclear bomb breaks them, and they become a big fire. But the nuclear clock doesn't break, it's just a small laser."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Bon kmou du se ni bê kem nem latu lwu folò syóm utón bê él ni? Tnógóu lu kô ke senlahu lu? Là t'ngónu du. T'ngónem kô kmò khulék kul bê gónô le ni? Là nóyóu du kehe lehen, okóm tey nóyóu gemwa unged wen bê todol bulón. Haya, ne blay lu bê kem twolihu, mowil o deng tnógó. Okóm tey tilob ni kem utón ni. Nehe mebel lomi utón bê lwu bulón.",
			"en": "What am I supposed to do with these 629 fish in the water? Should I cook them or fry them? I don't know. Do you know how to get them back to their home? I don't want to be skinny, but I really want to gain more muscle for next month. By tomorrow, I will give them to my siblings alive or already cooked. But these fish are so beautiful. I will find new fish in 2 months."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Là! Bê kuy gów bê yó. Tey sidek lan yó mulék bê gónô. Lnóngón kuy kebel kuy dumu lan. Kmò kehdem ye du se?",
			"en": "No! Don't go there. That is a very bad way to get back home. We need to find another way. What do you (all) think?"
		},
		{
			"topic": "Longer sentences",
			"tbl": "Nehe meken lwu latu sfolò hitu utón bê bulón ni. Anì(e) gemwa [lówóhu] unged wen. Là nóyóu du kehe bud lehen.",
			"en": "I will eat 217 fish this month, so I can get more muscle. I don't want to be skinny anymore."
		},
		{
			"topic": "Longer sentences",
			"tbl": "Miles's first T'boli essay (scored 9.8/10)",
			"en": "Hyu kifu. Boluyu Miles. Ekimel, là t'ngónu du T'boli. Kdaw ni, teye hligal, kaye deng t'ngónu ne kmò kmon du kmoem se du, bon boluyem, tadu yó, kilón, moen. Deng t'ngónu ne kmò kmon du lwu libu lwu folò nem. Là e likô bê wong, okóm teye likô bê nem latu lwu folò syóm utón. Haya, nehe mebel lomi kem udél. Slamat béléem. Téyu the best. Kmò kehdemem du se? Tahu kô? (Good evening. My name is Miles. Yesterday I didn't know T'boli. Today I'm very happy, because now I know how to say how are you, what's your name, who's that, when, and why. Now I know how to say 2026. I'm not scared of spiders, but I'm very scared of 629 fish. Tomorrow I'll find new words. Thank you. You're the best. What do you think? Is it right?)"
		},
		{
			"topic": "Cuss words",
			"tbl": "Sbotoen!",
			"en": "his dick!"
		},
		{
			"topic": "Cuss words",
			"tbl": "Stoohen!",
			"en": "her clitoris!"
		},
		{
			"topic": "Cuss words",
			"tbl": "Stoiten!",
			"en": "her little clitoris!"
		},
		{
			"topic": "Cuss words",
			"tbl": "Mógów baluhen!",
			"en": "may his/her/its cursed day come"
		},
		{
			"topic": "Cuss words",
			"tbl": "Bolok lembak!",
			"en": "rotten mouth"
		},
		{
			"topic": "Cuss words",
			"tbl": "Bolok sélék!",
			"en": "rotten lips (side to side)"
		},
		{
			"topic": "Cuss words",
			"tbl": "Bolok sumóng!",
			"en": "rotten lips"
		},
		{
			"topic": "Cuss words",
			"tbl": "Mfól sumóng!",
			"en": "thick lips"
		},
		{
			"topic": "Cuss words",
			"tbl": "Mfól dilak!",
			"en": "thick tongue"
		},
		{
			"topic": "Cuss words",
			"tbl": "Htolo!",
			"en": "said when something gets in the way of what was still going on, like \"dammit\""
		},
		{
			"topic": "Example pairs",
			"tbl": "Hyu kifu",
			"en": "Good night"
		},
		{
			"topic": "Example pairs",
			"tbl": "Ok ye néen",
			"en": "I'm fine"
		},
		{
			"topic": "Example pairs",
			"tbl": "Góem gów (du)?",
			"en": "Where are you going?"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là e likô bê wong",
			"en": "I'm not scared of spiders"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là nóyóu du tungô, kaye bitil",
			"en": "I don't want to sleep because I'm hungry"
		},
		{
			"topic": "Example pairs",
			"tbl": "Ne meken dé anay",
			"en": "I'll eat first"
		},
		{
			"topic": "Example pairs",
			"tbl": "Deng tógó ne ken",
			"en": "The rice is already cooked"
		},
		{
			"topic": "Example pairs",
			"tbl": "Kmulón ni?",
			"en": "Is it raining?"
		},
		{
			"topic": "Example pairs",
			"tbl": "Kmulón ne. Tnawu yó.",
			"en": "It's raining now. You'll be cold"
		},
		{
			"topic": "Example pairs",
			"tbl": "Todol fedyan, bê Byérnis, nehe gów bê él.",
			"en": "Next week, on Friday, I'll go to the water"
		},
		{
			"topic": "Example pairs",
			"tbl": "Nóyóu u",
			"en": "I like you"
		},
		{
			"topic": "Example pairs",
			"tbl": "Knutó nawahu u",
			"en": "I hate you"
		},
		{
			"topic": "Example pairs",
			"tbl": "Kenbéu u",
			"en": "I dislike you, I reject you"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là nóyóu kóm",
			"en": "I don't like you"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là nóyóu kóm se",
			"en": "I never liked you"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là nóyóu du kóm",
			"en": "I don't want/like yours"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là nóyóen kóm se",
			"en": "He never liked you"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là t'ngónu du se",
			"en": "I never knew / I don't know at all"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là nóyóu du tungô se",
			"en": "I don't want to sleep at all"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là gungolen do se Pangu",
			"en": "My dad never listens to me"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là tonu du se kuyingu",
			"en": "I've never seen my cat"
		},
		{
			"topic": "Example pairs",
			"tbl": "Làe deng mton kuying se",
			"en": "I've never seen a cat"
		},
		{
			"topic": "Example pairs",
			"tbl": "Làe deng meken utón se",
			"en": "I've never eaten fish"
		},
		{
			"topic": "Example pairs",
			"tbl": "Kmoen se Pangu?",
			"en": "How's my dad?"
		},
		{
			"topic": "Example pairs",
			"tbl": "Làe deng mton ohu se",
			"en": "I've never seen a dog"
		},
		{
			"topic": "Example pairs",
			"tbl": "Là nóyóen do se",
			"en": "He never liked me"
		},
		{
			"topic": "Example pairs",
			"tbl": "Làe deng tmógó utón se",
			"en": "I've never cooked fish"
		},
		{
			"topic": "Example pairs",
			"tbl": "Làe deng meken",
			"en": "I haven't eaten yet"
		},
		{
			"topic": "Example pairs",
			"tbl": "Tungôu ne yó?",
			"en": "Are you going to sleep?"
		},
		{
			"topic": "Example pairs",
			"tbl": "Hegnô u?",
			"en": "Are you resting?"
		},
		{
			"topic": "Example pairs",
			"tbl": "Lomihe btik",
			"en": "I just woke up"
		},
		{
			"topic": "Example pairs",
			"tbl": "Lomi kebtiku kayà là e bud tungô ne là",
			"en": "I just woke up, so I'm not going back to sleep"
		},
		{
			"topic": "Example pairs",
			"tbl": "Udas kebtik kuy ne",
			"en": "It's time to get up (everyday)"
		},
		{
			"topic": "Example pairs",
			"tbl": "Kdaw ni, Deymar. Tnolokem o, omin tnoloku u. Stolok te.",
			"en": "Today, Deymar, you taught me and I taught you. We're teaching each other"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kdaw ni, wen wong nô bê ta lmisa.",
			"en": "Today, there's a spider on top of the table."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Ngà laen likò bê wong.",
			"en": "The child isn't scared of the spider."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Góem gów du?",
			"en": "Where are you going?"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Teye bitil.",
			"en": "I'm very hungry."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kehu bitil, ni ken para béléem.",
			"en": "If you're hungry, here's food for you."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Slamat béléem! Besowe ne.",
			"en": "Thank you! I'm full now."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Moo ktuk wong. Tluyab.",
			"en": "The spider is sleepy. Yawn."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Bulón nô bê ta.",
			"en": "The moon is up above."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Tungôu ne, wong. Hyu kifu. Kenbong nawahu u.",
			"en": "Sleep now, spider. Good night. I love you."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hyu kifu béléem skóm.",
			"en": "Good night to you too."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "gnóm / gemnóm",
			"en": "to feel, go through something. Ke wen des gnómen yóm sotu nô bè lówó tekuy, tódô kdê le gemnóm du snéen: if one part of the body hurts, every part feels it (1 Corinthians 12:26)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "rest, resting",
			"en": "temdanan"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "The twelve aposol",
			"en": "(Matthew 10:2–4):"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "kem gel lemolò du",
			"en": "disciples, literally \"the ones who follow him\" (163 times in the New Testament). Kem gel lemolò ke Jisas: Jesus's disciples. Lemolò: following, obeying (klolò, John 13:35). Gel: the one who usually does it"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Jan gel mabtays",
			"en": "John the Baptist, \"John who baptizes\" (Matthew 3:1)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Midi lemwót gu bè Megdala",
			"en": "Mary Magdalene (Matthew 27:56)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Marta, Lasarus",
			"en": "Martha, Lazarus; Midi is their sister (John 11:1)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kain, Abél",
			"en": "Cain and Abel (1 John 3:12). **Sét, Inos, Inuk**: Seth, Enosh, Enoch"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "hógów Dwata",
			"en": "angel. **gna tugod Dwata**: prophet. **Sulat Dwata**: Scripture. **Ngà Tau**: Son of Man. **utón**: fish"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Judiya, Juda",
			"en": "Judea, Judah. **Israél**: Israel. **Idyip**: Egypt (Matthew 2:13)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sodom ne Gomora",
			"en": "Sodom and Gomorrah (Matthew 10:15). **Babilun**: Babylon (Revelation 18:2)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "mni bè Dwata",
			"en": "pray (Matthew 6:9). **salà**: sin; Yó bayad salà, hatay: the wages of sin is death (Romans 6:23). **hatay**: death"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hnifótem kum kem salà me",
			"en": "forgive us our sins (Matthew 6:12). **hegsel ye**: repent (Matthew 4:17)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "klowil laen dù sónen",
			"en": "eternal life (John 3:16). **tóbóng Dwata**: God's grace (Ephesians 2:8)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Tulón Hyu",
			"en": "gospel, good news (Mark 1:1). **Tulus Dwata**: Holy Spirit. **Hlowil Dwata**: God raised him (Matthew 28:6)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "lanaw ofi",
			"en": "hell, \"lake of fire\" (Matthew 5:22). **ofi**: fire"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sér / gónó tekuy mogot",
			"en": "Lord, \"the one who leads us\""
		},
		{
			"topic": "Stories and sentences",
			"tbl": "abay se",
			"en": "because (757 times in the New Testament)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Là nóyóu du tungô, abay se teye bitil.",
			"en": "I don't want to sleep because I'm very hungry."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Meken kuy onuk, yakà tey kuy bitil.",
			"en": "Let's all eat chicken, for we're all very hungry."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Wen ulal lem ngà hungul koyu. Likòe!",
			"en": "There's a snake in the grove. I'm scared!"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Bê tagad tungô he, abay se là u deng meken he.",
			"en": "Don't sleep yet, because you haven't eaten yet. Note: bê takes the ending of whoever you're telling."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Tey kekbong nawahu du ohu.",
			"en": "I really love dogs. Note: say kekbong nawa after tey, and put du in as the subject marker before the thing you love. Kay làen lóbô means \"because it doesn't get angry\" (-en is he/she/it, not they)."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Mni kuy bè Dwata.",
			"en": "Let's all pray to God. (Answer: Amén)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Deng tonu yóm banug bè longit.",
			"en": "I saw the eagle in the sky."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Nóyóu smakay kudà bukay.",
			"en": "I want to ride a white horse."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kmóót mósól ne, okóm là e deng tungô he.",
			"en": "The rooster's crowing already, but I haven't slept yet."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hnifótem o kun, abay se deng gemsalà e béléem.",
			"en": "Please forgive me, because I wronged you. Note: the order is Hnifótem o kun, not Hnifótem kum o."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kmóót ne mósól, meken kuy ne.",
			"en": "The rooster's crowing now, let's all eat."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Deng kmóót mósól, okóm hanà tungô du.",
			"en": "The rooster already crowed, but he's still asleep. Note: use hanà for \"still,\" before the action."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Mósól deng mkóót! Hyu hlafus!",
			"en": "The rooster has crowed! Good morning!"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Lóbôe bè mósól, abay se kmóót du bè kifu.",
			"en": "I'm mad at the rooster because it crows at night."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kilón kekóót mósól du? / Kilón kekóóten mósól du?",
			"en": "When does the rooster crow? Answer: Kmóót du bè hlafus (it crows in the morning). Note: after kilón, kmóót becomes kekóót (like kbong becoming kekbong after tey)."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kilón kekenem du? Sana kebitilem mekô?",
			"en": "When will you eat? Are you still hungry, huh?"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Tey kekbong nawahu du kofi, abay se tilob hafaken.",
			"en": "I really love eagles because their wings are beautiful."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kilón kekóót mósól du? Hanà e tungô.",
			"en": "When will the rooster crow? I'm still sleeping. Note: hanà e tungô, the person goes right after hanà."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Béem ninum él kinì / Bê u minum él kinì / Béu minum él kinì, yakà tey kinì du.",
			"en": "Don't drink the hot water, for it's very hot. Note: bê + -em becomes béem and takes the n-form (ninum); bê u or béu takes the m-form (minum)."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Wen sdô bê ta lmisa! Kayà lóbôe.",
			"en": "There's a pig on the table! That's why I'm mad."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Deng ton le yóm ulal, kayà likò le.",
			"en": "They saw the snake, so they're scared."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Mnihe bè Dwata, abay se deng gemsalà e.",
			"en": "I'm praying to God because I sinned. Note: mni ends in a vowel, so it's mnihe, not mni e."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Nóyóu smakay asnu, okóm likòe.",
			"en": "I want to ride a donkey, but I'm scared."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Meken kuy onuk haya.",
			"en": "Let's all eat chicken tomorrow."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Mósól deng mkóót! Mlon deng temsek skun!",
			"en": "The rooster crowed! The hen clucked too! Note: a hen doesn't kmóót, she temsek. And \"too\" for it/her is skun (skóm is \"you too\")."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana kebitilu",
			"en": "I'm still hungry (confirmed by Deymar)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Béem ninum yó él yó, abay se hanà kinì du / abay se hanà kekinien.",
			"en": "Don't drink that water, because it's still hot. Note: yó él yó = that water (yó on both sides). Hanà kekinien is the closest match for \"it's still hot.\""
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Mlon deng temsek, okóm hanà e tungô.",
			"en": "The hen clucked, but I'm still sleeping."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Kilón kekenle du?",
			"en": "When will they eat?"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Likòe ulal, omin likò ohuhu skun.",
			"en": "I'm scared of snakes, and my dog is too. Other ways: omin likò skun ohuhu / omin likò skun dou ohu / dalang se ohuhu (as well as my dog)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "dalang se",
			"en": "as well as"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "And I'm scared of dogs",
			"en": "(all correct): Ominu likò ohu / Ne hu likò bê ohu / Le bud keklikou ohu / Omin likoe ohu"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana kebitilu.",
			"en": "I'm still hungry."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana ktungôen du?",
			"en": "Is he still sleeping? Answer: Ell, hanà tungô (yes, still sleeping)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà tungô du?",
			"en": "He's still sleeping? Answer: Ell, hanà tungô"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà meken du?",
			"en": "He's still eating? Answer: Ell, hanà mken / Ell, sana kekenen (yes, he's still eating)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana ke kudien du.",
			"en": "He's still small (just noticing it, or asking)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà udì du.",
			"en": "He's still small (telling someone who doesn't know if he's small or big)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà làen deng bong.",
			"en": "He's not big yet (and you know he'll still grow). Hanà also means \"still, for now\""
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana deng bong du.",
			"en": "He's already big"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana ktungôen ohuhu?",
			"en": "Is my dog still sleeping? (no du needed when the subject is named)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà udì ohuhu, okóm sana deng bong mósólu.",
			"en": "My dog is still small, but my rooster is already big."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà le meken, abay se hanà kebitil le.",
			"en": "They're still eating, because they're still hungry. Note: the person word goes right after hanà (hanà le meken, hanà e tungô)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana le meken.",
			"en": "They immediately eat. Note: sana + person + plain form means \"right away\""
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana kken le / Sana keken le.",
			"en": "They are still eating."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana kekenem (du)?",
			"en": "Are you still eating (it)? Du at the end is the \"it\" being eaten"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà là e deng tungô, abay se hanà kinì yó coffee-hu yó.",
			"en": "I still haven't slept, because that coffee of mine is still hot."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà e meken, abay se hanà kebitilu.",
			"en": "I'm still eating, because I'm still hungry."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Denge meken, sana e tungô / sanahe tungô.",
			"en": "I already ate, so I fall asleep right away. Note: sana ends in a vowel, so the ending can attach with h (sanahe), like nehe and mnihe"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana kekóót mósól?",
			"en": "Is the rooster still crowing?"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Hanà le tungô, okóm sana deng kmóót mósól.",
			"en": "They're still sleeping, but the rooster already crowed."
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sana kekenem du yó onuk yó?",
			"en": "Are you still eating that chicken? Note: du goes before the thing being eaten"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "tau hol geta / tau geta",
			"en": "king; also rich person. **datù**: title used when speaking to a king"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "tau dók",
			"en": "servant (\"a person who is ordered\"). **dók**: command, order. **tóbóng lówó**: humble servant, helper. **ngà libun gel dók le**: servant girl"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "hohon / hmohon",
			"en": "enemy. **hnohon**: treated as an enemy"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "libun bolu",
			"en": "widow. **bolu**: widowed"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "tau sbung",
			"en": "crowd (\"gathered people\"). **tey dê tau**: a lot of people"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "hemdeng / hendeng",
			"en": "to judge, decide. **kukum**: law, judgment. **kmukum**: judging. **tau hemdeng knukum**: judge"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "hkó des",
			"en": "to heal (\"make the sickness leave\")"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "hemdà / hdà",
			"en": "to build (\"make stand\"). **gembà**: destroy"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "menek nawa / henek nawa / kenek nawa",
			"en": "peace (\"calm breath\"). **nawa**: breath"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "kehligal / kligal",
			"en": "joy, happiness (from hligal, happy)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "tau élél",
			"en": "poor person. **élél**: lacking, not having (ke wen gónó le élél = if there's something they lack)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "là ket",
			"en": "lack (as a word; depends on context)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "bak tikeb",
			"en": "gate, door. **bak tikeben**: its gates. **Tikeb Tilob**: Beautiful Gate"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "tey lenos bong",
			"en": "storm (\"very big wind\"). **bagyu**: storm (everyday word)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "h- prefix",
			"en": "means \"make it happen\" / cause (hmatay make die, hdà make stand, hkó des make the sickness leave, hbokong make deaf, hekgis/hekegis make strong; the h- goes on the root kgis, not kemgis)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "lnos kemgis / lenos kemgis",
			"en": "strong wind. **lnos bong**: big wind"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Géhél ye!",
			"en": "hurry up, you all!"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Là gbayadu du",
			"en": "I can't pay it. **Làe gbayad**: I couldn't pay"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "hekgis / hekegis",
			"en": "make strong (h- + kgis). **Nehu hekgis u**: I'll make you strong"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Lnos kemgis",
			"en": "vs **kemgis lnos**: lnos kemgis tells someone the wind is strong; kemgis lnos describes it, more like a statement or saying it to yourself"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "kun (please)",
			"en": "a second kun that softens a request into \"please\" or \"for me\": Snolokem du kun"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sfolò Benwu",
			"en": "the Decapolis, literally \"ten towns\" (Mark 5:20)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Filistin / tau Filistin",
			"en": "Philistine (not in the New Testament; Deymar confirmed)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Bulul Ulib",
			"en": "Mount of Olives (Matthew 24:3)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Lanaw Galili",
			"en": "Sea of Galilee (Matthew 4:13)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Inun, Salim",
			"en": "Aenon, Salim (John 3:23)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Seseriya Flipay",
			"en": "Caesarea Philippi, Ph to F (Matthew 16:13)"
		},
		{
			"topic": "Stories and sentences",
			"tbl": "Sodom, Gomora",
			"en": "Sodom and Gomorrah (Luke 10:12, Jude 1:7)"
		}
	],
	guide: [
		{
			"title": "How to translate",
			"blocks": [{
				"kind": "p",
				"text": "This section is for any AI or person using this dictionary to translate English into T'boli. Everything below it is the full word list and the grammar it comes from."
			}]
		},
		{
			"title": "Instructions",
			"blocks": [
				{
					"kind": "li",
					"text": "Translate the meaning, not word by word. Build each sentence from the rules below and copy the patterns in the example pairs."
				},
				{
					"kind": "li",
					"text": "Use only the words in this dictionary. If a word you need isn't here, keep it in English inside [brackets] and say it's missing. Don't guess, and don't swap in Tagalog or another language unless this dictionary lists it as a borrowing."
				},
				{
					"kind": "li",
					"text": "English words can be borrowed with T'boli endings (rule 12)."
				},
				{
					"kind": "li",
					"text": "If a sentence could mean two things, give both and say which situation each one fits."
				},
				{
					"kind": "li",
					"text": "Keep the spelling and accent marks exactly as written here. The accents change the meaning (hnóbô is getting angry, hnobò is bladder)."
				}
			]
		},
		{
			"title": "Core rules",
			"blocks": [
				{
					"kind": "p",
					"text": "1. Word order. The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now). Whatever comes first is the focus: Miles ninumen él (Miles drank the water), Él ninum Miles (the water Miles drank)."
				},
				{
					"kind": "p",
					"text": "2. Who: endings on the word. I: -u or -e (Kenu, I eat; Nóyóu, I want; Bitile, I'm hungry; Denge, I'm done). You (one): -em, sometimes -u (Kenem, you eat; Bitilu, you're hungry). Formal you: -i (Dengi). He/she/it: -en (Kenen). They: -le. You all: -ye. We all: -kuy. You and me: -te. We but not you: me. Since -u can mean I or you, add the standalone word when it matters."
				},
				{
					"kind": "p",
					"text": "3. Standalone pronouns. O/Ou (me), U/Uu (you), Yu (you all), Du (him/her/it), Lu (them), Tu (us), Te (you and me), Mi (us, not you). Put them after the action to make it clear: Minume o él (I'm drinking water), Minume mi él (we're drinking water)."
				},
				{
					"kind": "p",
					"text": "4. No word for \"is\" when describing. Coffee-hu kinì (my coffee is hot). Se is used for how someone is: Kmoem se du? (how are you?). Nô is the \"is\" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table)."
				},
				{
					"kind": "p",
					"text": "5. Very. Tey/Téy takes the person ending: Teye bitil (I'm very hungry), Téyu temngón (you're very smart). Alì is extremely."
				},
				{
					"kind": "p",
					"text": "6. Action shapes on one root. Root alone is general (ken, eat). M inside or me- in front is happening or about to happen (meken, kmulón, tmolok). N inside is being done or ongoing with an ending (tnolok, t'nilówem). G- in front is by accident (gkulóne, I accidentally got rained on). S- in front is each other (ston, see each other), and sense- is together and still going (senseken). H- or het- in front is make it or let someone (hkinì, make hot; hetnaw, make cold). Hef- is asking someone to do it with your own thing (hefkodok)."
				},
				{
					"kind": "p",
					"text": "7. Time. Deng is done or already: Deng kenu (I ate), Denge meken (I already ate). Ne is now, already, or about to: Ne meken dé (I'm going to eat). Nehe (I will), Nehi (you will), Nele (they will). Bud in front is again: Bud kmulón (it'll rain again). Kdeng at the end is later. He at the end adds \"yet\" or \"again, hopefully\". Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday). Leave out kdeng when another word already says when."
				},
				{
					"kind": "p",
					"text": "8. Not. Là with the person: Làe or Là e (I'm not), Làu (you're not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't). Là e deng meken he (I haven't eaten yet). Bê is don't, or refusing: Bê tagad tungô he (don't sleep yet)."
				},
				{
					"kind": "p",
					"text": "9. Questions. The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón ke (when), Moen ke (why). For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?)."
				},
				{
					"kind": "p",
					"text": "10. Owning. The owner word goes before the thing: do (mine), kóm (yours), kun (his/hers/its), kul (theirs), kut (ours, you and me), kum (ours, 3 or more): Yó kóm ken, ni do ken (that's your food, this is my food). Dou dumu sbót (my friend). Body parts take -hu for my: matahu (my eyes), kuluhu (my head)."
				},
				{
					"kind": "p",
					"text": "11. Places. Bê covers in, on, at, to, under and beside. Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Bê also goes before a day: bê Byérnis (on Friday)."
				},
				{
					"kind": "p",
					"text": "12. Borrowed English words. The ending copies the word's last consonant sound: phone-nu (my phone), update-tu (I update), vitamin-nu (my vitamin). A word ending in a vowel sound takes an h: coffee-hu (my coffee). Endings that start with a consonant attach as they are: movie-le (their movie). Ke- means if or for doing it: Slamat bê ke-sendem du (thanks for sending it)."
				},
				{
					"kind": "p",
					"text": "13. Joining words. Omin (and), okóm (but), kay (because), kayà (so, that's why), anì (so that), ke or sok (if, when). Kay, ke and sok take the person ending themselves: Kaye bitil (because I'm hungry), Kehu bitil (if you're hungry), Soke bitil (when I'm hungry)."
				},
				{
					"kind": "p",
					"text": "14. Three kinds of \"we\". Te is you and me, kuy is all of us, me (or mi) is us but not you. Use me when telling a story, since the listener isn't part of it."
				},
				{
					"kind": "p",
					"text": "15. Sound rules. An accented final vowel (silà, ngà) ends in a full stop and takes an ending with no h, losing its accent (silaem, ngaen). A plain final vowel takes h before the ending (nawa, nawahu). A separate ending word like le never merges with a full stop word: silà le, never silale."
				}
			]
		},
		{
			"title": "How a sentence breaks down",
			"blocks": [
				{
					"kind": "li",
					"text": "Hkodoke béléem itlug (I'll boil an egg for you): hkodok (boil it) + -e (I), béléem (for you), itlug (egg)"
				},
				{
					"kind": "li",
					"text": "Là e deng meken he (I haven't eaten yet): là e (I'm not), deng (done), meken (eating), he (yet)"
				},
				{
					"kind": "li",
					"text": "Kehe bitil, ne meken dé (if I'm hungry, I'll eat): ke + -he (if I), bitil (hungry), ne meken dé (I'm going to eat)"
				},
				{
					"kind": "li",
					"text": "Haya bud te ston he (see you again tomorrow, hopefully): haya (tomorrow), bud (again), te (you and me), ston (see each other), he (hopefully)"
				}
			]
		},
		{
			"title": "Example pairs",
			"blocks": [
				{
					"kind": "p",
					"text": "Greetings and small talk"
				},
				{
					"kind": "li",
					"text": "Good morning: Hyu hlafus"
				},
				{
					"kind": "li",
					"text": "Good morning to you too: Hyu hlafus béléem skóm"
				},
				{
					"kind": "li",
					"text": "Good night: Hyu kifu"
				},
				{
					"kind": "li",
					"text": "What's up?: Syó du?"
				},
				{
					"kind": "li",
					"text": "How are you?: Kmoem se du?"
				},
				{
					"kind": "li",
					"text": "I'm fine: Ok ye néen"
				},
				{
					"kind": "li",
					"text": "And you?: Kóm du?"
				},
				{
					"kind": "li",
					"text": "What's your name?: Bon boluyem (du)?"
				},
				{
					"kind": "li",
					"text": "My name is Miles: Boluyu Miles"
				},
				{
					"kind": "li",
					"text": "What are you doing?: Bon nmoem (du)?"
				},
				{
					"kind": "li",
					"text": "Nothing, just sitting: Anduen. Len myón."
				},
				{
					"kind": "li",
					"text": "Where are you from?: Bê du gôem lemwót du?"
				},
				{
					"kind": "li",
					"text": "Where are you going?: Góem gów (du)?"
				},
				{
					"kind": "li",
					"text": "Is that right?: Tahu kô?"
				},
				{
					"kind": "li",
					"text": "Yes, that's true: Ell, tahu yó"
				},
				{
					"kind": "li",
					"text": "Thank you so much: Bong slamat"
				},
				{
					"kind": "li",
					"text": "Thanks to you: Slamat béléem"
				},
				{
					"kind": "li",
					"text": "You're welcome: Ominem dé"
				},
				{
					"kind": "li",
					"text": "Thanks for teaching me: Slamat bê ke-teachem do"
				},
				{
					"kind": "li",
					"text": "Wait a bit: Tagad he"
				},
				{
					"kind": "li",
					"text": "We'll see each other later: Bud te ston kdeng"
				},
				{
					"kind": "p",
					"text": "Feelings"
				},
				{
					"kind": "li",
					"text": "I'm very hungry. And you?: Teye bitil. Kóm du?"
				},
				{
					"kind": "li",
					"text": "I'm very happy: Teye hligal"
				},
				{
					"kind": "li",
					"text": "I'm exhausted: Teye kapuy"
				},
				{
					"kind": "li",
					"text": "I'm sleepy: Moo ktuku"
				},
				{
					"kind": "li",
					"text": "I'm full now: Besowe ne"
				},
				{
					"kind": "li",
					"text": "I'm thirsty, so I'm drinking water: Meenge, kayà minume o él"
				},
				{
					"kind": "li",
					"text": "I'm not scared of spiders: Là e likô bê wong"
				},
				{
					"kind": "li",
					"text": "I'm just joking: Olohu hlowon néen"
				},
				{
					"kind": "li",
					"text": "I don't want to sleep because I'm hungry: Là nóyóu du tungô, kaye bitil (du points to the subject, the sleeping)"
				},
				{
					"kind": "p",
					"text": "Food"
				},
				{
					"kind": "li",
					"text": "Let's eat: Meken kuy"
				},
				{
					"kind": "li",
					"text": "If you're hungry, eat: Kehu bitil, mekenu"
				},
				{
					"kind": "li",
					"text": "I ate: Deng kenu"
				},
				{
					"kind": "li",
					"text": "I already ate: Denge meken"
				},
				{
					"kind": "li",
					"text": "I'll eat first: Ne meken dé anay"
				},
				{
					"kind": "li",
					"text": "When I'm hungry, I fry leftover rice: Soke bitil, senlahu ken tnaw"
				},
				{
					"kind": "li",
					"text": "This food is delicious: Téy mi ken ni"
				},
				{
					"kind": "li",
					"text": "That's your food, this is my food: Yó kóm ken, ni do ken"
				},
				{
					"kind": "li",
					"text": "The rice is already cooked: Deng tógó ne ken"
				},
				{
					"kind": "li",
					"text": "My coffee is hot: Coffee-hu kinì"
				},
				{
					"kind": "li",
					"text": "My coffee is on the table: Coffee-hu nô bê ta lmisa"
				},
				{
					"kind": "li",
					"text": "I'm full now. That fish was really tasty!: Besowe ne. Utón nìen, téy mnóm!"
				},
				{
					"kind": "p",
					"text": "Weather and time"
				},
				{
					"kind": "li",
					"text": "Is it raining?: Kmulón ni?"
				},
				{
					"kind": "li",
					"text": "It's raining now. You'll be cold: Kmulón ne. Tnawu yó."
				},
				{
					"kind": "li",
					"text": "Tomorrow it'll rain again: Haya, bud kmulón"
				},
				{
					"kind": "li",
					"text": "Yesterday was extremely hot, but today is very cold: Ekimel alì kinì, okóm kdaw ni téy tnaw"
				},
				{
					"kind": "li",
					"text": "Next week, on Friday, I'll go to the water: Todol fedyan, bê Byérnis, nehe gów bê él."
				},
				{
					"kind": "li",
					"text": "What's the date today?: Bon kdaw du ni?"
				},
				{
					"kind": "p",
					"text": "People"
				},
				{
					"kind": "li",
					"text": "You are my friend: Uu dou dumu sbót"
				},
				{
					"kind": "li",
					"text": "I'm your friend: Ou kóm dumu sbót"
				},
				{
					"kind": "li",
					"text": "I like you: Nóyóu u"
				},
				{
					"kind": "li",
					"text": "I love you: Kenbong nawahu u"
				},
				{
					"kind": "li",
					"text": "I hate you: Knutó nawahu u"
				},
				{
					"kind": "li",
					"text": "I dislike you, I reject you: Kenbéu u"
				},
				{
					"kind": "li",
					"text": "I don't like you: Là nóyóu kóm (after là, u for \"you\" becomes kóm)"
				},
				{
					"kind": "li",
					"text": "I never liked you: Là nóyóu kóm se"
				},
				{
					"kind": "li",
					"text": "I don't want/like yours: Là nóyóu du kóm (du marks the thing, kóm is the owner)"
				},
				{
					"kind": "li",
					"text": "Rule after là: me and you switch to the owner words: o becomes do, u becomes kóm. Se after là means never / at all. When there's a thing, du holds its place, se comes right after du, and the thing is named last."
				},
				{
					"kind": "li",
					"text": "He never liked you: Là nóyóen kóm se"
				},
				{
					"kind": "li",
					"text": "I never knew / I don't know at all: Là t'ngónu du se"
				},
				{
					"kind": "li",
					"text": "I don't want to sleep at all: Là nóyóu du tungô se"
				},
				{
					"kind": "li",
					"text": "My dad never listens to me: Là gungolen do se Pangu"
				},
				{
					"kind": "li",
					"text": "I've never seen my cat: Là tonu du se kuyingu"
				},
				{
					"kind": "li",
					"text": "I've never seen a cat: Làe deng mton kuying se (làe = I don't, deng = already/ever, mton = seeing; for \"never have\" the I goes on là, and the action word takes the m form with no ending)"
				},
				{
					"kind": "li",
					"text": "I've never eaten fish: Làe deng meken utón se"
				},
				{
					"kind": "li",
					"text": "How's my dad?: Kmoen se Pangu?"
				},
				{
					"kind": "li",
					"text": "I've never seen a dog: Làe deng mton ohu se"
				},
				{
					"kind": "li",
					"text": "He never liked me: Là nóyóen do se"
				},
				{
					"kind": "li",
					"text": "I've never cooked fish: Làe deng tmógó utón se"
				},
				{
					"kind": "li",
					"text": "Four ways with gungol (hear/listen):"
				},
				{
					"kind": "li",
					"text": "Là gungolem do se: you can't even hear me (plain form)"
				},
				{
					"kind": "li",
					"text": "Là nungolem do se: you didn't even listen to me (g becomes n: done, past)"
				},
				{
					"kind": "li",
					"text": "Là gegungolem do se: you couldn't even hear me (doubled ge-)"
				},
				{
					"kind": "li",
					"text": "Làu kô mungol se: you never listened at all (\"you\" moves onto là, g becomes m, no ending, no \"me\")"
				},
				{
					"kind": "li",
					"text": "Kô after là = never. Làu kô + m form + se: you never (no ending, no \"me\"). Làe kô, làen kô work the same. To keep \"me\" in, use plain Là kô with the ending on the action word."
				},
				{
					"kind": "li",
					"text": "You never eat fish: Làu kô meken utón se"
				},
				{
					"kind": "li",
					"text": "You never sleep: Làu kô tungô se"
				},
				{
					"kind": "li",
					"text": "I never eat: Làe kô meken se"
				},
				{
					"kind": "li",
					"text": "He never cooks: Làen kô tmógó se"
				},
				{
					"kind": "li",
					"text": "You never see me: Là kô tonem do se (not Làu kô mton do se)"
				},
				{
					"kind": "li",
					"text": "You can't even see me: Là tonem do se"
				},
				{
					"kind": "li",
					"text": "I never get seen / nobody notices me: Làe kô gton se"
				},
				{
					"kind": "li",
					"text": "I never show up: Làe kô gfan se"
				},
				{
					"kind": "li",
					"text": "I can't even be seen: Làe gegton se"
				},
				{
					"kind": "li",
					"text": "G- forms act like m forms here: the person goes on là, the action word takes no ending"
				},
				{
					"kind": "li",
					"text": "New words:"
				},
				{
					"kind": "li",
					"text": "móyô: want, eager (Móyô me bud hmungol du: we want to hear it again)"
				},
				{
					"kind": "li",
					"text": "huluk: show up without others knowing, drop in unannounced"
				},
				{
					"kind": "li",
					"text": "tehe: used to be, formerly (yóm lóbô tehe mowil: the beast that was alive)"
				},
				{
					"kind": "li",
					"text": "klawi: time, period (klawihen: its time)"
				},
				{
					"kind": "li",
					"text": "kni: back then"
				},
				{
					"kind": "li",
					"text": "kat kô: how, so (exclamation)"
				},
				{
					"kind": "li",
					"text": "kodun: pitiful, \"nakakaawa\". Kodunu (I'm pitiful), Kodunem (you're pitiful), Kodunen (he/she/it's pitiful), Kodun le (they're pitiful), Téy kodunem (you're really pitiful: the ending goes on kodun, not on téy)"
				},
				{
					"kind": "li",
					"text": "ngau: my child, my children (ngà + -u; the accent drops)"
				},
				{
					"kind": "li",
					"text": "Téyu wélkam: you're very welcome (wélkam borrowed from English). Wélkamu: you're welcome (-u = you, like bitilu)"
				},
				{
					"kind": "li",
					"text": "hlosok: fallen (done form of mosok). ebéléu: from me. lembés: more than, beyond. anien: even though"
				},
				{
					"kind": "li",
					"text": "Deymar's poems (Oct 13):"
				},
				{
					"kind": "li",
					"text": "Kem blotik sok kifu tey knóón: the stars at night, so beautiful"
				},
				{
					"kind": "li",
					"text": "Él kulón deng le hlosok ne ta tonok, dalang se yóm dou lewok, mosok: the rain has already fallen to the earth, and so have my tears, falling"
				},
				{
					"kind": "li",
					"text": "Hnangatu uu, abay se tek sotu lówóhu ke sok kifu: I've been waiting for you, because I'm all alone at night"
				},
				{
					"kind": "li",
					"text": "Là móyô klifótu kóm se, anien kehu mayuk ebéléu: I never want to forget you, even when you're far from me"
				},
				{
					"kind": "li",
					"text": "Tey nóyóu yóm mohin, okóm yóm dou kekbong nawa kóm tey lembés bê yó he: I love the sea, but my love for you goes far beyond it"
				},
				{
					"kind": "li",
					"text": "English poems built into T'boli (Oct 13):"
				},
				{
					"kind": "li",
					"text": "Él mlel mógów bê mohin, ne hosòhu mógów béléem: the river runs to the sea, and my heart runs to you"
				},
				{
					"kind": "li",
					"text": "Kem blotik nangat le kekifuhen, dalang se kekangatu kóm: the stars wait for the night, the way I wait for you (nangat, n-form of hangat; kekifuhen = ke (if) + kifu (dark) + h + -en (it): when it turns dark; ke- form after dalang se; kóm for \"you\" as the one waited for)"
				},
				{
					"kind": "li",
					"text": "Anien ke klifót bulón kifu, là kô klifótu kóm se: even if the moon forgets the night, I'll never forget you"
				},
				{
					"kind": "li",
					"text": "Sentences:"
				},
				{
					"kind": "li",
					"text": "I don't want to keep showing up empty-handed like this: Lae móyô gel huluk hkawang ni dou"
				},
				{
					"kind": "li",
					"text": "Back in those days, everyone at home was so happy. Not anymore: Yóm hanà tehe klawihen kni, tey alì ligal kem tau bê gónô. Là ne ni"
				},
				{
					"kind": "li",
					"text": "If only it were like the way you used to love me back then: Ke lómón yóm tehe kekbong nawahem dou du kni"
				},
				{
					"kind": "li",
					"text": "I'm the eighth one: Ou gwoluhen yó"
				},
				{
					"kind": "li",
					"text": "Big fire! It's so hot: Ofi bong! Kat kô alì kinì"
				},
				{
					"kind": "li",
					"text": "We're dirt poor right now. My poor kids: Glayam bong ni du. Kodun le kem ngau (glayam = poor, poverty; bong = big; ni = right now; du = the subject, which here is glayam itself. Literally \"the poverty is big right now\")"
				},
				{
					"kind": "li",
					"text": "Là deng: not yet (deng = already, done)"
				},
				{
					"kind": "li",
					"text": "I haven't eaten yet: Làe deng meken (add se at the end and it becomes never)"
				},
				{
					"kind": "li",
					"text": "Who's that?: Tadu yó?"
				},
				{
					"kind": "li",
					"text": "That's him / that's us / that's them: Du yó / Tu yó / Lu yó"
				},
				{
					"kind": "li",
					"text": "It's our turn: Tu ne ni"
				},
				{
					"kind": "li",
					"text": "It's not me: Là o du se"
				},
				{
					"kind": "li",
					"text": "I didn't do that: Là o du mò du yó"
				},
				{
					"kind": "li",
					"text": "When will you get back home?: Kilón ke kulékem bê gónô?"
				},
				{
					"kind": "li",
					"text": "Why aren't you sleepy yet?: Moen ke là u gtungô du?"
				},
				{
					"kind": "li",
					"text": "Are you going to sleep?: Tungôu ne yó?"
				},
				{
					"kind": "li",
					"text": "Are you resting?: Hegnô u?"
				},
				{
					"kind": "li",
					"text": "I just woke up: Lomihe btik (right now). Lomi kebtiku: I woke up a while ago"
				},
				{
					"kind": "li",
					"text": "I just woke up, so I'm not going back to sleep: Lomi kebtiku kayà là e bud tungô ne là"
				},
				{
					"kind": "li",
					"text": "It's time to get up (everyday): Udas kebtik kuy ne"
				},
				{
					"kind": "li",
					"text": "Where's my phone?: Góen nô phone-nu (du)?"
				},
				{
					"kind": "li",
					"text": "Today, Deymar, you taught me and I taught you. We're teaching each other: Kdaw ni, Deymar. Tnolokem o, omin tnoloku u. Stolok te."
				}
			]
		},
		{
			"title": "Vowels and marks",
			"blocks": [{
				"kind": "p",
				"text": "A, À, E, È, É, Ê, I, Ì, O, Ò, Ó, Ô, U, Ù, and ’ (the glottal mark, as in T'boli, K'nôón)"
			}]
		},
		{
			"title": "Letters",
			"blocks": [{
				"kind": "p",
				"text": "B, D, E, F, G, H, I, K, L, M, N, O, P, R, S, T, U, W, Y"
			}]
		},
		{
			"title": "Borrowed words and names",
			"blocks": [
				{
					"kind": "li",
					"text": "Borrowed words keep their own spelling, even with letters T'boli doesn't have. Péro (but, from Spanish) stays Péro, not Féro"
				},
				{
					"kind": "li",
					"text": "Country names are written with T'boli letters"
				},
				{
					"kind": "li",
					"text": "Ph is always F: Alfabét (alphabet), Farmasi (pharmacy), Filipinas (Philippines), Faro (Pharaoh), Stéfén (Stephen)"
				},
				{
					"kind": "li",
					"text": "P in names: traditional T'boli uses F where English has P, so older people say Fól for Paul. The Bible mostly keeps P (Pol, Pitér) because its names came through English. It goes word by word: Faris (Paris), Fkistan (Pakistan), Fortugal (Portugal), but Péru (Peru)"
				}
			]
		},
		{
			"title": "Ng",
			"blocks": [{
				"kind": "p",
				"text": "Ng can be counted as its own letter or as N plus G. Both work. It's there for the sound, as in ngà and t'ngón."
			}]
		},
		{
			"title": "Vowels",
			"blocks": [
				{
					"kind": "li",
					"text": "E: like the u in burn (Ken, Teye, Ell)"
				},
				{
					"kind": "li",
					"text": "É: like the e in egg (néen)"
				},
				{
					"kind": "li",
					"text": "O: like the a in law"
				},
				{
					"kind": "li",
					"text": "Ò: like the a in law, but cut off with a full stop"
				},
				{
					"kind": "li",
					"text": "Ó: like the o in obvious"
				},
				{
					"kind": "li",
					"text": "Ô: like the o in obvious, but cut off with a full stop"
				},
				{
					"kind": "li",
					"text": "An accent on a final vowel (silà, ngà): the word ends in a full stop (see the sound rules)"
				}
			]
		},
		{
			"title": "Words that are easy to get wrong",
			"blocks": [
				{
					"kind": "li",
					"text": "Ell (yes): said like \"Ull\", the E is the u in burn"
				},
				{
					"kind": "li",
					"text": "Fun (owner): the u sounds like the u in uniform, not like \"fan\""
				},
				{
					"kind": "li",
					"text": "Ken (food): the E is the u in burn, not like Kentucky"
				},
				{
					"kind": "li",
					"text": "Ken tnaw: Ken with the u in burn, tnaw like \"T'NOW\" (the ow in now, with the W said at the end like the w in win)"
				},
				{
					"kind": "li",
					"text": "Accents change meaning. Hnóbô is getting angry, hnobò is bladder. Moen is why, Móen is short for Kmoem. Geslà is a surprise, gesla is being fried. Silà is corn, and silale would lose that meaning."
				},
				{
					"kind": "li",
					"text": "Msó is the fast way to say mesó (rice)."
				},
				{
					"kind": "li",
					"text": "Mestlu is how maistru (teacher) is actually said."
				}
			]
		},
		{
			"title": "Word order",
			"blocks": [
				{
					"kind": "li",
					"text": "The root word carries the meaning, and endings say who."
				},
				{
					"kind": "li",
					"text": "The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now)."
				},
				{
					"kind": "li",
					"text": "The main idea comes first: Meken kuy, Tahu kô ni."
				},
				{
					"kind": "li",
					"text": "Whoever or whatever comes first is the focus. Miles ninumen él (Miles drank the water) puts Miles first. Él ninum Miles (the water being drunk by Miles) puts the water first. Él ninumen Miles means the water drank Miles, because -en makes the water the one drinking."
				},
				{
					"kind": "li",
					"text": "Word order can change the meaning: Kmoem se du is \"how are you\", Kmoem du se is \"what did you do\"."
				},
				{
					"kind": "li",
					"text": "When \"it\" does something to a person, the -en ending is the \"it\" and the person comes after: Hetnawen u yó (it'll make you cold)."
				},
				{
					"kind": "li",
					"text": "\"More\" comes after the thing: unged wen, more muscle."
				},
				{
					"kind": "li",
					"text": "A color goes before mata: utón hulô mata (red-eye fish)."
				},
				{
					"kind": "li",
					"text": "With names, the names come first, then sbót le: Miles omin Deymar sbót le (Miles and Deymar are friends)."
				},
				{
					"kind": "li",
					"text": "Ni and yó point (\"this\" and \"that\"), and kô turns a statement into a question."
				}
			]
		},
		{
			"title": "No \"is\" when describing",
			"blocks": [
				{
					"kind": "li",
					"text": "Describing something needs no \"is\" at all: Coffee-hu kinì (my coffee is hot)."
				},
				{
					"kind": "li",
					"text": "Se is the \"be\" word for how someone is, and it goes in the middle: Kmoem se du? (how are you?)."
				},
				{
					"kind": "li",
					"text": "Nô is the \"is\" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table). Without nô, Coffee-hu bê ta lmisa is just \"my coffee on the table\"."
				}
			]
		},
		{
			"title": "Person endings",
			"blocks": [
				{
					"kind": "p",
					"text": "These attach to a word to say who."
				},
				{
					"kind": "li",
					"text": "-u: often \"you\" (Gówu, you go; Tungôu, you sleep; Mekenu, you're eating or \"eat!\"; Bitilu, you're hungry). In some words it means \"I\" (Kenu, I eat; Nóyóu, I want; Tnoloku, I teach). Since -u can mean either, add the standalone word when it matters."
				},
				{
					"kind": "li",
					"text": "-e: I (Bitile, I'm hungry; Denge, I'm done; Mekene, I'm eating; Teye, I'm very). Bitile can also mean \"they're hungry\"; Bitile lu is clearer for them."
				},
				{
					"kind": "li",
					"text": "-em: you (one person) (Kenem, you eat)"
				},
				{
					"kind": "li",
					"text": "-i: the formal \"you\", more specific than -u (Dengi, you're done; Kehi, you become; Lài, you are not)"
				},
				{
					"kind": "li",
					"text": "-en: him, her, it (Kenen, he/she/it eats)"
				},
				{
					"kind": "li",
					"text": "-le: them, not including the person you're talking to (Kenle, they eat)"
				},
				{
					"kind": "li",
					"text": "-ye: you all, the people you're talking to, speaker not included (Kenye)"
				},
				{
					"kind": "li",
					"text": "-kuy: we, us, 3 or more people (Kenkuy)"
				},
				{
					"kind": "li",
					"text": "-te: us two, just you and me (Kente)"
				},
				{
					"kind": "li",
					"text": "me: we, without the person you're talking to (Deng me, Kmò me du)"
				},
				{
					"kind": "li",
					"text": "-hu: my, on words that end in a plain vowel and on body parts (nawahu, matahu, kuluhu, lówóhu, coffee-hu). Tnoloku takes -u, not -hu."
				},
				{
					"kind": "p",
					"text": "The ending can jump forward to an earlier word: Kaye bitil (because I'm hungry) instead of Kay bitile. Same with Anìe (so I), and Kehu bitil (if you're hungry) instead of Ke bitilu."
				},
				{
					"kind": "p",
					"text": "When an ending could mean two people (minume, I or we), add the standalone word: minume o (I), minume mi (we)."
				},
				{
					"kind": "p",
					"text": "#### Second set, with Tey and Meken"
				},
				{
					"kind": "li",
					"text": "Teye: I am very"
				},
				{
					"kind": "li",
					"text": "Téyu: you are very"
				},
				{
					"kind": "li",
					"text": "Téy-: he/she/it is very"
				},
				{
					"kind": "li",
					"text": "Téyle: they are very"
				},
				{
					"kind": "li",
					"text": "Téyye: you all are very"
				},
				{
					"kind": "li",
					"text": "Téykuy: we are very"
				},
				{
					"kind": "li",
					"text": "Téyte: we (you and I) are very"
				},
				{
					"kind": "li",
					"text": "Mekene: I am eating"
				},
				{
					"kind": "li",
					"text": "Mekenu: you are eating, also \"eat!\" when telling someone to eat"
				},
				{
					"kind": "li",
					"text": "Meken du: he/she/it is eating"
				}
			]
		},
		{
			"title": "Standalone pronouns",
			"blocks": [
				{
					"kind": "li",
					"text": "O / Ou: me, I. Ou is specifically me, pointing at yourself."
				},
				{
					"kind": "li",
					"text": "U / Uu: you (one person). Uu is specifically you."
				},
				{
					"kind": "li",
					"text": "Yu: you (2 or more people)"
				},
				{
					"kind": "li",
					"text": "Du: him, her, it (used everywhere for he/she/it). It also points back at whatever the subject already is: in Kmoem du, du points at -em (you); in Glayam bong ni du, du points at glayam (the poverty). But after an action word (want, know, flash), du is the one it's done to: Nóyóu du tungô = I want him/her/it to sleep; T'ngónem du? = do you know him/her/it?; Snolokem du = flash him. So: I want to sleep is just Nóyóu tungô, and do you know? has no du. Context decides: when the talk is already about sleep, Là nóyóu du tungô means I don't want to sleep, with du pointing at the sleep. If the talk is about someone else, du becomes that person. A du right after nóyóu points at the action itself, so the thing it's done to needs a second du at the end: Là nóyóu du meken (I don't want to eat), Là nóyóu du meken du (I don't want to eat it). With du pointing back, Coffee-hu. Kinì bong ni du splits into two: My coffee. It's very hot. Plain Coffee-hu kinì is one sentence: my coffee is hot. The du right after nóyóu only comes with Là in front: Nóyóu meken du ni (I want to eat this) vs Là nóyóu du meken du yó (I don't want to eat that). Ni = this, something you're holding or that's in front of you; yó = that, farther away. Sotu nien = this one (Là nóyóu du yó, okóm nóyóu du ni sotu nien: I don't want that one, but I want this one)"
				},
				{
					"kind": "li",
					"text": "Love, for things vs living things: for things, use nóyô: Tey nóyóu ni kgal ni (I love this shirt). For living things, use kenbong nawa: Kenbong nawahu du ni wong ni (I love this spider), Kenbong nawahu ni du (I love this one, like a cat). Du points to the one being loved. New words: kgal = shirt, wong = spider"
				},
				{
					"kind": "li",
					"text": "Lu: them"
				},
				{
					"kind": "li",
					"text": "Tu: us"
				},
				{
					"kind": "li",
					"text": "Te: me and you"
				},
				{
					"kind": "li",
					"text": "Mi: us, I'm included but not the person I'm talking to"
				},
				{
					"kind": "li",
					"text": "Do: me, when I'm the one something happens to (from dou): Ktolok le do (they taught me)"
				},
				{
					"kind": "p",
					"text": "With yó: O yó (that's me), Ou yó (that's me, specifically me), U yó (that's you), Uu yó (that's you, specifically you), Du yó (that's him), Tu yó (that's us), Lu yó (that's them)."
				}
			]
		},
		{
			"title": "Three kinds of \"we\"",
			"blocks": [
				{
					"kind": "li",
					"text": "Te: you and me (Stolok te, we teach each other, like Tagalog \"tayo\")"
				},
				{
					"kind": "li",
					"text": "Kuy: all of us, 3 or more"
				},
				{
					"kind": "li",
					"text": "Me / Mi: us but not you (Stolok me, like Tagalog \"kami\"; Mi kem mag-cousin, us cousins, not counting you)"
				},
				{
					"kind": "p",
					"text": "Use me when telling a story, since the listener isn't part of it: Tmógó me utón (we're cooking fish, not you). Never tmógó mi utón. Me works everywhere kuy does: Kmò me du."
				}
			]
		},
		{
			"title": "Owning",
			"blocks": [
				{
					"kind": "p",
					"text": "The owner word goes before the thing: Yó kóm ken, ni do ken (that's your food, this is my food)."
				},
				{
					"kind": "li",
					"text": "Do: mine"
				},
				{
					"kind": "li",
					"text": "Dou: I own, my (Uu dou dumu sbót, you are my friend)"
				},
				{
					"kind": "li",
					"text": "Kóm: you own, yours"
				},
				{
					"kind": "li",
					"text": "Kun: he/she/it owns"
				},
				{
					"kind": "li",
					"text": "Kul: they own, theirs"
				},
				{
					"kind": "li",
					"text": "Kum: we (3 or more) own"
				},
				{
					"kind": "li",
					"text": "Kut: we (me and you) own, ours"
				},
				{
					"kind": "li",
					"text": "Do u ni: this is mine"
				},
				{
					"kind": "p",
					"text": "Body parts and vowel-final words take -hu for \"my\": kuluhu (my head), matahu (my eyes), lówóhu (my body), nawahu (my breath)."
				},
				{
					"kind": "p",
					"text": "Dumuhu sbót and dou dumu sbót both mean \"my friend\". Use dumuhu sbót when telling someone else about the friendship (he's my friend). Use dou dumu sbót when talking to the friend directly (Uu dou dumu sbót, you're my friend)."
				}
			]
		},
		{
			"title": "Pointing words",
			"blocks": [
				{
					"kind": "li",
					"text": "Ni: it, this; here's (Ni ken para béléem, here's food for you). At the end of a sentence it points to something right here. Ni is also right now, while ne is already."
				},
				{
					"kind": "li",
					"text": "Yó: that"
				},
				{
					"kind": "li",
					"text": "Nìen: this one, it (ni plus -en, pointing at the subject): Utón nìen, téy mnóm!"
				},
				{
					"kind": "li",
					"text": "Yóm: the"
				},
				{
					"kind": "li",
					"text": "Tu: far, there (see the dictionary entry)"
				}
			]
		},
		{
			"title": "Action shapes",
			"blocks": [
				{
					"kind": "p",
					"text": "One root changes shape to show how an action happens."
				},
				{
					"kind": "li",
					"text": "Root alone: general (ken, eat; tolok, teach; kodok, boil)"
				},
				{
					"kind": "li",
					"text": "M inside, or me- in front: happening or about to happen, like \"-ing\" (meken, kmulón, tmolok, lmobun, kminì, kmodok)"
				},
				{
					"kind": "li",
					"text": "N inside: being done, already done, or ongoing (tnolok, being taught; nsef, sucked; t'nilówem). With person endings the m becomes n (t'milów, t'nilówem). Kenbong (with -n-) is already happening, continuously, while kbong is still going."
				},
				{
					"kind": "li",
					"text": "Suggesting vs commanding: -u suggests (Mekenu, go ahead and eat). -em with kun commands (Snolokem du kun, flash him!)"
				},
				{
					"kind": "li",
					"text": "Careful with bê u: it means \"don't you,\" not \"onto you.\" Onto you is ebéléem"
				},
				{
					"kind": "li",
					"text": "Hyphen rule: when n meets g across parts of a word, write a hyphen (Hen-ganagem) so it's said n + g, not the ng in mango"
				},
				{
					"kind": "li",
					"text": "G- in front: by accident, without meaning it (gkulóne, I accidentally got rained on; gtolok, taught unexpectedly; gwa, accidentally taken; gsalig, unintentionally trust; gtungô, sleepy)"
				},
				{
					"kind": "li",
					"text": "S- in front: each other (ston, see each other; stolok, teach each other; swa, taking from each other; stóbóng, helping each other)"
				},
				{
					"kind": "li",
					"text": "Doubled first letter: both or together doing it (ssef, both sucking; kken, ate together)"
				},
				{
					"kind": "li",
					"text": "Sense- in front: together and still going (senseken, eating together; sensesef). It doesn't work on every verb: stowok, not sensetowok."
				},
				{
					"kind": "li",
					"text": "H- or het- in front: make it, or let someone else do it (hkinì, make hot; hetnaw, make cold; hsef, let someone suck; hsalig, let something trust; hetngón, let someone know). Add the person ending for who does it: Hkinìem ken (you heat the food), Hkinìu ken (I heat the food)."
				},
				{
					"kind": "li",
					"text": "Hef- in front: asking someone to do it with your own thing (hefkodok)"
				},
				{
					"kind": "li",
					"text": "K- form: already carries \"will\" (kulékem, you'll come back)"
				},
				{
					"kind": "p",
					"text": "Roots that show the whole system:"
				},
				{
					"kind": "li",
					"text": "Take: ma/mwa (take), nwa (taken), gwa (accidentally taken), swa (taking from each other). N- is done, g- is by accident, s- is each other."
				},
				{
					"kind": "li",
					"text": "Boil: kodok (boil), kmodok (boiling), hkodok (asking for it to be boiled; hkodoku, I'm boiling it), henkodok (being boiled), hefkodok (asking someone to boil something with your item)"
				},
				{
					"kind": "li",
					"text": "Teach: tolok, tmolok, tnolok, gtolok, htolok, stolok"
				}
			]
		},
		{
			"title": "Time words",
			"blocks": [
				{
					"kind": "p",
					"text": "Time is shown with small words around the verb, not by changing the verb itself."
				},
				{
					"kind": "li",
					"text": "Deng: done, already. Deng kenu (I ate), Denge meken (I already ate)."
				},
				{
					"kind": "li",
					"text": "Ne: now, already, a change happening, about to (like Tagalog \"na\"). Ne meken dé (I'm going to eat)."
				},
				{
					"kind": "li",
					"text": "Nehe: I will, for something you do yourself, with no object (Nehe dyó dé, Nehe bemli anay). Nehu: I will do something to something (Nehu bentik u anay, Nehu henken onuku haya), or telling someone else to do it (Nehu meken dé, you eat first). Nehi: you will. Nele: they will."
				},
				{
					"kind": "li",
					"text": "Bud: again, in front, for something that will happen. Bud kmulón (it'll rain again)."
				},
				{
					"kind": "li",
					"text": "Ne là: anymore, at the end of a sentence (là e bud tungô ne là, I'm not going back to sleep anymore). At the start, it means \"and not, not even\": Ton me du eginu okóm làen temngel béléme. Ne làen se mudél béléme. (We saw him earlier but he didn't look at us. And he didn't even talk to us.)"
				},
				{
					"kind": "li",
					"text": "Se after là: \"even\" (Ne làen se mudél béléme, and he didn't even talk to us)"
				},
				{
					"kind": "li",
					"text": "Là + endings: là e (I don't), làu (you don't), làen (he/she doesn't). Ston te eginu okóm làu temngel béléu: we saw each other earlier but you didn't look at me. Béléu: to me"
				},
				{
					"kind": "li",
					"text": "Kdeng: later, at the end of a sentence. On its own at the start it means \"wait!\""
				},
				{
					"kind": "li",
					"text": "He: at the end, adds \"yet\" or \"again, hopefully\". Là e deng meken he (I haven't eaten yet). Bud te ston he (we'll see each other again, hopefully)."
				},
				{
					"kind": "li",
					"text": "Leave out kdeng when another word already says when: Haya bud kmulón, not Haya bud kmulón kdeng."
				},
				{
					"kind": "li",
					"text": "Days: Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday), Ekuloy (the day before yesterday), Sotu ni (the day after tomorrow)."
				},
				{
					"kind": "li",
					"text": "Todol is next and gna is past: todol bulón (next month), gna halay (last year)."
				},
				{
					"kind": "li",
					"text": "Time words come from nature: kdaw is sun and day, bulón is moon and month, halay is the rice plant and year."
				}
			]
		},
		{
			"title": "Not",
			"blocks": [
				{
					"kind": "li",
					"text": "Là with the person: Làe or Là e (I'm not), Làu or Là u (you're not), Lài (you, one specific person, are not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't), Là ye (you all aren't), Là kuy (we all aren't), Là me (we aren't, not counting you)."
				},
				{
					"kind": "li",
					"text": "Là e deng meken he: I haven't eaten yet."
				},
				{
					"kind": "li",
					"text": "Bê is don't, or refusing: Bê tagad tungô he (don't sleep yet). Bê kuy gów bê yó (don't go there)."
				}
			]
		},
		{
			"title": "Questions",
			"blocks": [
				{
					"kind": "li",
					"text": "The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón ke (when), Moen ke (why)."
				},
				{
					"kind": "li",
					"text": "For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?)."
				},
				{
					"kind": "li",
					"text": "Ke always comes after kilón (when) and moen (why)."
				},
				{
					"kind": "li",
					"text": "Moen (why) is its own word, not Móen (short for Kmoem)."
				},
				{
					"kind": "li",
					"text": "Use Kmoem when you're asking someone directly, Kmoen when it's indirect."
				},
				{
					"kind": "li",
					"text": "Kô ke offers a choice: Mekenu silà kô ke ken? (are you eating corn or rice?)"
				}
			]
		},
		{
			"title": "Places",
			"blocks": [
				{
					"kind": "li",
					"text": "Bê covers every location: on, in, at, to, above, under, beside. The context tells you which."
				},
				{
					"kind": "li",
					"text": "Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Kuying bê ta lmisa (the cat is on the table)."
				},
				{
					"kind": "li",
					"text": "Bê also goes in front of a day: bê Byérnis (on Friday)."
				},
				{
					"kind": "li",
					"text": "Nô is the \"is\" for where something is."
				}
			]
		},
		{
			"title": "Sound rules",
			"blocks": [
				{
					"kind": "li",
					"text": "S- + h becomes sf-: the h turns into f after the \"each other\" s-, so it doesn't sound like sh (hangat → sfangat, not shangat)"
				},
				{
					"kind": "li",
					"text": "The -h rule: when a word ends in a plain vowel, add h before the ending: nawa becomes nawahu (my breath), coffee becomes coffee-hu."
				},
				{
					"kind": "li",
					"text": "Full stop vowels: an accent on a final vowel (silà, ngà) means a full stop at the end of the word, so it takes an ending without h, and the accent goes away when the ending is attached: silà, silaem (your corn); ngà, ngaen (his/her child)."
				},
				{
					"kind": "li",
					"text": "Separate ending words never merge: a separate ending word like le never merges with a full stop word. Silà le, never silale, because losing the accent takes away the word's meaning."
				}
			]
		},
		{
			"title": "Joining words",
			"blocks": [
				{
					"kind": "li",
					"text": "Omin: and"
				},
				{
					"kind": "li",
					"text": "Okóm: but (Okóm close, but close)"
				},
				{
					"kind": "li",
					"text": "Péro: but (borrowed from Spanish)"
				},
				{
					"kind": "li",
					"text": "Kay: because. Takes the person ending: Kaye bitil (because I'm hungry)."
				},
				{
					"kind": "li",
					"text": "Kayà: so, that's why (borrowed from Tagalog)"
				},
				{
					"kind": "li",
					"text": "Anì: so, so that. Anìe (so I)."
				},
				{
					"kind": "li",
					"text": "Ke / Sok: if, when. Both take the person ending: Kehu bitil (if you're hungry), Soke bitil (when I'm hungry)."
				},
				{
					"kind": "li",
					"text": "Dé kô: maybe, perhaps, I guess so; if (something happens), depending on context"
				},
				{
					"kind": "li",
					"text": "O: or (borrowed from English)"
				},
				{
					"kind": "li",
					"text": "Kô ke: or, when suggesting someone pick one"
				},
				{
					"kind": "li",
					"text": "Ewen: so"
				},
				{
					"kind": "li",
					"text": "Galì: oh, so that's why"
				}
			]
		},
		{
			"title": "Borrowed words",
			"blocks": [
				{
					"kind": "p",
					"text": "English words follow their sound, not their spelling. The ending copies the last consonant sound of the word, so update (ends in a t sound) becomes update-tu, update-tem, update-ten, and phone becomes phone-nu, not phoneu. When the spelling already ends in that consonant, the ending can attach directly or with a doubled letter and hyphen. The hyphen keeps the English word recognizable."
				},
				{
					"kind": "li",
					"text": "Chatu / Chat-tu: I chat"
				},
				{
					"kind": "li",
					"text": "Vitaminu / Vitamin-nu: my vitamin"
				},
				{
					"kind": "li",
					"text": "Phone-nu: my phone"
				},
				{
					"kind": "li",
					"text": "Slippersu: my slippers"
				},
				{
					"kind": "li",
					"text": "Update-tu: I update. Ke-update tu also works, with the ending standing alone. Update-le: they update (endings that start with a consonant attach as they are)."
				},
				{
					"kind": "li",
					"text": "Coffee-hu: my coffee (words that really end in a vowel sound take h)"
				},
				{
					"kind": "li",
					"text": "Movie-le: their movie (consonant endings need no h)"
				},
				{
					"kind": "li",
					"text": "Downloadem: you download. Downloaden: he/she/it downloads."
				},
				{
					"kind": "li",
					"text": "Ke-: if, or for doing it: Ke-savem (if you save, for saving), Ke-downloadem (if you download)."
				},
				{
					"kind": "p",
					"text": "Other borrowings:"
				},
				{
					"kind": "li",
					"text": "From Spanish: the days of the week, the trading numbers, para (for), péro (but), maistru/mestlu (teacher)"
				},
				{
					"kind": "li",
					"text": "From Tagalog: kayà (so, that's why), kailangan (need)"
				},
				{
					"kind": "li",
					"text": "From Hiligaynon: anay (first, for now), aslum (sour), kahang (spicy)"
				},
				{
					"kind": "li",
					"text": "From English: o (or), tisting (tasting), and any English word with T'boli endings"
				},
				{
					"kind": "li",
					"text": "Akad (Sunday) may come from Malay or Arabic \"Ahad\" instead of Spanish."
				}
			]
		},
		{
			"title": "Ke- after kilón and tey",
			"blocks": [
				{
					"kind": "li",
					"text": "After kilón (when) and tey (very), the m-form of an action becomes a ke- form: kmóót turns into kekóót, meken turns into keken, kbong turns into kekbong."
				},
				{
					"kind": "li",
					"text": "Kilón kekóót mósól du? When does the rooster crow?"
				},
				{
					"kind": "li",
					"text": "Kilón kekenen du? When will he eat?"
				},
				{
					"kind": "li",
					"text": "Kilón kekenem du? When will you eat? (du goes at the end for the subject)"
				},
				{
					"kind": "li",
					"text": "Tey kekbong nawahu du ohu. I really love dogs."
				}
			]
		},
		{
			"title": "Ke, bê and para bê",
			"blocks": [
				{
					"kind": "li",
					"text": "Ke: to, for, or, and possession. Ke Dwata: to God, or God's. Ke Dwata yó: that's God's. Ke Miles: or Miles, Miles' belongings, or for Miles."
				},
				{
					"kind": "li",
					"text": "Bê: to. Bê Miles: to Miles."
				},
				{
					"kind": "li",
					"text": "Para bê: for something or someone, being given to them. Ken para bê kem ngà: food for the children. Ke is for when it belongs to them."
				}
			]
		},
		{
			"title": "Bible verses",
			"blocks": [{
				"kind": "p",
				"text": "From Udél Dwata: Gna Kesfasad ne Lomi Kesfasad, the T'boli Bible (old covenant and new covenant)."
			}]
		},
		{
			"title": "John 3:16",
			"blocks": [{
				"kind": "p",
				"text": "Tey alì kbong nawa Dwata kul yó kem tau bè klamangen benwu, gloken tódô hamà klowil yóm Ngaen tek sotu, anì yó, kihu tau hemtahu béléen là gógówen elem hatay, okóm gutahen yóm klowil laen dù sónen."
			}, {
				"kind": "p",
				"text": "In English: \"For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life.\" Words from the lessons that appear in it: kbong nawa (love), kem tau (people), Ngaen tek sotu (his only child), hemtahu (believing), là gógówen elem hatay (he won't be lost to death)."
			}]
		},
		{
			"title": "Proverbs 3:5",
			"blocks": [
				{
					"kind": "p",
					"text": "Confirmed accurate by Deymar."
				},
				{
					"kind": "p",
					"text": "Hol hewótem lem but blututem yóm ksaligem ke Dwata, béem abay genléd nawa yóm kóm khulung temnef."
				},
				{
					"kind": "p",
					"text": "In English: \"Trust in the Lord with all your heart, and lean not on your own understanding.\" Words from the lessons that appear in it: lem (inside), blutut (belly), ksaligem (your trust), ke Dwata (to God), genléd nawa (rely on), kóm (your)."
				}
			]
		},
		{
			"title": "A bedtime story: the spider",
			"blocks": [
				{
					"kind": "p",
					"text": "A short story in T'boli, with corrections applied."
				},
				{
					"kind": "li",
					"text": "Kdaw ni, wen wong nô bê ta lmisa.: Today, there's a spider on top of the table."
				},
				{
					"kind": "li",
					"text": "Ngà laen likò bê wong.: The child isn't scared of the spider."
				},
				{
					"kind": "li",
					"text": "Góem gów du?: Where are you going?"
				},
				{
					"kind": "li",
					"text": "Teye bitil.: I'm very hungry."
				},
				{
					"kind": "li",
					"text": "Kehu bitil, ni ken para béléem.: If you're hungry, here's food for you."
				},
				{
					"kind": "li",
					"text": "Slamat béléem! Besowe ne.: Thank you! I'm full now."
				},
				{
					"kind": "li",
					"text": "Moo ktuk wong. Tluyab.: The spider is sleepy. Yawn."
				},
				{
					"kind": "li",
					"text": "Bulón nô bê ta.: The moon is up above."
				},
				{
					"kind": "li",
					"text": "Tungôu ne, wong. Hyu kifu. Kenbong nawahu u.: Sleep now, spider. Good night. I love you."
				},
				{
					"kind": "li",
					"text": "Hyu kifu béléem skóm.: Good night to you too."
				},
				{
					"kind": "p",
					"text": "Notes from the corrections: wen is \"there is / there was\", used whenever something shows up in a story; ngà drops its accent when an ending attaches (ngaen); ni here means \"here's\"."
				}
			]
		},
		{
			"title": "Added Oct 13",
			"blocks": [
				{
					"kind": "li",
					"text": "fi: points to a direction or place, over there. Kama fi: the pillow over there"
				},
				{
					"kind": "li",
					"text": "gnóm / gemnóm: to feel, go through something. Ke wen des gnómen yóm sotu nô bè lówó tekuy, tódô kdê le gemnóm du snéen: if one part of the body hurts, every part feels it (1 Corinthians 12:26)"
				},
				{
					"kind": "li",
					"text": "papél: paper"
				},
				{
					"kind": "li",
					"text": "temdanan: rest, resting. Ke Jisas deng mom gtungô, temdanan te kama fi: Jesus was asleep, resting on the pillow (Mark 4:38)"
				},
				{
					"kind": "li",
					"text": "rest, resting: temdanan"
				},
				{
					"kind": "li",
					"text": "pillow: kama"
				},
				{
					"kind": "li",
					"text": "paper: papél"
				}
			]
		},
		{
			"title": "Bible names (confirmed Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Jisas: Jesus. Jisas Krays: Jesus Christ (Matthew 1:1). Misaya: Messiah (Matthew 16:16)"
				},
				{
					"kind": "li",
					"text": "The twelve aposol (Matthew 10:2–4):"
				},
				{
					"kind": "p",
					"text": "1. Simun Pitér: Simon Peter. Also Sifas, which means botu, stone (John 1:42)"
				},
				{
					"kind": "p",
					"text": "2. Andru: Andrew, twoli Pitér (Peter's brother)"
				},
				{
					"kind": "p",
					"text": "3. Jim: James, ngà Sibidi (son of Zebedee)"
				},
				{
					"kind": "p",
					"text": "4. Jan: John, his brother. The two were called Buanirgis, Kem Ngà Lugung (Sons of Thunder)"
				},
				{
					"kind": "p",
					"text": "5. Filip: Philip"
				},
				{
					"kind": "p",
					"text": "6. Bartulumyu: Bartholomew"
				},
				{
					"kind": "p",
					"text": "7. Tumas: Thomas"
				},
				{
					"kind": "p",
					"text": "8. Matyu: Matthew, yóm tau gel mtuk bwis (the tax collector)"
				},
				{
					"kind": "p",
					"text": "9. Jim ngà Alfiyus: James son of Alphaeus (Matthew spells it Elfiyus)"
				},
				{
					"kind": "p",
					"text": "10. Tadiyus: Thaddeus (Tediyus in Matthew). Luke calls him Judas ngà yóm sotu Jim"
				},
				{
					"kind": "p",
					"text": "11. Simun: Simon the Zealot, yóm tau tehe mung mofin yóm kul benwu"
				},
				{
					"kind": "p",
					"text": "12. Judas Iskariyut: Judas Iscariot, yóm fen bemlay sumóng ke Jisas"
				},
				{
					"kind": "li",
					"text": "twoli: brother. botu: stone. lugung: thunder. bwis: tax"
				},
				{
					"kind": "li",
					"text": "kem gel lemolò du: disciples, literally \"the ones who follow him\" (163 times in the New Testament). Kem gel lemolò ke Jisas: Jesus's disciples. Lemolò: following, obeying (klolò, John 13:35). Gel: the one who usually does it"
				},
				{
					"kind": "li",
					"text": "aposol: apostle (Matthew 10:2). Kristyan: Christian (Acts 11:26)"
				},
				{
					"kind": "li",
					"text": "disciples: kem gel lemolò du. apostle: aposol"
				},
				{
					"kind": "li",
					"text": "Midi: Mary, sawang libun (young woman, Luke 1:27). Yê Jisas: mother of Jesus"
				},
				{
					"kind": "li",
					"text": "Jusif: Joseph, yóm tehe myehen ke Midi (Mary's husband, Matthew 1:16)"
				},
				{
					"kind": "li",
					"text": "Jan gel mabtays: John the Baptist, \"John who baptizes\" (Matthew 3:1)"
				},
				{
					"kind": "li",
					"text": "Pol: Paul, also Sol (Saul) (Acts 13:9)"
				},
				{
					"kind": "li",
					"text": "Ilisabét: Elizabeth. Sekariya: Zechariah (Luke 1:5)"
				},
				{
					"kind": "li",
					"text": "Dabid: David. Abraham, Isak, Jakub: Abraham, Isaac, Jacob (Matthew 1:2)"
				},
				{
					"kind": "li",
					"text": "Midi lemwót gu bè Megdala: Mary Magdalene (Matthew 27:56)"
				},
				{
					"kind": "li",
					"text": "Marta, Lasarus: Martha, Lazarus; Midi is their sister (John 11:1)"
				},
				{
					"kind": "li",
					"text": "Hirod: Herod. Paylét: Pilate"
				},
				{
					"kind": "li",
					"text": "yê: mother. mà: father. libun: woman. logi: man. sawang: young"
				},
				{
					"kind": "li",
					"text": "mother: yê. father: mà. woman: libun. man: logi. young: sawang"
				},
				{
					"kind": "li",
					"text": "Adam: Adam, ngà Dwata (Luke 3:38). Ib: Eve (2 Corinthians 11:3)"
				},
				{
					"kind": "li",
					"text": "Kain, Abél: Cain and Abel (1 John 3:12). Sét, Inos, Inuk: Seth, Enosh, Enoch"
				},
				{
					"kind": "li",
					"text": "Nuwa: Noah (Matthew 24:37). Sara: Sarah (Hebrews 11:11)"
				},
				{
					"kind": "li",
					"text": "Lat: Lot; yóm gfà yehen Lat: Lot's wife (Luke 17:32)"
				},
				{
					"kind": "li",
					"text": "Musis: Moses. Juswa: Joshua (Acts 7:45). Rahab: Rahab (Hebrews 11:31)"
				},
				{
					"kind": "li",
					"text": "Selumun: Solomon. Ilaydya: Elijah. Isaya: Isaiah. Danyél: Daniel"
				},
				{
					"kind": "li",
					"text": "Juna: Jonah; lem blutut yóm tey utón bong: in the belly of a huge fish (Matthew 12:40)"
				},
				{
					"kind": "li",
					"text": "Dwata: God. Gabrél: Gabriel. Maykél: Michael. Seitan: Satan"
				},
				{
					"kind": "li",
					"text": "hógów Dwata: angel. gna tugod Dwata: prophet. Sulat Dwata: Scripture. Ngà Tau: Son of Man. utón: fish"
				},
				{
					"kind": "li",
					"text": "angel: hógów Dwata. prophet: gna tugod Dwata. God: Dwata. fish: utón"
				}
			]
		},
		{
			"title": "Bible places (confirmed Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Bitlihim: Bethlehem, sotu benwu udì (Matthew 2:6). Nasarit: Nazareth (Matthew 2:23)"
				},
				{
					"kind": "li",
					"text": "Galili: Galilee. Lanaw Galili: Sea of Galilee. Kapérnaum: Capernaum (Matthew 4:13)"
				},
				{
					"kind": "li",
					"text": "Kana: Cana (John 2:1). Él Jurdan: Jordan River (Matthew 3:13). Samarya: Samaria. Jiriku: Jericho"
				},
				{
					"kind": "li",
					"text": "Jirusalim: Jerusalem. Bulul Ulib: Mount of Olives (Matthew 24:3). Gitsimani: Gethsemane (Matthew 26:36)"
				},
				{
					"kind": "li",
					"text": "Golgata: Golgotha, Bangag Kulu, Place of the Skull (Matthew 27:33). Bitani: Bethany"
				},
				{
					"kind": "li",
					"text": "Judiya, Juda: Judea, Judah. Israél: Israel. Idyip: Egypt (Matthew 2:13)"
				},
				{
					"kind": "li",
					"text": "Sodom ne Gomora: Sodom and Gomorrah (Matthew 10:15). Babilun: Babylon (Revelation 18:2)"
				},
				{
					"kind": "li",
					"text": "Damaskus: Damascus (Acts 9:3). Antyok: Antioch. Atin: Athens. Kurin: Corinth (Acts 18:1)"
				},
				{
					"kind": "li",
					"text": "Ifisus: Ephesus (Acts 19:1). Rom: Rome. Itali: Italy (Acts 27:1). Marta: Malta (Acts 28:1)"
				},
				{
					"kind": "li",
					"text": "syudad: city. benwu: land, place. benwu udì: town. prubinsya: province. él: river. lanaw: lake. bulul: mountain. kulu: head, skull"
				},
				{
					"kind": "li",
					"text": "hungul: a patch that stands apart: an island, or a clump of trees in a field (used in everyday T'boli too)"
				},
				{
					"kind": "li",
					"text": "hungul te mohin: island, \"a hungul in the sea\" (Acts 21:1, Acts 27:26, Revelation 1:9, Revelation 16:20)"
				},
				{
					"kind": "li",
					"text": "ngà hungul koyu: garden, grove, \"a little hungul of trees\" (Matthew 26:36, Mark 14:32, John 18:1)"
				},
				{
					"kind": "li",
					"text": "mohin: sea. koyu: tree, wood. udì: small"
				},
				{
					"kind": "li",
					"text": "island: hungul te mohin. garden/grove: ngà hungul koyu. sea: mohin. tree: koyu. city: syudad. river: él. lake: lanaw. mountain: bulul"
				}
			]
		},
		{
			"title": "Bible terms (confirmed Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "kros: cross (Matthew 27:32). longit: heaven, sky; Mà me bè longit: Our Father in heaven (Matthew 6:9)"
				},
				{
					"kind": "li",
					"text": "mni bè Dwata: pray (Matthew 6:9). salà: sin; Yó bayad salà, hatay: the wages of sin is death (Romans 6:23). hatay: death"
				},
				{
					"kind": "li",
					"text": "Hnifótem kum kem salà me: forgive us our sins (Matthew 6:12). hegsel ye: repent (Matthew 4:17)"
				},
				{
					"kind": "li",
					"text": "hemtahu: believe (John 3:16). kbong nawa: love, \"big heart\" (John 3:16)"
				},
				{
					"kind": "li",
					"text": "klowil laen dù sónen: eternal life (John 3:16). tóbóng Dwata: God's grace (Ephesians 2:8)"
				},
				{
					"kind": "li",
					"text": "Tulón Hyu: gospel, good news (Mark 1:1). Tulus Dwata: Holy Spirit. Hlowil Dwata: God raised him (Matthew 28:6)"
				},
				{
					"kind": "li",
					"text": "lanaw ofi: hell, \"lake of fire\" (Matthew 5:22). ofi: fire"
				},
				{
					"kind": "li",
					"text": "Sér / gónó tekuy mogot: Lord, \"the one who leads us\""
				},
				{
					"kind": "li",
					"text": "cross: kros. heaven: longit. pray: mni. sin: salà. death: hatay. love: kbong nawa. fire: ofi"
				}
			]
		},
		{
			"title": "Animals (confirmed Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "ubiha: sheep (Luke 15:4). Ngà Ubiha Dwata: Lamb of God (John 1:29)"
				},
				{
					"kind": "li",
					"text": "obun: dove (Matthew 3:16). ulal: snake (Matthew 10:16). asnu: donkey (Matthew 21:2)"
				},
				{
					"kind": "li",
					"text": "kudà: horse; kudà bukay: white horse (Revelation 6:2). bukay: white"
				},
				{
					"kind": "li",
					"text": "safì: ox, cow (Luke 13:15). kambing: goat (Matthew 25:32). sdô: pig (Matthew 8:31). ohu: dog (Matthew 15:26)"
				},
				{
					"kind": "li",
					"text": "ógóf: livestock, animal. tau semgyok ógóf: shepherd. ógóf lóbô: angry animal"
				},
				{
					"kind": "li",
					"text": "lóbô: anger. Matthew 10:16: lóbô lem bnes boluyen wolf, the fierce forest animal called wolf"
				},
				{
					"kind": "li",
					"text": "kamél: camel. liyun: lion (1 Peter 5:8). banug: eagle (Revelation 4:7)"
				},
				{
					"kind": "li",
					"text": "bolos: fox. lefunges: den, hole (Matthew 8:20)"
				},
				{
					"kind": "li",
					"text": "onuk: chicken, also bird in general. ngà onuk bnes: sparrows, little forest birds (Matthew 10:29). onuk koyu: birds of the air"
				},
				{
					"kind": "li",
					"text": "mósól: rooster. (Not the same as mosol: going or walking downward)"
				},
				{
					"kind": "li",
					"text": "mlon: hen. hafak: wing (Matthew 23:37)"
				},
				{
					"kind": "li",
					"text": "tlangas: locust. tneb: honey (Matthew 3:4). syufón: scorpion (Luke 10:19)"
				},
				{
					"kind": "li",
					"text": "wolf: kept in English in the Bible"
				},
				{
					"kind": "li",
					"text": "sheep: ubiha. dove: obun. snake: ulal. donkey: asnu. horse: kudà. cow: safì. goat: kambing. pig: sdô. dog: ohu. bird, chicken: onuk. rooster: mósól. hen: mlon. eagle: banug. fox: bolos. white: bukay. anger: lóbô"
				}
			]
		},
		{
			"title": "Joining words from the Bible (confirmed Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "abay se: because (757 times in the New Testament)"
				},
				{
					"kind": "li",
					"text": "Luke 2:7: abay se là bud wen gónó le nô lem yóm gónô (because there was no room for them in the inn)"
				},
				{
					"kind": "li",
					"text": "Matthew 5:3: abay se deng le sana gmung ne bè yó kem tau nogot Dwata (for theirs is the Kingdom of Heaven)"
				},
				{
					"kind": "li",
					"text": "John 9:22: abay se likò le yó kem Ju (because they feared the Jews)"
				},
				{
					"kind": "li",
					"text": "1 Peter 5:8: Abay se wen Seitan yóm hohon ye (because your adversary, the devil)"
				},
				{
					"kind": "li",
					"text": "yakà: for, because (172 times in the New Testament)"
				},
				{
					"kind": "li",
					"text": "Matthew 4:17: yakà móyónen hto ne yóm buteng Dwata mogot tau (for the Kingdom of Heaven is near)"
				},
				{
					"kind": "li",
					"text": "Matthew 2:13: yakà angat hfebel Hirod du yóm ngà (for Herod will seek the young child)"
				},
				{
					"kind": "li",
					"text": "because: kay, abay se, yakà"
				}
			]
		},
		{
			"title": "Sentences graded 5/5 (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Là nóyóu du tungô, abay se teye bitil. I don't want to sleep because I'm very hungry."
				},
				{
					"kind": "li",
					"text": "Meken kuy onuk, yakà tey kuy bitil. Let's all eat chicken, for we're all very hungry."
				},
				{
					"kind": "li",
					"text": "Wen ulal lem ngà hungul koyu. Likòe! There's a snake in the grove. I'm scared!"
				},
				{
					"kind": "li",
					"text": "Bê tagad tungô he, abay se là u deng meken he. Don't sleep yet, because you haven't eaten yet. Note: bê takes the ending of whoever you're telling."
				},
				{
					"kind": "li",
					"text": "Tey kekbong nawahu du ohu. I really love dogs. Note: say kekbong nawa after tey, and put du in as the subject marker before the thing you love. Kay làen lóbô means \"because it doesn't get angry\" (-en is he/she/it, not they)."
				},
				{
					"kind": "li",
					"text": "likò: afraid, fear. Likòe: I'm scared. Likò le: they feared (John 9:22)"
				}
			]
		},
		{
			"title": "Sentences graded 5/5, round 2 (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Mni kuy bè Dwata. Let's all pray to God. (Answer: Amén)"
				},
				{
					"kind": "li",
					"text": "Deng tonu yóm banug bè longit. I saw the eagle in the sky."
				},
				{
					"kind": "li",
					"text": "Nóyóu smakay kudà bukay. I want to ride a white horse."
				},
				{
					"kind": "li",
					"text": "Kmóót mósól ne, okóm là e deng tungô he. The rooster's crowing already, but I haven't slept yet."
				},
				{
					"kind": "li",
					"text": "Other ways: Kmóót ne mósól (the rooster's crowing now), Deng kmóót mósól (the rooster already crowed), Mósól deng mkóót (the rooster has crowed, said like an announcement)"
				},
				{
					"kind": "li",
					"text": "Hnifótem o kun, abay se deng gemsalà e béléem. Please forgive me, because I wronged you. Note: the order is Hnifótem o kun, not Hnifótem kum o."
				},
				{
					"kind": "li",
					"text": "kofi: eagle, the everyday word (banug is the Bible word)"
				},
				{
					"kind": "li",
					"text": "kmóót: crow (a rooster crowing)"
				},
				{
					"kind": "li",
					"text": "gemsalà: to sin against, to wrong someone"
				},
				{
					"kind": "li",
					"text": "eagle: banug, kofi"
				}
			]
		},
		{
			"title": "Rooster sentences, graded 5/5 (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Kmóót ne mósól, meken kuy ne. The rooster's crowing now, let's all eat."
				},
				{
					"kind": "li",
					"text": "Deng kmóót mósól, okóm hanà tungô du. The rooster already crowed, but he's still asleep. Note: use hanà for \"still,\" before the action."
				},
				{
					"kind": "li",
					"text": "Mósól deng mkóót! Hyu hlafus! The rooster has crowed! Good morning!"
				},
				{
					"kind": "li",
					"text": "Lóbôe bè mósól, abay se kmóót du bè kifu. I'm mad at the rooster because it crows at night."
				},
				{
					"kind": "li",
					"text": "Kilón kekóót mósól du? / Kilón kekóóten mósól du? When does the rooster crow? Answer: Kmóót du bè hlafus (it crows in the morning). Note: after kilón, kmóót becomes kekóót (like kbong becoming kekbong after tey)."
				}
			]
		},
		{
			"title": "10-sentence round, corrections (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Kilón kekenem du? Sana kebitilem mekô? When will you eat? Are you still hungry, huh?"
				},
				{
					"kind": "li",
					"text": "Tey kekbong nawahu du kofi, abay se tilob hafaken. I really love eagles because their wings are beautiful."
				},
				{
					"kind": "li",
					"text": "Kilón kekóót mósól du? Hanà e tungô. When will the rooster crow? I'm still sleeping. Note: hanà e tungô, the person goes right after hanà."
				},
				{
					"kind": "li",
					"text": "Béem ninum él kinì / Bê u minum él kinì / Béu minum él kinì, yakà tey kinì du. Don't drink the hot water, for it's very hot. Note: bê + -em becomes béem and takes the n-form (ninum); bê u or béu takes the m-form (minum)."
				},
				{
					"kind": "li",
					"text": "Wen sdô bê ta lmisa! Kayà lóbôe. There's a pig on the table! That's why I'm mad."
				},
				{
					"kind": "li",
					"text": "Deng ton le yóm ulal, kayà likò le. They saw the snake, so they're scared."
				},
				{
					"kind": "li",
					"text": "Mnihe bè Dwata, abay se deng gemsalà e. I'm praying to God because I sinned. Note: mni ends in a vowel, so it's mnihe, not mni e."
				},
				{
					"kind": "li",
					"text": "Nóyóu smakay asnu, okóm likòe. I want to ride a donkey, but I'm scared."
				},
				{
					"kind": "li",
					"text": "Meken kuy onuk haya. Let's all eat chicken tomorrow."
				},
				{
					"kind": "li",
					"text": "Mósól deng mkóót! Mlon deng temsek skun! The rooster crowed! The hen clucked too! Note: a hen doesn't kmóót, she temsek. And \"too\" for it/her is skun (skóm is \"you too\")."
				},
				{
					"kind": "li",
					"text": "temsek: a hen clucking or cackling"
				},
				{
					"kind": "li",
					"text": "sana: still (Sana kebitilem mekô?)"
				}
			]
		},
		{
			"title": "Round 5 corrections (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Sana kebitilu: I'm still hungry (confirmed by Deymar)"
				},
				{
					"kind": "li",
					"text": "Béem ninum yó él yó, abay se hanà kinì du / abay se hanà kekinien. Don't drink that water, because it's still hot. Note: yó él yó = that water (yó on both sides). Hanà kekinien is the closest match for \"it's still hot.\""
				},
				{
					"kind": "li",
					"text": "Mlon deng temsek, okóm hanà e tungô. The hen clucked, but I'm still sleeping."
				},
				{
					"kind": "li",
					"text": "Kilón kekenle du? When will they eat?"
				},
				{
					"kind": "li",
					"text": "Likòe ulal, omin likò ohuhu skun. I'm scared of snakes, and my dog is too. Other ways: omin likò skun ohuhu / omin likò skun dou ohu / dalang se ohuhu (as well as my dog)"
				},
				{
					"kind": "li",
					"text": "dalang se: as well as"
				},
				{
					"kind": "li",
					"text": "And I'm scared of dogs (all correct): Ominu likò ohu / Ne hu likò bê ohu / Le bud keklikou ohu / Omin likoe ohu"
				},
				{
					"kind": "li",
					"text": "keklikò: the ke- form of likò (scared), as in keklikou"
				}
			]
		},
		{
			"title": "Sana vs hanà (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "sana: still, when you're not sure it's still happening, or when you're just noticing or asking. Takes the ke- form: sana ktungôen, sana kekenen, sana ke kudien"
				},
				{
					"kind": "li",
					"text": "hanà: still, when you're sure it's still happening, or telling someone who doesn't know. Takes the plain form: hanà tungô, hanà meken, hanà udì"
				},
				{
					"kind": "li",
					"text": "Sana kebitilu. I'm still hungry."
				},
				{
					"kind": "li",
					"text": "Sana ktungôen du? Is he still sleeping? Answer: Ell, hanà tungô (yes, still sleeping)"
				},
				{
					"kind": "li",
					"text": "Hanà tungô du? He's still sleeping? Answer: Ell, hanà tungô"
				},
				{
					"kind": "li",
					"text": "Hanà meken du? He's still eating? Answer: Ell, hanà mken / Ell, sana kekenen (yes, he's still eating)"
				},
				{
					"kind": "li",
					"text": "Sana ke kudien du. He's still small (just noticing it, or asking)"
				},
				{
					"kind": "li",
					"text": "Hanà udì du. He's still small (telling someone who doesn't know if he's small or big)"
				},
				{
					"kind": "li",
					"text": "Hanà làen deng bong. He's not big yet (and you know he'll still grow). Hanà also means \"still, for now\""
				},
				{
					"kind": "li",
					"text": "Sana deng bong du. He's already big"
				},
				{
					"kind": "li",
					"text": "udì: small. bong: big"
				}
			]
		},
		{
			"title": "Sana/hanà round, graded (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Sana ktungôen ohuhu? Is my dog still sleeping? (no du needed when the subject is named)"
				},
				{
					"kind": "li",
					"text": "Hanà udì ohuhu, okóm sana deng bong mósólu. My dog is still small, but my rooster is already big."
				},
				{
					"kind": "li",
					"text": "Hanà le meken, abay se hanà kebitil le. They're still eating, because they're still hungry. Note: the person word goes right after hanà (hanà le meken, hanà e tungô)"
				},
				{
					"kind": "li",
					"text": "Sana le meken. They immediately eat. Note: sana + person + plain form means \"right away\""
				},
				{
					"kind": "li",
					"text": "Sana kken le / Sana keken le. They are still eating."
				},
				{
					"kind": "li",
					"text": "Sana kekenem (du)? Are you still eating (it)? Du at the end is the \"it\" being eaten"
				},
				{
					"kind": "li",
					"text": "Hanà là e deng tungô, abay se hanà kinì yó coffee-hu yó. I still haven't slept, because that coffee of mine is still hot."
				}
			]
		},
		{
			"title": "Round 7, graded 5/5 (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "Hanà e meken, abay se hanà kebitilu. I'm still eating, because I'm still hungry."
				},
				{
					"kind": "li",
					"text": "Denge meken, sana e tungô / sanahe tungô. I already ate, so I fall asleep right away. Note: sana ends in a vowel, so the ending can attach with h (sanahe), like nehe and mnihe"
				},
				{
					"kind": "li",
					"text": "Sana kekóót mósól? Is the rooster still crowing?"
				},
				{
					"kind": "li",
					"text": "Hanà le tungô, okóm sana deng kmóót mósól. They're still sleeping, but the rooster already crowed."
				},
				{
					"kind": "li",
					"text": "Sana kekenem du yó onuk yó? Are you still eating that chicken? Note: du goes before the thing being eaten"
				}
			]
		},
		{
			"title": "Confirmed from Bible word hunt round 4: Everyday life (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "mambang: bread, a loaf. Hitu botù mambang = seven loaves; botù counts loaves"
				},
				{
					"kind": "li",
					"text": "tnafay: bread (from Tagalog tinapay)"
				},
				{
					"kind": "li",
					"text": "bnotu: food packed for a trip"
				},
				{
					"kind": "li",
					"text": "bnék: seed (Bible: sbotù bnék halay, one grain of wheat; sohul bnék, sow seed). Bnék hyu = good seed"
				},
				{
					"kind": "li",
					"text": "lem: seed (Deymar's word; also lem = in/inside)"
				},
				{
					"kind": "li",
					"text": "lan: path, road, way"
				},
				{
					"kind": "li",
					"text": "tébéd: rope, cord. fét: tied, bound. fes tébéd: whip of cords"
				},
				{
					"kind": "li",
					"text": "bag: bag (from English). tlumfà: sandals"
				},
				{
					"kind": "li",
					"text": "abì: basket. lukas: leftovers"
				},
				{
					"kind": "li",
					"text": "huket: net"
				},
				{
					"kind": "li",
					"text": "solok: lamp, light. hemtom solok: light a lamp"
				},
				{
					"kind": "li",
					"text": "blay: gift, give. kenhulung: gift, talent"
				},
				{
					"kind": "li",
					"text": "lebeng: grave, tomb; to bury. lembeng: burying"
				},
				{
					"kind": "li",
					"text": "kilib: tomb cut into rock, cave (Bible: John 19:41 kilib lomi, new tomb; Hebrews 11:38 caves)"
				}
			]
		},
		{
			"title": "Confirmed from Bible word hunt round 4: People (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "tau hol geta / tau geta: king; also rich person. datù: title used when speaking to a king"
				},
				{
					"kind": "li",
					"text": "harì: king (from Tagalog hari)"
				},
				{
					"kind": "li",
					"text": "tau dók: servant (\"a person who is ordered\"). dók: command, order. tóbóng lówó: humble servant, helper. ngà libun gel dók le: servant girl"
				},
				{
					"kind": "li",
					"text": "hohon / hmohon: enemy. hnohon: treated as an enemy"
				},
				{
					"kind": "li",
					"text": "libun bolu: widow. bolu: widowed"
				},
				{
					"kind": "li",
					"text": "tau sbung: crowd (\"gathered people\"). tey dê tau: a lot of people"
				},
				{
					"kind": "li",
					"text": "mentey: to guard, keep watch. sendalù mentey: guards. sendalù: soldier"
				},
				{
					"kind": "li",
					"text": "hemdeng / hendeng: to judge, decide. kukum: law, judgment. kmukum: judging. tau hemdeng knukum: judge"
				}
			]
		},
		{
			"title": "Confirmed from Bible word hunt round 4: Doing words (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "hmatay: to kill (\"make die\"). hnatay: killed. ghatay: able to be killed"
				},
				{
					"kind": "li",
					"text": "kéng: lie, to tell a lie. gel mò kéng: keep lying"
				},
				{
					"kind": "li",
					"text": "hógów: to send. deng hógówu: I sent. hógów Dwata: angel (\"God's sent one\")"
				},
				{
					"kind": "li",
					"text": "eted: send (general), deliver"
				},
				{
					"kind": "li",
					"text": "muta: to harvest. nuta: the harvest. fun nuta: owner of the harvest"
				},
				{
					"kind": "li",
					"text": "hkó des: to heal (\"make the sickness leave\")"
				},
				{
					"kind": "li",
					"text": "hemdà / hdà: to build (\"make stand\"). gembà: destroy"
				},
				{
					"kind": "li",
					"text": "nélék: chose, chosen. kélék: choosing, appointing"
				},
				{
					"kind": "li",
					"text": "mebel: to look for, search. hnebelen: he searched for"
				},
				{
					"kind": "li",
					"text": "fasad: promise. fasaden: his promise"
				},
				{
					"kind": "li",
					"text": "sohul: to sow, scatter seeds. smohul: sowing. ksohulen: his sowing"
				},
				{
					"kind": "li",
					"text": "hulu: to plant"
				}
			]
		},
		{
			"title": "Confirmed from Bible word hunt round 4: Feelings and ideas (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "menek nawa / henek nawa / kenek nawa: peace (\"calm breath\"). nawa: breath"
				},
				{
					"kind": "li",
					"text": "kehligal / kligal: joy, happiness (from hligal, happy)"
				},
				{
					"kind": "li",
					"text": "kehtahu: faith, belief (from tahu, true). hemtahu: believe"
				},
				{
					"kind": "li",
					"text": "ktahuhen: the truth. Tódô tulónu kuy ktahuhen: I tell you the truth"
				},
				{
					"kind": "li",
					"text": "kgis: strength. kemgis: strong"
				},
				{
					"kind": "li",
					"text": "lewok: tears. mosok lewok: tears falling"
				},
				{
					"kind": "li",
					"text": "mosok: something falling on its own, by itself"
				}
			]
		},
		{
			"title": "Confirmed from Bible word hunt round 4: Describing words (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "tau élél: poor person. élél: lacking, not having (ke wen gónó le élél = if there's something they lack)"
				},
				{
					"kind": "li",
					"text": "glayam: poor"
				},
				{
					"kind": "li",
					"text": "là ket: lack (as a word; depends on context)"
				},
				{
					"kind": "li",
					"text": "butô: blind"
				},
				{
					"kind": "li",
					"text": "bokong: deaf. hbokong: to make deaf. umew: mute"
				}
			]
		},
		{
			"title": "Confirmed from Bible word hunt round 4: Things and places (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "blówón: gold. kuruna: crown"
				},
				{
					"kind": "li",
					"text": "filak: silver, money"
				},
				{
					"kind": "li",
					"text": "tifas: wine. ninum: a drink (from minum). ninum lóbô: strong drink"
				},
				{
					"kind": "li",
					"text": "bak tikeb: gate, door. bak tikeben: its gates. Tikeb Tilob: Beautiful Gate"
				},
				{
					"kind": "li",
					"text": "tey lenos bong: storm (\"very big wind\"). bagyu: storm (everyday word)"
				},
				{
					"kind": "li",
					"text": "nulu: wedding. gónô mulu: wedding house/feast. ken nuluhen: his wedding feast. logi myehen: groom"
				}
			]
		},
		{
			"title": "Notes from Deymar (Oct 13)",
			"blocks": [
				{
					"kind": "li",
					"text": "h- prefix: means \"make it happen\" / cause (hmatay make die, hdà make stand, hkó des make the sickness leave, hbokong make deaf, hekgis/hekegis make strong; the h- goes on the root kgis, not kemgis)"
				},
				{
					"kind": "li",
					"text": "lem: inside; seed is lem because it's the inside (same word)"
				},
				{
					"kind": "li",
					"text": "Old words like mambang (bread) and tey lenos bong (storm) are still said, mostly by older people; younger people use tnafay, bagyu, harì"
				},
				{
					"kind": "li",
					"text": "lnos: wind (short form of lenos)"
				},
				{
					"kind": "li",
					"text": "husek: come/go inside of something; add the person after for who goes in. Husek ye: you all get in, come in, go in. Géhél ye husek: hurry, you all get in"
				},
				{
					"kind": "li",
					"text": "lnos kemgis / lenos kemgis: strong wind. lnos bong: big wind"
				},
				{
					"kind": "li",
					"text": "Géhél ye!: hurry up, you all!"
				},
				{
					"kind": "li",
					"text": "Strong wind, go inside: Tey lnos bong! Mulék kuy bê lem gónô ne. Géhél ye! Husek ye. (Very big wind! We go back inside the house now. Hurry up! Come in.)"
				},
				{
					"kind": "li",
					"text": "Huseku: you're going in. Huseke: I was going in. Husek du: he/she goes in. Takes the rest of the person endings too"
				},
				{
					"kind": "li",
					"text": "Describing word goes after the thing: lnos kemgis (strong wind), gónô bong (big house)"
				},
				{
					"kind": "li",
					"text": "He's poor, he doesn't have any food: Glayam du, làen ket kenen. (làen = he doesn't; kenen = his food; the endings carry the person)"
				},
				{
					"kind": "li",
					"text": "I'll send you money: Nehu eted filak béléem."
				},
				{
					"kind": "li",
					"text": "There's a storm tomorrow. Really strong wind!: Wen bagyu haya. Tey lnos kemgis!"
				},
				{
					"kind": "li",
					"text": "His tears are falling, so cheer him up: Mosok lewoken, henligalem du."
				},
				{
					"kind": "li",
					"text": "slaf: have to, worry; same meaning as lóngón"
				},
				{
					"kind": "li",
					"text": "senlaf: to do something fast; figuring out how to do it. Senlafu kekenu: I'm figuring out how I'll eat. Lnóngón works the same way"
				},
				{
					"kind": "li",
					"text": "g-: able to (gbayad, able to pay; ghatay, able to be killed). Là gbayadu (du): I can't pay (it). bayad: pay in general"
				},
				{
					"kind": "li",
					"text": "Don't (you) worry: Béu lóngónem / Tafa nawahem / Heslafem"
				},
				{
					"kind": "li",
					"text": "I can't sleep: Làe gtungô. Là gtungôu?: you can't sleep? Là u gtungô?: you couldn't sleep?"
				},
				{
					"kind": "li",
					"text": "Là gbayadu du: I can't pay it. Làe gbayad: I couldn't pay"
				},
				{
					"kind": "li",
					"text": "hekgis / hekegis: make strong (h- + kgis). Nehu hekgis u: I'll make you strong"
				},
				{
					"kind": "li",
					"text": "Lnos kemgis vs kemgis lnos: lnos kemgis tells someone the wind is strong; kemgis lnos describes it, more like a statement or saying it to yourself"
				},
				{
					"kind": "li",
					"text": "I don't have any money: làen ket filaku (-en, because the money is the subject: my money isn't there)"
				},
				{
					"kind": "li",
					"text": "Don't worry, I'll make you strong: Béu lóngónem, nehu hekgis u."
				},
				{
					"kind": "li",
					"text": "I couldn't sleep yesterday because the wind was really strong: Làe gtungô ekimel, kay tey lnos kemgis."
				},
				{
					"kind": "li",
					"text": "I can't pay it, because I don't have any money: Là gbayadu du, kay làen ket filaku."
				},
				{
					"kind": "li",
					"text": "Hurry, all of you, get inside the big house: Géhél ye husek bê lem gónô bong."
				},
				{
					"kind": "li",
					"text": "Tomorrow I'll plant seeds next to my house: Haya, nehu hulu lem bê lohok gónôu."
				},
				{
					"kind": "li",
					"text": "I'll build a big house by the water: Nehu hdà gónô bong bê lohok él."
				},
				{
					"kind": "li",
					"text": "The strong wind will make you cold: Hetnawen u lnos kemgis."
				},
				{
					"kind": "li",
					"text": "Feed my cats!: Henkenem kem kuyingu kun!"
				},
				{
					"kind": "li",
					"text": "I'll heal him (make his sickness leave): Nehu hkó desen."
				},
				{
					"kind": "li",
					"text": "Make them happy (command): Hefligalem lu."
				},
				{
					"kind": "li",
					"text": "My teacher: mestluhu. Thanks, my teacher: Slamat béléem, mestluhu."
				},
				{
					"kind": "li",
					"text": "Look it up in our notes!: Nebelem du bê sulat te kun! (everyday version: Nebelem bê notes-te kun!)"
				},
				{
					"kind": "li",
					"text": "Deymar is my teacher, and my friend: Deymar mestluhu, omin dou dumu sbót. (dou = my)"
				},
				{
					"kind": "li",
					"text": "And I'm his friend too: Omin ou kun dumu sbót."
				},
				{
					"kind": "li",
					"text": "I'll help you: Nehu tnóbóng u (tóbong takes the n inside here)"
				},
				{
					"kind": "li",
					"text": "Teacher Deymar taught me the words of T'boli: Tnoloken o Mestlu Deymar kem udél T'boli. Passive version: Ou tnolok Mestlu Deymar udél T'boli."
				},
				{
					"kind": "li",
					"text": "I want everyone to be happy: Kóyô u / Kóyóu ke kdéen tau hol hligal. Dou kóyô also works, meaning \"my want\""
				},
				{
					"kind": "li",
					"text": "kun: his/hers/its, something he/she/it owns. Fits the set: kut (ours), kuy (yours), kul (theirs), kun (his/hers)"
				},
				{
					"kind": "li",
					"text": "And I'm his friend, telling someone: Omin ou dumuhen sbót."
				},
				{
					"kind": "li",
					"text": "kun (please): a second kun that softens a request into \"please\" or \"for me\": Snolokem du kun"
				},
				{
					"kind": "li",
					"text": "Please get his bag (for me): Nwahem do kun yóm kun bag. First kun = please; yóm kun = the one that's his, and the bag is the subject"
				},
				{
					"kind": "li",
					"text": "Please get me his bag: Nwahem do kun bagen. The -en on bag says who owns it"
				},
				{
					"kind": "li",
					"text": "nwahem: you get/take it (wa, take; same root as gwa and swa)"
				},
				{
					"kind": "li",
					"text": "Please get me my bag: Nwahem do kun baghu."
				},
				{
					"kind": "li",
					"text": "lana: gone, disappear, die out (là nóyóen du ke lana udél T'boli: he doesn't want T'boli to disappear)"
				},
				{
					"kind": "li",
					"text": "néen: only, just. Fun néen (just for fun), Ok néen (just okay)"
				},
				{
					"kind": "li",
					"text": "Filipinas: Philippines"
				},
				{
					"kind": "li",
					"text": "Alfabét: alphabet"
				},
				{
					"kind": "li",
					"text": "Farmasi: pharmacy"
				},
				{
					"kind": "li",
					"text": "Faris: Paris"
				},
				{
					"kind": "li",
					"text": "Fkistan: Pakistan"
				},
				{
					"kind": "li",
					"text": "Fortugal: Portugal"
				},
				{
					"kind": "li",
					"text": "Péru: Peru"
				},
				{
					"kind": "li",
					"text": "Fól: Paul (traditional; the Bible spells it Pol)"
				},
				{
					"kind": "li",
					"text": "Faro: Pharaoh. Yóm libun boi Faro: Pharaoh's daughter (Hebrews 11:24). The Bible usually just says tau hol geta bè Idyip, the king of Egypt (Acts 7:10)"
				},
				{
					"kind": "li",
					"text": "Stéfén: Stephen (Acts 7:1)"
				}
			]
		},
		{
			"title": "Places in Canaan, from the Bible, confirmed (Oct 13)",
			"blocks": [
				{
					"kind": "p",
					"text": "The land and regions"
				},
				{
					"kind": "li",
					"text": "Kanan: Canaan. tau Kanan: a Canaanite (Matthew 15:22)"
				},
				{
					"kind": "li",
					"text": "Judiya: Judea (Matthew 2:1)"
				},
				{
					"kind": "li",
					"text": "Samarya: Samaria (John 4:5)"
				},
				{
					"kind": "li",
					"text": "Galili: Galilee (Luke 1:26)"
				},
				{
					"kind": "li",
					"text": "Idumiya: Idumea (Mark 3:8)"
				},
				{
					"kind": "li",
					"text": "Sfolò Benwu: the Decapolis, literally \"ten towns\" (Mark 5:20)"
				},
				{
					"kind": "li",
					"text": "Falistin: Palestine (not in the New Testament; Deymar confirmed)"
				},
				{
					"kind": "li",
					"text": "Filistin / tau Filistin: Philistine (not in the New Testament; Deymar confirmed)"
				},
				{
					"kind": "p",
					"text": "Jerusalem and around it"
				},
				{
					"kind": "li",
					"text": "Jirusalim: Jerusalem (Matthew 4:5)"
				},
				{
					"kind": "li",
					"text": "Sayun: Zion (1 Peter 2:6)"
				},
				{
					"kind": "li",
					"text": "Bitlihim: Bethlehem (Matthew 2:1)"
				},
				{
					"kind": "li",
					"text": "Bitani: Bethany (Matthew 26:6)"
				},
				{
					"kind": "li",
					"text": "Bitfid: Bethphage (Matthew 21:1)"
				},
				{
					"kind": "li",
					"text": "Bulul Ulib: Mount of Olives (Matthew 24:3)"
				},
				{
					"kind": "li",
					"text": "Gitsimani: Gethsemane (Matthew 26:36)"
				},
				{
					"kind": "li",
					"text": "Golgata: Golgotha. Bangag Kulu: skull, the meaning the verse gives (Matthew 27:33)"
				},
				{
					"kind": "li",
					"text": "Silom: Siloam (John 9:7)"
				},
				{
					"kind": "li",
					"text": "Kidron: Kidron (John 18:1)"
				},
				{
					"kind": "li",
					"text": "Imiyus: Emmaus (Luke 24:13)"
				},
				{
					"kind": "li",
					"text": "Ifraim: Ephraim (John 11:54)"
				},
				{
					"kind": "li",
					"text": "Arimatiya: Arimathea (Luke 23:50)"
				},
				{
					"kind": "li",
					"text": "Rama: Ramah (Matthew 2:18)"
				},
				{
					"kind": "p",
					"text": "Galilee and the lake"
				},
				{
					"kind": "li",
					"text": "Lanaw Galili: Sea of Galilee (Matthew 4:13)"
				},
				{
					"kind": "li",
					"text": "Nasarit: Nazareth (Luke 1:26)"
				},
				{
					"kind": "li",
					"text": "Kapérnaum: Capernaum (Matthew 4:13)"
				},
				{
					"kind": "li",
					"text": "Kana: Cana (John 21:2)"
				},
				{
					"kind": "li",
					"text": "Nain: Nain (Luke 7:11)"
				},
				{
					"kind": "li",
					"text": "Bitsayda: Bethsaida (Luke 10:13)"
				},
				{
					"kind": "li",
					"text": "Kurasin: Chorazin (Luke 10:13)"
				},
				{
					"kind": "li",
					"text": "Megdala: Magdala (John 20:1)"
				},
				{
					"kind": "li",
					"text": "Ginésarit: Gennesaret (Matthew 14:34)"
				},
				{
					"kind": "li",
					"text": "Dalmanuta: Dalmanutha (Mark 8:10)"
				},
				{
					"kind": "li",
					"text": "Girasin: Gerasenes (Matthew 8:28)"
				},
				{
					"kind": "p",
					"text": "Jordan valley"
				},
				{
					"kind": "li",
					"text": "Jurdan: Jordan River (Matthew 3:13)"
				},
				{
					"kind": "li",
					"text": "Jiriku: Jericho (Luke 10:30)"
				},
				{
					"kind": "li",
					"text": "Inun, Salim: Aenon, Salim (John 3:23)"
				},
				{
					"kind": "li",
					"text": "Sikar: Sychar (John 4:5)"
				},
				{
					"kind": "p",
					"text": "Coast and north"
				},
				{
					"kind": "li",
					"text": "Tayal: Tyre (Luke 10:13)"
				},
				{
					"kind": "li",
					"text": "Sidon: Sidon (Luke 10:13). In Acts 9:35, Sidon is also used for Sharon"
				},
				{
					"kind": "li",
					"text": "Tulimas: Ptolemais, the P dropped (Acts 21:7)"
				},
				{
					"kind": "li",
					"text": "Seseriya: Caesarea (Acts 8:40)"
				},
				{
					"kind": "li",
					"text": "Seseriya Flipay: Caesarea Philippi, Ph to F (Matthew 16:13)"
				},
				{
					"kind": "li",
					"text": "Jupa: Joppa (Acts 9:36)"
				},
				{
					"kind": "li",
					"text": "Lida: Lydda (Acts 9:35)"
				},
				{
					"kind": "li",
					"text": "Asdod: Azotus, the old Hebrew name (Acts 8:40)"
				},
				{
					"kind": "li",
					"text": "Gasa: Gaza (Acts 8:26)"
				},
				{
					"kind": "li",
					"text": "Antipatris: Antipatris (Acts 23:31)"
				},
				{
					"kind": "p",
					"text": "Old Canaan cities"
				},
				{
					"kind": "li",
					"text": "Sodom, Gomora: Sodom and Gomorrah (Luke 10:12, Jude 1:7)"
				}
			]
		}
	]
};
var ENTRIES = data.entries;
var EN_INDEX = data.index;
var PHRASES = data.phrases;
var GUIDE = data.guide;
var LETTERS = [...new Set(ENTRIES.map((e) => e.letter).filter(Boolean))];
var TOPICS = [...new Set(PHRASES.map((p) => p.topic))];
var QUICK_ENGLISH = [
	"good morning",
	"how are you?",
	"thank you so much",
	"I love you",
	"I'm very hungry",
	"let's eat"
];
function norm(value) {
	return value.trim().toLowerCase().replace(/[“”"']/g, "").replace(/[?.!,;:]+/g, "").replace(/\s+/g, " ");
}
function fold(value) {
	return norm(value).normalize("NFD").replace(/\p{M}/gu, "");
}
var NO_WORD = /* @__PURE__ */ new Set([
	"a",
	"an",
	"am",
	"is",
	"are",
	"was",
	"were",
	"be",
	"been",
	"being",
	"do",
	"does",
	"did",
	"of",
	"have",
	"has",
	"had",
	"will",
	"can",
	"let"
]);
var CONTRACTIONS = {
	"i'm": ["I", "am"],
	"you're": ["you", "are"],
	"we're": ["we", "are"],
	"they're": ["they", "are"],
	"he's": ["he", "is"],
	"she's": ["she", "is"],
	"it's": ["it", "is"],
	"that's": ["that", "is"],
	"what's": ["what", "is"],
	"where's": ["where", "is"],
	"who's": ["who", "is"],
	"there's": ["there", "is"],
	"i'll": ["I", "will"],
	"you'll": ["you", "will"],
	"we'll": ["we", "will"],
	"they'll": ["they", "will"],
	"i've": ["I", "have"],
	"we've": ["we", "have"],
	"don't": ["do", "not"],
	"can't": ["can", "not"],
	"won't": ["will", "not"],
	"didn't": ["did", "not"],
	"isn't": ["is", "not"],
	"aren't": ["are", "not"],
	"let's": ["let", "us"],
	"haven't": ["have", "not"],
	"hasn't": ["has", "not"]
};
function normLex(value) {
	return value.trim().toLowerCase().replace(/[“”"']/g, "").replace(/[?.!,;:()]+/g, " ").replace(/\s+/g, " ").trim();
}
function soften(value) {
	let s = value.trim().toLowerCase();
	s = s.replace(/\([^)]*\)/g, " ");
	for (const [re, to] of [
		[/\bi'm\b/g, "i am"],
		[/\byou're\b/g, "you are"],
		[/\bwe're\b/g, "we are"],
		[/\bthey're\b/g, "they are"],
		[/\bhe's\b/g, "he is"],
		[/\bshe's\b/g, "she is"],
		[/\bit's\b/g, "it is"],
		[/\bthat's\b/g, "that is"],
		[/\bwhat's\b/g, "what is"],
		[/\bwhere's\b/g, "where is"],
		[/\bwho's\b/g, "who is"],
		[/\bthere's\b/g, "there is"],
		[/\bi'll\b/g, "i will"],
		[/\byou'll\b/g, "you will"],
		[/\bwe'll\b/g, "we will"],
		[/\bthey'll\b/g, "they will"],
		[/\bi've\b/g, "i have"],
		[/\bdon't\b/g, "do not"],
		[/\bcan't\b/g, "cannot"],
		[/\bwon't\b/g, "will not"],
		[/\blet's\b/g, "let us"],
		[/\bhaven't\b/g, "have not"],
		[/\bisn't\b/g, "is not"],
		[/\baren't\b/g, "are not"],
		[/\bdidn't\b/g, "did not"]
	]) s = s.replace(re, to);
	return normLex(s);
}
function compactGloss(heads) {
	const parts = heads.split(";").map((part) => part.replace(/\s*\([^)]*\)/g, " ").replace(/\s+under\s+.*/i, "").replace(/\s+/g, " ").trim()).filter(Boolean);
	const unique = [];
	for (const part of parts) if (!unique.some((item) => item.toLowerCase() === part.toLowerCase())) unique.push(part);
	const two = unique.slice(0, 2).join(" · ");
	if (two.length <= 32) return two;
	return unique[0] ?? "";
}
var LEX = /* @__PURE__ */ new Map();
function addLex(key, gloss) {
	const k = normLex(key);
	if (!k || k.length > 48 || NO_WORD.has(k) || LEX.has(k)) return;
	const g = gloss.trim();
	if (!g) return;
	LEX.set(k, g);
}
for (const item of EN_INDEX) {
	const gloss = compactGloss(item.heads);
	const exact = normLex(item.en);
	if (exact && gloss && !NO_WORD.has(exact)) LEX.set(exact, gloss);
}
for (const item of EN_INDEX) {
	const gloss = LEX.get(normLex(item.en));
	if (!gloss) continue;
	const spelled = item.en.replace(/\(([^)]+)\)/g, " $1 ").replace(/\s+/g, " ").trim();
	const beforeParen = item.en.replace(/\s*\([^)]*\)\s*$/, "").trim();
	const aliases = /* @__PURE__ */ new Set([spelled, beforeParen]);
	for (const bit of spelled.split(",")) aliases.add(bit.trim());
	for (const alias of aliases) addLex(alias, gloss);
}
function clauseSplit(value) {
	const parts = value.split(/(?<=[.!?])\s+/).map((part) => part.trim()).filter(Boolean);
	return parts.length ? parts : [value.trim()].filter(Boolean);
}
function pushPair(rows, en, tbl, rank) {
	const english = en.replace(/\s*\([^)]*\)/g, " ").replace(/\s+/g, " ").trim();
	const tboli = tbl.trim();
	if (!english || !tboli) return;
	rows.push({
		en: english,
		tbl: tboli,
		rank
	});
	const ec = clauseSplit(english);
	const tc = clauseSplit(tboli);
	if (ec.length < 2 || ec.length !== tc.length) return;
	for (let i = 0; i < ec.length; i++) {
		const left = ec[i];
		const right = tc[i];
		if (!left || !right) continue;
		if (soften(left) === soften(english)) continue;
		rows.push({
			en: left,
			tbl: right,
			rank: rank + 1
		});
	}
}
function collectPairs() {
	const rows = [];
	for (const phrase of PHRASES) {
		const rank = phrase.topic === "Stories and sentences" ? 2 : phrase.topic === "Cuss words" ? 4 : 0;
		pushPair(rows, phrase.en, phrase.tbl, rank);
	}
	for (const entry of ENTRIES) {
		for (const example of entry.examples) if (example.en) pushPair(rows, example.en, example.tbl, 1);
		for (const form of entry.forms) {
			if (!form.gloss || form.gloss.includes("(") || form.gloss.length > 90) continue;
			const words = soften(form.gloss).split(" ").filter(Boolean);
			if (words.length < 2 || words.length > 14) continue;
			pushPair(rows, form.gloss, form.form, 1);
		}
	}
	return rows;
}
var PAIRS = collectPairs();
function firstGloss(gloss) {
	return (gloss.split("·")[0]?.split("/")[0] ?? gloss).trim();
}
for (const pair of PAIRS) {
	const en = soften(pair.en).split(" ").filter(Boolean);
	const tbl = pair.tbl.replace(/[?.!]+$/g, "").split(/\s+/).filter(Boolean);
	if (en.length !== 2 || tbl.length !== 2) continue;
	const g0 = LEX.get(en[0] ?? "");
	const g1 = LEX.get(en[1] ?? "");
	const same = (gloss, word) => !!gloss && fold(firstGloss(gloss)) === fold(word);
	if (same(g0, tbl[0] ?? "") && !g1) addLex(en[1] ?? "", tbl[1] ?? "");
	else if (same(g1, tbl[1] ?? "") && !g0) addLex(en[0] ?? "", tbl[0] ?? "");
	else if (same(g0, tbl[1] ?? "") && !g1) addLex(en[1] ?? "", tbl[0] ?? "");
	else if (same(g1, tbl[0] ?? "") && !g0) addLex(en[0] ?? "", tbl[1] ?? "");
}
function wordGloss(word) {
	const key = normLex(word);
	if (!key || NO_WORD.has(key)) return null;
	return LEX.get(key) ?? (key.endsWith("s") ? null : LEX.get(`${key}s`) ?? null);
}
function glossEnglish(text) {
	const rough = text.trim().split(/\s+/).filter(Boolean);
	const tokens = [];
	for (const piece of rough) {
		const bare = piece.replace(/^[("']+|[)"'.!?,;:]+$/g, "") || piece;
		const split = CONTRACTIONS[bare.toLowerCase()];
		if (!wordGloss(bare) && split) tokens.push(...split);
		else tokens.push(bare);
	}
	return tokens.map((label) => {
		if (NO_WORD.has(normLex(label))) return {
			en: label,
			tbl: null,
			gap: true
		};
		return {
			en: label,
			tbl: wordGloss(label),
			gap: false
		};
	});
}
function lookupPhrase(english) {
	const key = soften(english);
	if (key.split(" ").filter(Boolean).length < 2) return null;
	const hits = PAIRS.filter((pair) => soften(pair.en) === key);
	if (!hits.length) return null;
	const best = /* @__PURE__ */ new Map();
	for (const hit of hits) {
		const id = normLex(hit.tbl);
		const prev = best.get(id);
		if (!prev || hit.rank < prev.rank) best.set(id, {
			tbl: hit.tbl,
			rank: hit.rank
		});
	}
	const [first, ...rest] = [...best.values()].sort((a, b) => a.rank - b.rank || a.tbl.length - b.tbl.length);
	if (!first) return null;
	return {
		tbl: first.tbl,
		alts: rest.slice(0, 2).map((item) => item.tbl)
	};
}
function entriesForLetter(letter) {
	return ENTRIES.filter((e) => e.letter === letter);
}
function searchEntries(query, limit = 40) {
	const q = fold(query);
	if (!q) return [];
	return ENTRIES.map((entry) => {
		const head = fold(entry.head);
		const gloss = fold(entry.gloss);
		const forms = entry.forms.map((f) => `${fold(f.form)} ${fold(f.gloss)}`).join(" ");
		let score = 0;
		if (head === q) score = 100;
		else if (head.startsWith(q)) score = 80;
		else if (gloss.startsWith(q)) score = 70;
		else if (head.includes(q) || gloss.includes(q)) score = 50;
		else if (forms.includes(q)) score = 30;
		return {
			entry,
			score
		};
	}).filter((row) => row.score > 0).sort((a, b) => b.score - a.score || a.entry.head.localeCompare(b.entry.head)).slice(0, limit).map((row) => row.entry);
}
function searchEnglish(query, limit = 40) {
	const q = fold(query);
	if (!q) return [];
	return EN_INDEX.filter((item) => fold(item.en).includes(q) || fold(item.heads).includes(q)).sort((a, b) => {
		return (fold(a.en).startsWith(q) ? 0 : 1) - (fold(b.en).startsWith(q) ? 0 : 1) || a.en.localeCompare(b.en);
	}).slice(0, limit);
}
function searchPhrases(query, limit = 40) {
	const q = fold(query);
	if (!q) return [];
	return PHRASES.filter((item) => fold(item.en).includes(q) || fold(item.tbl).includes(q) || fold(item.topic).includes(q)).slice(0, limit);
}
function phrasesByTopic(topic) {
	return PHRASES.filter((p) => p.topic === topic);
}
function tokens(query) {
	return fold(query).split(" ").filter((w) => w.length > 2);
}
function contextForTranslation(query) {
	const words = tokens(query);
	const phraseHits = PHRASES.filter((p) => {
		const hay = fold(`${p.en} ${p.tbl}`);
		return words.some((w) => hay.includes(w));
	}).slice(0, 8);
	const wordHits = EN_INDEX.filter((item) => words.some((w) => fold(item.en) === w || fold(item.en).includes(w))).slice(0, 14);
	const ruleText = (GUIDE.find((s) => s.title === "Core rules")?.blocks ?? []).map((b) => b.text).join("\n").slice(0, 2200);
	return [
		"Use ONLY these T'boli words and sentence patterns from Deymar's lessons. If a word is missing, leave it in English inside [brackets]. Do not invent words and do not use Tagalog.",
		ruleText ? `Rules:\n${ruleText}` : "",
		phraseHits.length ? `Example sentences:\n${phraseHits.map((p) => `- ${p.en} → ${p.tbl}`).join("\n")}` : "",
		wordHits.length ? `Word list:\n${wordHits.map((w) => `- ${w.en}: ${w.heads}`).join("\n")}` : ""
	].filter(Boolean).join("\n\n");
}
//#endregion
export { QUICK_ENGLISH as a, entriesForLetter as c, phrasesByTopic as d, searchEnglish as f, LETTERS as i, glossEnglish as l, searchPhrases as m, EN_INDEX as n, TOPICS as o, searchEntries as p, GUIDE as r, contextForTranslation as s, ENTRIES as t, lookupPhrase as u };
