import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as Copy, v as Check } from "../_libs/lucide-react.mjs";
import { a as STORAGE_KEY, i as SAMPLES, n as useIme } from "./router-DW5w4w-K.mjs";
import { n as ImeTextarea } from "./ime-field-WzsZTvOs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/write-DQ8Cin9A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WriteScreen() {
	const ime = useIme();
	const [text, setText] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			setText(localStorage.getItem("tboli-keyboard-draft") ?? "");
		} catch {
			setText("");
		}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		try {
			localStorage.setItem(STORAGE_KEY, text);
		} catch {}
	}, [text, ready]);
	async function copy() {
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1400);
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold tracking-tight",
				children: "Write"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: ime.installed && ime.selected ? "Tap the page — your Tboli keyboard slides up." : "Turn the keyboard on in Settings, or type with the phone board."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex justify-end gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void copy(),
					disabled: !text,
					className: "inline-flex h-10 items-center gap-1.5 rounded-md bg-key px-3 text-sm font-medium text-key-fg disabled:opacity-40",
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-4",
						strokeWidth: 2
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
						className: "size-4",
						strokeWidth: 2
					}), copied ? "Copied" : "Copy"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setText(""),
					disabled: !text,
					className: "h-10 rounded-md bg-key-mod px-3 text-sm font-medium text-key-mod-fg disabled:opacity-40",
					children: "Clear"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeTextarea, {
				id: "tboli-draft",
				lang: ime.lang === "tbl" ? "tbl" : "en",
				value: text,
				onChange: (e) => setText(e.target.value),
				placeholder: ime.lang === "tbl" ? "ngà, bê, tnalak…" : "Write here",
				className: "mt-3 min-h-48 bg-surface"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs tabular-nums text-subtle",
				children: [[...text].length, " characters"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-1.5 overflow-x-auto",
				children: SAMPLES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setText((t) => `${t}${t && !t.endsWith(" ") ? " " : ""}${s.tboli} `),
					className: "shrink-0 rounded-md bg-surface px-2.5 py-1.5 text-left shadow-panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-sm",
						children: s.tboli
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-2xs text-subtle",
						children: s.en
					})]
				}, s.tboli))
			})
		]
	});
}
var SplitComponent = WriteScreen;
//#endregion
export { SplitComponent as component };
