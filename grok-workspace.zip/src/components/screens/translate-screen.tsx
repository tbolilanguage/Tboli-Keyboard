import { useEffect, useMemo, useState } from "react";
import { getRouteApi } from "@tanstack/react-router";
import { ArrowRight, Check, LoaderCircle } from "lucide-react";
import { ImeInput } from "@/components/ime-field";
import { QUICK_ENGLISH, glossEnglish, lookupPhrase } from "@/lib/dictionary";
import { translateToTboli } from "@/lib/translate";

const translateRoute = getRouteApi("/translate");

export function TranslateScreen() {
  const { en } = translateRoute.useSearch();
  const [english, setEnglish] = useState(en);
  const [aiText, setAiText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    if (!en) return;
    setEnglish(en);
    setAiText("");
    setError(null);
  }, [en]);

  const gloss = useMemo(() => glossEnglish(english), [english]);
  const phrase = useMemo(() => lookupPhrase(english), [english]);

  function setQuery(next: string) {
    setEnglish(next);
    setAiText("");
    setError(null);
    setCopied(null);
  }

  async function translate() {
    const q = english.trim();
    if (!q || busy || phrase) return;
    setBusy(true);
    setError(null);
    try {
      const result = await translateToTboli({ data: { q } });
      if (result.ok) setAiText(result.text);
      else {
        setAiText("");
        setError(result.error);
      }
    } catch {
      setError("Translation is unavailable right now.");
    } finally {
      setBusy(false);
    }
  }

  async function copy(text: string) {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(text);
      window.setTimeout(() => setCopied((cur) => (cur === text ? null : cur)), 1400);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="px-4 pt-6 pb-8">
      <h1 className="font-display text-3xl font-semibold tracking-tight">Translate</h1>
      <p className="mt-1 text-sm text-muted">
        Word for word shows as you type. The full phrase shows only when that sentence is in Deymar's lessons.
      </p>

      <div className="mt-5 flex items-center gap-2 text-sm font-medium text-muted">
        <span>English</span>
        <ArrowRight className="size-3.5 text-subtle" strokeWidth={2} />
        <span>Tboli</span>
      </div>

      <ImeInput
        value={english}
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            void translate();
          }
        }}
        placeholder="Type an English phrase"
        className="mt-2 bg-surface"
        lang="en"
      />

      <div className="mt-3 flex gap-1.5 overflow-x-auto">
        {QUICK_ENGLISH.map((label) => (
          <button
            key={label}
            type="button"
            onClick={() => setQuery(label)}
            className="h-9 shrink-0 rounded-sm bg-surface px-2.5 text-xs text-muted"
          >
            {label}
          </button>
        ))}
      </div>

      {gloss.length > 0 ? (
        <div className="mt-4 overflow-hidden rounded-xl bg-surface shadow-panel">
          <p className="px-4 pt-3 text-xs font-medium tracking-wide text-subtle">Word for word</p>
          <ul className="mt-1 max-h-56 overflow-y-auto px-2 pb-2">
            {gloss.map((piece, index) => (
              <li
                key={`${piece.en}-${index}`}
                className="flex items-baseline gap-3 border-t border-border px-2 py-2 first:border-t-0"
              >
                <span className="w-2/5 shrink-0 text-sm text-muted">{piece.en}</span>
                <span className="min-w-0 flex-1 text-right font-display text-lg leading-tight" lang="tbl">
                  {piece.gap ? (
                    <span className="text-sm text-subtle">no word</span>
                  ) : piece.tbl ? (
                    piece.tbl
                  ) : (
                    <span className="text-sm text-subtle">[{piece.en}]</span>
                  )}
                </span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {phrase ? (
        <div className="mt-3 rounded-xl bg-primary p-4 text-primary-fg shadow-panel">
          <p className="text-xs font-medium tracking-wide text-primary-fg/75">Full phrase</p>
          <p className="mt-2 font-display text-2xl leading-snug" lang="tbl">
            {phrase.tbl}
          </p>
          {phrase.alts.length > 0 ? (
            <ul className="mt-3 space-y-1 border-t border-white/15 pt-2">
              {phrase.alts.map((alt) => (
                <li key={alt}>
                  <button
                    type="button"
                    onClick={() => void copy(alt)}
                    className="text-left text-base text-primary-fg/85"
                    lang="tbl"
                  >
                    Also {alt}
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
          <button
            type="button"
            onClick={() => void copy(phrase.tbl)}
            className="mt-3 inline-flex h-10 items-center gap-1.5 rounded-md bg-key px-3 text-sm font-medium text-key-fg"
          >
            {copied === phrase.tbl ? <Check className="size-4" strokeWidth={2} /> : null}
            {copied === phrase.tbl ? "Copied" : "Copy phrase"}
          </button>
        </div>
      ) : english.trim() ? (
        <div className="mt-3 rounded-xl bg-surface p-4 shadow-panel">
          <p className="text-sm text-subtle">
            {gloss.length > 1
              ? "No full phrase yet. It appears when the whole sentence matches a lesson."
              : "Keep typing. A full phrase appears when the sentence matches."}
          </p>
          {error ? <p className="mt-2 text-sm text-muted">{error}</p> : null}
          {aiText ? (
            <div className="mt-3 border-t border-border pt-3">
              <p className="text-xs font-medium tracking-wide text-subtle">Built from the lessons</p>
              <p className="mt-1 font-display text-2xl leading-snug" lang="tbl">
                {aiText}
              </p>
              <p className="mt-1 text-xs text-subtle">Not a stored sentence.</p>
              <button
                type="button"
                onClick={() => void copy(aiText)}
                className="mt-3 inline-flex h-10 items-center gap-1.5 rounded-md bg-key px-3 text-sm font-medium text-key-fg"
              >
                {copied === aiText ? <Check className="size-4" strokeWidth={2} /> : null}
                {copied === aiText ? "Copied" : "Copy Tboli"}
              </button>
            </div>
          ) : null}
          {!aiText && english.trim().split(/\s+/).length >= 2 ? (
            <button
              type="button"
              onClick={() => void translate()}
              disabled={busy}
              className="mt-3 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-key text-sm font-medium text-key-fg transition-transform duration-150 ease-out active:scale-[0.98] disabled:opacity-40"
            >
              {busy ? <LoaderCircle className="size-4 animate-spin" strokeWidth={2} /> : null}
              Build a sentence anyway
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
