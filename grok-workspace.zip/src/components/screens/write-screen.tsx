import { useEffect, useState } from "react";
import { Check, Copy } from "lucide-react";
import { ImeTextarea } from "@/components/ime-field";
import { useIme } from "@/components/ime-provider";
import { SAMPLES, STORAGE_KEY } from "@/lib/tboli";

export function WriteScreen() {
  const ime = useIme();
  const [text, setText] = useState("");
  const [ready, setReady] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      setText(localStorage.getItem(STORAGE_KEY) ?? "");
    } catch {
      setText("");
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(STORAGE_KEY, text);
    } catch {
      /* ignore */
    }
  }, [text, ready]);

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="px-4 pt-6 pb-8">
      <h1 className="font-display text-3xl font-semibold tracking-tight">Write</h1>
      <p className="mt-1 text-sm text-muted">
        {ime.installed && ime.selected
          ? "Tap the page — your Tboli keyboard slides up."
          : "Turn the keyboard on in Settings, or type with the phone board."}
      </p>

      <div className="mt-4 flex justify-end gap-1.5">
        <button
          type="button"
          onClick={() => void copy()}
          disabled={!text}
          className="inline-flex h-10 items-center gap-1.5 rounded-md bg-key px-3 text-sm font-medium text-key-fg disabled:opacity-40"
        >
          {copied ? <Check className="size-4" strokeWidth={2} /> : <Copy className="size-4" strokeWidth={2} />}
          {copied ? "Copied" : "Copy"}
        </button>
        <button
          type="button"
          onClick={() => setText("")}
          disabled={!text}
          className="h-10 rounded-md bg-key-mod px-3 text-sm font-medium text-key-mod-fg disabled:opacity-40"
        >
          Clear
        </button>
      </div>

      <ImeTextarea
        id="tboli-draft"
        lang={ime.lang === "tbl" ? "tbl" : "en"}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={
          ime.lang === "tbl" ? "ngà, bê, tnalak…" : "Write here"
        }
        className="mt-3 min-h-48 bg-surface"
      />

      <p className="mt-2 text-xs tabular-nums text-subtle">{[...text].length} characters</p>

      <div className="mt-4 flex gap-1.5 overflow-x-auto">
        {SAMPLES.map((s) => (
          <button
            key={s.tboli}
            type="button"
            onClick={() => setText((t) => `${t}${t && !t.endsWith(" ") ? " " : ""}${s.tboli} `)}
            className="shrink-0 rounded-md bg-surface px-2.5 py-1.5 text-left shadow-panel"
          >
            <span className="block font-display text-sm">{s.tboli}</span>
            <span className="block text-2xs text-subtle">{s.en}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
