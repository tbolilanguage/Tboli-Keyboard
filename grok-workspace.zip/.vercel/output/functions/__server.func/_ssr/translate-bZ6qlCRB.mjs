import { s as contextForTranslation, u as lookupPhrase } from "./dictionary-D-_jSYMr.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/translate-bZ6qlCRB.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var translateToTboli_createServerFn_handler = createServerRpc({
	id: "c555f0eb5aa3c7b7d8bd924627e0c8b704423218ef965720e5bb219d1d6ca699",
	name: "translateToTboli",
	filename: "src/lib/translate.ts"
}, (opts) => translateToTboli.__executeServer(opts));
var translateToTboli = createServerFn({ method: "POST" }).validator((input) => ({ q: String(input?.q ?? "").slice(0, 280) })).handler(translateToTboli_createServerFn_handler, async ({ data }) => {
	const q = data.q.trim();
	if (!q) return {
		ok: false,
		error: "Type an English phrase first."
	};
	const phrase = lookupPhrase(q);
	if (phrase) return {
		ok: true,
		text: phrase.tbl,
		source: "book"
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "That phrase isn't in Deymar's dictionary. Try good morning, child, or I love you."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .2,
			max_tokens: 160,
			messages: [{
				role: "system",
				content: "Translate English into T'boli as taught by native speaker Deymar. Copy spelling and accents exactly (ngà, bê, t'ngón). Build the meaning from the rules, not word by word. Use only words in the notes. If a word is missing, keep it in English inside [brackets]. Reply with ONLY the T'boli sentence."
			}, {
				role: "user",
				content: `${contextForTranslation(q)}\n\nEnglish:\n${q}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: "Translation is unavailable right now."
	};
	const text = ((await res.json()).choices?.[0]?.message?.content ?? "").trim();
	if (!text) return {
		ok: false,
		error: "No translation returned."
	};
	return {
		ok: true,
		text,
		source: "ai"
	};
});
//#endregion
export { translateToTboli_createServerFn_handler };
