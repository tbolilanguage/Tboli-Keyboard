import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Globe, g as ChevronRight, l as Keyboard } from "../_libs/lucide-react.mjs";
import { n as useIme, s as cn } from "./router-DW5w4w-K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-C60lnMZA.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsScreen() {
	const ime = useIme();
	const on = ime.installed && ime.selected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold tracking-tight",
				children: "Settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "This is the keyboard’s own app — languages, layout, and the switch that turns it into the board you type with."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "px-1 text-xs font-medium tracking-wide text-subtle uppercase",
					children: "Keyboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 overflow-hidden rounded-xl bg-surface shadow-panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/enable",
							className: "flex items-center gap-3 px-4 py-3.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, {
									className: "size-5 text-primary",
									strokeWidth: 1.75
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: "Keyboard settings"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-subtle",
										children: on ? "On · chosen as current keyboard" : "Off · add it to type everywhere"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
									className: "size-5 text-subtle",
									strokeWidth: 2
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-4 py-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
								className: "size-5 text-primary",
								strokeWidth: 1.75
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: "Languages"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-subtle",
									children: "English and Tboli only"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2 px-4 pb-4",
							children: ["en", "tbl"].map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => ime.setLang(lang),
								className: cn("h-10 flex-1 rounded-md text-sm font-medium", ime.lang === lang ? "bg-primary text-primary-fg" : "bg-key-mod text-key-mod-fg"),
								children: lang === "en" ? "English" : "Tboli"
							}, lang))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "px-1 text-xs font-medium tracking-wide text-subtle uppercase",
					children: "How it works"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-2 space-y-2 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-surface px-4 py-3 shadow-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: "1. Open the app"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: "Translate, write, and look up vowels. This is the full Tboli Keyboard."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-surface px-4 py-3 shadow-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: "2. Add it in Keyboard settings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: "Same place you enable Gboard or the iPhone board. Toggle Tboli Keyboard on, then set it as the current keyboard."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-surface px-4 py-3 shadow-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: "3. Type anywhere"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: "Tap a field in Messages, Notes, or Search — a normal keyboard pops up. Globe switches English and Tboli."
							})]
						})
					]
				})]
			})
		]
	});
}
var SplitComponent = SettingsScreen;
//#endregion
export { SplitComponent as component };
