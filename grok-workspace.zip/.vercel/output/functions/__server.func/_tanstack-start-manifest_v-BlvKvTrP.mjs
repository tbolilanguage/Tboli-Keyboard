//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BlvKvTrP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/dictionary",
			"/enable",
			"/settings",
			"/translate",
			"/try",
			"/write"
		],
		preloads: ["/assets/index-FqmpAvj9.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-FqmpAvj9.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bdia4Klj.js", "/assets/keyboard-Su0WtX64.js"]
	},
	"/dictionary": {
		filePath: "/workspace/src/routes/dictionary.tsx",
		children: void 0,
		preloads: [
			"/assets/dictionary-DDJbpS-j.js",
			"/assets/ime-field-nhGXHNRZ.js",
			"/assets/dictionary-CwreWGzu.js"
		]
	},
	"/enable": {
		filePath: "/workspace/src/routes/enable.tsx",
		children: void 0,
		preloads: [
			"/assets/enable-D3OoMOXJ.js",
			"/assets/check-BGAPr_Ox.js",
			"/assets/chevron-left-BfM72ZjI.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-BXOByfgf.js", "/assets/keyboard-Su0WtX64.js"]
	},
	"/translate": {
		filePath: "/workspace/src/routes/translate.tsx",
		children: void 0,
		preloads: [
			"/assets/translate-Ao0nPZ2g.js",
			"/assets/check-BGAPr_Ox.js",
			"/assets/ime-field-nhGXHNRZ.js",
			"/assets/dictionary-CwreWGzu.js"
		]
	},
	"/try": {
		filePath: "/workspace/src/routes/try.tsx",
		children: void 0,
		preloads: [
			"/assets/try-GGENtiqe.js",
			"/assets/chevron-left-BfM72ZjI.js",
			"/assets/ime-field-nhGXHNRZ.js"
		]
	},
	"/write": {
		filePath: "/workspace/src/routes/write.tsx",
		children: void 0,
		preloads: [
			"/assets/write-JinMOk5b.js",
			"/assets/check-BGAPr_Ox.js",
			"/assets/ime-field-nhGXHNRZ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
