import { useState } from "react";
import { EMOJI_GROUPS } from "@/lib/emoji";
import { cn } from "@/lib/utils";

export function EmojiPanel({
  onPick,
  onAbc,
}: {
  onPick: (glyph: string) => void;
  onAbc: () => void;
}) {
  const [groupId, setGroupId] = useState(EMOJI_GROUPS[0]?.id ?? "new");
  const group = EMOJI_GROUPS.find((g) => g.id === groupId) ?? EMOJI_GROUPS[0];

  return (
    <div
      className="rounded-xl bg-surface p-2 shadow-panel sm:p-3"
      role="group"
      aria-label="Emoji keyboard"
    >
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-2xs leading-snug text-subtle">
          Drawn by this phone — Android 17 or iOS 27 emoji, not a web font
        </p>
        <button
          type="button"
          onPointerDown={(e) => e.preventDefault()}
          onClick={onAbc}
          className="h-10 shrink-0 rounded-md bg-key-mod px-3 text-sm font-medium text-key-mod-fg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          ABC
        </button>
      </div>
      <div className="mb-2 flex gap-1 overflow-x-auto pb-1">
        {EMOJI_GROUPS.map((g) => (
          <button
            key={g.id}
            type="button"
            onPointerDown={(e) => e.preventDefault()}
            onClick={() => setGroupId(g.id)}
            className={cn(
              "h-9 shrink-0 rounded-sm px-2.5 text-xs font-medium transition-transform duration-150 ease-out active:scale-[0.96]",
              g.id === groupId
                ? "bg-primary text-primary-fg"
                : "bg-key-mod text-key-mod-fg",
            )}
          >
            {g.label}
          </button>
        ))}
      </div>
      {groupId === "new" ? (
        <ul className="grid grid-cols-4 gap-1.5">
          {group.items.map((item) => (
            <li key={item.name}>
              <button
                type="button"
                title={item.name}
                aria-label={item.name}
                onPointerDown={(e) => e.preventDefault()}
                onClick={() => onPick(item.glyph)}
                className="flex h-16 w-full flex-col items-center justify-center rounded-md bg-key text-key-fg transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                <span className="font-emoji text-2xl leading-none">{item.glyph}</span>
                <span className="mt-1 max-w-full truncate px-1 text-2xs text-subtle">
                  {item.name}
                </span>
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <ul className="grid max-h-44 grid-cols-8 gap-1 overflow-y-auto sm:max-h-52">
          {group.items.map((item) => (
            <li key={`${item.name}-${item.glyph}`}>
              <button
                type="button"
                title={item.name}
                aria-label={item.name}
                onPointerDown={(e) => e.preventDefault()}
                onClick={() => onPick(item.glyph)}
                className="flex size-10 items-center justify-center rounded-sm bg-key text-key-fg transition-transform duration-150 ease-out active:scale-[0.96] sm:size-11"
              >
                <span className="font-emoji text-xl leading-none sm:text-2xl">
                  {item.glyph}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
