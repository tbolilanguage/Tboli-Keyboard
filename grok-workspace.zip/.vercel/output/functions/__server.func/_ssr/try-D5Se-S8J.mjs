import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronLeft, i as Search } from "../_libs/lucide-react.mjs";
import { n as useIme, s as cn } from "./router-DW5w4w-K.mjs";
import { n as ImeTextarea, t as ImeInput } from "./ime-field-WzsZTvOs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/try-D5Se-S8J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TryScreen() {
	const ime = useIme();
	const [app, setApp] = (0, import_react.useState)("messages");
	const on = ime.installed && ime.selected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-full flex-col px-4 pt-4 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "inline-flex h-10 items-center gap-1 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-4",
					strokeWidth: 2
				}), "Home"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold tracking-tight",
				children: "Type anywhere"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: on ? "These are ordinary fields. Tap one — the keyboard pops up, same as on the phone." : "Turn the keyboard on first, then tap a field here."
			}),
			!on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/enable",
				className: "mt-3 flex h-11 items-center justify-center rounded-md bg-primary text-sm font-medium text-primary-fg",
				children: "Open keyboard settings"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex rounded-lg bg-surface p-1",
				children: [
					["messages", "Messages"],
					["notes", "Notes"],
					["search", "Search"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setApp(id),
					className: cn("h-9 flex-1 rounded-md text-sm font-medium", app === id ? "bg-primary text-primary-fg" : "text-muted"),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 min-h-0 flex-1 rounded-xl bg-surface p-3 shadow-panel",
				children: [
					app === "messages" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesApp, {}) : null,
					app === "notes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesApp, {}) : null,
					app === "search" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchApp, {}) : null
				]
			})
		]
	});
}
function MessagesApp() {
	const [draft, setDraft] = (0, import_react.useState)("");
	const [thread, setThread] = (0, import_react.useState)(["Holo — type below in Tboli or English."]);
	function send() {
		const next = draft.trim();
		if (!next) return;
		setThread((t) => [...t, next]);
		setDraft("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-80 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-subtle",
				children: "Messages"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 min-h-0 flex-1 space-y-2 overflow-y-auto",
				children: thread.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: cn("max-w-[85%] rounded-lg px-3 py-2 text-sm", i === 0 ? "bg-surface-2 text-muted" : "ml-auto bg-primary text-primary-fg"),
					children: line
				}, `${i}-${line}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-2 flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					send();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeInput, {
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					placeholder: "Message",
					className: "flex-1 bg-bg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 shrink-0 rounded-md bg-primary px-3 text-sm font-medium text-primary-fg",
					children: "Send"
				})]
			})
		]
	});
}
function NotesApp() {
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-80 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-wide text-subtle",
			children: "Notes"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeTextarea, {
			value: note,
			onChange: (e) => setNote(e.target.value),
			placeholder: "Start a note…",
			className: "mt-2 min-h-0 flex-1 bg-bg"
		})]
	});
}
function SearchApp() {
	const [q, setQ] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-80 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-subtle",
				children: "Search"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					className: "pointer-events-none absolute top-3 left-3 size-4 text-subtle",
					strokeWidth: 2
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImeInput, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search",
					className: "bg-bg pl-9"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: q ? `Results for “${q}”` : "Type with Tboli Keyboard — globe key for English."
			})
		]
	});
}
var SplitComponent = TryScreen;
//#endregion
export { SplitComponent as component };
