export type EmojiItem = {
  glyph: string;
  name: string;
};

export type EmojiGroup = {
  id: string;
  label: string;
  items: EmojiItem[];
};

/** Unicode 17.0 — ships with Android 17 and current iOS. Drawn by the OS, not this app. */
export const UNICODE_17: EmojiItem[] = [
  { glyph: "\u{1FAEA}", name: "Distorted face" },
  { glyph: "\u{1FAEF}", name: "Fight cloud" },
  { glyph: "\u{1FAC8}", name: "Hairy creature" },
  { glyph: "\u{1FACD}", name: "Orca" },
  { glyph: "\u{1FA8A}", name: "Trombone" },
  { glyph: "\u{1FA8E}", name: "Treasure chest" },
  { glyph: "\u{1F6D8}", name: "Landslide" },
  { glyph: "\u{1F9D1}\u{200D}\u{1FA70}", name: "Ballet dancer" },
];

export const EMOJI_GROUPS: EmojiGroup[] = [
  { id: "new", label: "New", items: UNICODE_17 },
  {
    id: "smileys",
    label: "Smileys",
    items: [
      { glyph: "😀", name: "Grinning" },
      { glyph: "😃", name: "Smiling" },
      { glyph: "😄", name: "Smile" },
      { glyph: "😁", name: "Beaming" },
      { glyph: "😅", name: "Sweat smile" },
      { glyph: "😂", name: "Tears of joy" },
      { glyph: "🤣", name: "ROFL" },
      { glyph: "😊", name: "Blush" },
      { glyph: "😇", name: "Halo" },
      { glyph: "🙂", name: "Slight smile" },
      { glyph: "😉", name: "Wink" },
      { glyph: "😍", name: "Heart eyes" },
      { glyph: "🥰", name: "Smiling hearts" },
      { glyph: "😘", name: "Kiss" },
      { glyph: "😋", name: "Yum" },
      { glyph: "🤔", name: "Thinking" },
      { glyph: "😴", name: "Sleeping" },
      { glyph: "🥲", name: "Tear smile" },
      { glyph: "😭", name: "Loud cry" },
      { glyph: "😤", name: "Huff" },
      { glyph: "🤯", name: "Exploding head" },
      { glyph: "🥳", name: "Party" },
      { glyph: "😎", name: "Cool" },
      { glyph: "🥺", name: "Pleading" },
    ],
  },
  {
    id: "gestures",
    label: "Hands",
    items: [
      { glyph: "👍", name: "Thumbs up" },
      { glyph: "👎", name: "Thumbs down" },
      { glyph: "👏", name: "Clap" },
      { glyph: "🙏", name: "Folded hands" },
      { glyph: "🙌", name: "Raised hands" },
      { glyph: "🤝", name: "Handshake" },
      { glyph: "✌️", name: "Victory" },
      { glyph: "🤞", name: "Crossed" },
      { glyph: "🫶", name: "Heart hands" },
      { glyph: "👋", name: "Wave" },
      { glyph: "💪", name: "Flex" },
    ],
  },
  {
    id: "hearts",
    label: "Hearts",
    items: [
      { glyph: "❤️", name: "Red heart" },
      { glyph: "🧡", name: "Orange heart" },
      { glyph: "💛", name: "Yellow heart" },
      { glyph: "💚", name: "Green heart" },
      { glyph: "💙", name: "Blue heart" },
      { glyph: "💜", name: "Purple heart" },
      { glyph: "🖤", name: "Black heart" },
      { glyph: "🤍", name: "White heart" },
      { glyph: "💕", name: "Two hearts" },
      { glyph: "💞", name: "Revolving" },
      { glyph: "💖", name: "Sparkling" },
      { glyph: "💯", name: "Hundred" },
    ],
  },
  {
    id: "nature",
    label: "Nature",
    items: [
      { glyph: "🌞", name: "Sun" },
      { glyph: "🌙", name: "Moon" },
      { glyph: "⭐", name: "Star" },
      { glyph: "🌈", name: "Rainbow" },
      { glyph: "🌧️", name: "Rain" },
      { glyph: "🌸", name: "Blossom" },
      { glyph: "🌿", name: "Herb" },
      { glyph: "🌳", name: "Tree" },
      { glyph: "🌊", name: "Wave" },
      { glyph: "🔥", name: "Fire" },
      { glyph: "🐕", name: "Dog" },
      { glyph: "🐈", name: "Cat" },
      { glyph: "🐦", name: "Bird" },
      { glyph: "🐟", name: "Fish" },
      { glyph: "🦋", name: "Butterfly" },
      { glyph: "🌾", name: "Sheaf" },
    ],
  },
  {
    id: "food",
    label: "Food",
    items: [
      { glyph: "🍚", name: "Rice" },
      { glyph: "🍜", name: "Noodles" },
      { glyph: "🍌", name: "Banana" },
      { glyph: "🥭", name: "Mango" },
      { glyph: "🥥", name: "Coconut" },
      { glyph: "🐟", name: "Fish" },
      { glyph: "🍖", name: "Meat" },
      { glyph: "☕", name: "Coffee" },
      { glyph: "🍵", name: "Tea" },
      { glyph: "🍯", name: "Honey" },
      { glyph: "🥘", name: "Pan" },
      { glyph: "🎂", name: "Cake" },
    ],
  },
  {
    id: "places",
    label: "Places",
    items: [
      { glyph: "🏠", name: "House" },
      { glyph: "🏔️", name: "Mountain" },
      { glyph: "🏞️", name: "Park" },
      { glyph: "⛪", name: "Church" },
      { glyph: "🚤", name: "Boat" },
      { glyph: "🚗", name: "Car" },
      { glyph: "🇵🇭", name: "Philippines" },
      { glyph: "🎉", name: "Party" },
      { glyph: "🎵", name: "Music" },
      { glyph: "🥁", name: "Drum" },
      { glyph: "🧵", name: "Thread" },
      { glyph: "👗", name: "Dress" },
    ],
  },
];
