import { useIme } from "@/components/ime-provider";
import { cn } from "@/lib/utils";
import type { InputHTMLAttributes, TextareaHTMLAttributes } from "react";

type Shared = {
  className?: string;
};

export function ImeInput({
  className,
  onFocus,
  onBlur,
  ...props
}: Shared & InputHTMLAttributes<HTMLInputElement>) {
  const ime = useIme();
  const useBoard = ime.installed && ime.selected;
  return (
    <input
      {...props}
      inputMode={useBoard ? "none" : props.inputMode}
      autoComplete={useBoard ? "off" : props.autoComplete}
      autoCorrect={useBoard ? "off" : props.autoCorrect}
      spellCheck={useBoard ? false : props.spellCheck}
      onFocus={(e) => {
        if (useBoard) ime.register(e.currentTarget);
        onFocus?.(e);
      }}
      onBlur={(e) => {
        if (useBoard) ime.hide();
        onBlur?.(e);
      }}
      className={cn(
        "h-11 w-full rounded-md bg-surface-2 px-3 text-base text-fg outline-none placeholder:text-subtle focus:shadow-focus",
        className,
      )}
    />
  );
}

export function ImeTextarea({
  className,
  onFocus,
  onBlur,
  ...props
}: Shared & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const ime = useIme();
  const useBoard = ime.installed && ime.selected;
  return (
    <textarea
      {...props}
      inputMode={useBoard ? "none" : props.inputMode}
      autoComplete={useBoard ? "off" : props.autoComplete}
      spellCheck={useBoard ? false : props.spellCheck}
      onFocus={(e) => {
        if (useBoard) ime.register(e.currentTarget);
        onFocus?.(e);
      }}
      onBlur={(e) => {
        if (useBoard) ime.hide();
        onBlur?.(e);
      }}
      className={cn(
        "min-h-32 w-full resize-y rounded-lg bg-surface-2 px-3.5 py-3 font-display text-xl leading-relaxed text-fg outline-none placeholder:text-subtle focus:shadow-focus",
        className,
      )}
    />
  );
}
