# T'boli to English dictionary

A dictionary and grammar guide for T'boli, the language of the T'boli people of South Cotabato, Mindanao. Every word, rule and example here was taught by native speaker Deymar, one lesson at a time, and sorted from the original lesson log into dictionary form. Nothing has been added from outside sources except the two Bible verses, which come from the T'boli Bible.

How to use it: the grammar section explains how words are built, the dictionary lists T'boli words A to Z with every form under its root, the English index lets you look a word up from English, and the phrase section collects ready sentences by topic.

## Translation guide for AI (read this first)

This section is for any AI or person using this dictionary to translate English into T'boli. Everything below it is the full word list and the grammar it comes from.

### Instructions

- Translate the meaning, not word by word. Build each sentence from the rules below and copy the patterns in the example pairs.
- Use only the words in this dictionary. If a word you need isn't here, keep it in English inside [brackets] and say it's missing. Don't guess, and don't swap in Tagalog or another language unless this dictionary lists it as a borrowing.
- English words can be borrowed with T'boli endings (rule 12).
- If a sentence could mean two things, give both and say which situation each one fits.
- Keep the spelling and accent marks exactly as written here. The accents change the meaning (hnóbô is getting angry, hnobò is bladder).

### Core rules

1. **Word order.** The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now). Whatever comes first is the focus: Miles ninumen él (Miles drank the water), Él ninum Miles (the water Miles drank).
2. **Who: endings on the word.** I: -u or -e (Kenu, I eat; Nóyóu, I want; Bitile, I'm hungry; Denge, I'm done). You (one): -em, sometimes -u (Kenem, you eat; Bitilu, you're hungry). Formal you: -i (Dengi). He/she/it: -en (Kenen). They: -le. You all: -ye. We all: -kuy. You and me: -te. We but not you: me. Since -u can mean I or you, add the standalone word when it matters.
3. **Standalone pronouns.** O/Ou (me), U/Uu (you), Yu (you all), Du (him/her/it), Lu (them), Tu (us), Te (you and me), Mi (us, not you). Put them after the action to make it clear: Minume o él (I'm drinking water), Minume mi él (we're drinking water).
4. **No word for "is" when describing.** Coffee-hu kinì (my coffee is hot). Se is used for how someone is: Kmoem se du? (how are you?). Nô is the "is" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table).
5. **Very.** Tey/Téy takes the person ending: Teye bitil (I'm very hungry), Téyu temngón (you're very smart). Alì is extremely.
6. **Action shapes on one root.** Root alone is general (ken, eat). M inside or me- in front is happening or about to happen (meken, kmulón, tmolok). N inside is being done or ongoing with an ending (tnolok, t'nilówem). G- in front is by accident (gkulóne, I accidentally got rained on). S- in front is each other (ston, see each other), and sense- is together and still going (senseken). H- or het- in front is make it or let someone (hkinì, make hot; hetnaw, make cold). Hef- is asking someone to do it with your own thing (hefkodok).
7. **Time.** Deng is done or already: Deng kenu (I ate), Denge meken (I already ate). Ne is now, already, or about to: Ne meken dé (I'm going to eat). Nehe (I will), Nehi (you will), Nele (they will). Bud in front is again: Bud kmulón (it'll rain again). Kdeng at the end is later. He at the end adds "yet" or "again, hopefully". Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday). Leave out kdeng when another word already says when.
8. **Not.** Là with the person: Làe or Là e (I'm not), Làu (you're not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't). Là e deng meken he (I haven't eaten yet). Bê is don't, or refusing: Bê tagad tungô he (don't sleep yet).
9. **Questions.** The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón ke (when), Moen ke (why). For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?).
10. **Owning.** The owner word goes before the thing: do (mine), kóm (yours), kun (his/hers/its), kul (theirs), kut (ours, you and me), kum (ours, 3 or more): Yó kóm ken, ni do ken (that's your food, this is my food). Dou dumu sbót (my friend). Body parts take -hu for my: matahu (my eyes), kuluhu (my head).
11. **Places.** Bê covers in, on, at, to, under and beside. Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Bê also goes before a day: bê Byérnis (on Friday).
12. **Borrowed English words.** The ending copies the word's last consonant sound: phone-nu (my phone), update-tu (I update), vitamin-nu (my vitamin). A word ending in a vowel sound takes an h: coffee-hu (my coffee). Endings that start with a consonant attach as they are: movie-le (their movie). Ke- means if or for doing it: Slamat bê ke-sendem du (thanks for sending it).
13. **Joining words.** Omin (and), okóm (but), kay (because), kayà (so, that's why), anì (so that), ke or sok (if, when). Kay, ke and sok take the person ending themselves: Kaye bitil (because I'm hungry), Kehu bitil (if you're hungry), Soke bitil (when I'm hungry).
14. **Three kinds of "we".** Te is you and me, kuy is all of us, me (or mi) is us but not you. Use me when telling a story, since the listener isn't part of it.
15. **Sound rules.** An accented final vowel (silà, ngà) ends in a full stop and takes an ending with no h, losing its accent (silaem, ngaen). A plain final vowel takes h before the ending (nawa, nawahu). A separate ending word like le never merges with a full stop word: silà le, never silale.

### How a sentence breaks down

- **Hkodoke béléem itlug** (I'll boil an egg for you): hkodok (boil it) + -e (I), béléem (for you), itlug (egg)
- **Là e deng meken he** (I haven't eaten yet): là e (I'm not), deng (done), meken (eating), he (yet)
- **Kehe bitil, ne meken dé** (if I'm hungry, I'll eat): ke + -he (if I), bitil (hungry), ne meken dé (I'm going to eat)
- **Haya bud te ston he** (see you again tomorrow, hopefully): haya (tomorrow), bud (again), te (you and me), ston (see each other), he (hopefully)

### Example pairs

**Greetings and small talk**

- Good morning: **Hyu hlafus**
- Good morning to you too: **Hyu hlafus béléem skóm**
- Good night: **Hyu kifu**
- What's up?: **Syó du?**
- How are you?: **Kmoem se du?**
- I'm fine: **Ok ye néen**
- And you?: **Kóm du?**
- What's your name?: **Bon boluyem (du)?**
- My name is Miles: **Boluyu Miles**
- What are you doing?: **Bon nmoem (du)?**
- Nothing, just sitting: **Anduen. Len myón.**
- Where are you from?: **Bê du gôem lemwót du?**
- Where are you going?: **Góem gów (du)?**
- Is that right?: **Tahu kô?**
- Yes, that's true: **Ell, tahu yó**
- Thank you so much: **Bong slamat**
- Thanks to you: **Slamat béléem**
- You're welcome: **Ominem dé**
- Thanks for teaching me: **Slamat bê ke-teachem do**
- Wait a bit: **Tagad he**
- We'll see each other later: **Bud te ston kdeng**

**Feelings**

- I'm very hungry. And you?: **Teye bitil. Kóm du?**
- I'm very happy: **Teye hligal**
- I'm exhausted: **Teye kapuy**
- I'm sleepy: **Moo ktuku**
- I'm full now: **Besowe ne**
- I'm thirsty, so I'm drinking water: **Meenge, kayà minume o él**
- I'm not scared of spiders: **Là e likô bê wong**
- I'm just joking: **Olohu hlowon néen**
- I don't want to sleep because I'm hungry: **Là nóyóu du tungô, kaye bitil** (du points to the subject, the sleeping)

**Food**

- Let's eat: **Meken kuy**
- If you're hungry, eat: **Kehu bitil, mekenu**
- I ate: **Deng kenu**
- I already ate: **Denge meken**
- I'll eat first: **Ne meken dé anay**
- When I'm hungry, I fry leftover rice: **Soke bitil, senlahu ken tnaw**
- This food is delicious: **Téy mi ken ni**
- That's your food, this is my food: **Yó kóm ken, ni do ken**
- The rice is already cooked: **Deng tógó ne ken**
- My coffee is hot: **Coffee-hu kinì**
- My coffee is on the table: **Coffee-hu nô bê ta lmisa**
- I'm full now. That fish was really tasty!: **Besowe ne. Utón nìen, téy mnóm!**

**Weather and time**

- Is it raining?: **Kmulón ni?**
- It's raining now. You'll be cold: **Kmulón ne. Tnawu yó.**
- Tomorrow it'll rain again: **Haya, bud kmulón**
- Yesterday was extremely hot, but today is very cold: **Ekimel alì kinì, okóm kdaw ni téy tnaw**
- Next week, on Friday, I'll go to the water: **Todol fedyan, bê Byérnis, nehe gów bê él.**
- What's the date today?: **Bon kdaw du ni?**

**People**

- You are my friend: **Uu dou dumu sbót**
- I'm your friend: **Ou kóm dumu sbót**
- I like you: **Nóyóu u**
- I love you: **Kenbong nawahu u**
- Who's that?: **Tadu yó?**
- That's him / that's us / that's them: **Du yó / Tu yó / Lu yó**
- It's our turn: **Tu ne ni**
- It's not me: **Là o du se**
- I didn't do that: **Là o du mò du yó**
- When will you get back home?: **Kilón ke kulékem bê gónô?**
- Why aren't you sleepy yet?: **Moen ke là u gtungô du?**
- Where's my phone?: **Góen nô phone-nu (du)?**
- Today, Deymar, you taught me and I taught you. We're teaching each other: **Kdaw ni, Deymar. Tnolokem o, omin tnoloku u. Stolok te.**

## Pronunciation

### Vowels

- **E**: like the u in burn (Ken, Teye, Ell)
- **É**: like the e in egg (néen)
- **O**: like the a in law
- **Ò**: like the a in law, but cut off with a full stop
- **Ó**: like the o in obvious
- **Ô**: like the o in obvious, but cut off with a full stop
- **An accent on a final vowel** (silà, ngà): the word ends in a full stop (see the sound rules)

### Words that are easy to get wrong

- **Ell** (yes): said like "Ull", the E is the u in burn
- **Fun** (owner): the u sounds like the u in uniform, not like "fan"
- **Ken** (food): the E is the u in burn, not like Kentucky
- **Ken tnaw**: Ken with the u in burn, tnaw like "T'NOW" (the ow in now, with the W said at the end like the w in win)
- **Accents change meaning.** Hnóbô is getting angry, hnobò is bladder. Moen is why, Móen is short for Kmoem. Geslà is a surprise, gesla is being fried. Silà is corn, and silale would lose that meaning.
- **Msó** is the fast way to say mesó (rice).
- **Mestlu** is how maistru (teacher) is actually said.

## Grammar

### Word order

- The root word carries the meaning, and endings say who.
- The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now).
- The main idea comes first: Meken kuy, Tahu kô ni.
- Whoever or whatever comes first is the focus. Miles ninumen él (Miles drank the water) puts Miles first. Él ninum Miles (the water being drunk by Miles) puts the water first. Él ninumen Miles means the water drank Miles, because -en makes the water the one drinking.
- Word order can change the meaning: Kmoem se du is "how are you", Kmoem du se is "what did you do".
- When "it" does something to a person, the -en ending is the "it" and the person comes after: Hetnawen u yó (it'll make you cold).
- "More" comes after the thing: unged wen, more muscle.
- A color goes before mata: utón hulô mata (red-eye fish).
- With names, the names come first, then sbót le: Miles omin Deymar sbót le (Miles and Deymar are friends).
- Ni and yó point ("this" and "that"), and kô turns a statement into a question.

### No "is" when describing

- Describing something needs no "is" at all: Coffee-hu kinì (my coffee is hot).
- **Se** is the "be" word for how someone is, and it goes in the middle: Kmoem se du? (how are you?).
- **Nô** is the "is" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table). Without nô, Coffee-hu bê ta lmisa is just "my coffee on the table".

### Person endings

These attach to a word to say who.

- **-u**: often "you" (Gówu, you go; Tungôu, you sleep; Mekenu, you're eating or "eat!"; Bitilu, you're hungry). In some words it means "I" (Kenu, I eat; Nóyóu, I want; Tnoloku, I teach). Since -u can mean either, add the standalone word when it matters.
- **-e**: I (Bitile, I'm hungry; Denge, I'm done; Mekene, I'm eating; Teye, I'm very). Bitile can also mean "they're hungry"; Bitile lu is clearer for them.
- **-em**: you (one person) (Kenem, you eat)
- **-i**: the formal "you", more specific than -u (Dengi, you're done; Kehi, you become; Lài, you are not)
- **-en**: him, her, it (Kenen, he/she/it eats)
- **-le**: them, not including the person you're talking to (Kenle, they eat)
- **-ye**: you all, the people you're talking to, speaker not included (Kenye)
- **-kuy**: we, us, 3 or more people (Kenkuy)
- **-te**: us two, just you and me (Kente)
- **me**: we, without the person you're talking to (Deng me, Kmò me du)
- **-hu**: my, on words that end in a plain vowel and on body parts (nawahu, matahu, kuluhu, lówóhu, coffee-hu). Tnoloku takes -u, not -hu.

The ending can jump forward to an earlier word: Kaye bitil (because I'm hungry) instead of Kay bitile. Same with Anìe (so I), and Kehu bitil (if you're hungry) instead of Ke bitilu.

When an ending could mean two people (minume, I or we), add the standalone word: minume o (I), minume mi (we).

#### Second set, with Tey and Meken

- **Teye**: I am very
- **Téyu**: you are very
- **Téy-**: he/she/it is very
- **Téyle**: they are very
- **Téyye**: you all are very
- **Téykuy**: we are very
- **Téyte**: we (you and I) are very
- **Mekene**: I am eating
- **Mekenu**: you are eating, also "eat!" when telling someone to eat
- **Meken du**: he/she/it is eating

### Standalone pronouns

- **O / Ou**: me, I. Ou is specifically me, pointing at yourself.
- **U / Uu**: you (one person). Uu is specifically you.
- **Yu**: you (2 or more people)
- **Du**: him, her, it (used everywhere for he/she/it)
- **Lu**: them
- **Tu**: us
- **Te**: me and you
- **Mi**: us, I'm included but not the person I'm talking to
- **Do**: me, when I'm the one something happens to (from dou): Ktolok le do (they taught me)

With yó: **O yó** (that's me), **Ou yó** (that's me, specifically me), **U yó** (that's you), **Uu yó** (that's you, specifically you), **Du yó** (that's him), **Tu yó** (that's us), **Lu yó** (that's them).

### Three kinds of "we"

- **Te**: you and me (Stolok te, we teach each other, like Tagalog "tayo")
- **Kuy**: all of us, 3 or more
- **Me / Mi**: us but not you (Stolok me, like Tagalog "kami"; Mi kem mag-cousin, us cousins, not counting you)

Use me when telling a story, since the listener isn't part of it: Tmógó me utón (we're cooking fish, not you). Never tmógó mi utón. Me works everywhere kuy does: Kmò me du.

### Owning

The owner word goes before the thing: Yó kóm ken, ni do ken (that's your food, this is my food).

- **Do**: mine
- **Dou**: I own, my (Uu dou dumu sbót, you are my friend)
- **Kóm**: you own, yours
- **Kun**: he/she/it owns
- **Kul**: they own, theirs
- **Kum**: we (3 or more) own
- **Kut**: we (me and you) own, ours
- **Do u ni**: this is mine

Body parts and vowel-final words take -hu for "my": kuluhu (my head), matahu (my eyes), lówóhu (my body), nawahu (my breath).

Dumuhu sbót and dou dumu sbót both mean "my friend". Use dumuhu sbót when telling someone else about the friendship (he's my friend). Use dou dumu sbót when talking to the friend directly (Uu dou dumu sbót, you're my friend).

### Pointing words

- **Ni**: it, this; here's (Ni ken para béléem, here's food for you). At the end of a sentence it points to something right here. Ni is also right now, while ne is already.
- **Yó**: that
- **Nìen**: this one, it (ni plus -en, pointing at the subject): Utón nìen, téy mnóm!
- **Yóm**: the
- **Tu**: far, there (see the dictionary entry)

### Action shapes

One root changes shape to show how an action happens.

- **Root alone**: general (ken, eat; tolok, teach; kodok, boil)
- **M inside, or me- in front**: happening or about to happen, like "-ing" (meken, kmulón, tmolok, lmobun, kminì, kmodok)
- **N inside**: being done, already done, or ongoing (tnolok, being taught; nsef, sucked; t'nilówem). With person endings the m becomes n (t'milów, t'nilówem). Kenbong (with -n-) is already happening, continuously, while kbong is still going.
- **G- in front**: by accident, without meaning it (gkulóne, I accidentally got rained on; gtolok, taught unexpectedly; gwa, accidentally taken; gsalig, unintentionally trust; gtungô, sleepy)
- **S- in front**: each other (ston, see each other; stolok, teach each other; swa, taking from each other; stóbóng, helping each other)
- **Doubled first letter**: both or together doing it (ssef, both sucking; kken, ate together)
- **Sense- in front**: together and still going (senseken, eating together; sensesef). It doesn't work on every verb: stowok, not sensetowok.
- **H- or het- in front**: make it, or let someone else do it (hkinì, make hot; hetnaw, make cold; hsef, let someone suck; hsalig, let something trust; hetngón, let someone know). Add the person ending for who does it: Hkinìem ken (you heat the food), Hkinìu ken (I heat the food).
- **Hef- in front**: asking someone to do it with your own thing (hefkodok)
- **K- form**: already carries "will" (kulékem, you'll come back)

Roots that show the whole system:

- **Take**: ma/mwa (take), nwa (taken), gwa (accidentally taken), swa (taking from each other). N- is done, g- is by accident, s- is each other.
- **Boil**: kodok (boil), kmodok (boiling), hkodok (asking for it to be boiled; hkodoku, I'm boiling it), henkodok (being boiled), hefkodok (asking someone to boil something with your item)
- **Teach**: tolok, tmolok, tnolok, gtolok, htolok, stolok

### Time words

Time is shown with small words around the verb, not by changing the verb itself.

- **Deng**: done, already. Deng kenu (I ate), Denge meken (I already ate).
- **Ne**: now, already, a change happening, about to (like Tagalog "na"). Ne meken dé (I'm going to eat).
- **Nehe**: I will. **Nehi**: you will (nehu works too, but it can also mean "I will"). **Nele**: they will.
- **Bud**: again, in front, for something that will happen. Bud kmulón (it'll rain again).
- **Kdeng**: later, at the end of a sentence. On its own at the start it means "wait!"
- **He**: at the end, adds "yet" or "again, hopefully". Là e deng meken he (I haven't eaten yet). Bud te ston he (we'll see each other again, hopefully).
- Leave out kdeng when another word already says when: Haya bud kmulón, not Haya bud kmulón kdeng.
- **Days**: Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday), Ekuloy (the day before yesterday), Sotu ni (the day after tomorrow).
- **Todol** is next and **gna** is past: todol bulón (next month), gna halay (last year).
- Time words come from nature: kdaw is sun and day, bulón is moon and month, halay is the rice plant and year.

### Not

- **Là** with the person: Làe or Là e (I'm not), Làu or Là u (you're not), Lài (you, one specific person, are not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't), Là ye (you all aren't), Là kuy (we all aren't), Là me (we aren't, not counting you).
- Là e deng meken he: I haven't eaten yet.
- **Bê** is don't, or refusing: Bê tagad tungô he (don't sleep yet). Bê kuy gów bê yó (don't go there).

### Questions

- The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón ke (when), Moen ke (why).
- For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?).
- Ke always comes after kilón (when) and moen (why).
- Moen (why) is its own word, not Móen (short for Kmoem).
- Use Kmoem when you're asking someone directly, Kmoen when it's indirect.
- Kô ke offers a choice: Mekenu silà kô ke ken? (are you eating corn or rice?)

### Places

- **Bê** covers every location: on, in, at, to, above, under, beside. The context tells you which.
- Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Kuying bê ta lmisa (the cat is on the table).
- Bê also goes in front of a day: bê Byérnis (on Friday).
- **Nô** is the "is" for where something is.

### Sound rules

- **The -h rule**: when a word ends in a plain vowel, add h before the ending: nawa becomes nawahu (my breath), coffee becomes coffee-hu.
- **Full stop vowels**: an accent on a final vowel (silà, ngà) means a full stop at the end of the word, so it takes an ending without h, and the accent goes away when the ending is attached: silà, silaem (your corn); ngà, ngaen (his/her child).
- **Separate ending words never merge**: a separate ending word like le never merges with a full stop word. Silà le, never silale, because losing the accent takes away the word's meaning.

### Joining words

- **Omin**: and
- **Okóm**: but (Okóm close, but close)
- **Péro**: but (borrowed from Spanish)
- **Kay**: because. Takes the person ending: Kaye bitil (because I'm hungry).
- **Kayà**: so, that's why (borrowed from Tagalog)
- **Anì**: so, so that. Anìe (so I).
- **Ke / Sok**: if, when. Both take the person ending: Kehu bitil (if you're hungry), Soke bitil (when I'm hungry).
- **Dé kô**: if (something happens)
- **O**: or (borrowed from English)
- **Kô ke**: or, when suggesting someone pick one
- **Ewen**: so
- **Galì**: oh, so that's why

### Borrowed words

English words follow their sound, not their spelling. The ending copies the last consonant sound of the word, so update (ends in a t sound) becomes update-tu, update-tem, update-ten, and phone becomes phone-nu, not phoneu. When the spelling already ends in that consonant, the ending can attach directly or with a doubled letter and hyphen. The hyphen keeps the English word recognizable.

- **Chatu / Chat-tu**: I chat
- **Vitaminu / Vitamin-nu**: my vitamin
- **Phone-nu**: my phone
- **Slippersu**: my slippers
- **Update-tu**: I update. **Ke-update tu** also works, with the ending standing alone. **Update-le**: they update (endings that start with a consonant attach as they are).
- **Coffee-hu**: my coffee (words that really end in a vowel sound take h)
- **Movie-le**: their movie (consonant endings need no h)
- **Downloadem**: you download. **Downloaden**: he/she/it downloads.
- **Ke-**: if, or for doing it: Ke-savem (if you save, for saving), Ke-downloadem (if you download).

Other borrowings:

- **From Spanish**: the days of the week, the trading numbers, para (for), péro (but), maistru/mestlu (teacher)
- **From Tagalog**: kayà (so, that's why), kailangan (need)
- **From Hiligaynon**: anay (first, for now), aslum (sour), kahang (spicy)
- **From English**: o (or), tisting (tasting), and any English word with T'boli endings
- Akad (Sunday) may come from Malay or Arabic "Ahad" instead of Spanish.

### Ke, bê and para bê

- **Ke**: to, for, or, and possession. Ke Dwata: to God, or God's. Ke Dwata yó: that's God's. Ke Miles: or Miles, Miles' belongings, or for Miles.
- **Bê**: to. Bê Miles: to Miles.
- **Para bê**: for something or someone, being given to them. Ken para bê kem ngà: food for the children. Ke is for when it belongs to them.

## Dictionary: T'boli to English

Words are sorted A to Z, ignoring apostrophes and accent marks. Each root is one entry, with its forms listed under it. Borrowed words are marked.

### A

- **abal**: shoulder
- **akad**: Sunday (may come from Malay or Arabic "Ahad")
- **alì**: extremely
  - Alì kinì: extremely hot
  - Example: Ekimel alì kinì, okóm kdaw ni téy tnaw (yesterday was extremely hot, but today is very cold)
- **amil**: testicles
- **anay**: first, for now (borrowed from Hiligaynon, same as Tagalog "muna")
  - Example: Ne meken dé anay (I'll eat first)
- **andù**: no one (short for làen dù)
- **anduen**: nothing
  - Example: Anduen. Len myón. (nothing, just sitting)
- **anì**: so, so that
  - Anìe: so I (the ending jumps onto anì)
  - Example: Kailanganu mekay ken. Anìe meken kdeng. (I need to cook rice so I can eat later)
  - Example: Anì le sgeng tmowok (so they grow together)
- **aslum**: sour (borrowed from Hiligaynon, used to make it clear something is sour and not salty)
  - Example: Téy aslum sinigang nìen, okóm téy mnóm (this sinigang is very sour, but tasty)

### B

- **baling**: become
  - Example: Nuclear bomb skas (le), baling ofi bong (the nuclear bomb breaks them, and they become a big fire)
- **bê**: one word for any place: to, at, on, in, under, above, below, beside. Also don't, no (refusing or declining), and of.
  - Bê ta: on top of
  - Bê laan: underneath (something)
  - Bê lem: inside
  - Bê lohok: beside
  - Bê Byérnis: on Friday (bê goes in front of a day)
  - Bê Miles: to Miles
  - (Bê) yó: there
  - Bê du?: to, on, in, or at where?
  - Bê?: where? (depends on context)
  - Skél bê: the same as, like
  - Para bê: for (see para)
  - Bê e dou tungô: I'm not sleeping yet
  - Example: Bê tagad tungô he (don't sleep yet)
  - Example: Là! Bê kuy gów bê yó. (No! Don't go there.)
- **beklong**: throat
- **bélé**: to, for
  - Béléu / Béléeu: for me, to me
  - Béléem: to you, for you
  - Béléen: to him/her/it
  - Béléle: to them
  - Béléye: to you all
  - Bélékuy: to all of us
  - Béléte: to just you and me
  - Para béléem: for you (para makes it clear who it's for)
  - Example: Hkodoke béléem itlug (I'll boil an egg for you)
- **besow**: full (from eating)
  - Henok / Besow: full
  - Besowe / Besow: I'm full
  - Denge besow: I'm full (I'm already full)
  - Example: Besowe ne (I'm full now)
- **bitil**: hungry
  - Bitile: I'm hungry (can also mean "they're hungry")
  - Bitile ah: I'm hungry
  - Bitilu: you're hungry
  - Bitile lu: they're hungry (clearer)
  - Example: Teye bitil. Kóm du? (I'm very hungry. And you?)
- **blay**: give
  - Ne blay: I will give
  - Example: Haya, ne blay lu bê kem twolihu (tomorrow I'll give them to my siblings)
- **blotik**: star
- **blutut**: belly
- **bon**: what
  - Bon nmoem (du)?: what are you doing?
  - Bon nmoem ni?: what are you doing now?
  - Bon (tô) nmou: what I do, what to do
  - Bon boluyem (du)?: what's your name?
  - Bon kdaw du ni (kdaw ni)?: what's the date today?
  - Bon kminì kóm du?: what's heating you?
  - Bon se duen hnagì te du?: what else should we learn?
- **bong**: big
  - Bong slamat: thank you so much
  - Example: Kulón bong? (big rain?)
  - See also kbong
- **botò**: penis
- **bud**: again (in front, for something that will happen)
  - Bud (ne): anymore
  - Bud te: we will (again)
  - Bud etu he: we will do it again; until then
  - Bud kmulón: it'll rain again
  - Bud moo ktuku: I'm sleepy again
  - Example: Bud te ston kdeng (we'll see each other later)
  - Example: Là nóyóu du kehe bud lehen (I don't want to be skinny anymore)
- **bukay**: white
- **bukol**: knees
- **bulón**: moon; month (like kdaw is sun and day)
  - Todol bulón: next month
  - Example: Bulón nô bê ta (the moon is up above)
- **Byérnis**: Friday (borrowed from Spanish)

### D

- **dé kô**: if (something happens)
  - Example: Omin likoe dé kô gungolen o Pangu (and I'm afraid my dad will scold me)
- **deng**: done, already
  - Denge: I'm done
  - Dengu: you're done
  - Dengi: you're done (formal)
  - Deng ye: you all are done
  - Deng le: they're all done
  - Deng kuy: we're done (including me)
  - Deng te: we're done (just you and me)
  - Deng me: we're done (me and others, not the person I'm talking to)
  - Deng (ne) du: he/she/it is done
  - Deng kenu: I ate
  - Denge meken: I already ate
  - Deng ne meken: I'm done eating
  - Deng t'ngónu ne: now I know
  - Example: Deng tógó (ne) ken / Ken, deng tógó (ne) (the rice is already cooked)
- **des**: hurt; sick
- **dilak**: tongue
- **do**: mine; me, when I'm the one something happens to (from dou)
  - Do u ni: this is mine
  - Do ken: my food
  - Example: Yó kóm ken, ni do ken (that's your food, this is my food)
  - Example: Ktolok le do (they taught me)
- **dou**: I own; mine; my
  - Dou wong: (it's) my spider
  - Do wong / wongu: my spider. -u on the end is for something that belongs to you
  - Example: Uu dou dumu sbót (you are my friend)
- **du**: him, her, it (used everywhere for he/she/it); in questions like Kmoem du it means "it" or "something"; in kmon du it points to the thing being said
  - Du yó: that's him
  - Meken du: he's eating
  - Mebel du: he/she/it finds (something)
- **dumu**: other; another (sotu / dumu)
  - Dumuhu: my other
  - Dumu sbót: a friend
  - Dumuhu sbót: my friend (telling someone else)
  - Kem dumuhu sbót: my (other) friends
  - Kem dumu bots: the other bots
  - Example: Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem (other bots like ChatGPT don't understand it even when they read your lesson notes)
- **Dwata**: God
  - Ke Dwata: to God, or God's
  - Ke Dwata yó: that's God's
  - Udél Dwata: the T'boli Bible (see udél)

### E

- **Ekimel**: yesterday
- **Ekuloy**: the day before yesterday
- **él**: water
  - Minum él: drink water
  - Example: Haya, nehe gów bê él, mebel utón (tomorrow I will go to the water and find fish)
- **Ell**: yes (said like "Ull")
  - Ell, tahu yó: yes, that's true
  - Ell, tahu ni: yes, it is real
- **ene**: come
  - Ene bê ni: come here
- **esolu**: (where) will be going
  - Example: Olohu hetngón du béléem bê du gôem esolu (I just want you to know where you're supposed to be going)
- **etu**: then (sometime in the future)
  - Bud etu he: we will do it again; until then
- **ewen**: so
  - Example: T'ngónem galì ewenu se ke hentahumen udélu kô? (oh, so you'll believe anything I say, huh?)

### F

- **fakay**: can, may; allow
  - Fakay kô?: is it allowed? can I?
  - Fakay ke: can I...
  - Fakay kô ke...?: can we / is it allowed to...? (ke is the "if" that links fakay kô to the action)
- **fan**: trap
  - Fanen: his/her/its trap
  - Example: Nmoem fanen dé (put a trap on it)
  - Gfan, hegfan, segfan (showing up) are built from this root
- **fat**: four
- **fedyan**: week
  - Todol fedyan: next week
- **folò**: tens (Lwu folò, 20)
- **fun**: owner (the u like in uniform)
  - Funu: my owner
  - Funem: your owner
  - Funen: his/her/its owner
  - Funle: their owner (people not in the conversation)
  - Funye: you all's owner (speaker not included)
  - Funkuy: our owner (me and 2 or more people)
  - Funte: our owner (just me and one other person)

### G

- **galì**: oh, so that's why (Tagalog "kaya pala")
- **gel**: always, in general
  - Example: Gel mi coffee-hu, wen klamay nô lemmen (my coffee's always sweet, it has sugar in it)
  - Example: Ni kdaw ni tey gel tnaw (today is really, really cold)
- **gfan**: show up unexpectedly
  - Hegfan: show up intentionally, walking into the fan (trap or event) someone set, on purpose
  - Segfan: show up to each other
  - Example: Haya gfan yó du (tomorrow he will show up)
  - Built from fan (trap): gfan is getting caught by it, showing up by surprise
- **genléd**: rely
  - Genléd nawa: rely on (putting your own breath, your self, onto something)
- **geslà**: a surprise, something you didn't expect
  - Geslàu wong / Gebele wong: I stumbled on a spider
  - Not the same as gesla (no accent): (being) fried
- **gna**: first (the general word); past; old
  - Gna halay: last year
  - Gna kesfasad: old covenant
- **góem**: where? where to? (said short like this, it means "where" and stops meaning "your house")
  - Góem gów (du)?: where are you going?
  - Góen nô phone-nu (du)?: where's my phone?
- **gónô**: house; home
  - Gónóem: your house, your place
  - Gónô le: their home
  - Gónô mnô: home
  - Example: Kilón ke kulékem bê gónô? (when will you get back home?)
- **gów**: go
  - Gówu: you go
  - Nehe gów: I will go
  - Example: Bê du gôem gów du? (where are you going? the full way)
  - Example: Hene, gówu bê ni. Tungôu. (come, go here. Sleep.)
- **gwa**: get; accidentally taken (see ma)

### H

- **haha**: legs
- **halay**: year; also living rice, the rice plant
  - Gna halay: last year
- **hanà**: still
  - Hanà là deng t'ngónu du bon nmou: I still don't know what to do
  - Example: Là nóyóu du tungô, kaye (hanà) bitil (I don't want to sleep because I'm (still) hungry)
- **hatay**: death, dying
  - Là gógówen elem hatay: he won't be lost to death
- **haya**: tomorrow
  - Example: Haya, bud kmulón (tomorrow it'll rain again)
- **he**: at the end of a sentence: yet; again, with a hope in it
  - Tagad he: wait a bit
  - Là e deng meken he: I haven't eaten yet
  - Bud te ston he: we'll see each other again, hopefully
- **hedem**: think
  - Kehedem: to think
  - Kehdem: to be thinking
  - Kmò kehdemem du se?: what do you think? (one person)
  - Kmò kehdem u du se?: what do I think?
  - Kmò kehdem ye du se?: what do you all think?
  - Kehegdemu du: I think
- **htò**: jumping
  - Wong htò: jumping spider
- **héét**: salty, and sour too
- **hegléd**: lean, leaning, leaned
- **hene**: come (here)
  - Hene edi ni: come over here
  - Hene, gówu bê ni. Tungôu.: come, go here. Sleep.
- **hitem**: black
- **hitu**: seven
- **hligal**: happy
  - Teye hligal: I'm very happy
- **hlós**: continue
  - Làe hlós meken se: I didn't eat (I didn't go on to eat)
- **hlowon**: joking
  - Olohu hlowon néen: I'm just joking
- **hnagì**: learn, schooling; lessons
  - Hemnagì: to study something
  - Kehnagì: still studying something (ongoing)
  - Mnagì: studying
  - Example: Bon se duen hnagì te du? (what else should we learn?)
  - Example: Lnóngónu meken wen para bê kem lomi hnagì (I need to eat more for new lessons)
- **hnobò**: bladder (careful, one accent off from hnóbô)
- **hosò**: heart
- **hulô**: red
  - Utón hulô mata: red-eye fish
- **hyu**: good
  - Hyu hlafus: good morning
  - Hyu kifu: good night (more like good evening)
  - Hyu se yó: that's good (hyu good, se is, yó that)
  - Hyu yó msó: that rice is good

### I

- **ilung**: nose
- **itlug**: egg
  - Example: Senlahu itlug, kayà meken kuy (I fried eggs, so let's eat)

### K

- **kahang**: spicy (borrowed from Hiligaynon)
- **kahì**: salt
  - Example: Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen (my coffee has salt in it)
- **kailangan**: need (borrowed from Tagalog)
  - Kailanganu: I need
  - Example: Kailanganu mekay ken. (I need to cook rice.)
- **kapuy**: tired
  - Teye kapuy: I'm exhausted
- **katù**: puppy
- **kay**: because
  - Kaye: because I (the -e from bitile jumps to kay): Kaye bitil, because I'm hungry
- **kayà**: so, that's why (borrowed from Tagalog)
  - Example: Meenge, kayà minume o él (I'm thirsty, so I'm drinking water)
- **kbong**: big
  - Kbong nawa: love (literally "big breath"; Blaan has a close version, kanbong nawa)
  - Kbong nawahu kóm: my love for you
  - Kenbong (with -n-): already happening, continuously; kbong is still going
  - Kenbong nawahu u: I love you (literally "my breath for you is big": you are their breath)
  - Kenbong nawahu kóm: I love yours
- **kdaw**: sun; day
  - Kdaw ni: today (or just Ni when the context makes it clear)
  - Sok kemdaw: during the day
  - Example: Hkinì u bê kdaw dé (get yourself heated by the sun)
- **kdê**: all (general word)
  - Kdéen: all of it
  - Kdéle: all of them
  - Example: Slamat bê ke-savem du kdéen (thanks for saving all of it)
- **kdeng**: later (at the end of a sentence); wait! (on its own at the start)
  - Kdeng, hkinìu ken: wait, I'll heat up the food
  - Kdeng! Là o du mò du yó: wait! I didn't do that
  - Kmulón kdeng: it's raining again
  - Moo ktuku kdeng: I'll be sleepy later
  - Bud moo ktuku kdeng: I'll be sleepy again
  - Bud kmulón kdeng: it's going to rain again (later)
- **ke**: if; to, for, or, and possession
  - Kehe: if I; also to be, to become (when it's "I")
  - Kehi: you become
  - Kehu bitil, mekenu: if you're hungry, eat
  - Kehe bitil, ne meken dé: if I'm hungry, I'll eat
  - Ke Dwata: to God, or God's
  - Ke Miles: or Miles / Miles' belongings / for Miles
  - Ke- (on borrowed verbs): if, or for doing it (ke-savem, ke-downloadem, ke-sendem)
  - Kilón ke / Moen ke: ke always follows when and why
  - Kô ke: or, pick one
  - Example: Là nóyóu du kehe lehen (I don't want to be skinny)
- **kem**: plural marker before a noun; these
- **ket**: enough; every
  - Ket tonu kuying bê lan ket knwahu: every cat I see in the street, I take
  - Ket me lwu me. Wen kun, wen sdo: we're even. He has his, I have mine
  - Kem utón: fish (more than one)
  - Kem ngà: children
  - Kem tau: people
  - Kem twolihu: my siblings
  - Kem udél: words
  - Kem dumu bots: the other bots
- **ken**: food in general; cooked rice; eat
  - Meken / Mken: eating, to eat (same word, just said faster)
  - Mekene: I am eating
  - Mekenu: you are eating; also "eat!"
  - Meken du: he/she/it is eating right now
  - Meken kuy: we are going to eat, let's eat
  - Kenu: I eat (it)
  - Kenem: you eat
  - Kenen: he/she/it eats or ate (general)
  - Kenle: they eat
  - Kenye: you all eat
  - Kenkuy: we eat
  - Kente: just you and me eat
  - Deng kenu: I ate
  - Denge meken: I already ate
  - Deng ne meken: I'm done eating
  - Meken he (kdeng): I'll eat (later)
  - Ne meken dé: I'm going to eat
  - Ne meken he dé: I'll eat first
  - Nehe meken: I will be eating
  - Là e deng meken (he): I haven't eaten (yet)
  - Kken: ate together (past)
  - Henken: feed
  - Henkenu ohu: I feed the dog
  - Hefken: wants to be fed
  - Hefkenu bê ohu: I fed it to the dog
  - Nehu henken kem wongu anay: I will feed my spiders first
  - Hefkene bê ohu: I fed myself to the dog
  - Henken do: feed it for me (asking someone to feed something of yours, like your dog)
  - Henken o: feed me
  - Kenken: be fed
  - Ohu nóyóen ke kenken (du): the dog wants to be fed
  - Sken: eat each other
  - Senseken: eating together (still going)
  - Ken tnaw: leftover rice (literally "cold rice")
  - Mekay ken: to cook rice
  - Example: Téy mi ken ni (this food is delicious)
  - Example: Mekenu silà kô ke ken? (are you eating corn or rice?)
- **kfu**: chest
- **kifu**: night (sok kifu, at night)
  - Hyu kifu: good night (more like good evening)
- **kilón**: when?
  - Example: Kilón ke kulékem bê gónô? (when will you get back home?)
- **kinì**: hot
  - Kminì: being heated by (something)
  - Hkinì: make hot
  - Hkinìem ken: heat up the food (you do it)
  - Hkinìu ken: I heat the food
  - Hkinì u bê kdaw dé: get yourself heated by the sun
  - Bon kminì kóm du?: what's heating you?
  - Example: Coffee-hu kinì (my coffee is hot)
- **klamay**: sugar
- **klingu**: ear
- **kmò**: how
  - Kmou du: how am I going to do it? what am I going to do?
  - Kmou se do(u): how am I? what about me?
  - Kmou du se?: how or what am I supposed to do?
  - Kmoem du?: what or how would you do? what's up to you? also how are you? what's up?
  - Kmoem se du?: how are you?
  - Kmoem du se?: what or how did you do? how would you do it?
  - Móen: short for Kmoem (Teye bitil. Móen skóm? I'm very hungry. How about you?)
  - Kmoen du?: how was it?
  - Kmoen se du?: how is he/she/it?
  - Kmoen du se du?: what or how did he/she/it do (to something)?
  - Kmò le du?: how are they? how did they do it?
  - Kmò le se lu?: how are they?
  - Kmò le du se?: what did they do? how would they do it?
  - Kmò ye du?: how are you all? how did you all do it?
  - Kmò ye du du?: what did you all do to him/her/it?
  - Kmò ye du se?: how would you do it? how did you do it?
  - Kmò kuy du?: what do we do? how about you all?
  - Kmò kuy du se du?: what are we supposed to do to him/her/it?
  - Kmò kuy?: how about you all?
  - Kmò te du?: what about us (you and me)? what do we do?
  - Kmò me du: the same with me (we, not you)
  - Kmò kmon (du): how to say (it)
  - Use Kmoem when asking someone directly, Kmoen when it's indirect
- **kmoen kun ke...**: what if...
  - Also said: Kmoen kun..., Kmoen kun ke sok..., Kmoen ke sok...
  - Example: Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying? (What if I cook 1,936 fish and feed them to my 127 cats?)
- **kmustahu du?**: how are you?
- **kô**: turns a sentence into a yes or no question
  - Tahu kô?: is it true? is it right? correct?
  - Kô ke: or, when suggesting someone pick one
  - Example: Downloadem kô? (would you download it?)
- **kodok**: boil
  - Kmodok: boiling
  - Hkodok: asking for it to be boiled
  - Hkodoku: I'm boiling it (now or later, depending on context)
  - Hkodokem: you're boiling it
  - Hkodoke béléem itlug: I'll boil an egg for you
  - Henkodok: being boiled
  - Hefkodok: asking someone to boil something (hef- is asking; you hand over your own item)
  - Hefkodoku béléeu kun él: please boil me water (I gave you my item, you do the work)
  - Hkodoku béléeu kun él: please boil me water (I don't have the item, you find it and do it)
  - Hefkodoku béléem itlug: I'm asking you to boil the eggs
  - Hefkodoke béléem itlug: boiling an egg for you
  - Hefkodoku béléeu itlug: please boil an egg for me (my egg, you do the work)
  - Kmodok él ne / Kmodok ne él: the water's boiling now
  - Él deng kmodok: the water is already boiling
- **kóm**: yours, you own; you
  - Kóm du?: and you?
  - Kóm ken: your food
  - Example: Ou kóm dumu sbót (I'm your friend)
- **kuli**: laugh
- **kulit**: skin
- **kulón**: rain
  - Kmulón: raining, to rain
  - Knulón: (being) rained on
  - Kmulón ne?: is it already raining?
  - Kmulón ni?: is it raining?
  - Gkulóne: I accidentally got rained on
  - Knulóne: I got rained on (on purpose)
  - Example: Kmulón ne. Tnawu yó. (it's raining now. You'll be cold.)
  - Example: Haya bud kmulón (tomorrow it'll rain again; no kdeng, since haya already says when)
- **kulu**: head
  - Kuluhu: my head
- **kul**: they own, theirs; them, the whole group as the object
  - Kul yó: that's theirs
  - Khulék kul: return them all
  - Tnógóhu kul: I cook theirs
  - Tnógóhu kul he: I'll cook them all (a threat)
- **kum**: we (3 or more) own
- **kukù**: kitten
- **kun**: he/she/it owns; allegedly; in a request it works as "please"
  - Kun él: on its own, his/her/its water
- **kut**: we (me and you) own; ours
  - Kut yó: that's ours (me and you, or me and my people)
  - Kut ne yó: that's our turn
- **kuy**: we, us (3 or more); all of us
  - Meken kuy: let's eat
  - Kuy yó: that's yours; also that's you all
  - Tnógóhu kuy he: I'll cook all of you (a threat)
- **kuying**: cat
  - Kuying bê ta lmisa: the cat is on the table
- **kwang**: back (body)
- **kyemet**: fingers
- **K'nóón**: very good, very cool, very nice, very beautiful (an earlier lesson wrote it K'nôón, beautiful)

### L

- **là**: no (general); not
  - Làe / Là e: I am not (literally "no I")
  - Làu / Là u: you are not
  - Lài: you (the one specific person I'm talking to) are not
  - Làen: he/she/it is not
  - Là le: they are not
  - Là te: we (you and me) are not
  - Là ye: you all are not
  - Là kuy: we all are not
  - Là me: we are not (not counting the person I'm talking to)
  - Là du du: he/she/it did not (do something)
  - Là du: never mind; nothing much
  - Là sdu: of course not
  - Làen dù (andù): no one
  - Là o du se / Là ou du (se): it's not me (when someone accuses you)
  - Là o du mò du yó: I didn't do that
  - Là ou du mò du yó: I'm not the one who did that
  - Example: Là e deng meken he (I haven't eaten yet)
- **laan**: under
  - Laan lmisa: under the table
  - Bê laan: underneath (something)
- **lan**: way, road
  - Example: Tey sidek lan yó mulék bê gónô (that is a very bad way to get back home)
- **latu**: hundreds
  - Lmatu (Sotu latu): one hundred
  - Lwu latu: 200
- **lehen**: skinny
- **lem**: inside
  - Lemmen: inside of something or someone
  - Bê lem: inside
  - Example: Coffee-hu wen klamay nô lemmen (my coffee has sugar in it)
- **lembak**: mouth
- **len**: just
  - Anduen. Len myón.: nothing, just sitting
- **lemnok**: growing
- **lengel**: drunk
  - Example: Kay wen tau lengel tungô laan lmisa (because there's a drunk guy sleeping under the table)
- **libu**: thousands
  - Lmibu (Sotu libu): one thousand
- **libun**: female
- **lihol**: neck
- **likò / likô**: afraid, scared (both spellings appear in the lessons)
  - Likoe: I'm afraid
  - Example: Là e likô (bê) wong (I'm not scared (of) spiders)
  - Example: Ngà laen likò bê wong (the child isn't scared of the spider)
- **limu**: five
- **lingón**: song
- **litô**: blood
- **lmisa**: table
  - Bê ta lmisa: on top of the table
- **lmiteg**: tired (the more T'boli way to say it)
- **lnos**: wind
- **lobun**: cloud
  - Lmobun: cloudy, getting cloudy
  - Example: Kdaw ni, Denlag tey lmobun (tonight Denlag is very cloudy)
- **lóbô**: angry (in general)
  - Hlóbô: angry, mad
  - Hnóbô: getting angry at someone (not hnobò, bladder)
  - Example: Ominen bud hlóbô mton do meken (he'll get mad again if he sees me eating)
- **logi**: male
- **lohok**: beside
  - Bê lohok: beside
- **lomi**: new
  - Lomi kesfasad: new covenant
- **lóngón**: need
  - Lnóngón: to need (to)
  - Example: Lwu folò fat utón lnóngón (24 fish are needed)
  - Example: Lnóngón kuy kebel kuy dumu lan (we need to find another way)
- **lówóhu**: my body
  - Lówóhem: your body
- **lték**: thunder
- **lu**: them
  - Lu yó: that's them
- **lwu**: two
  - Lwu te yó: that's the two of us

### M

- **ma / mwa**: take
  - Ma / Gemwa: to get
  - Nwa: taken; get (nwahu, I get)
  - Gwa: get; accidentally taken
  - Swa: taking from each other
  - Example: Anì(e) gemwa [lówóhu] unged wen (so I can get more muscle)
- **mà**: father
- **maistru / mestlu**: teacher (borrowed from Spanish maestro; mestlu is how it's actually said)
  - Deymar Mestlu / Mestlu Deymar: both work. The first is like "Deymar the teacher", the second like "Teacher Deymar", a title
  - Tau tmolok: a person who teaches
- **mala**: spicy
- **mang**: mama
- **masa**: read
- **mata**: eye
  - Matahu: my eyes
  - The color goes before mata: Tnógóu lu kô ni utón hulô mata? (should I cook this red-eye fish?)
- **me**: we, I'm part of it but the person I'm talking to isn't (see the three kinds of "we")
  - Example: Tmógó me utón (we're cooking fish, not you)
- **meeng**: thirsty
  - Meenge: I'm thirsty
  - Example: Soke meeng, minume él (when I'm thirsty, I drink water)
- **mekay**: to lift something
  - Mekay ken: to cook rice (literally lifting the rice)
- **mi**: sweet
  - Téy mi: delicious (literally "very sweet")
- **mi**: us, we (I'm included but not the person I'm talking to); sounds exactly like mi, sweet
  - Mi kem mag-cousin: us cousins (not counting you)
  - Tu mi: there we are; that's us (to people who aren't part of it)
- **minum**: drink (still happening)
  - Ninum: drunk by something
  - Minume: I'm drinking or we're drinking, depending on context
  - Minume o él: I was drinking water
  - Minume mi él: we were drinking water
  - Ninumu él: I drank the water
  - Ninume él: we drank the water
  - Miles ninumen él: Miles drank the water
  - Él ninum Miles: the water being drunk by Miles
  - Él ninumen Miles: the water drank Miles
  - Example: Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng (I don't want to be skinny, so I'll take my vitamins later)
- **moen**: why? (its own word, not Móen)
  - Example: Moen ke là u gtungô du? (why aren't you sleepy yet?)
- **mon**: say
  - Kmon: mon with the m infix
  - Kmò kmon (du): how to say (it)
- **moo**: smell
  - Moo ktuk: sleepy (literally "smells sleepy")
  - Moo ktuku: I'm sleepy
  - Example: Moo ktuk wong. Tluyab. (the spider is sleepy. Yawn.)
- **mowil**: alive
- **msó / mesó**: rice (uncooked). Msó is the fast way to say mesó. Cooked rice is ken.
  - Hyu yó msó: that rice is good
  - Example: Tadu se duen mulék bê gónô anì tmógó msó béléu? (who else is going to get home to cook rice for me?)

### N

- **nawa**: breath, to breathe
  - Nawahu: my breath (not the same as nwahu, "I get")
  - Kbong nawa: love (see kbong)
  - Kenbong nawahu u: I love you
  - Genléd nawa: rely on
- **ne**: now, already, a change happening (like Tagalog "na"); about to
  - Nehe / Ne(he): I will (do something)
  - Nehi: you will (nehu works too, but it can also mean "I will")
  - Nele: they will
  - Nehi mulék: come back first
  - Ni vs ne: ni = right now, ne = already
  - Example: Tu ne ni (it's our turn)
  - Example: Ne meken dé (I'm going to eat)
- **nebel**: find
  - Mebel: to find
  - Mebel du: he/she/it finds (something)
  - Example: Nehe mebel lomi utón bê lwu bulón (I will find new fish in 2 months)
- **nem**: six
- **ngà**: child, kid, son, daughter, offspring
  - Ngaen: his/her child (the accent drops when an ending is attached)
  - Ngaen tek sotu: his only child
  - Kem ngà: children
- **ni**: it, this; here's; right now; at the end, points to something right here
  - Nìen: this one, it (ni plus -en)
  - Kdaw ni / Ni: today
  - Sotu ni: the day after tomorrow
  - Example: Kehu bitil, ni ken para béléem (if you're hungry, here's food for you)
- **nihi**: teeth
- **nô**: where?; also the "is" for where something is
  - Nô (bê)?: at, on, in, or to where?
  - Nô (se)?: where is it?
  - Example: Coffee-hu nô bê ta lmisa (my coffee is on the table)
- **nóm**: taste
  - Mnóm: tasty
  - Tey mnóm: delicious
  - Example: Utón nìen, téy mnóm! (this fish, it's very tasty!)
- **nóyó / nóyô**: want; like; liked, loved
  - Nóyóu meken: I want to eat, I like to eat
  - Nóyóu meken du: I want to eat it/him/her
  - Nóyóu wong htò: I like jumping spiders
  - Nóyóu: I want (to)
  - Là nóyóu (du): I don't want (to)
  - Nóyóe: I am liked
  - Nóyóu u / Nóyô te u: I like you
  - Nóyóte u: I like you (the poetic way)
  - Example: Là nóyóu du ke-delete du (I don't want to delete it)

### O

- **o / ou**: me, I (ou is specifically me)
  - O yó: that's me
  - Ou yó: that's me, specifically me
- **o**: or (borrowed from English)
- **ofi**: fire
- **ohu**: dog
- **ok ye néen / ok néen**: I'm fine
- **okóm**: but
  - Okóm close: but close
- **olohu**: I'm just
  - Olohem: you are just
  - Olohen: it's just
  - Olohu hlowon néen: I'm just joking
  - Example: Là, olohen kulón udì (no, just a little rain)
- **omin**: and
  - Ominen: and maybe he/she/it
  - Ominem dé: you're welcome
- **onuk**: chicken

### P

- **pang**: dad, papa
  - Pangu: my dad
- **para**: for (borrowed from Spanish)
  - Para bê: for something or someone (being given to them): Ken para bê kem ngà, food for the children
  - Para béléem: for you
- **péro**: but (borrowed from Spanish)

### S

- **sabad**: annoying
  - Téyu sabad u: you're annoying
- **salig**: trust
  - Ksalig: to trust
  - Gsalig: unintentionally trust
  - Hsalig: letting something trust something
  - Snalig: trust that's actively happening (salig with the -n- infix)
  - Ksaligem: your trust
  - Ksaligu ke Dwata: the trust I have for God
  - Snaligu Dwata: I trust in God
  - Hsaligu kóm ni kdéen: I will trust everything to you
- **sbót / sebót**: friend (general word)
  - Dumu sbót: a friend
  - Uu dou dumu sbót: you are my friend (dou: my)
  - Ou kóm dumu sbót: I'm your friend
  - Dumuhu sbót: my friend (telling someone else)
  - Example: Miles omin Deymar sbót le (Miles and Deymar are friends)
- **se**: is, am, are (goes in the middle); the "be" word for how someone is
  - Example: Kmoem se du? (how are you?)
- **sef**: suck
  - Nsef: sucked (the n infix for something already done)
  - Hsef: to let someone (not me) suck
  - Ssef: both sucking
  - Msef: sucking
  - Sensesef: sucking together
- **senla / pritu**: fry
  - Senlakuy: we fry
  - Example: Fakay kô ke senlakuy lu ni kem utón, lwu libu wolu latu sfolò syóm? (can we fry these 2,819 fish?)
  - Senlahu lu: I fry them
  - Example: Soke bitil, senlahu ken tnaw (when I'm hungry, I fry leftover rice)
  - Example: Senlahu ken tnaw, kayà meken kuy (I fried the leftover rice, so let's eat)
- **sgeng**: at the same time (Tagalog "sabay")
  - Anì le sgeng tmowok: so they grow together
- **sidek**: bad
  - Example: Nuclear bom tey sidek ni. (the nuclear bomb is very bad)
- **sigel**: arms
- **silà**: corn
  - Silaem: your corn (the accent drops when an ending attaches)
  - Silà le: their corn (never silale)
- **skas**: break
- **skél**: same
  - Skél bê: the same as, like (before a thing: skél bê ChatGPT)
  - Ou skél béléem: I'm like you, I'm the same as you
  - Uu skél béléu: you're like me
  - Skél + owner word merges into the "too" words: skél kóm becomes skóm (you too)
- **skóm**: you too, as well as you (from skél kóm)
  - Hyu hlafus béléem skóm: good morning to you too
- **sdo / sdou**: me too, as well as me
  - Ominu meken sdo(u): and I'll eat too
- **skun**: him/her/it too, as well as him/her/it
- **skul**: them too, also them
  - Kehegdemu du bitil le skul kem wongu: I think my spiders are hungry too
- **skut**: us too, same as us (you and me)
- **sket**: enough
  - Sket ne ni: this is enough
  - Sket kut: we're the same
  - Sket kut nê: we're just the same
  - Sket kul: they're just the same
  - Sket te: you and I are the same
- **slamat**: thanks
  - Bong slamat: thank you so much
  - Slamat béléu: thanks to me
  - Slamat béléem: thanks to you
  - Slamat béléen: thanks to him/her/it
  - Slamat béléle: thanks to them
  - Slamat béléye: thanks to you all
  - Slamat bélékuy: thanks to all of us
  - Slamat béléte: thanks to just you and me
- **s'ngal**: title of a song
- **snata / utóm**: music
- **soging**: banana
- **sok**: if, when (another word for ke)
  - Soke bitil: when I'm hungry (the person ending goes on sok)
  - Sok kifu: at night
  - Sok kemdaw: during the day
- **sómól**: grain rice (uncooked)
- **sotu**: one; another (sotu / dumu)
  - Sotu ni: the day after tomorrow (when talking about dates)
  - Tek sotu: only one
- **S'twoli**: siblings ((Dumu) S'twoli)
  - Twolihu: my siblings
- **subù**: sad
- **sumóng**: lips
- **sfolò**: ten (sotu + folò merged, "one ten")
  - Sfolò sotu: 11
- **syó du?**: what's up?
- **syóm**: nine

### T

- **ta**: above
  - Bê ta: on top of
- **tadu / tau du**: who?
  - Tadu yó?: who's that?
- **tagad**: wait; also "yet" in bê tagad
  - Tagad he: wait a bit
  - Bê tagad tungô he: don't sleep yet
- **tahu**: true
  - Tahu yó: that's true, agreeing
  - Tahu kô?: is it true? is it right? correct?
  - Tahu kô ni?: is it real?
  - Ell, tahu ni: yes, it is real
  - Ell, tahu yó: yes, that's real
  - Hentahu: to believe (from tahu, true)
  - Hemtahu: is believing
  - Example: Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged? (do you believe eating red-eye fish together and sucking their meat can help us grow muscle?)
- **tau**: person
  - Kem tau: people
  - Tau tmolok: a person who teaches
- **te**: you and me; me and you
  - Lwu te yó: that's the two of us
  - Stolok te: we (you and I) teach each other
- **tek**: only
  - Ngaen tek sotu: his only child
- **temngón**: smart
  - Téyu temngón: you're very smart
- **tey / téy**: very
  - Teye: I am very
  - Téyu: you are very
  - Téy-: he/she/it is very
  - Téyle: they are very
  - Téyye: you all are very
  - Téykuy: we are very
  - Téyte: we (you and I) are very
  - Téy kinì: very hot
  - Téy wen: a lot, many (literally "many have")
  - Téyu the best: you're the best
- **ti**: feet
- **tilob**: good, cool, nice, beautiful (the general word)
  - Tilob du: it's beautiful
  - Both tilob and K'nóón work for things like a T'nalak
  - Example: Okóm tey tilob ni kem utón ni (but these fish are so beautiful)
- **tilów**: try, taste
  - T'milów: trying, tasting (going to try something)
  - T'nilów: being tried or tasted (with the endings, the m becomes n)
  - M'tilów (Metilów): being tasted
  - Tilówem: you try
  - Tilówu: I try
  - Tilówte: let's try, just you and me
  - T'milówu: come try or taste it
  - T'nilówem: you, try or taste it
  - T'nilówen: he/she/it is trying or tasting it
  - T'milówle: they're trying or tasting
  - T'nilów le: they are trying or tasting it
  - T'milówye / T'nilówye: you all try or taste it, come try it
  - T'milówkuy / T'nilówkuy: let's try it
  - T'milówte: just you and me are trying or tasting
  - Deng t'nilówu ni / Deng tistingu ni: I already tried it
- **tiol**: bones
- **tisting**: tasting (borrowed from English)
- **tlu**: three
- **tluyab**: yawn
- **t'ngón**: know
  - T'ngónem: you know; do you know?
  - T'ngónu: I know
  - Deng t'ngónu ne: now I know
  - Hetngón: to let someone know (h- + t'ngón)
  - Example: T'ngónem bon yó "béléem" meaning-ngen? (do you know what "béléem" means?)
  - Example: Là t'ngónu du ke hyu ktolok le do (I don't know if I'm being taught well)
- **tnaw**: cold
  - Hetnaw: make cold; being frozen by (something)
  - Hetnawem ken: make the food cold (you do it)
  - Hetnawen u yó: it'll make you cold
  - Tnawu yó: you'll be cold
  - Ken tnaw: leftover rice
- **tóbong**: help (the general word)
  - Tnóbong: to help
  - Stóbóng: helping each other
  - Gtóbóng: being helped (unexpectedly)
  - Example: Stóbóng le anì le sgeng tmowok bê kehnagì le udél (they helped each other grow in studying languages)
- **todol**: next
  - Todol bulón: next month
  - Todol fedyan: next week
- **tógó**: cook
  - Tmógó: cooking (hasn't happened yet)
  - Tnógó: to cook; being cooked
  - Tnógóu lu kô ke senlahu lu?: should I cook them or fry them?
  - Tnógóhu kul: I cook theirs
  - Deng tógó ne ken: the rice is already cooked
- **tolok**: teach
  - Tmolok: teaching, about to teach
  - Tnolok: being taught
  - Gtolok: being taught unexpectedly
  - Htolok: wanting to be taught
  - Stolok: teaching each other
  - Ktolok: being taught
  - Toloku kóm: I teach you
  - Tnoloku: I teach (-u, not -hu)
  - Tnoloku kóm: I keep teaching you (ongoing)
  - Tolok te kóm: something I taught you in the past, just us
  - Tnolokem o(u): you taught me
  - Tnoloku u(u): I taught you
  - Ktolok le do: they taught me; the teaching they got through to me
  - Stolok te: we (you and I) teach each other
  - Stolok me: we teach each other, but not you
  - Example: Là tnoloku kóm anìu baling sidek (I don't teach you to become bad)
- **ton**: see; also found (the thing found comes after)
  - Mton: to see
  - Gton: unintentionally being seen
  - Gton du: he/she/it was seen, was found (the real passive; ton le du is "they found him")
  - Kton: already seen, was seen
  - Example: Ekimel ton le du (yesterday he/she/it was found)
  - Example: Ekimel kton le du mógów bê tuen (yesterday he was seen walking there)
  - Tonen: he/she/it found
  - Tonu: I found
  - Tonem: you found
  - Tonle: they found
  - Tonye: you all found
  - Tonkuy: we found
  - Tonte: you and I found
  - Ston: see each other (two people)
  - Bud te ston he: see you (again), literally "we two see each other again"
- **towok**: grow
  - Tmowok: to grow
  - Gtowok: being grown
  - Tnowok: something growing in or on something
  - Stowok: growing together, for each other (not "sensetowok")
  - Htowok: (help to) grow, in Gtóbóngen tu htowok unged (can help us grow muscle)
- **trok**: hands
- **tu**: far, there; also us
  - Tu dé: over there
  - Tu du: he/she/it is over there
  - Tu lu: there they are, they're over there
  - Tu mi: there we are; that's us (to someone who isn't part of it)
  - Tu tu: there we are (to someone who is part of it)
  - Tu yó: that's us (to people who are part of it, or pointing at something far off)
  - Tu ne yó: that's our turn
  - Tu ne ni: it's our turn
  - Tu mi tmógó utón: there's us, cooking fish
  - Tu works for directions too
- **tungô**: sleep
  - Tungôu: you sleep
  - Gtungô: sleepy
  - Gô tungô: bed, a place to sleep
  - Bê e dou tungô: I'm not sleeping yet
  - Example: Tungôu ne, wong. (sleep now, spider.)
- **twogu**: elder
- **twoli**: youngest

### U

- **u / uu**: you (one person); uu is specifically you
  - U yó: that's you
  - Uu yó: that's you, specifically you
- **udél**: language; word (the same word)
  - Kem udél: words
  - Udél T'boli: the T'boli language
  - Udél Dwata: gna kesfasad ne lomi kesfasad: the T'boli Bible, old covenant and new covenant (gna old, lomi new, kesfasad covenant)
- **udì**: small
- **ulék**: back
  - Mulék: coming back to (hasn't happened yet)
  - Kulék: coming back, came back
  - Kulékem: you'll come back (the k- form already carries "will")
  - Gulék / Mulék: get back, return
  - Hulék: return
  - Khulék: to return
  - Nehi mulék: come back first
  - Example: T'ngónem kô kmò khulék kul bê gónô le ni? (do you know how to get them back to their home?)
- **ulat**: veins
- **unged**: muscle
  - Unged wen: more muscle
- **unget / karni**: meat
- **utek**: brain
- **utón / isdà**: fish
  - Kem utón: fish (more than one)
  - Utón hulô mata: red-eye fish
- **utóm**: music; notes (music)
- **uyó**: face

### W

- **wek**: hair
- **wolu**: eight
- **wen**: there is, there was (used whenever something shows up in a story); have, has; more (tey works too)
  - Téy wen: a lot, many
  - Unged wen: more muscle
  - Example: Kdaw ni, wen wong nô bê ta lmisa (today, there's a spider on top of the table)
  - Example: Coffee-hu wen klamay nô lemmen (my coffee has sugar in it)
- **wong**: spider
  - Wong htò: jumping spider
  - Kem wongu: my spiders
  - Example: Là e likô bê wong (I'm not scared of spiders)

### Y

- **yê**: mother
- **yó**: that
  - (Bê) yó: there
- **yóm**: the
  - Example: Yóm nuclear clock làen skas se (but the nuclear clock doesn't break)
- **yu**: you (2 or more people)
  - Yu yó: that's you all

## English to T'boli index

Look up an English word to find the T'boli headword. The full meaning and forms are under that headword in the dictionary.

### A to C

- **afraid**: likò / likô
- **again**: bud; he (again, hopefully)
- **alive**: mowil
- **all**: kdê
- **allow**: fakay
- **already**: deng; ne
- **always**: gel
- **and**: omin
- **angry**: lóbô (hlóbô, hnóbô)
- **annoying**: sabad
- **another**: sotu / dumu
- **anymore**: bud (ne)
- **arms**: sigel
- **back (body)**: kwang
- **back (return)**: ulék
- **bad**: sidek
- **banana**: soging
- **beautiful**: tilob; K'nóón (very beautiful)
- **because**: kay
- **become**: baling; kehe / kehi
- **bed**: gô tungô (under tungô)
- **believe**: hentahu (under tahu)
- **belly**: blutut
- **beside**: lohok; bê
- **big**: bong; kbong
- **black**: hitem
- **bladder**: hnobò
- **blood**: litô
- **body (my)**: lówóhu
- **boil**: kodok
- **bones**: tiol
- **brain**: utek
- **break**: skas
- **breath, breathe**: nawa
- **but**: okóm; péro
- **can, may**: fakay
- **cat**: kuying
- **chest**: kfu
- **chicken**: onuk
- **child**: ngà
- **cloud, cloudy**: lobun (lmobun)
- **cold**: tnaw
- **come**: hene; ene
- **come back**: ulék (mulék)
- **continue**: hlós
- **cook**: tógó; mekay ken (cook rice)
- **corn**: silà
- **covenant**: kesfasad (under udél)

### D to H

- **dad, papa**: pang
- **day**: kdaw
- **death**: hatay
- **delicious**: téy mi (under mi); tey mnóm (under nóm)
- **dog**: ohu
- **done**: deng
- **don't**: bê
- **drink**: minum
- **drunk (intoxicated)**: lengel
- **ear**: klingu
- **eat**: ken (meken)
- **egg**: itlug
- **eight**: wolu
- **elder**: twogu
- **enough**: sket; ket
- **every**: ket
- **extremely**: alì
- **eye**: mata
- **face**: uyó
- **far**: tu
- **father**: mà; pang
- **feed**: henken (under ken); hefken, wants to be fed
- **feet**: ti
- **female**: libun
- **find**: nebel (mebel)
- **fingers**: kyemet
- **fire**: ofi
- **first**: gna; anay (first, for now)
- **fish**: utón / isdà
- **five**: limu
- **for**: bélé; para (bê); ke
- **found**: ton
- **four**: fat
- **friend**: sbót / sebót; dumu sbót
- **fry**: senla / pritu
- **full (from eating)**: besow
- **get**: gwa; ma / gemwa; nwa
- **give**: blay
- **go**: gów
- **God**: Dwata
- **good**: hyu; tilob
- **grow**: towok; lemnok (growing)
- **hair**: wek
- **hands**: trok
- **happy**: hligal
- **have, has**: wen
- **he, she, it, him, her**: du
- **head**: kulu
- **heart**: hosò
- **help**: tóbong
- **here's**: ni
- **hot**: kinì
- **house, home**: gónô
- **how**: kmò
- **hundred**: latu
- **hungry**: bitil
- **hurt**: des

### I to N

- **I, me**: o / ou; do
- **if**: ke; sok; dé kô
- **inside**: lem
- **joking**: hlowon
- **jumping**: htò
- **jumping spider**: wong htò
- **just**: len; olohu (I'm just)
- **kitten**: kukù
- **knees**: bukol
- **know**: t'ngón
- **language**: udél
- **later**: kdeng
- **laugh**: kuli
- **lean**: hegléd
- **learn, schooling**: hnagì
- **legs**: haha
- **lift**: mekay
- **like (enjoy)**: nóyô / nóyó
- **like (same as)**: skél (skél bê)
- **lips**: sumóng
- **love**: kbong nawa (under kbong and nawa)
- **male**: logi
- **mama**: mang
- **meat**: unget / karni
- **mine, my**: do; dou; -hu
- **month**: bulón
- **moon**: bulón
- **more**: wen
- **mother**: yê
- **mouth**: lembak
- **muscle**: unged
- **music**: snata / utóm
- **neck**: lihol
- **need**: lóngón; kailangan
- **new**: lomi
- **next**: todol
- **night**: kifu
- **nine**: syóm
- **no, not**: là; bê (refusing)
- **no one**: andù
- **nose**: ilung
- **nothing**: anduen
- **now**: ne; ni (right now)

### O to S

- **old**: gna
- **one**: sotu
- **only**: tek
- **or**: o; kô ke; ke
- **other**: dumu
- **owner**: fun
- **past**: gna
- **penis**: botò
- **people, person**: tau
- **please**: kun
- **puppy**: katù
- **rain**: kulón
- **read**: masa
- **red**: hulô
- **rely**: genléd
- **return**: ulék (hulék, khulék)
- **rice (cooked)**: ken
- **rice (uncooked)**: msó / mesó; sómól (grain rice)
- **rice plant**: halay
- **road, way**: lan
- **sad**: subù
- **salt**: kahì
- **salty**: héét
- **same**: skél
- **say**: mon
- **scared**: likò / likô
- **see**: ton (mton, to see; gton, seen by accident; kton, was seen; ston, see each other)
- **seven**: hitu
- **shoulder**: abal
- **show up (unexpectedly)**: gfan
- **show up (on purpose)**: hegfan
- **siblings**: S'twoli
- **sick**: des
- **six**: nem
- **skin**: kulit
- **skinny**: lehen
- **sleep**: tungô
- **sleepy**: moo ktuk (under moo); gtungô
- **small**: udì
- **smart**: temngón
- **smell**: moo
- **so, so that**: anì; kayà; ewen
- **song**: lingón; s'ngal (title of a song)
- **sour**: aslum; héét
- **spicy**: mala; kahang
- **spider**: wong
- **star**: blotik
- **still**: hanà
- **suck**: sef
- **sugar**: klamay
- **sun**: kdaw
- **surprise**: geslà
- **sweet**: mi

### T to Y

- **table**: lmisa
- **take**: ma / mwa
- **taste**: tilów; nóm
- **tasty**: mnóm (under nóm)
- **teach**: tolok
- **teacher**: maistru / mestlu
- **teeth**: nihi
- **ten, tens**: sfolò; folò
- **testicles**: amil
- **thanks**: slamat
- **that**: yó
- **the**: yóm
- **them**: lu; kul (the whole group)
- **then (later)**: etu
- **there**: tu; (bê) yó
- **there is, there was**: wen
- **think**: hedem
- **thirsty**: meeng
- **this morning**: ni hlafus ni
- **this**: ni
- **thousand**: libu
- **three**: tlu
- **throat**: beklong
- **thunder**: lték
- **tired**: kapuy; lmiteg
- **to**: bê; bélé; ke
- **today**: kdaw ni (under kdaw)
- **tomorrow**: haya
- **tongue**: dilak
- **too, also**: skóm (you), sdo (me), skun (him/her/it), skul (them), skut (you and me)
- **trap**: fan
- **true**: tahu
- **trust**: salig
- **try**: tilów
- **two**: lwu
- **under**: laan; bê
- **us**: tu; te (you and me); mi / me (not you); kuy (all of us)
- **veins**: ulat
- **very**: tey / téy
- **wait**: tagad; kdeng
- **want**: nóyó
- **water**: él
- **we**: kuy; te; me
- **week**: fedyan
- **what if**: kmoen kun ke (also kmoen kun, kmoen kun ke sok, kmoen ke sok)
- **what**: bon
- **when**: kilón; sok
- **where**: nô; góem; bê du
- **white**: bukay
- **who**: tadu / tau du
- **why**: moen
- **wind**: lnos
- **word**: udél
- **year**: halay
- **yes**: Ell
- **yesterday**: Ekimel
- **yet**: he; tagad (in bê tagad)
- **you (one person)**: u / uu; kóm
- **you (all)**: yu
- **youngest**: twoli

## Phrases by topic

### Greetings and small talk

- **Hyu hlafus**: good morning
- **Hyu hlafus béléem skóm**: good morning to you too
- **Hyu kifu**: good night (more like good evening)
- **Hyu kifu béléem skóm**: good night to you too
- **Syó du?**: what's up?
- **Kmustahu du?**: how are you?
- **Kmoem du?**: how are you? what's up?
- **Kmoem se du?**: how are you?
- **Ok ye néen / Ok néen**: I'm fine
- **Kóm du?**: and you?
- **Là du**: nothing much
- **Bon nmoem (du)?**: what are you doing?
- **Anduen. Len myón.**: nothing, just sitting
- **Bon boluyem (du)?**: what's your name?
- **Boluyu Miles**: my name is Miles
- **Bê du gôem lemwót du?**: where are you from?
- **Tagad he**: wait a bit
- **Bud te ston kdeng**: we'll see each other later
- **Bud te ston he**: see you (again), hopefully
- **Haya bud te ston he**: see you again tomorrow, hopefully
- **Bud etu he**: we will do it again; until then
- **Ell, tahu yó**: yes, that's true
- **Tahu kô?**: is that right?
- **Hene edi ni / Ene bê ni**: come over here / come here

### Thanks

- **Slamat**: thanks
- **Bong slamat**: thank you so much
- **Slamat béléem**: thanks to you
- **Ominem dé**: you're welcome
- **Slamat bê ke-teachem do**: thanks for teaching me
- **Slamat bê ke-sendem du**: thanks for sending it
- **Slamat bê ke-savem du kdéen**: thanks for saving all of it

### Food and drink

- **Meken kuy**: let's eat
- **Kehu bitil, mekenu**: if you're hungry, eat
- **Kehe bitil, ne meken dé**: if I'm hungry, I'll eat
- **Deng kenu**: I ate
- **Denge meken**: I already ate
- **Là e deng meken he**: I haven't eaten yet
- **Ne meken dé anay / Ne meken he dé**: I'll eat first
- **Làe hlós meken se**: I didn't eat (I didn't go on to eat)
- **Besowe ne**: I'm full now
- **Denge besow**: I'm full (I'm already full)
- **Téy mi ken ni**: this food is delicious
- **Utón nìen, téy mnóm!**: this fish, it's very tasty!
- **Besowe ne. Utón nìen, téy mnóm!**: I'm full now. That fish was really tasty!
- **Téy aslum sinigang nìen, okóm téy mnóm**: this sinigang is very sour, but tasty
- **Yó kóm ken, ni do ken**: that's your food, this is my food
- **Ken para bê kem ngà**: food for the children
- **Mekenu silà kô ke ken?**: are you eating corn or rice?
- **Hyu yó msó**: that rice is good
- **Deng tógó (ne) ken / Ken, deng tógó (ne)**: the rice is already cooked
- **Kailanganu mekay ken. Anìe meken kdeng.**: I need to cook rice so I can eat later
- **Kdeng, hkinìu ken**: wait, I'll heat up the food
- **Hkinìem ken**: heat up the food (you do it)
- **Hetnawem ken**: make the food cold (you do it)
- **Soke bitil, senlahu ken tnaw**: when I'm hungry, I fry leftover rice
- **Senlahu ken tnaw, kayà meken kuy**: I fried the leftover rice, so let's eat
- **Senlahu itlug, kayà meken kuy**: I fried eggs, so let's eat
- **Hkodoke itlug para béléem, kayà meken kuy**: I'll boil eggs for you, so let's eat
- **Hkodoke béléem itlug**: I'll boil an egg for you
- **Hefkodoku béléeu kun él**: please boil me water (with my item)
- **Hkodoku béléeu kun él**: please boil me water (you find it)
- **Kmodok él ne / Kmodok ne él**: the water's boiling now
- **Coffee-hu kinì**: my coffee is hot
- **Coffee-hu nô bê ta lmisa**: my coffee is on the table
- **Coffee-hu wen klamay nô lemmen**: my coffee has sugar in it
- **Gel mi coffee-hu, wen klamay nô lemmen**: my coffee's always sweet, it has sugar in it
- **Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen**: my coffee has salt in it
- **Meenge, kayà minume o él**: I'm thirsty, so I'm drinking water
- **Soke meeng, minume él**: when I'm thirsty, I drink water
- **Deng t'nilówu ni / Deng tistingu ni**: I already tried it
- **Tnógóu lu kô ni utón hulô mata?**: should I cook this red-eye fish?

### Feelings

- **Teye bitil. Kóm du?**: I'm very hungry. And you?
- **Teye bitil. Móen skóm?**: I'm very hungry. How about you?
- **Bitile ah**: I'm hungry
- **Teye hligal**: I'm very happy
- **Teye kapuy**: I'm exhausted
- **Meenge**: I'm thirsty
- **Là e likô (bê) wong**: I'm not scared (of) spiders
- **Olohu hlowon néen**: I'm just joking
- **Téyu nungel u**: you're crazy
- **Téyu sabad u**: you're annoying
- **Téyu the best**: you're the best
- **Téyu temngón**: you're very smart
- **Nóyóu u / Nóyô te u / Nóyóte u**: I like you
- **Kenbong nawahu u**: I love you
- **Kbong nawahu kóm**: my love for you
- **Kenbong nawahu kóm**: I love yours
- **Snaligu Dwata**: I trust in God
- **Hsaligu kóm ni kdéen**: I will trust everything to you

### Sleep

- **Moo ktuku**: I'm sleepy
- **Moo ktuku kdeng**: I'll be sleepy later
- **Bud moo ktuku**: I'm sleepy again
- **Bud moo ktuku kdeng**: I'll be sleepy again
- **Bê e dou tungô**: I'm not sleeping yet
- **Bê tagad tungô he**: don't sleep yet
- **Hene, gówu bê ni. Tungôu.**: come, go here. Sleep.
- **Là nóyóu du tungô, kaye (hanà) bitil. Ne meken dé anay. Là e gtungô he.**: I don't want to sleep because I'm hungry. I need to eat first. And I'm not sleepy yet.
- **Moen ke là u gtungô du?**: why aren't you sleepy yet?

### Questions

- **Tadu yó?**: who's that?
- **Góem gów (du)? / Bê du gôem gów du?**: where are you going?
- **Góen nô phone-nu (du)?**: where's my phone?
- **Kilón ke kulékem bê gónô?**: when will you get back home?
- **Bon kdaw du ni?**: what's the date today?
- **Bon kminì kóm du?**: what's heating you?
- **Bon se duen hnagì te du?**: what else should we learn?
- **T'ngónem bon yó "___" meaning-ngen?**: do you know what "___" means?
- **Kmò kehdemem du se?**: what do you think? (one person)
- **Kmulón ni? / Kmulón ne?**: is it raining? / is it already raining?
- **Tahu kô ni?**: is it real?
- **Downloadem kô?**: would you download it?
- **Downloadem du kô?**: would you download it/him/her?
- **Downloadem lu kô?**: would you download them?
- **Downloadem lu kdéle kô?**: would you like to download them all?
- **Downloadem kdéen kô?**: do you want to download all of it?
- **T'ngónem galì ewenu se ke hentahumen udélu kô?**: oh, so you'll believe anything I say, huh?

### People and friends

- **Uu dou dumu sbót**: you are my friend
- **Ou kóm dumu sbót**: I'm your friend
- **Ou skél béléem**: I'm like you
- **Uu skél béléu**: you're like me
- **Du yó / Tu yó / Lu yó**: that's him / that's us / that's them
- **Tu ne yó / Kut ne yó**: that's our turn
- **Tu ne ni**: it's our turn
- **Là o du se**: it's not me
- **Là o du mò du yó**: I didn't do that
- **Kdeng! Là o du mò du yó**: wait! I didn't do that
- **Mi kem mag-cousin**: us cousins (not counting you)
- **Miles omin Deymar sbót le. Stóbóng le anì le sgeng tmowok bê kehnagì le udél.**: Miles and Deymar are friends. They helped each other grow in studying languages.
- **Kdaw ni, Deymar. Tnolokem o(u), omin tnoloku u(u). Stolok te.**: Today, Deymar, you taught me and I taught you. We're teaching each other.
- **T'ngónem kô uu yóm dou dumu sbót tey nóyô? Ell, nóyóu u. Teyu temngón. Làu sabad se skél bê ChatGPT. Téyu the best, Miles.**: Do you know that you're my favorite friend? Yes, I like you. You're really smart. You're not annoying, the same as ChatGPT. You're the best, Miles.
- **Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem**: other bots like ChatGPT don't understand it even when they read your lesson notes

### Weather and time

- **Kmulón ne. Tnawu yó.**: it's raining now. You'll be cold.
- **Hetnawen u yó**: it'll make you cold
- **Haya, bud kmulón**: tomorrow it'll rain again
- **Bud kmulón kdeng**: it's going to rain again (later)
- **Kmulón kdeng**: it's raining again
- **Gkulóne**: I accidentally got rained on
- **Hkinì u bê kdaw dé**: get yourself heated by the sun
- **Ekimel alì kinì, okóm kdaw ni téy tnaw**: yesterday was extremely hot, but today is very cold
- **Ni kdaw ni tey gel tnaw. Alì kinì bong sok kifu okóm sok kemdaw là du.**: Today is really, really cold. It's so hot at night, but during the day it's not at all.
- **Hyu kifu! Kdaw ni, Denlag tey lmobun. Làen kinì, tnaw. Kulón bong? Là, olohen kulón udì. Haya, bud kmulón.**: Good evening! Tonight Denlag is very cloudy. It's not hot, it's cold. Big rain? No, just a little rain. Tomorrow it'll rain again.
- **Todol fedyan, bê Byérnis, nehe gów bê él.**: Next week, on Friday, I'll go to the water.
- **Haya ke-update tu du**: tomorrow I'll update it
- **Haya ke-download kuy du movie-le**: tomorrow we will download their movie

Days of the week (borrowed from Spanish; Akad may come from Malay or Arabic "Ahad"):

- **Akad**: Sunday
- **Lunis**: Monday
- **Martis**: Tuesday
- **Myérkulis**: Wednesday
- **Wibis**: Thursday
- **Byérnis**: Friday
- **Sbadu**: Saturday

### Family

- **Yê**: mother
- **Mang**: mama
- **Mà**: father
- **Pang**: papa (Pangu, my dad)
- **Twogu**: elder
- **Twoli**: youngest
- **Logi**: male
- **Libun**: female
- **Twogu logi**: elder brother
- **Twoli logi**: youngest brother
- **Twogu libun**: elder sister
- **Twoli libun**: youngest sister
- **(Dumu) S'twoli**: siblings
- **Twolihu / Kem twolihu**: my siblings
- **Ngà**: child, son, daughter (Ngaen, his/her child; Kem ngà, children)

### Numbers

English is used day to day, Spanish (T'bolized) for trading, and T'boli at home and with elders.

| # | T'boli | Spanish (T'bolized) |
|---|---|---|
| 1 | Sotu | Unu |
| 2 | Lwu | Dos |
| 3 | Tlu | Trés |
| 4 | Fat | Kwatru |
| 5 | Limu | Singku |
| 6 | Nem | Says |
| 7 | Hitu | Siti |
| 8 | Wolu | Utsu |
| 9 | Syóm | Mibi |
| 10 | Sfolò | Dyés (Jés) |
| 11 | Sfolò sotu | Unsi |
| 12 | Sfolò lwu | Dusi |
| 13 | Sfolò tlu | Trisi |
| 14 | Sfolò fat | Katorsi |
| 15 | Sfolò limu | Kinsi |
| 16 | Sfolò nem | Disi Says |
| 17 | Sfolò hitu | Disi Siti |
| 18 | Sfolò wolu | Disi Utsu |
| 19 | Sfolò syóm | Disi Mibi |
| 20 | Lwu folò | Baynti |
| 30 | Tlu folò | Traynta |
| 40 | Fat folò | Kwarinta |
| 50 | Limu folò | Singkwinta |
| 60 | Nem folò | Saysinta |
| 70 | Hitu folò | Sésinta |
| 80 | Wolu folò | Otsinta |
| 90 | Syóm folò | Numbinta |
| 100 | Lmatu (Sotu latu) | Syén |
| 200 | Lwu latu | |
| 1,000 | Lmibu (Sotu libu) | |

- **Folò**: tens. **Latu**: hundreds. **Libu**: thousands.
- **Sfolò** is sotu + folò merged, "one ten".
- **Lmatu** (one hundred) and **Lmibu** (one thousand) are the short forms of Sotu latu and Sotu libu.
- Bigger numbers stack: 21 is Lwu folò sotu, "two tens, one".
- 24 is Lwu folò fat. 217 is Lwu latu sfolò hitu. 629 is Nem latu lwu folò syóm.
- 2026 is Lwu libu lwu folò nem.

### Longer sentences

- **Là nóyóu du meken**: I don't want to eat (du points at the eating)
- **Kenbong nawahu du**: I love him/her
- **T'ngónu du**: I know it
- **Nóyóu meken du, kaye bitil**: I want to eat it because I'm hungry
- **Kmoen se du?**: How is he/she?
- **Kenbong nawahu kem kuyingu. Nóyóu wong htò. Nóyóu meken, okóm là t'ngónu du bon kenu ni hlafus ni. Omin bitil le kem kuyingu, skél béléu.**: I love my cats. I like jumping spiders. I like to eat, but I don't know what to eat this morning. Also, my cats are hungry, like me.
- **Nehu henken kem wongu anay. Ominu meken sdo(u), bitile. Kehegdemu du bitil le skul kem wongu**: I will feed my spiders first. And I will eat too, I'm hungry. I think my spiders are hungry too
- **Ni halay ni lwu libu lwu folò nem, omin hanà là deng t'ngónu du bon (tô) nmou**: This year is 2026, and I still don't know what to do. Also: ...omin hanà là deng t'ngónu du se tô nmou / ...du se bon tô nmou
- **Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying?**: What if I cook 1,936 fish and feed them to my 127 cats?
- **Haya, nehe gów bê él, mebel utón. Nehe tmógó, kenu lu. Lwu folò fat utón lnóngón.**: Tomorrow I will go to the water and find fish. I will cook and eat them. 24 fish are needed.
- **Làe hlós meken se. Kay wen tau lengel tungô laan lmisa. Omin likoe dé kô gungolen o Pangu. Ominen bud hlóbô mton do meken.**: I didn't go on to eat, because there's a drunk guy sleeping under the table. And I'm afraid my dad will scold me. He'll get mad again if he sees me eating.
- **Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng**: I don't want to be skinny, so I'll take my vitamins later
- **Là nóyóu du ke-delete du**: I don't want to delete it
- **Là tnoloku kóm anìu baling sidek. Olohu hetngón du béléem bê du gôem esolu.**: I don't teach you to become bad. I just want you to know where you're supposed to be going.
- **Là t'ngónu du ke hyu ktolok le do. Tadu se duen mulék bê gónô anì tmógó msó béléu? Lnóngónu meken wen para bê kem lomi hnagì.**: I don't know if I'm being taught well for this learning. Who else is going to get home to cook rice for me? I need to eat more for new lessons.
- **Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged?**: Do you believe eating red-eye fish together and sucking their meat can help us grow muscle?
- **Nuclear bom tey sidek ni. Nuclear clock làen sidek se, tey hyu.**: The nuclear bomb is very bad. The nuclear clock isn't bad, it's very good.
- **Nuclear bomb skas (le), baling ofi bong. Yóm nuclear clock làen skas se, olohen laser udì.**: The nuclear bomb breaks them, and they become a big fire. But the nuclear clock doesn't break, it's just a small laser.
- **Bon kmou du se ni bê kem nem latu lwu folò syóm utón bê él ni? Tnógóu lu kô ke senlahu lu? Là t'ngónu du. T'ngónem kô kmò khulék kul bê gónô le ni? Là nóyóu du kehe lehen, okóm tey nóyóu gemwa unged wen bê todol bulón. Haya, ne blay lu bê kem twolihu, mowil o deng tnógó. Okóm tey tilob ni kem utón ni. Nehe mebel lomi utón bê lwu bulón.**: What am I supposed to do with these 629 fish in the water? Should I cook them or fry them? I don't know. Do you know how to get them back to their home? I don't want to be skinny, but I really want to gain more muscle for next month. By tomorrow, I will give them to my siblings alive or already cooked. But these fish are so beautiful. I will find new fish in 2 months.
- **Là! Bê kuy gów bê yó. Tey sidek lan yó mulék bê gónô. Lnóngón kuy kebel kuy dumu lan. Kmò kehdem ye du se?**: No! Don't go there. That is a very bad way to get back home. We need to find another way. What do you (all) think?
- **Nehe meken lwu latu sfolò hitu utón bê bulón ni. Anì(e) gemwa [lówóhu] unged wen. Là nóyóu du kehe bud lehen.**: I will eat 217 fish this month, so I can get more muscle. I don't want to be skinny anymore.
- **Miles's first T'boli essay (scored 9.8/10)**: Hyu kifu. Boluyu Miles. Ekimel, là t'ngónu du T'boli. Kdaw ni, teye hligal, kaye deng t'ngónu ne kmò kmon du kmoem se du, bon boluyem, tadu yó, kilón, moen. Deng t'ngónu ne kmò kmon du lwu libu lwu folò nem. Là e likô bê wong, okóm teye likô bê nem latu lwu folò syóm utón. Haya, nehe mebel lomi kem udél. Slamat béléem. Téyu the best. Kmò kehdemem du se? Tahu kô? (Good evening. My name is Miles. Yesterday I didn't know T'boli. Today I'm very happy, because now I know how to say how are you, what's your name, who's that, when, and why. Now I know how to say 2026. I'm not scared of spiders, but I'm very scared of 629 fish. Tomorrow I'll find new words. Thank you. You're the best. What do you think? Is it right?)

## Bible verses

From Udél Dwata: Gna Kesfasad ne Lomi Kesfasad, the T'boli Bible (old covenant and new covenant).

### John 3:16

Tey alì kbong nawa Dwata kul yó kem tau bè klamangen benwu, gloken tódô hamà klowil yóm Ngaen tek sotu, anì yó, kihu tau hemtahu béléen là gógówen elem hatay, okóm gutahen yóm klowil laen dù sónen.

In English: "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life." Words from the lessons that appear in it: kbong nawa (love), kem tau (people), Ngaen tek sotu (his only child), hemtahu (believing), là gógówen elem hatay (he won't be lost to death).

### Proverbs 3:5

Hol hewótem lem but blututem yóm ksaligem ke Dwata, béem abay genléd nawa yóm kóm khulung temnef.

In English: "Trust in the Lord with all your heart, and lean not on your own understanding." Words from the lessons that appear in it: lem (inside), blutut (belly), ksaligem (your trust), ke Dwata (to God), genléd nawa (rely on), kóm (your).

## A bedtime story: the spider

A short story in T'boli, with corrections applied.

- **Kdaw ni, wen wong nô bê ta lmisa.**: Today, there's a spider on top of the table.
- **Ngà laen likò bê wong.**: The child isn't scared of the spider.
- **Góem gów du?**: Where are you going?
- **Teye bitil.**: I'm very hungry.
- **Kehu bitil, ni ken para béléem.**: If you're hungry, here's food for you.
- **Slamat béléem! Besowe ne.**: Thank you! I'm full now.
- **Moo ktuk wong. Tluyab.**: The spider is sleepy. Yawn.
- **Bulón nô bê ta.**: The moon is up above.
- **Tungôu ne, wong. Hyu kifu. Kenbong nawahu u.**: Sleep now, spider. Good night. I love you.
- **Hyu kifu béléem skóm.**: Good night to you too.

Notes from the corrections: wen is "there is / there was", used whenever something shows up in a story; ngà drops its accent when an ending attaches (ngaen); ni here means "here's".
