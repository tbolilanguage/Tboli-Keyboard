import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useIme, s as cn } from "./router-DW5w4w-K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ime-field-WzsZTvOs.js
var import_jsx_runtime = require_jsx_runtime();
function ImeInput({ className, onFocus, onBlur, ...props }) {
	const ime = useIme();
	const useBoard = ime.installed && ime.selected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		inputMode: useBoard ? "none" : props.inputMode,
		autoComplete: useBoard ? "off" : props.autoComplete,
		autoCorrect: useBoard ? "off" : props.autoCorrect,
		spellCheck: useBoard ? false : props.spellCheck,
		onFocus: (e) => {
			if (useBoard) ime.register(e.currentTarget);
			onFocus?.(e);
		},
		onBlur: (e) => {
			if (useBoard) ime.hide();
			onBlur?.(e);
		},
		className: cn("h-11 w-full rounded-md bg-surface-2 px-3 text-base text-fg outline-none placeholder:text-subtle focus:shadow-focus", className)
	});
}
function ImeTextarea({ className, onFocus, onBlur, ...props }) {
	const ime = useIme();
	const useBoard = ime.installed && ime.selected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		inputMode: useBoard ? "none" : props.inputMode,
		autoComplete: useBoard ? "off" : props.autoComplete,
		spellCheck: useBoard ? false : props.spellCheck,
		onFocus: (e) => {
			if (useBoard) ime.register(e.currentTarget);
			onFocus?.(e);
		},
		onBlur: (e) => {
			if (useBoard) ime.hide();
			onBlur?.(e);
		},
		className: cn("min-h-32 w-full resize-y rounded-lg bg-surface-2 px-3.5 py-3 font-display text-xl leading-relaxed text-fg outline-none placeholder:text-subtle focus:shadow-focus", className)
	});
}
//#endregion
export { ImeTextarea as n, ImeInput as t };
