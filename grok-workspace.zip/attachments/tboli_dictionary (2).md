# T'boli to English dictionary

A dictionary and grammar guide for T'boli, the language of the T'boli people of South Cotabato, Mindanao. Every word, rule and example here was taught by native speaker Deymar, one lesson at a time, and sorted from the original lesson log into dictionary form. Nothing has been added from outside sources except the two Bible verses, which come from the T'boli Bible.

## About Deymar

This dictionary is credited to Deymar, a native T'boli and native speaker of the language. Every word, rule and example in it comes from him.

He started it so future generations of T'boli can use it and translate between English and T'boli. As the modern world moves in, he doesn't want the T'boli language to fade or disappear, so he's writing it down while it's still spoken every day.

Outside T'boli, Deymar studies other languages for fun, including Spanish, Arabic, Bangla, Hindi, and Malayalam.

### In T'boli

- **Deymar yó tau T'boli, omin udél T'boli udélen.** Deymar is a T'boli person, and T'boli is his language.
- **Kdéen udél ni, tnolok Deymar.** Every word here was taught by Deymar.
- **Nóyóen anì kem ngà T'boli kdeng translate-le udél English bê udél T'boli.** He wants T'boli children in the future to translate English into T'boli.
- **Là nóyóen du ke lana udél T'boli bê benwu ni.** He doesn't want the T'boli language to disappear from this world.
- **Dumu udél gel hnagì Deymar: Spanish, Arabic, Bangla, Hindi, omin Malayalam, fun néen.** Other languages Deymar studies: Spanish, Arabic, Bangla, Hindi, and Malayalam, for fun.

### In Bible T'boli (graded perfect by Deymar, Oct 13)

- **Deymar ni, sotu tau T'boli, ne yóm udél T'boli yó, udélen.** This Deymar is a T'boli person, and the T'boli language is his language.
- **Yó kem kdéen udél bè ni, tnolok Deymar.** All the words here were taught by Deymar.
- **Nóyóen anì yó kem ngà T'boli tmulón yóm lan yó kem udél English bè udél T'boli.** He wants the T'boli children to tell the meaning of English words in T'boli.
- **Abay se là nóyóen du ke lana yóm udél T'boli bè klamangen benwu.** Because he does not want the T'boli language to disappear from all the world.
- **Tódô hnagìen snéen yó kem dumu udél: udél Kestilà, Arabic, Bangla, Hindi, ne Malayalam, abay se kehligalen.** He also studies other languages: Spanish, Arabic, Bangla, Hindi and Malayalam, because they are his joy.

### In traditional T'boli (graded perfect by Deymar, Oct 13)

- **Deymar tau T'boli, udél T'boli udélen.** Deymar is a T'boli person; T'boli is his language.
- **Kdéen udél ni, tnolok Deymar.** Every word here, Deymar taught.
- **Nóyóen anì kem ngà T'boli tmulón lan udél English bê udél T'boli kdeng.** He wants T'boli kids to tell the meaning of English in T'boli, later on.
- **Là nóyóen ke lana udél T'boli bê benwu ni.** He doesn't want T'boli gone from this world.
- **Dumu udél hnagì Deymar: udél Kestilà, Arabic, Bangla, Hindi, Malayalam, kay hligal du.** Other languages Deymar learns: Spanish, Arabic, Bangla, Hindi, Malayalam, because they make him happy.

Note: **udél Kestilà** is Spanish, from Romans 15:24, where Spain is **Spén** and the Spanish people are **Kestilà** (from Castilla). Bible style adds yóm, yó kem, Tódô and abay se; traditional style drops English borrowings like translate and fun.

How to use it: the grammar section explains how words are built, the dictionary lists T'boli words A to Z with every form under its root, the English index lets you look a word up from English, and the phrase section collects ready sentences by topic.

## Translation guide for AI (read this first)

This section is for any AI or person using this dictionary to translate English into T'boli. Everything below it is the full word list and the grammar it comes from.

### Instructions

- Translate the meaning, not word by word. Build each sentence from the rules below and copy the patterns in the example pairs.
- Use only the words in this dictionary. If a word you need isn't here, keep it in English inside [brackets] and say it's missing. Don't guess, and don't swap in Tagalog or another language unless this dictionary lists it as a borrowing.
- English words can be borrowed with T'boli endings (rule 12).
- If a sentence could mean two things, give both and say which situation each one fits.
- Keep the spelling and accent marks exactly as written here. The accents change the meaning (hnóbô is getting angry, hnobò is bladder).

### Core rules

1. **Word order.** The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now). Whatever comes first is the focus: Miles ninumen él (Miles drank the water), Él ninum Miles (the water Miles drank).
2. **Who: endings on the word.** I: -u or -e (Kenu, I eat; Nóyóu, I want; Bitile, I'm hungry; Denge, I'm done). You (one): -em, sometimes -u (Kenem, you eat; Bitilu, you're hungry). Formal you: -i (Dengi). He/she/it: -en (Kenen). They: -le. You all: -ye. We all: -kuy. You and me: -te. We but not you: me. Since -u can mean I or you, add the standalone word when it matters.
3. **Standalone pronouns.** O/Ou (me), U/Uu (you), Yu (you all), Du (him/her/it), Lu (them), Tu (us), Te (you and me), Mi (us, not you). Put them after the action to make it clear: Minume o él (I'm drinking water), Minume mi él (we're drinking water).
4. **No word for "is" when describing.** Coffee-hu kinì (my coffee is hot). Se is used for how someone is: Kmoem se du? (how are you?). Nô is the "is" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table).
5. **Very.** Tey/Téy takes the person ending: Teye bitil (I'm very hungry), Téyu temngón (you're very smart). Alì is extremely.
6. **Action shapes on one root.** Root alone is general (ken, eat). M inside or me- in front is happening or about to happen (meken, kmulón, tmolok). N inside is being done or ongoing with an ending (tnolok, t'nilówem). G- in front is by accident (gkulóne, I accidentally got rained on). S- in front is each other (ston, see each other), and sense- is together and still going (senseken). H- or het- in front is make it or let someone (hkinì, make hot; hetnaw, make cold). Hef- is asking someone to do it with your own thing (hefkodok).
7. **Time.** Deng is done or already: Deng kenu (I ate), Denge meken (I already ate). Ne is now, already, or about to: Ne meken dé (I'm going to eat). Nehe (I will), Nehi (you will), Nele (they will). Bud in front is again: Bud kmulón (it'll rain again). Kdeng at the end is later. He at the end adds "yet" or "again, hopefully". Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday). Leave out kdeng when another word already says when.
8. **Not.** Là with the person: Làe or Là e (I'm not), Làu (you're not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't). Là e deng meken he (I haven't eaten yet). Bê is don't, or refusing: Bê tagad tungô he (don't sleep yet).
9. **Questions.** The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón ke (when), Moen ke (why). For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?).
10. **Owning.** The owner word goes before the thing: do (mine), kóm (yours), kun (his/hers/its), kul (theirs), kut (ours, you and me), kum (ours, 3 or more): Yó kóm ken, ni do ken (that's your food, this is my food). Dou dumu sbót (my friend). Body parts take -hu for my: matahu (my eyes), kuluhu (my head).
11. **Places.** Bê covers in, on, at, to, under and beside. Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Bê also goes before a day: bê Byérnis (on Friday).
12. **Borrowed English words.** The ending copies the word's last consonant sound: phone-nu (my phone), update-tu (I update), vitamin-nu (my vitamin). A word ending in a vowel sound takes an h: coffee-hu (my coffee). Endings that start with a consonant attach as they are: movie-le (their movie). Ke- means if or for doing it: Slamat bê ke-sendem du (thanks for sending it).
13. **Joining words.** Omin (and), okóm (but), kay (because), kayà (so, that's why), anì (so that), ke or sok (if, when). Kay, ke and sok take the person ending themselves: Kaye bitil (because I'm hungry), Kehu bitil (if you're hungry), Soke bitil (when I'm hungry).
14. **Three kinds of "we".** Te is you and me, kuy is all of us, me (or mi) is us but not you. Use me when telling a story, since the listener isn't part of it.
15. **Sound rules.** An accented final vowel (silà, ngà) ends in a full stop and takes an ending with no h, losing its accent (silaem, ngaen). A plain final vowel takes h before the ending (nawa, nawahu). A separate ending word like le never merges with a full stop word: silà le, never silale.

### How a sentence breaks down

- **Hkodoke béléem itlug** (I'll boil an egg for you): hkodok (boil it) + -e (I), béléem (for you), itlug (egg)
- **Là e deng meken he** (I haven't eaten yet): là e (I'm not), deng (done), meken (eating), he (yet)
- **Kehe bitil, ne meken dé** (if I'm hungry, I'll eat): ke + -he (if I), bitil (hungry), ne meken dé (I'm going to eat)
- **Haya bud te ston he** (see you again tomorrow, hopefully): haya (tomorrow), bud (again), te (you and me), ston (see each other), he (hopefully)

### Example pairs

**Greetings and small talk**

- Good morning: **Hyu hlafus**
- Good morning to you too: **Hyu hlafus béléem skóm**
- Good night: **Hyu kifu**
- What's up?: **Syó du?**
- How are you?: **Kmoem se du?**
- I'm fine: **Ok ye néen**
- And you?: **Kóm du?**
- What's your name?: **Bon boluyem (du)?**
- My name is Miles: **Boluyu Miles**
- What are you doing?: **Bon nmoem (du)?**
- Nothing, just sitting: **Anduen. Len myón.**
- Where are you from?: **Bê du gôem lemwót du?**
- Where are you going?: **Góem gów (du)?**
- Is that right?: **Tahu kô?**
- Yes, that's true: **Ell, tahu yó**
- Thank you so much: **Bong slamat**
- Thanks to you: **Slamat béléem**
- You're welcome: **Ominem dé**
- Thanks for teaching me: **Slamat bê ke-teachem do**
- Wait a bit: **Tagad he**
- We'll see each other later: **Bud te ston kdeng**

**Feelings**

- I'm very hungry. And you?: **Teye bitil. Kóm du?**
- I'm very happy: **Teye hligal**
- I'm exhausted: **Teye kapuy**
- I'm sleepy: **Moo ktuku**
- I'm full now: **Besowe ne**
- I'm thirsty, so I'm drinking water: **Meenge, kayà minume o él**
- I'm not scared of spiders: **Là e likô bê wong**
- I'm just joking: **Olohu hlowon néen**
- I don't want to sleep because I'm hungry: **Là nóyóu du tungô, kaye bitil** (du points to the subject, the sleeping)

**Food**

- Let's eat: **Meken kuy**
- If you're hungry, eat: **Kehu bitil, mekenu**
- I ate: **Deng kenu**
- I already ate: **Denge meken**
- I'll eat first: **Ne meken dé anay**
- When I'm hungry, I fry leftover rice: **Soke bitil, senlahu ken tnaw**
- This food is delicious: **Téy mi ken ni**
- That's your food, this is my food: **Yó kóm ken, ni do ken**
- The rice is already cooked: **Deng tógó ne ken**
- My coffee is hot: **Coffee-hu kinì**
- My coffee is on the table: **Coffee-hu nô bê ta lmisa**
- I'm full now. That fish was really tasty!: **Besowe ne. Utón nìen, téy mnóm!**

**Weather and time**

- Is it raining?: **Kmulón ni?**
- It's raining now. You'll be cold: **Kmulón ne. Tnawu yó.**
- Tomorrow it'll rain again: **Haya, bud kmulón**
- Yesterday was extremely hot, but today is very cold: **Ekimel alì kinì, okóm kdaw ni téy tnaw**
- Next week, on Friday, I'll go to the water: **Todol fedyan, bê Byérnis, nehe gów bê él.**
- What's the date today?: **Bon kdaw du ni?**

**People**

- You are my friend: **Uu dou dumu sbót**
- I'm your friend: **Ou kóm dumu sbót**
- I like you: **Nóyóu u**
- I love you: **Kenbong nawahu u**
- Who's that?: **Tadu yó?**
- That's him / that's us / that's them: **Du yó / Tu yó / Lu yó**
- It's our turn: **Tu ne ni**
- It's not me: **Là o du se**
- I didn't do that: **Là o du mò du yó**
- When will you get back home?: **Kilón ke kulékem bê gónô?**
- Why aren't you sleepy yet?: **Moen ke là u gtungô du?**
- Are you going to sleep?: **Tungôu ne yó?**
- Are you resting?: **Hegnô u?**
- I just woke up: **Lomihe btik** (right now). **Lomi kebtiku**: I woke up a while ago
- I just woke up, so I'm not going back to sleep: **Lomi kebtiku kayà là e bud tungô ne là**
- It's time to get up (everyday): **Udas kebtik kuy ne**
- Where's my phone?: **Góen nô phone-nu (du)?**
- Today, Deymar, you taught me and I taught you. We're teaching each other: **Kdaw ni, Deymar. Tnolokem o, omin tnoloku u. Stolok te.**

## The T'boli alphabet

### Vowels and marks

A, À, E, È, É, Ê, I, Ì, O, Ò, Ó, Ô, U, Ù, and ’ (the glottal mark, as in T'boli, K'nôón)

### Letters

B, D, E, F, G, H, I, K, L, M, N, O, P, R, S, T, U, W, Y

### Borrowed words and names

- **Borrowed words keep their own spelling,** even with letters T'boli doesn't have. Péro (but, from Spanish) stays Péro, not Féro
- **Country names are written with T'boli letters**
- **Ph is always F:** Alfabét (alphabet), Farmasi (pharmacy), Filipinas (Philippines), Faro (Pharaoh), Stéfén (Stephen)
- **P in names:** traditional T'boli uses F where English has P, so older people say Fól for Paul. The Bible mostly keeps P (Pol, Pitér) because its names came through English. It goes word by word: Faris (Paris), Fkistan (Pakistan), Fortugal (Portugal), but Péru (Peru)

### Ng

Ng can be counted as its own letter or as N plus G. Both work. It's there for the sound, as in ngà and t'ngón.

## Pronunciation

### Vowels

- **E**: like the u in burn (Ken, Teye, Ell)
- **É**: like the e in egg (néen)
- **O**: like the a in law
- **Ò**: like the a in law, but cut off with a full stop
- **Ó**: like the o in obvious
- **Ô**: like the o in obvious, but cut off with a full stop
- **An accent on a final vowel** (silà, ngà): the word ends in a full stop (see the sound rules)

### Words that are easy to get wrong

- **Ell** (yes): said like "Ull", the E is the u in burn
- **Fun** (owner): the u sounds like the u in uniform, not like "fan"
- **Ken** (food): the E is the u in burn, not like Kentucky
- **Ken tnaw**: Ken with the u in burn, tnaw like "T'NOW" (the ow in now, with the W said at the end like the w in win)
- **Accents change meaning.** Hnóbô is getting angry, hnobò is bladder. Moen is why, Móen is short for Kmoem. Geslà is a surprise, gesla is being fried. Silà is corn, and silale would lose that meaning.
- **Msó** is the fast way to say mesó (rice).
- **Mestlu** is how maistru (teacher) is actually said.

## Grammar

### Word order

- The root word carries the meaning, and endings say who.
- The action or description usually comes first, then the person: Meken du (he's eating), Teye bitil (I'm very hungry), Kmulón ne (it's raining now).
- The main idea comes first: Meken kuy, Tahu kô ni.
- Whoever or whatever comes first is the focus. Miles ninumen él (Miles drank the water) puts Miles first. Él ninum Miles (the water being drunk by Miles) puts the water first. Él ninumen Miles means the water drank Miles, because -en makes the water the one drinking.
- Word order can change the meaning: Kmoem se du is "how are you", Kmoem du se is "what did you do".
- When "it" does something to a person, the -en ending is the "it" and the person comes after: Hetnawen u yó (it'll make you cold).
- "More" comes after the thing: unged wen, more muscle.
- A color goes before mata: utón hulô mata (red-eye fish).
- With names, the names come first, then sbót le: Miles omin Deymar sbót le (Miles and Deymar are friends).
- Ni and yó point ("this" and "that"), and kô turns a statement into a question.

### No "is" when describing

- Describing something needs no "is" at all: Coffee-hu kinì (my coffee is hot).
- **Se** is the "be" word for how someone is, and it goes in the middle: Kmoem se du? (how are you?).
- **Nô** is the "is" for where something is: Coffee-hu nô bê ta lmisa (my coffee is on the table). Without nô, Coffee-hu bê ta lmisa is just "my coffee on the table".

### Person endings

These attach to a word to say who.

- **-u**: often "you" (Gówu, you go; Tungôu, you sleep; Mekenu, you're eating or "eat!"; Bitilu, you're hungry). In some words it means "I" (Kenu, I eat; Nóyóu, I want; Tnoloku, I teach). Since -u can mean either, add the standalone word when it matters.
- **-e**: I (Bitile, I'm hungry; Denge, I'm done; Mekene, I'm eating; Teye, I'm very). Bitile can also mean "they're hungry"; Bitile lu is clearer for them.
- **-em**: you (one person) (Kenem, you eat)
- **-i**: the formal "you", more specific than -u (Dengi, you're done; Kehi, you become; Lài, you are not)
- **-en**: him, her, it (Kenen, he/she/it eats)
- **-le**: them, not including the person you're talking to (Kenle, they eat)
- **-ye**: you all, the people you're talking to, speaker not included (Kenye)
- **-kuy**: we, us, 3 or more people (Kenkuy)
- **-te**: us two, just you and me (Kente)
- **me**: we, without the person you're talking to (Deng me, Kmò me du)
- **-hu**: my, on words that end in a plain vowel and on body parts (nawahu, matahu, kuluhu, lówóhu, coffee-hu). Tnoloku takes -u, not -hu.

The ending can jump forward to an earlier word: Kaye bitil (because I'm hungry) instead of Kay bitile. Same with Anìe (so I), and Kehu bitil (if you're hungry) instead of Ke bitilu.

When an ending could mean two people (minume, I or we), add the standalone word: minume o (I), minume mi (we).

#### Second set, with Tey and Meken

- **Teye**: I am very
- **Téyu**: you are very
- **Téy-**: he/she/it is very
- **Téyle**: they are very
- **Téyye**: you all are very
- **Téykuy**: we are very
- **Téyte**: we (you and I) are very
- **Mekene**: I am eating
- **Mekenu**: you are eating, also "eat!" when telling someone to eat
- **Meken du**: he/she/it is eating

### Standalone pronouns

- **O / Ou**: me, I. Ou is specifically me, pointing at yourself.
- **U / Uu**: you (one person). Uu is specifically you.
- **Yu**: you (2 or more people)
- **Du**: him, her, it (used everywhere for he/she/it)
- **Lu**: them
- **Tu**: us
- **Te**: me and you
- **Mi**: us, I'm included but not the person I'm talking to
- **Do**: me, when I'm the one something happens to (from dou): Ktolok le do (they taught me)

With yó: **O yó** (that's me), **Ou yó** (that's me, specifically me), **U yó** (that's you), **Uu yó** (that's you, specifically you), **Du yó** (that's him), **Tu yó** (that's us), **Lu yó** (that's them).

### Three kinds of "we"

- **Te**: you and me (Stolok te, we teach each other, like Tagalog "tayo")
- **Kuy**: all of us, 3 or more
- **Me / Mi**: us but not you (Stolok me, like Tagalog "kami"; Mi kem mag-cousin, us cousins, not counting you)

Use me when telling a story, since the listener isn't part of it: Tmógó me utón (we're cooking fish, not you). Never tmógó mi utón. Me works everywhere kuy does: Kmò me du.

### Owning

The owner word goes before the thing: Yó kóm ken, ni do ken (that's your food, this is my food).

- **Do**: mine
- **Dou**: I own, my (Uu dou dumu sbót, you are my friend)
- **Kóm**: you own, yours
- **Kun**: he/she/it owns
- **Kul**: they own, theirs
- **Kum**: we (3 or more) own
- **Kut**: we (me and you) own, ours
- **Do u ni**: this is mine

Body parts and vowel-final words take -hu for "my": kuluhu (my head), matahu (my eyes), lówóhu (my body), nawahu (my breath).

Dumuhu sbót and dou dumu sbót both mean "my friend". Use dumuhu sbót when telling someone else about the friendship (he's my friend). Use dou dumu sbót when talking to the friend directly (Uu dou dumu sbót, you're my friend).

### Pointing words

- **Ni**: it, this; here's (Ni ken para béléem, here's food for you). At the end of a sentence it points to something right here. Ni is also right now, while ne is already.
- **Yó**: that
- **Nìen**: this one, it (ni plus -en, pointing at the subject): Utón nìen, téy mnóm!
- **Yóm**: the
- **Tu**: far, there (see the dictionary entry)

### Action shapes

One root changes shape to show how an action happens.

- **Root alone**: general (ken, eat; tolok, teach; kodok, boil)
- **M inside, or me- in front**: happening or about to happen, like "-ing" (meken, kmulón, tmolok, lmobun, kminì, kmodok)
- **N inside**: being done, already done, or ongoing (tnolok, being taught; nsef, sucked; t'nilówem). With person endings the m becomes n (t'milów, t'nilówem). Kenbong (with -n-) is already happening, continuously, while kbong is still going.
- **Suggesting vs commanding**: -u suggests (Mekenu, go ahead and eat). -em with kun commands (Snolokem du kun, flash him!)
- **Careful with bê u**: it means "don't you," not "onto you." Onto you is ebéléem
- **Hyphen rule**: when n meets g across parts of a word, write a hyphen (Hen-ganagem) so it's said n + g, not the ng in mango
- **G- in front**: by accident, without meaning it (gkulóne, I accidentally got rained on; gtolok, taught unexpectedly; gwa, accidentally taken; gsalig, unintentionally trust; gtungô, sleepy)
- **S- in front**: each other (ston, see each other; stolok, teach each other; swa, taking from each other; stóbóng, helping each other)
- **Doubled first letter**: both or together doing it (ssef, both sucking; kken, ate together)
- **Sense- in front**: together and still going (senseken, eating together; sensesef). It doesn't work on every verb: stowok, not sensetowok.
- **H- or het- in front**: make it, or let someone else do it (hkinì, make hot; hetnaw, make cold; hsef, let someone suck; hsalig, let something trust; hetngón, let someone know). Add the person ending for who does it: Hkinìem ken (you heat the food), Hkinìu ken (I heat the food).
- **Hef- in front**: asking someone to do it with your own thing (hefkodok)
- **K- form**: already carries "will" (kulékem, you'll come back)

Roots that show the whole system:

- **Take**: ma/mwa (take), nwa (taken), gwa (accidentally taken), swa (taking from each other). N- is done, g- is by accident, s- is each other.
- **Boil**: kodok (boil), kmodok (boiling), hkodok (asking for it to be boiled; hkodoku, I'm boiling it), henkodok (being boiled), hefkodok (asking someone to boil something with your item)
- **Teach**: tolok, tmolok, tnolok, gtolok, htolok, stolok

### Time words

Time is shown with small words around the verb, not by changing the verb itself.

- **Deng**: done, already. Deng kenu (I ate), Denge meken (I already ate).
- **Ne**: now, already, a change happening, about to (like Tagalog "na"). Ne meken dé (I'm going to eat).
- **Nehe**: I will, for something you do yourself, with no object (Nehe dyó dé, Nehe bemli anay). **Nehu**: I will do something to something (Nehu bentik u anay, Nehu henken onuku haya), or telling someone else to do it (Nehu meken dé, you eat first). **Nehi**: you will. **Nele**: they will.
- **Bud**: again, in front, for something that will happen. Bud kmulón (it'll rain again).
- **Ne là**: anymore, at the end of a sentence (là e bud tungô ne là, I'm not going back to sleep anymore). At the start, it means "and not, not even": Ton me du eginu okóm làen temngel béléme. Ne làen se mudél béléme. (We saw him earlier but he didn't look at us. And he didn't even talk to us.)
- **Se after là**: "even" (Ne làen se mudél béléme, and he didn't even talk to us)
- **Là + endings**: là e (I don't), làu (you don't), làen (he/she doesn't). Ston te eginu okóm làu temngel béléu: we saw each other earlier but you didn't look at me. Béléu: to me
- **Kdeng**: later, at the end of a sentence. On its own at the start it means "wait!"
- **He**: at the end, adds "yet" or "again, hopefully". Là e deng meken he (I haven't eaten yet). Bud te ston he (we'll see each other again, hopefully).
- Leave out kdeng when another word already says when: Haya bud kmulón, not Haya bud kmulón kdeng.
- **Days**: Kdaw ni (today), Haya (tomorrow), Ekimel (yesterday), Ekuloy (the day before yesterday), Sotu ni (the day after tomorrow).
- **Todol** is next and **gna** is past: todol bulón (next month), gna halay (last year).
- Time words come from nature: kdaw is sun and day, bulón is moon and month, halay is the rice plant and year.

### Not

- **Là** with the person: Làe or Là e (I'm not), Làu or Là u (you're not), Lài (you, one specific person, are not), Làen (he/she/it isn't), Là le (they aren't), Là te (you and I aren't), Là ye (you all aren't), Là kuy (we all aren't), Là me (we aren't, not counting you).
- Là e deng meken he: I haven't eaten yet.
- **Bê** is don't, or refusing: Bê tagad tungô he (don't sleep yet). Bê kuy gów bê yó (don't go there).

### Questions

- The question word goes first: Bon (what), Kmò (how), Nô (where), Góem (where to), Tadu (who), Kilón ke (when), Moen ke (why).
- For a yes or no question, add kô: Tahu kô? (is that right?), Downloadem kô? (would you download it?).
- Ke always comes after kilón (when) and moen (why).
- Moen (why) is its own word, not Móen (short for Kmoem).
- Use Kmoem when you're asking someone directly, Kmoen when it's indirect.
- Kô ke offers a choice: Mekenu silà kô ke ken? (are you eating corn or rice?)

### Places

- **Bê** covers every location: on, in, at, to, above, under, beside. The context tells you which.
- Add a position word for the exact spot: bê ta (on top of), bê laan (underneath), bê lem (inside), bê lohok (beside). Kuying bê ta lmisa (the cat is on the table).
- Bê also goes in front of a day: bê Byérnis (on Friday).
- **Nô** is the "is" for where something is.

### Sound rules
- **S- + h becomes sf-**: the h turns into f after the "each other" s-, so it doesn't sound like sh (hangat → sfangat, not shangat)

- **The -h rule**: when a word ends in a plain vowel, add h before the ending: nawa becomes nawahu (my breath), coffee becomes coffee-hu.
- **Full stop vowels**: an accent on a final vowel (silà, ngà) means a full stop at the end of the word, so it takes an ending without h, and the accent goes away when the ending is attached: silà, silaem (your corn); ngà, ngaen (his/her child).
- **Separate ending words never merge**: a separate ending word like le never merges with a full stop word. Silà le, never silale, because losing the accent takes away the word's meaning.

### Joining words

- **Omin**: and
- **Okóm**: but (Okóm close, but close)
- **Péro**: but (borrowed from Spanish)
- **Kay**: because. Takes the person ending: Kaye bitil (because I'm hungry).
- **Kayà**: so, that's why (borrowed from Tagalog)
- **Anì**: so, so that. Anìe (so I).
- **Ke / Sok**: if, when. Both take the person ending: Kehu bitil (if you're hungry), Soke bitil (when I'm hungry).
- **Dé kô**: maybe, perhaps, I guess so; if (something happens), depending on context
- **O**: or (borrowed from English)
- **Kô ke**: or, when suggesting someone pick one
- **Ewen**: so
- **Galì**: oh, so that's why

### Borrowed words

English words follow their sound, not their spelling. The ending copies the last consonant sound of the word, so update (ends in a t sound) becomes update-tu, update-tem, update-ten, and phone becomes phone-nu, not phoneu. When the spelling already ends in that consonant, the ending can attach directly or with a doubled letter and hyphen. The hyphen keeps the English word recognizable.

- **Chatu / Chat-tu**: I chat
- **Vitaminu / Vitamin-nu**: my vitamin
- **Phone-nu**: my phone
- **Slippersu**: my slippers
- **Update-tu**: I update. **Ke-update tu** also works, with the ending standing alone. **Update-le**: they update (endings that start with a consonant attach as they are).
- **Coffee-hu**: my coffee (words that really end in a vowel sound take h)
- **Movie-le**: their movie (consonant endings need no h)
- **Downloadem**: you download. **Downloaden**: he/she/it downloads.
- **Ke-**: if, or for doing it: Ke-savem (if you save, for saving), Ke-downloadem (if you download).

Other borrowings:

- **From Spanish**: the days of the week, the trading numbers, para (for), péro (but), maistru/mestlu (teacher)
- **From Tagalog**: kayà (so, that's why), kailangan (need)
- **From Hiligaynon**: anay (first, for now), aslum (sour), kahang (spicy)
- **From English**: o (or), tisting (tasting), and any English word with T'boli endings
- Akad (Sunday) may come from Malay or Arabic "Ahad" instead of Spanish.

### Ke- after kilón and tey
- After **kilón** (when) and **tey** (very), the m-form of an action becomes a **ke-** form: kmóót turns into kekóót, meken turns into keken, kbong turns into kekbong.
  - Kilón kekóót mósól du? When does the rooster crow?
  - Kilón kekenen du? When will he eat?
  - Kilón kekenem du? When will you eat? (du goes at the end for the subject)
  - Tey kekbong nawahu du ohu. I really love dogs.

### Ke, bê and para bê

- **Ke**: to, for, or, and possession. Ke Dwata: to God, or God's. Ke Dwata yó: that's God's. Ke Miles: or Miles, Miles' belongings, or for Miles.
- **Bê**: to. Bê Miles: to Miles.
- **Para bê**: for something or someone, being given to them. Ken para bê kem ngà: food for the children. Ke is for when it belongs to them.

## Dictionary: T'boli to English

Words are sorted A to Z, ignoring apostrophes and accent marks. Each root is one entry, with its forms listed under it. Borrowed words are marked.

### A

- **abal**: shoulder
- **adat**: attitude, personality
  - Madat: respect (kóyô me ke kdéen tau hol madat yóm kóm boluy, we want everyone to respect your name, Matthew 6:9)
  - Example: Nehu madat ke Mà (I also respect Father)
  - Nadat: respected
  - Example: Nadaten lu kem tau (he respects the people)
  - Example: Madat du bê kem tau (he shows respect to the people)
  - Example: Nadatu du (I respected him)
  - Example: Tey nadat yóm boluyem (your name is very respected)
  - Example: Kóyô me ke kdéen tau madat ke Dwata (we want everyone to respect God)
- **akad**: Sunday (may come from Malay or Arabic "Ahad")
- **alì**: extremely
  - Alì kinì: extremely hot
  - Example: Ekimel alì kinì, okóm kdaw ni téy tnaw (yesterday was extremely hot, but today is very cold)
- **amil**: testicles
- **anay**: first, for now (borrowed from Hiligaynon, same as Tagalog "muna")
  - Example: Ne meken dé anay (I'll eat first)
- **andù**: no one (short for làen dù)
- **anduen**: nothing
  - Example: Anduen. Len myón. (nothing, just sitting)
- **angkel**: uncle (borrowed from English)
- **anì**: so, so that
  - Anìe: so I (the ending jumps onto anì)
  - Example: Kailanganu mekay ken. Anìe meken kdeng. (I need to cook rice so I can eat later)
  - Example: Anì le sgeng tmowok (so they grow together)
- **anti**: aunt (borrowed from English)
- **aslum**: sour (borrowed from Hiligaynon, used to make it clear something is sour and not salty)
  - Example: Téy aslum sinigang nìen, okóm téy mnóm (this sinigang is very sour, but tasty)

### B

- **bak**: mouth, opening (baken, his mouth)
- **bak bengaw**: window, the traditional word: the hole or entry in the wall
- **bak tikeb**: door
- **baling**: become
  - Example: Nuclear bomb skas (le), baling ofi bong (the nuclear bomb breaks them, and they become a big fire)
- **balu**: a strand of hair; tornado
  - Mógów baluhen!: (cuss) may his/her/its cursed day come
- **bangkù**: seat, bench, chair
- **bayad**: pay (bnayadu, I pay it; gbayad, able to pay)
- **beeng**: molars, jaw (beeng le, gnashing their teeth, Acts 7:54)
- **beng**: wall, door; the general word for the cover of a house
- **benwu**: town, place, world
- **betek**: color, style, design
- **bintanà**: window (borrowed from Spanish ventana)
- **blat**: heavy (keblaten, its heaviness)
- **blawang**: mosquito
- **blihen**: its price
- **bnos**: hide something (bnosu, I hid it). Hebnos: hide yourself. Buni: hidden, secret
- **bok**: book (boku, my books)
- **bratu**: cheap (borrowed from Spanish barato)
- **btik**: wake up, get up (Lomihe btik, I just woke up)
- **btiki**: wake up! / get up! (to one person)
- **bulung**: medicine (bulung mata, eye medicine; hbulung, being treated)
- **bê**: one word for any place: to, at, on, in, under, above, below, beside. Also don't, no (refusing or declining), and of.
  - Bê ta: on top of
  - Bê laan: underneath (something)
  - Bê lem: inside
  - Bê lohok: beside
  - Bê Byérnis: on Friday (bê goes in front of a day)
  - Bê Miles: to Miles
  - (Bê) yó: there
  - Bê du?: to, on, in, or at where?
  - Bê?: where? (depends on context)
  - Skél bê: the same as, like
  - Para bê: for (see para)
  - Bê e dou tungô: I'm not sleeping yet
  - Example: Bê tagad tungô he (don't sleep yet)
  - Example: Là! Bê kuy gów bê yó. (No! Don't go there.)
- **bé**: grandmother (béhem, your grandmother, 2 Timothy 1:5)
- **béem bayà**: don't abandon, don't leave (béem bayà mi, don't leave us, Matthew 6:13)
- **beklong**: throat
- **bélé**: to, for
  - Béléu / Béléeu: for me, to me
  - Béléem: to you, for you
  - Béléen: to him/her/it
  - Béléle: to them
  - Béléye: to you all
  - Bélékuy: to all of us
  - Béléte: to just you and me
  - Para béléem: for you (para makes it clear who it's for)
  - Example: Hkodoke béléem itlug (I'll boil an egg for you)
- **bemli**: buy, buying
  - Nehe bemli anay: I will buy first
- **bentik**: wake up, wake someone up
  - Nehu bentik u anay: I will wake you up later
  - Nehu bentik dé: just get up already
- **benwu**: world, place
  - Gu laanen là deng wen benwu he: before there was any world yet, in the beginning (John 1:1)
- **besow**: full (from eating)
  - Henok / Besow: full
  - Besowe / Besow: I'm full
  - Denge besow: I'm full (I'm already full)
  - Example: Besowe ne (I'm full now)
- **bew**: carabao, water buffalo
- **bitil**: hungry
  - Bitile: I'm hungry (can also mean "they're hungry")
  - Bitile ah: I'm hungry
  - Bitilu: you're hungry
  - Bitile lu: they're hungry (clearer)
  - Example: Teye bitil. Kóm du? (I'm very hungry. And you?)
- **blay**: give
  - Ne blay: I will give
  - Example: Haya, ne blay lu bê kem twolihu (tomorrow I'll give them to my siblings)
- **blotik**: star
- **blutut**: belly, stomach; also womb
- **bnes**: grass
- **boi**: princess (a title)
- **bolok**: rotten
  - Bolok lembak!: (cuss) rotten mouth
  - Bolok sélék!: (cuss) rotten lips, side to side
  - Bolok sumóng!: (cuss) rotten lips
- **bon**: what
  - Bon nmoem (du)?: what are you doing?
  - Bon nmoem ni?: what are you doing now?
  - Bon (tô) nmou: what I do, what to do
  - Bon boluyem (du)?: what's your name?
  - Bon kdaw du ni (kdaw ni)?: what's the date today?
  - Bon kminì kóm du?: what's heating you?
  - Bon se duen hnagì te du?: what else should we learn?
- **bong**: big
  - Téy kinì bong: it's really, really hot
  - Bong slamat: thank you so much
  - Example: Kulón bong? (big rain?)
  - See also kbong
- **botò**: penis
- **boto**: dick (vulgar)
  - Sbotoen!: (cuss) his dick!
- **botu**: stone
- **boyu**: do; also a filler like Tagalog "ano" (um, you know)
  - Là boyu hu du ganì: I don't even do it
  - Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal: um, we were still walking, then we saw a snake
- **bud**: again (in front, for something that will happen)
  - Bud (ne): anymore
  - Bud te: we will (again)
  - Bud etu he: we will do it again; until then
  - Bud kmulón: it'll rain again
  - Bud moo ktuku: I'm sleepy again
  - Example: Bud te ston kdeng (we'll see each other later)
  - Example: Là nóyóu du kehe bud lehen (I don't want to be skinny anymore)
- **bukay**: white
- **bukol**: knees
- **bulók**: flower (bulók lem bnes, flowers in the grass, Luke 12:27)
- **bulón**: moon; month (like kdaw is sun and day)
  - Todol bulón: next month
  - Example: Bulón nô bê ta (the moon is up above)
- **bulul**: mountain (Bulul Ulib, Mount of Olives)
- **bungu**: fruit (kbunguhen, its fruit)
- **Byérnis**: Friday (borrowed from Spanish)

### D

- **demyol**: pull, drag
- **des kinì**: fever, literally "hot sickness" (kkinien, its heat)
- **dlag**: wild (ohu dlag, wild dogs)
- **dlag lamang**: forest (dlag, wild; lamang, wide)
- **dmilot**: draw a sword
- **dnadu**: field for planting (dnaduhen, his field)
- **do (me)** (also dou): me, for me. Nitem do kun sélfónu: carry my phone for me
- **doli beng**: the other side of the backyard
- **duktur**: doctor (borrowed)
- **dyo**: bathe (whole body)
- **dyo**: bathe (whole body)
- **dyol**: pull, drag (demyol, pulling). Dyol le ówóng bê kilil: they pulled the boat to shore
- **dé kô**: maybe, perhaps, I guess so, I think so; if (something happens), depending on context
  - Example: Omin likoe dé kô gungolen o Pangu (and I'm afraid my dad will hear me)
- **deng**: done, already
  - Denge: I'm done
  - Dengu: you're done
  - Dengi: you're done (formal)
  - Deng ye: you all are done
  - Deng le: they're all done
  - Deng kuy: we're done (including me)
  - Deng te: we're done (just you and me)
  - Deng me: we're done (me and others, not the person I'm talking to)
  - Deng (ne) du: he/she/it is done
  - Deng kenu: I ate
  - Denge meken: I already ate
  - Deng ne meken: I'm done eating
  - Deng t'ngónu ne: now I know
  - Example: Deng tógó (ne) ken / Ken, deng tógó (ne) (the rice is already cooked)
- **des**: hurt; sick
- **dilak**: tongue
  - Mfól dilak!: (cuss) thick tongue
- **dlimun**: made, created
  - Kedlimunen: what he made, his creation (John 1:3)
- **do**: mine; me, when I'm the one something happens to (from dou)
  - Do u ni: this is mine
  - Do ken: my food
  - Example: Yó kóm ken, ni do ken (that's your food, this is my food)
  - Example: Ktolok le do (they taught me)
- **dou**: I own; mine; my
  - Dou wong: (it's) my spider
  - Do wong / wongu: my spider. -u on the end is for something that belongs to you
  - Example: Uu dou dumu sbót (you are my friend)
- **doun**: leaf (dounen, its leaves)
- **du**: him, her, it (used everywhere for he/she/it); in questions like Kmoem du it means "it" or "something"; in kmon du it points to the thing being said
  - Du yó: that's him
  - Meken du: he's eating
  - Mebel du: he/she/it finds (something)
- **dumu**: other; another (sotu / dumu)
  - Dumuhu: my other
  - Dumu sbót: a friend
  - Dumuhu sbót: my friend (telling someone else)
  - Kem dumuhu sbót: my (other) friends
  - Kem dumu bots: the other bots
  - Example: Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem (other bots like ChatGPT don't understand it even when they read your lesson notes)
- **dumuhen setwoli**: relatives, kin, cousin (Colossians 4:10, Luke 1:58)
- **Dwata**: God
  - Ke Dwata: to God, or God's
  - Ke Dwata yó: that's God's
  - Udél Dwata: the T'boli Bible (see udél)

- **dyó**: swim; take a shower
  - Nehe dyó dé: I'm going to swim / take a shower
- **dê**: many (tey dê, very many; là holen wen, few)
- **dóyón**: proud
- **dù**: touch (mdù, touching; nduen, he touched it; béem ndù, don't touch)
- **dù (touch)**: touch (mdù, touching; gemdù, touch). Béem ndù sélfónu: don't touch my phone
### E

- **ebuteng**: last night
  - Henslòu mlóy ebuteng: I was running fast last night
  - Nógówu u ebuteng: I went to you last night
- **eginu**: earlier
  - Eginu hlafus: earlier this morning
  - Eginu kifu: earlier at night, last night
- **Ekimel**: yesterday
- **Ekimel kimel**: yesterday afternoon
  - Ekimel kimel téy kinì: yesterday afternoon was so hot
- **Ekuloy**: the day before yesterday
- **elaan**: down, downward
- **elem**: into, up to (elem mohin, into the sea; elem bulul, up the mountain)
- **él**: water
  - Minum él: drink water
  - Example: Haya, nehe gów bê él, mebel utón (tomorrow I will go to the water and find fish)
- **él alah**: the Allah River, in Allah Valley, what Deymar's place calls the river
- **él mlel**: river, literally flowing water
- **Ell**: yes (said like "Ull")
  - Ell, tahu yó: yes, that's true
  - Ell, tahu ni: yes, it is real
- **ene**: come
  - Ene bê ni: come here
- **esolu**: (where) will be going
  - Example: Olohu hetngón du béléem bê du gôem esolu (I just want you to know where you're supposed to be going)
- **etu**: then (sometime in the future)
  - Bud etu he: we will do it again; until then
- **ewen**: so
  - Example: T'ngónem galì ewenu se ke hentahumen udélu kô? (oh, so you'll believe anything I say, huh?)

### F

- **fak**: frog
- **fakay**: can, may; allow
  - Fakay kô?: is it allowed? can I?
  - Fakay ke: can I...
  - Fakay kô ke...?: can we / is it allowed to...? (ke is the "if" that links fakay kô to the action)
- **fan**: trap
  - Fanen: his/her/its trap
  - Example: Nmoem fanen dé (put a trap on it)
  - Gfan, hegfan, segfan (showing up) are built from this root
- **fat**: four
- **fedyan**: week
  - Todol fedyan: next week
- **filak**: money, silver
- **folò**: tens (Lwu folò, 20)
- **fun**: owner (the u like in uniform)
  - Funu: my owner
  - Funem: your owner
  - Funen: his/her/its owner
  - Funle: their owner (people not in the conversation)
  - Funye: you all's owner (speaker not included)
  - Funkuy: our owner (me and 2 or more people)
  - Funte: our owner (just me and one other person)

### G

- **gafit**: caught in the act
- **galì**: oh, so that's why (Tagalog "kaya pala")
- **ganag**: slow
  - Hen-ganagem: slow down (you). The hyphen keeps n and g apart, so it isn't read as the ng in mango
- **ganì**: even, really; backs up that something is true
  - Là t'ngónu du ganì do: I don't even know (it)
  - Là boyu hu du ganì: I don't even do it
- **gebtik**: woken up suddenly
- **gemnóm des**: being sick (desen, his sickness)
- **geta**: high, for status or the height of something (tau geta, rich person)
- **ginggung**: blue
- **glayam**: suffering (tey keglayamu, I am in anguish)
- **gotu**: nothing left, all gone (gotu le yóm ken, they left no rice)
- **gulom**: ant
- **gungol**: hear (gungolen o, he hears/heard me). Gungolen o Pangu: my dad hears/heard me. **Gegungolem o / Gel gungolem o**: you always hear me (gel = always, also shown by doubling ge-)
- **guta**: catch, get something (like fish)
- **géhél**: hurry; also soon
- **ge / gel**: always, usually; the one who does it (ge is everyday speech, gel is the Bible spelling). Dumu udél gel hnagì Deymar: other languages Deymar studies
  - Example: Gel mi coffee-hu, wen klamay nô lemmen (my coffee's always sweet, it has sugar in it)
  - Example: Ni kdaw ni tey gel tnaw (today is really, really cold)
- **gfan**: show up unexpectedly
  - Hegfan: show up intentionally, walking into the fan (trap or event) someone set, on purpose
  - Segfan: show up to each other
  - Example: Haya gfan yó du (tomorrow he will show up)
  - Built from fan (trap): gfan is getting caught by it, showing up by surprise
- **genléd**: rely
  - Genléd nawa: rely on (putting your own breath, your self, onto something)
- **geslà**: a surprise, something you didn't expect
  - Geslàu wong / Gebele wong: I stumbled on a spider
  - Not the same as gesla (no accent): (being) fried
- **gna**: first (the general word); past; old
  - Gna halay: last year
  - Gna kesfasad: old covenant
- **góem**: where? where to? (said short like this, it means "where" and stops meaning "your house")
  - Góem gów (du)?: where are you going?
  - Góen nô phone-nu (du)?: where's my phone?
- **gónô**: house; home
  - Gónôem lemwót du?: where are you from?
  - Gónôem gu du? / Gôem gu?: where did you go? where have you been? (like Tagalog "saan ka galing?")
  - Gónôem msut? / Gôem sut?: where were you born?
  - Gónóem: your house, your place
  - Gónô le: their home
  - Gónô mnô: home
  - Example: Kilón ke kulékem bê gónô? (when will you get back home?)
- **gónô fedyan**: market (the place); fedyan alone is week or market day
- **gów**: go
  - Gówu: you go
  - Nehe gów: I will go
  - Example: Bê du gôem gów du? (where are you going? the full way)
  - Example: Hene, gówu bê ni. Tungôu. (come, go here. Sleep.)
- **gwa**: get; accidentally taken (see ma)

### H

- **haha**: legs
- **halay**: year; also living rice, the rice plant
  - Gna halay: last year
- **hampang**: play, like kids playing (borrowed from Hiligaynon)
- **hangat**: wait, wait for (the subject is the one waiting)
  - Hangat ye o dé!: wait for me!
  - Hangatu kkól Yê: I'm waiting for Mother to come back
  - Tagad dé, Mà. Ne hangat ken: wait, Father. I'm still waiting for the food
- **hanà**: still
  - Hanà là deng t'ngónu du bon nmou: I still don't know what to do
  - Example: Là nóyóu du tungô, kaye (hanà) bitil (I don't want to sleep because I'm (still) hungry)
- **hatay**: death, dying
  - Là gógówen elem hatay: he won't be lost to death
- **haya**: tomorrow
  - Key haya: every day (written ket haya in Matthew 6:11)
  - Example: Haya, bud kmulón (tomorrow it'll rain again)
- **hbalù**: sell (hbaluen, he sold it)
- **he**: at the end of a sentence: yet; again, with a hope in it
  - Tagad he: wait a bit
  - Là e deng meken he: I haven't eaten yet
  - Bud te ston he: we'll see each other again, hopefully
- **hebetik**: jump up, leap to your feet
- **hedem**: think; also the closest word for bored
  - Kehedem: to think
  - Kehdem: to be thinking
  - Kmò kehdemem du se?: what do you think? (one person)
  - Kmò kehdem u du se?: what do I think?
  - Kmò kehdem ye du se?: what do you all think?
  - Kehegdemu du: I think
  - Kehegdemem du: you think
  - Kehegdem le du: they think
- **heglaan**: humble
- **heglomboy**: long robe
- **hegmón**: proud in a bad way, arrogant. Kehegmón: pride
- **hegnô**: rest, lie down
- **helek**: sand (helek bè kilil mohin, sand on the seashore)
- **hemken**: to feed (from ken)
- **hemsag**: shouted
  - Tong ye hemsag: so you guys shouted
- **hemtedeng knô**: acting righteous, fake. Tau gel hemtedeng knô: a hypocrite (Acts 23:3)
- **hemyak**: shameful
- **hendóm**: lend, let someone borrow
- **hentulón nawa**: remember (keep in mind on purpose). Gtulón bè nawa: it came back to mind
- **hitok**: muddy, mud
- **hkawang**: empty, empty-handed
- **hlifót**: pretend not to know something (in a bad way). Compare hlingu (pretend to be someone)
- **hlingu / hlingón**: pretend to be someone, disguise yourself as. Hlingu le tau hemtahu: they pretend to be believers (Galatians 2:4)
- **hmungol**: listen (hnungol ye, you all listen)
- **hmungol**: listen (hnungol, listen to it). Hnungol ye o dé: listen to me, all of you
- **hnas**: opened up, uncovered
- **hnifót**: forgive (hnifótem, you forgive) (Matthew 6:12)
- **hnifótem du kun**: forgive him, please
- **hnifótem o**: sorry, forgive me (the everyday apology)
- **hnolo**: oil
- **htò**: jumping, jump, jumped (same form for now and past)
  - Wong htò / Htò wong: the spider is jumping; the spider jumped; jumping spider
  - Wót wong htò: the spider keeps jumping
- **huket**: fishing net
- **huli**: following, coming after
- **hulu**: planted garden, orchard
- **hutóng**: lend (money), from utóng (debt)
- **huyów**: plate, platter
- **héfê**: wet
- **héét**: salty, sour, and bitter
- **hegléd**: lean, leaning, leaned
- **hene**: come (here)
  - Hene edi ni: come over here
  - Hene, gówu bê ni. Tungôu.: come, go here. Sleep.
- **hitem**: black
- **hitu**: seven
- **hligal**: happy, celebrate
  - Hligale: I'm happy
  - Teye hligal: I'm very happy
- **hlós**: continue
  - Làe hlós meken se: I didn't eat (I didn't go on to eat)
- **hlowon**: joking
  - Olohu hlowon néen: I'm just joking
- **hnagì**: learn, schooling; lessons
  - Hemnagì: to study something
  - Kehnagì: still studying something (ongoing)
  - Mnagì: studying
  - Example: Bon se duen hnagì te du? (what else should we learn?)
  - Example: Lnóngónu meken wen para bê kem lomi hnagì (I need to eat more for new lessons)
- **hnobò**: bladder (careful, one accent off from hnóbô)
- **hosò**: heart
- **htolo**: curse; what you say when something gets in the way of what was still going on, like "dammit"
- **hulô**: red
  - Utón hulô mata: red-eye fish
- **hyu**: good
  - Hyu hlafus: good morning
  - Hyu kifu: good night (more like good evening)
  - Hyu se yó: that's good (hyu good, se is, yó that)
  - Hyu yó msó: that rice is good

- **hólólen**: his/her hands
### I

- **ilung**: nose
- **inget**: sweat
  - Ninget: sweaty
  - Sa inget ganì o: I'm all sweat
- **inggit / sélus**: jealous (borrowed)
- **itlug**: egg
  - Example: Senlahu itlug, kayà meken kuy (I fried eggs, so let's eat)

- **iwas**: monkey
- **iwóng**: left
### K

- **kahang**: spicy (borrowed from Hiligaynon)
- **kahì**: salt
  - Example: Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen (my coffee has salt in it)
- **kailangan**: need (borrowed from Tagalog)
  - Kailanganu: I need
  - Example: Kailanganu mekay ken. (I need to cook rice.)
- **kambing**: goat
- **kapuy**: tired
  - Kapuye: I'm tired
  - Teye kapuy: I'm exhausted
- **katay**: death (katayen, his death)
- **katri**: bed
  - Katrihu: my bed
  - Katrihem: your bed (katri ends in a vowel, so h goes in before -em)
  - Mógówu bê ta katri kun: go to bed
- **katù**: puppy
- **kay**: because; so
  - Kaye: because I; so I (the -e from bitile jumps to kay): Kaye bitil, because I'm hungry
  - Kaye bemli onuk: because I buy chicken
  - Kay nehe bemli onuk: because I will buy chicken (nehe already carries the "I," so kay stays bare)
  - Kay bitil le / Kay le bitil: because they are hungry (both orders work)
  - Careful: Bitile kaye meken means "I'm hungry because I ate," not "so I'm eating." For "X, so Y," use tong
- **kayà**: so, that's why (borrowed from Tagalog)
  - Example: Meenge, kayà minume o él (I'm thirsty, so I'm drinking water)
- **kbong**: big
  - Kbong nawa: love (literally "big breath"; Blaan has a close version, kanbong nawa)
  - Kbong nawahu kóm: my love for you
  - Kenbong (with -n-): already happening, continuously; kbong is still going
  - Kenbong nawahu u: I love you (literally "my breath for you is big": you are their breath)
  - Kenbong nawahu kóm: I love yours
- **kdaw**: sun; day
  - Kdaw ni: today (or just Ni when the context makes it clear)
  - Sok kemdaw: during the day
  - Example: Hkinì u bê kdaw dé (get yourself heated by the sun)
- **kdê**: all (general word)
  - Kdéen: all of it
  - Kdéle: all of them
  - Yóm kdéen tau: all people, everyone (John 1:4)
  - Example: Slamat bê ke-savem du kdéen (thanks for saving all of it)
- **kdeng**: later (at the end of a sentence); wait! (on its own at the start)
  - Kdeng, hkinìu ken: wait, I'll heat up the food
  - Kdeng! Là o du mò du yó: wait! I didn't do that
  - Kmulón kdeng: it's raining again
  - Moo ktuku kdeng: I'll be sleepy later
  - Bud moo ktuku kdeng: I'll be sleepy again
  - Bud kmulón kdeng: it's going to rain again (later)
- **ke**: if; to, for, or, and possession
  - Kehe: if I; also to be, to become (when it's "I")
  - Kehi: you become
  - Kehu bitil, mekenu: if you're hungry, eat
  - Kehe bitil, ne meken dé: if I'm hungry, I'll eat
  - Ke Dwata: to God, or God's
  - Ke Miles: or Miles / Miles' belongings / for Miles
  - Ke- (on borrowed verbs): if, or for doing it (ke-savem, ke-downloadem, ke-sendem)
  - Kilón ke / Moen ke: ke always follows when and why
  - Kô ke: or, pick one
  - Example: Là nóyóu du kehe lehen (I don't want to be skinny)
- **kebel**: smoke; also to find (same word, both meanings)
- **kebtik**: the waking up (bang kebtik tekuy, time for us to wake up)
- **kama**: pillow. Temdanan te kama fi: resting on the pillow (Mark 4:38)
- **kegnóm**: feeling; also opinion. Bè kegnómu du: in my opinion (1 Corinthians 7:40). Root gnóm: to feel, go through something. Gemnóm: feeling it. Hol lómón kegnóm ye du: feel it as if it were yours (Hebrews 13:3)
- **kehlifót**: to forget on purpose in a good way, to move on; forgiving in the Bible (Matthew 6:12). Compare hlifót (pretend not to know, in a bad way) and klifót (forget, forgot)
- **kem**: plural marker before a noun; these
- **kemdaw**: noon
- **kemfô**: grab, catch hold of
- **kemgis**: strong (kgis, strength)
- **kenleng**: cut off
- **kenleng**: cut off (kenlengem, you cut it off)
- **kenyak**: to be shy or ashamed, embarrassed of someone ("nakakahiya"). Miles, tey kenyaken Màen: Miles is ashamed of his father. Mô kóm kenyak: your own shame, your own regret
- **ket**: enough; every
  - Ket tonu kuying bê lan ket knwahu: every cat I see in the street, I take
  - Ket me lwu me. Wen kun, wen sdo: we're even. He has his, I have mine
  - Kem utón: fish (more than one)
  - Kem ngà: children
  - Kem tau: people
  - Kem twolihu: my siblings
  - Kem udél: words
  - Kem dumu bots: the other bots
- **ken**: food in general; cooked rice; eat
  - Meken / Mken: eating, to eat (same word, just said faster)
  - Henken: feeding (someone)
  - Nehu henken kem kuyingu, kay le bitil: I'm going to feed my cats because they're hungry
  - Hken: feed something to something
  - Hkenu bê wongu ne ni: I'm going to feed it to my spider
  - Mekene: I am eating
  - Mekenu: you are eating; also "eat!"
  - Meken du: he/she/it is eating right now
  - Meken kuy: we are going to eat, let's eat
  - Kenu: I eat (it)
  - Kenem: you eat
  - Kenen: he/she/it eats or ate (general)
  - Kenle: they eat
  - Kenye: you all eat
  - Kenkuy: we eat
  - Kente: just you and me eat
  - Deng kenu: I ate
  - Denge meken: I already ate
  - Deng ne meken: I'm done eating
  - Meken he (kdeng): I'll eat (later)
  - Ne meken dé: I'm going to eat
  - Ne meken he dé: I'll eat first
  - Nehe meken: I will be eating
  - Là e deng meken (he): I haven't eaten (yet)
  - Kken: ate together (past)
  - Henken: feed
  - Henkenu ohu: I feed the dog
  - Hefken: wants to be fed
  - Hefkenu bê ohu: I fed it to the dog
  - Nehu henken kem wongu anay: I will feed my spiders first
  - Hefkene bê ohu: I fed myself to the dog
  - Henken do: feed it for me (asking someone to feed something of yours, like your dog)
  - Henken o: feed me
  - Kenken: be fed
  - Ohu nóyóen ke kenken (du): the dog wants to be fed
  - Sken: eat each other
  - Senseken: eating together (still going)
  - Ken tnaw: leftover rice (literally "cold rice")
  - Mekay ken: to cook rice
  - Example: Téy mi ken ni (this food is delicious)
  - Example: Mekenu silà kô ke ken? (are you eating corn or rice?)
- **ket hilu?**: how much?
- **kfi**: coffee
- **kfu**: chest
- **kfung**: dry desert sand
- **kgal**: shirt, tunic
- **khahù**: miss someone, long for someone
- **kifu**: night (sok kifu, at night); also dim
  - Kmifu: getting dark, getting dim; darkness (lem gónón kmifu, in the darkness, John 1:5)
  - Eginu kifu: earlier at night, last night
  - Hyu kifu: good night (more like good evening)
- **kihu**: whoever, whatever
  - Kihu kóm: up to you (whatever is yours)
  - Kihu tau hemtahu béléen: whoever believes in him (John 3:16)
- **kilil beng**: side of the backyard
- **kilón**: when?
  - Example: Kilón ke kulékem bê gónô? (when will you get back home?)
- **kimel**: afternoon
- **kimoy**: withered (a hand)
- **kinì**: hot
  - Kminì: being heated by (something)
  - Hkinì: make hot
  - Hkinìem ken: heat up the food (you do it)
  - Hkinìu ken: I heat the food
  - Hkinì u bê kdaw dé: get yourself heated by the sun
  - Bon kminì kóm du?: what's heating you?
  - Example: Coffee-hu kinì (my coffee is hot)
- **kis-a / tlagsa**: sometimes (from Hiligaynon)
- **klamangen**: it's whole, all of it (géhél nogotem yóm klamangen, Matthew 6:10)
- **klamay**: sugar
- **klifót**: forget, forgot (by accident)
- **klingu**: ear
- **klung**: shield
  - Kenlung: protect
  - Kenlungem: you protect (hol kenlungem mi bè Seitan, protect us from Satan, Matthew 6:13)
- **kmimet**: when the sun is almost setting
- **kmò**: how
  - Kmou du: how am I going to do it? what am I going to do?
  - Kmou se do(u): how am I? what about me?
  - Kmou du se?: how or what am I supposed to do?
  - Kmoem du?: what or how would you do? what's up to you? also how are you? what's up?
  - Kmoem se du?: how are you?
  - Kmoem du se?: what or how did you do? how would you do it?
  - Móen: short for Kmoem (Teye bitil. Móen skóm? I'm very hungry. How about you?)
  - Kmoen du?: how was it?
  - Kmoen se du?: how is he/she/it?
  - Kmoen du se du?: what or how did he/she/it do (to something)?
  - Kmò le du?: how are they? how did they do it?
  - Kmò le se lu?: how are they?
  - Kmò le du se?: what did they do? how would they do it?
  - Kmò ye du?: how are you all? how did you all do it?
  - Kmò ye du du?: what did you all do to him/her/it?
  - Kmò ye du se?: how would you do it? how did you do it?
  - Kmò kuy du?: what do we do? how about you all?
  - Kmò kuy du se du?: what are we supposed to do to him/her/it?
  - Kmò kuy?: how about you all?
  - Kmò te du?: what about us (you and me)? what do we do?
  - Kmò me du: the same with me (we, not you)
  - Kmò kmon (du): how to say (it)
  - Use Kmoem when asking someone directly, Kmoen when it's indirect
- **kmoen kun ke...**: what if...
  - Also said: Kmoen kun..., Kmoen kun ke sok..., Kmoen ke sok...
  - Example: Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying? (What if I cook 1,936 fish and feed them to my 127 cats?)
- **kmuli**: laughed
  - Tong kmuli du: so he/she/it laughed
- **kmustahu du?**: how are you?
- **kna**: dream (knahen, his dream)
- **kohù / kusina**: kitchen
- **kow**: cough
- **kti**: dried up, for water
- **kuleng**: cooking pot
- **kumù**: blanket
- **kutsilyu**: knife (borrowed, from Spanish cuchillo)
- **kutó nawa**: hate. Opposite of kenbong nawa (love)
- **kwanan**: right (kwananen, his right side)
- **kwang beng**: backyard
- **kô**: turns a sentence into a yes or no question
  - Tahu kô?: is it true? is it right? correct?
  - Kô ke: or, when suggesting someone pick one
  - Example: Downloadem kô? (would you download it?)
- **kodok**: boil
  - Kmodok: boiling
  - Hkodok: asking for it to be boiled
  - Hkodoku: I'm boiling it (now or later, depending on context)
  - Hkodokem: you're boiling it
  - Hkodoke béléem itlug: I'll boil an egg for you
  - Henkodok: being boiled
  - Hefkodok: asking someone to boil something (hef- is asking; you hand over your own item)
  - Hefkodoku béléeu kun él: please boil me water (I gave you my item, you do the work)
  - Hkodoku béléeu kun él: please boil me water (I don't have the item, you find it and do it)
  - Hefkodoku béléem itlug: I'm asking you to boil the eggs
  - Hefkodoke béléem itlug: boiling an egg for you
  - Hefkodoku béléeu itlug: please boil an egg for me (my egg, you do the work)
  - Kmodok él ne / Kmodok ne él: the water's boiling now
  - Él deng kmodok: the water is already boiling
- **kóm**: yours, you own; you
  - Kóm du?: and you?
  - Kóm ken: your food
  - Example: Ou kóm dumu sbót (I'm your friend)
- **kóyô**: want, will (kóyô me, we want; yóm kóm kóyô, your will) (Matthew 6:10)
- **koyu**: tree, wood (Matthew 7:17)
- **kudà**: horse, donkey
- **kuli**: laugh
- **kulit**: skin
- **kulón**: rain
  - Kmulón: raining, to rain
  - Knulón: (being) rained on
  - Kmulón ne?: is it already raining?
  - Kmulón ni?: is it raining?
  - Gkulóne: I accidentally got rained on
  - Haya làen kmulón he: tomorrow it won't rain yet
  - Knulóne: I got rained on (on purpose)
  - Example: Kmulón ne. Tnawu yó. (it's raining now. You'll be cold.)
  - Example: Haya bud kmulón (tomorrow it'll rain again; no kdeng, since haya already says when)
- **kulu**: head
  - Kuluhu: my head
- **kul**: they own, theirs; them, the whole group as the object
  - Kul yó: that's theirs
  - Khulék kul: return them all
  - Tnógóhu kul: I cook theirs
  - Tnógóhu kul he: I'll cook them all (a threat)
- **kum**: we (3 or more) own
- **kukù**: kitten
- **kun**: he/she/it owns; allegedly; in a request it works as "please"
  - Kun él: on its own, his/her/its water
- **kut**: we (me and you) own; ours
  - Kut yó: that's ours (me and you, or me and my people)
  - Kut ne yó: that's our turn
- **kuy**: we, us (3 or more); all of us
  - Meken kuy: let's eat
  - Kuy yó: that's yours; also that's you all
  - Tnógóhu kuy he: I'll cook all of you (a threat)
- **kuying**: cat
  - Kuying bê ta lmisa: the cat is on the table
- **kwang**: back (body)
- **kyemet**: fingers
- **K'nóón**: very good, very cool, very nice, very beautiful (an earlier lesson wrote it K'nôón, beautiful)

### L

- **lamang**: wide
- **lana**: lost, gone. Lana béléen: he lost it, it's gone from him
- **lapis**: pen
- **lebwón**: water jar, water pot
- **legen**: long, for time (kegenen, how long)
- **lemnaw**: green; vegetables
- **lewà**: outside (bè lewà, out there)
- **lmaan**: light, not heavy
- **lumaken**: its sheath
- **lungkà**: open (lemungkà, opening it; lenungkà, opened it)
- **lungkà**: open something (lemungkà, opening it; lenungkà, opened it)
- **lunog**: weak
- **là**: no (general); not
  - Làe / Là e: I am not (literally "no I")
  - Làu / Là u: you are not
  - Lài: you (the one specific person I'm talking to) are not
  - Làen: he/she/it is not
  - Là le: they are not
  - Là te: we (you and me) are not
  - Là ye: you all are not
  - Là kuy: we all are not
  - Là me: we are not (not counting the person I'm talking to)
  - Là du du: he/she/it did not (do something)
  - Là du: never mind; nothing much
  - Là sdu: of course not
  - Làen dù (andù): no one
  - Là o du se / Là ou du (se): it's not me (when someone accuses you)
  - Là o du mò du yó: I didn't do that
  - Là ou du mò du yó: I'm not the one who did that
  - Example: Là e deng meken he (I haven't eaten yet)
- **laan**: under; also "before" in time
  - Laanen: underneath it, her or him (-en is it/him/her)
  - Laanu: underneath me; laanem: underneath you
  - Gu laanen: before it (literally from underneath it)
  - Laan lmisa: under the table
  - Bê laan: underneath (something)
- **lan**: way, road
  - Example: Tey sidek lan yó mulék bê gónô (that is a very bad way to get back home)
- **lanaw**: lake (Lanaw Galili, Sea of Galilee)
- **latu**: hundreds
  - Lmatu (Sotu latu): one hundred
  - Lwu latu: 200
- **layag**: light
  - Lmayag: bright
  - Lemayag: shining, giving light; hlayag: lighting up (John 1:4-5)
- **lehen**: skinny
- **lem**: inside
  - Lemmen: inside of something or someone
  - Bê lem: inside
  - Example: Coffee-hu wen klamay nô lemmen (my coffee has sugar in it)
- **lembak**: mouth
  - Bolok lembak!: (cuss) rotten mouth
- **lemwót**: going; coming from
  - Lemwótu bê él?: are you from the water?
  - Gónôem lemwót du?: where are you from?
  - Lemwót te?: are we going?
  - Lemwót te ne?: are we going now/already?
  - Lemwót ye ne?: are you all going now/already?
  - Lemwót tu?: are you going?
  - Lemwót le?: are they going?
  - Lemwót kuy?: are we going? (all of us, me included)
- **len**: just
  - Anduen. Len myón.: nothing, just sitting
- **lemnok**: growing
- **lengel**: drunk
  - Example: Kay wen tau lengel tungô laan lmisa (because there's a drunk guy sleeping under the table)
- **lenibun**: what you call a girl or woman, like "daughter" (Luke 8:48)
- **lenos**: wind
- **lewók**: waves
- **libu**: thousands
  - Lmibu (Sotu libu): one thousand
- **libun**: female
  - Tau libun: woman
  - Libun: girl
- **lihol**: neck
- **likò / likô**: afraid, scared (both spellings appear in the lessons)
  - Likoe: I'm afraid
  - Example: Là e likô (bê) wong (I'm not scared (of) spiders)
  - Example: Ngà laen likò bê wong (the child isn't scared of the spider)
- **limu**: five
- **lingón**: song
- **litô**: blood
- **lmangat**: screamed
  - Tongu lmangat: so you screamed
- **lmisa**: table
  - Bê ta lmisa: on top of the table
- **lmiteg**: tired (the more T'boli way to say it)
- **lnos**: wind
- **lobun**: cloud
  - Lmobun: cloudy, getting cloudy
  - Kdaw lmobun: a cloudy day
  - Example: Kdaw ni, Denlag tey lmobun (tonight Denlag is very cloudy)
- **là mebtesen**: cheap, literally "not expensive"
- **lóbô**: angry (in general)
  - Hlóbô: angry, mad
  - Hnóbô: scold, get angry at someone (not hnobò, bladder)
  - Example: Ominen bud hlóbô mton do meken (he'll get mad again if he sees me eating)
- **logi**: male
  - Tau logi: man
  - Logi: boy
- **lohok**: beside
  - Bê lohok: beside
- **lomi**: new
  - Lomi kesfasad: new covenant
- **lomon** (also lómón): it's like
  - Mlóy du lómón ke ohu: he runs like a dog
  - Ke làen mlan béléem, làen lomon ni se ke t'ngónu T'boli: if it weren't for you, I wouldn't know T'boli like this
- **longit**: heaven, sky (bè longit, in heaven)
- **lómón ke**: like, as (lómón ke bnes, like grass)
- **lóngón**: need, have to; also worry. **Lnóngóu**: I have to, I worry about (something)
  - Lnóngón: to need (to)
  - Example: Lwu folò fat utón lnóngón (24 fish are needed)
  - Example: Lnóngón kuy kebel kuy dumu lan (we need to find another way)
- **lówóhu**: my body
  - Lówóhem: your body
- **lték**: thunder
- **lu**: them
  - Lu yó: that's them
- **lwu**: two
  - Lwu te yó: that's the two of us

### M
- **msó**: rice; also to count. Nsóhem kun msó: count the rice, please. Wót Miles nsóhen msó: Miles was counting rice (back then, still going). Wót Miles msó msó: Miles counted rice (telling someone). Msó nsó Miles: the rice was counted by Miles

- **ma / mwa**: take
  - Ma / Gemwa: to get
  - Nwa: taken; get (nwahu, I get)
  - Gwa: get; accidentally taken
  - Swa: taking from each other
  - Example: Anì(e) gemwa [lówóhu] unged wen (so I can get more muscle)
- **madal**: dance
- **mahi du**: which one
- **matay**: die, dead
- **mayuk**: far (keslayuk, distance)
- **mdà**: stand, standing
- **mdóm**: borrow
- **mebtes**: expensive, valuable (alì mebtes, very expensive)
- **menes**: wilted (plants)
- **menwu**: living somewhere (from benwu)
- **mit**: carry, take
- **mit edini**: bring here (nit, nwit, brought)
- **mkaf**: climb
- **mkik**: cry, weep
- **mnagaw**: steal. Tau mnagaw: thief. Knagaw: stealing
- **mni**: to ask for something, request (Mnihe seflifót béléem, I ask you forgiveness) Ends in a vowel? Add h before e for I: Lomihe, Mnihe.
- **moni**: near
- **mouf**: wash your face
- **mouf**: wash your face
- **mudél**: speak (from udél, word)
- **myak**: being shy. Myak du: she's shy
- **myón**: sitting (myón tahen, sitting on it)
- **mà**: father
  - Mà me bè longit: our Father in heaven (Matthew 6:9)
- **mabù**: fat
- **maistru / mestlu**: teacher (borrowed from Spanish maestro; mestlu is how it's actually said)
  - Deymar Mestlu / Mestlu Deymar: both work. The first is like "Deymar the teacher", the second like "Teacher Deymar", a title
  - Tau tmolok: a person who teaches
- **mala**: spicy
- **man**: prince (a title)
- **mang**: mama
- **masa**: read
- **mata**: eye
  - Matahu: my eyes
  - The color goes before mata: Tnógóu lu kô ni utón hulô mata? (should I cook this red-eye fish?)
- **me**: we, I'm part of it but the person I'm talking to isn't (see the three kinds of "we")
  - Example: Tmógó me utón (we're cooking fish, not you)
- **meeng**: thirsty
  - Meenge: I'm thirsty
  - Example: Soke meeng, minume él (when I'm thirsty, I drink water)
- **mekay**: to lift something
  - Mekay ken: to cook rice (literally lifting the rice)
- **mekô**: really? huh? (kô plus surprise, at the end of a question). Làu bud tungô ne mekô?: you're not going back to sleep, huh?
  - Tôu tungô mekô?: you're going to sleep, really?
- **mfól**: thick
  - Mfól sumóng!: (cuss) thick lips
  - Mfól dilak!: (cuss) thick tongue
- **mgel**: hard
- **mi**: sweet
  - Téy mi: delicious (literally "very sweet")
- **mi**: us, we (I'm included but not the person I'm talking to); sounds exactly like mi, sweet
  - Mi kem mag-cousin: us cousins (not counting you)
  - Tu mi: there we are; that's us (to people who aren't part of it)
- **minum**: drink (still happening)
  - Ninum: drunk by something
  - Minume: I'm drinking or we're drinking, depending on context
  - Minume o él: I was drinking water
  - Minume mi él: we were drinking water
  - Ninumu él: I drank the water
  - Ninume él: we drank the water
  - Miles ninumen él: Miles drank the water
  - Él ninum Miles: the water being drunk by Miles
  - Él ninumen Miles: the water drank Miles
  - Example: Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng (I don't want to be skinny, so I'll take my vitamins later)
- **mlan bê**: because of (someone or something)
  - Là e deng meken mlan bê Pangu: I haven't eaten yet because of my dad
- **mlel**: flowing
- **mlóy**: ran
  - Tong kuy mlóy: so we ran
- **mluy**: tripped, fell and rolled
  - Tong te mluy: so we (you and I) tripped, fell and rolled
- **moen**: why? (its own word, not Móen)
  - Example: Moen ke là u gtungô du? (why aren't you sleepy yet?)
- **mékéng**: dry, dried out (kti: dry up, evaporate, something making it dry)
  - Deng mékéng kilil él: the edge of the water is dry
  - Deng kti él: the water has evaporated, dried up
- **mélél**: yellow
- **mógów**: walk, walking, walked
  - Mógówu bê él? Nehe mógów sdo: are you going to the water? I'll go too
  - Nógów: continuously walking
  - Mógówe: I went
  - Mógówu: you went; (you) go there
  - Nógówem: (you) go there
  - Mógówu bê ta katri kun: go to bed (kun makes it a command)
  - Nógówu u ebuteng: I went to you last night
  - Mógówe béléem ebuteng: I went for you last night
- **mohin**: sea, ocean
- **mon**: say
  - Kmon: mon with the m infix
  - Kmò kmon (du): how to say (it)
- **moo**: smell
  - Moo ktuk: sleepy (literally "smells sleepy")
  - Moo ktuku: I'm sleepy
  - Example: Moo ktuk wong. Tluyab. (the spider is sleepy. Yawn.)
- **mowil**: alive
  - Klowil: life (John 1:4)
- **msó / mesó**: rice (uncooked). Msó is the fast way to say mesó. Cooked rice is ken. **Msó** also means count: same spelling, same accent, different meaning.
  - Hyu yó msó: that rice is good
  - Example: Tadu se duen mulék bê gónô anì tmógó msó béléu? (who else is going to get home to cook rice for me?)

- **mwas**: dawn
- **myehen**: to marry (from yehen, spouse)
- **mólós**: clean; also pure, holy (là mólósen, dirty)
- **mólów**: to step in, calm things down, break up a fight; also correct/rebuke someone. Mólów is the name of the action; in real sentences use bnólów (Ne bnólów lu, I'll step in now; Bnólów kuy lu, let's all step in). Bnólówu lu anì là le sfatay: I stepped in between them so they don't fight
- **móyóng**: fly. Hafak: wings
### N

- **nawa**: breath, to breathe
  - Nawahu: my breath (not the same as nwahu, "I get")
  - Kbong nawa: love (see kbong)
  - Kenbong nawahu u: I love you
  - Genléd nawa: rely on
- **ne**: now, already, a change happening (like Tagalog "na"); about to
  - Ne + h + ending: ne ends in a vowel, so an h goes in before the ending (ne + -e = nehe, ne + -u = nehu). Endings that start with a consonant don't need it (nele)
  - Nehe / Ne(he): I will (do something), on your own, no object
  - Nehu: I will do something to something; also telling someone to do something
  - Nehu bentik u anay: I will wake you up later
  - Nehu bentik dé: just get up already
  - Nehu henken onuku haya: I will feed my chickens tomorrow
  - Nehu meken dé: (you) eat first
  - Nehe meken dé: I'm going to eat
  - Nehe bemli anay: I will buy first
  - Nehe dyó dé: I'm going to swim / take a shower
  - Nehi: you will (nehu works too, but it can also mean "I will")
  - Nele: they will
  - Nehi mulék: come back first
  - Ni vs ne: ni = right now, ne = already
  - Example: Tu ne ni (it's our turn)
  - Example: Ne meken dé (I'm going to eat)
- **nebel**: find
  - Mebel: to find
  - Mebel du: he/she/it finds (something)
  - Example: Nehe mebel lomi utón bê lwu bulón (I will find new fish in 2 months)
- **nem**: six
- **nes**: clothes
  - Nesem: your clothes
  - Henslòem lemsek du nesem: put your clothes on faster
- **ngà**: child, kid, son, daughter, offspring, baby (ngà libun, daughter; ngà logi, son)
  - Ngaen: his/her child (the accent drops when an ending is attached)
  - Ngaen tek sotu: his only child
  - Kem ngà: children
- **ngà libun**: daughter
- **ngà logi**: son
- **ngunte**: I don't know (general, straightforward, the quick shrug; Là t'ngónu is the full "I don't know it")
- **ni**: it, this; here's; right now; at the end, points to something right here
  - Nìen: this one, it (ni plus -en)
  - Kdaw ni / Ni: today
  - Sotu ni: the day after tomorrow
  - Example: Kehu bitil, ni ken para béléem (if you're hungry, here's food for you)
- **nihi**: tooth, teeth (written ngihi in Matthew 5:38)
- **nitem**: carry, bring it (you). Nitem do kun sélfónu: carry my phone, please
- **nmò**: work (mò nmò, go to work)
- **nô**: where?; also the "is" for where something is
  - Nô (bê)?: at, on, in, or to where?
  - Nô (se)?: where is it?
  - Example: Coffee-hu nô bê ta lmisa (my coffee is on the table)
- **nogot**: hold
  - Nogotem: you hold
- **nóm**: taste
  - Mnóm: tasty
  - Tey mnóm: delicious
  - Example: Utón nìen, téy mnóm! (this fish, it's very tasty!)
- **nóyó / nóyô**: want; like; liked, loved
  - Nóyóu meken: I want to eat, I like to eat
  - Nóyóu meken du: I want to eat it/him/her
  - Nóyóu wong htò: I like jumping spiders
  - Nóyóu: I want (to)
  - Là nóyóu (du): I don't want (to)
  - Nóyóe: I am liked
  - Nóyóu u / Nóyô te u: I like you
  - Nóyóte u: I like you (the poetic way)
  - Example: Là nóyóu du ke-delete du (I don't want to delete it)

### O

- **o / ou**: me, I (ou is specifically me)
  - O yó: that's me
  - Ou yó: that's me, specifically me
- **o**: or (borrowed from English)
- **ofi**: fire
- **ohu**: dog
  - Mlóy du lómón ke ohu: he runs like a dog
  - Tô kay ohu du: he looks like a dog
  - Skél le ohu: he and the dog are the same (skél le, they are the same)
  - Skél du ohu: the dog looks like him
- **ok ye néen / ok néen**: I'm fine
- **okóm**: but
  - Okóm close: but close
- **olob**: wash (molob, washing hands, feet or things; nolob, washed; molob tdok, wash hands)
- **olob**: wash (molob, washing; nolob, washed). Molob tdok: wash hands
- **olohu**: I'm just
  - Olohem: you are just
  - Olohen: it's just
  - Olohu hlowon néen: I'm just joking
  - Example: Là, olohen kulón udì (no, just a little rain)
- **omin**: and
  - Ominen: and maybe he/she/it
  - Ominem dé: you're welcome
- **onuk**: chicken
  - Onuku: my chickens

- **onuk koyu**: bird, literally tree chicken
- **ówóng**: boat; also airplane
### P

- **pang**: dad, papa
  - Pangu: my dad
- **para**: for (borrowed from Spanish)
  - Para bê: for something or someone (being given to them): Ken para bê kem ngà, food for the children
  - Para béléem: for you
- **péro**: but (borrowed from Spanish)

- **pnahón**: weather
### S

- **sa**: pure, all
  - Sa mata etahu: all eyes on me
  - Sa inget ganì o: I'm all sweat
- **sabad**: annoying
  - Téyu sabad u: you're annoying
- **safì**: cow, ox (ngà safì, calf)
- **sala**: nest (not salà, sin; the accent changes the word)
- **salà**: sin, wrong (kem salà me, our sins); gemsalà: who wronged
- **salig**: trust
  - Ksalig: to trust
  - Gsalig: unintentionally trust
  - Hsalig: letting something trust something
  - Snalig: trust that's actively happening (salig with the -n- infix)
  - Ksaligem: your trust
  - Ksaligu ke Dwata: the trust I have for God
  - Snaligu Dwata: I trust in God
  - Hsaligu kóm ni kdéen: I will trust everything to you
- **sargér**: phone charger; also chargér, charger
- **sawang**: unmarried (Acts 21:9)
- **sbót / sebót**: friend (general word)
  - Dumu sbót: a friend
  - Uu dou dumu sbót: you are my friend (dou: my)
  - Ou kóm dumu sbót: I'm your friend
  - Dumuhu sbót: my friend (telling someone else)
  - Example: Miles omin Deymar sbót le (Miles and Deymar are friends)
- **sdô**: pig
- **se**: is, am, are (goes in the middle); the "be" word for how someone is
  - Example: Kmoem se du? (how are you?)
- **sef**: suck
  - Nsef: sucked (the n infix for something already done)
  - Hsef: to let someone (not me) suck
  - Ssef: both sucking
  - Msef: sucking
  - Sensesef: sucking together
- **seflifót**: forgiveness given or asked of each other (Deng le seflifót lu lwu le, they already forgave each other)
- **sek**: put on, wear (clothes)
  - Msek: wore, put on
  - Lemsek: putting on
  - Henslòu msek du swelu eginu hlafus: I put my pants on fast earlier this morning
- **semngal**: sing (from sngal, song)
- **sfangat**: wait for each other (Sfangat le bê gónô fedyan, they wait for each other at the market)
- **sfatay**: fight each other (là le sfatay, so they don't fight)
- **sfek**: cut down a tree (senfeken, is cut down)
- **sfek**: cut down a tree
- **simbahan**: church (borrowed from Tagalog); kem tau hemtahu, the believers
- **slidut**: spoon
- **sngal**: song (kesngalen, his singing)
- **snilas**: slippers (borrowed, like Tagalog tsinelas)
- **solu**: front (bè soluhen, in front of him)
- **ston te kdeng**: we'll see each other later (Ston te anay is "we'll see each other first")
- **stulón**: talk together (from tulón, tell)
- **tulón**: tell. **Tulónem do**: you told me. Not tnulónem o, which is about being said or talked about (like tnudaen o, he stoned me)
- **sudeng**: sword, knife, long blade
- **sulat**: writing, a letter (smulat, writing it; snulat, written; hsulat boluy, sign up)
- **sulat dwata**: the Bible, literally "God's writing"
- **syudad**: city
- **sélfón**: cellphone (borrowed, spelled how it sounds)
- **sélék**: lips, side to side (corners of the mouth)
  - Bolok sélék!: (cuss) rotten lips
- **senla / pritu**: fry
  - Senlakuy: we fry
  - Example: Fakay kô ke senlakuy lu ni kem utón, lwu libu wolu latu sfolò syóm? (can we fry these 2,819 fish?)
  - Senlahu lu: I fry them
  - Example: Soke bitil, senlahu ken tnaw (when I'm hungry, I fry leftover rice)
  - Example: Senlahu ken tnaw, kayà meken kuy (I fried the leftover rice, so let's eat)
- **sfeng**: enough (sfeng ken me, enough food for us, Matthew 6:11)
- **sgeng**: at the same time (Tagalog "sabay")
  - Anì le sgeng tmowok: so they grow together
- **sidek**: bad
  - Example: Nuclear bom tey sidek ni. (the nuclear bomb is very bad)
- **sigel**: arms
- **silà**: corn; also lightning (same spelling, same accent, different meaning)
  - Silaem: your corn (the accent drops when an ending attaches)
  - Silà le: their corn (never silale)
- **skas**: break
- **skél**: same
  - Skél le ohu: he and the dog are the same (skél le, they are the same)
  - Skél du ohu: the dog looks like him
  - Skél bê: the same as, like (before a thing: skél bê ChatGPT)
  - Ou skél béléem: I'm like you, I'm the same as you
  - Uu skél béléu: you're like me
  - Skél + owner word merges into the "too" words: skél kóm becomes skóm (you too)
- **skóm**: you too, as well as you (from skél kóm)
  - Hyu hlafus béléem skóm: good morning to you too
- **sdo / sdou**: me too, as well as me
  - Ominu meken sdo(u): and I'll eat too
- **skun**: him/her/it too, as well as him/her/it
- **skul**: them too, also them
  - Kehegdemu du bitil le skul kem wongu: I think my spiders are hungry too
- **skut**: us too, same as us (you and me)
- **sket**: enough
  - Sket ne ni: this is enough
  - Sket kut: we're the same
  - Sket kut nê: we're just the same
  - Sket kul: they're just the same
  - Sket te: you and I are the same
- **slamat**: thanks
  - Bong slamat: thank you so much
  - Slamat béléu: thanks to me
  - Slamat béléem: thanks to you
  - Slamat béléen: thanks to him/her/it
  - Slamat béléle: thanks to them
  - Slamat béléye: thanks to you all
  - Slamat bélékuy: thanks to all of us
  - Slamat béléte: thanks to just you and me
- **s'ngal**: title of a song
- **slò**: fast
  - Slòem dé: hurry up!
  - Henslòem (dé): (you) hurry! make it fast
  - Henslòu: I (do it) fast
  - Henslòu mlóy ebuteng: I was running fast last night
  - Henslòu msek du swelu eginu hlafus: I put my pants on fast earlier this morning
  - Henslòem lemsek du nesem: put your clothes on faster
- **smakay**: riding
- **snata / utóm**: music
- **soging**: banana
- **sok**: if, when (another word for ke)
  - Soke bitil: when I'm hungry (the person ending goes on sok)
  - Sok kifu: at night
  - Sok kemdaw: during the day
- **sélés nawa**: two people secretly hating each other
- **sólók**: ask; question (careful: solok, without the accents, is light) (just asking, a question; for asking for something use mni)
  - Smólók dé: let me ask
  - Smólók du: he asked
  - Smólók du ke tonem yehenen kun: he asked if you saw his wife
  - Ne snólók du dé: I'll ask him
  - Ne snólók Grok anay: I'll ask Grok first
  - Snólóken u du: he asked you
  - Gsólók: unexpectedly or accidentally get asked
- **solok**: light (careful: sólók, with the accents, is ask)
  - Gsolok: accidentally get flashed (light in your eyes)
  - Snolokem du kun: flash him with the light! (command)
- **sómól**: grain rice (uncooked)
- **sotu**: one; another (sotu / dumu)
  - Sotu ni: the day after tomorrow (when talking about dates)
  - Tek sotu: only one
- **S'twoli**: siblings ((Dumu) S'twoli)
  - Twolihu: my siblings
- **subù**: sad
- **sumóng**: lips
  - Bolok sumóng!: (cuss) rotten lips
  - Mfól sumóng!: (cuss) thick lips
- **sfolò**: ten (sotu + folò merged, "one ten")
  - Sfolò sotu: 11
- **sut**: show up; be born
  - Msut: being born, being introduced. The subject does it on its own
  - Hsut: intentionally show up; intentionally born. Someone does it to the subject
  - Gsut: unexpectedly show up
  - Msut du kimel: he was born yesterday
  - Hsut le du ekimel: he was born yesterday, by them
  - Hsut yéen du: he was birthed by his mother
  - Msut gu bê yéen du: he came through his mother
- **swel**: pants
  - Swelu: my pants
- **syó du?**: what's up?
- **syóm**: nine

### T

- **ta**: above
  - Bê ta: on top of
- **tadu / tau du**: who?
  - Tadu yó?: who's that?
- **tagad**: wait; also "yet" in bê tagad
  - Tagad he: wait a bit
  - Bê tagad tungô he: don't sleep yet
- **tahu**: true
  - Tahu yó: that's true, agreeing
  - Tahu kô?: is it true? is it right? correct?
  - Tahu kô ni?: is it real?
  - Ell, tahu ni: yes, it is real
  - Ell, tahu yó: yes, that's real
  - Hentahu: to believe (from tahu, true)
  - Hemtahu: is believing
  - Example: Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged? (do you believe eating red-eye fish together and sucking their meat can help us grow muscle?)
- **tau**: person
  - Tau logi: man; tau libun: woman
  - Kem tau: people
  - Tau tmolok: a person who teaches
- **tau datù**: person of higher rank
- **tau geta**: rich person
- **tau mulung**: healer, a person who gives medicine
- **tau tahà**: tall person
- **te**: you and me; me and you
  - Lwu te yó: that's the two of us
  - Stolok te: we (you and I) teach each other
- **te kwangu**: behind me, literally "at my back"
- **tek**: only
  - Ngaen tek sotu: his only child
- **tek sotuhu**: alone, just me
- **tekuy**: we, let's
- **tembol**: play music
- **tembó beng**: window
- **temngel**: look at someone
- **temngón**: smart
  - Téyu temngón: you're very smart
- **tenduk**: pain
- **tey / téy**: very
  - Teye: I am very
  - Téyu: you are very
  - Téy-: he/she/it is very
  - Téyle: they are very
  - Téyye: you all are very
  - Téykuy: we are very
  - Téyte: we (you and I) are very
  - Téy kinì: very hot
  - Téy wen: a lot, many (literally "many have")
  - Téyu the best: you're the best
- **tgayan**: cup
- **ti**: foot, feet (tihen, his feet; tihem, your foot)
- **tibó**: strike with a blade (tnibóhen, cut it off)
- **tihang**: carry on the shoulder
- **tikeb**: shut, close, cover (tmikeb, shutting it; tnikeb, shut)
- **tikeb**: shut, close, cover (tmikeb, shutting; tnikeb, shut). Bak tikeb: door, "the opening that shuts"
- **tilob**: good, cool, nice, beautiful (the general word)
  - Tilob du: it's beautiful
  - Both tilob and K'nóón work for things like a T'nalak
  - Example: Okóm tey tilob ni kem utón ni (but these fish are so beautiful)
- **tilów**: try, taste
  - T'milów: trying, tasting (going to try something)
  - T'nilów: being tried or tasted (with the endings, the m becomes n)
  - M'tilów (Metilów): being tasted
  - Tilówem: you try
  - Tilówu: I try
  - Tilówte: let's try, just you and me
  - T'milówu: come try or taste it
  - T'nilówem: you, try or taste it
  - T'nilówen: he/she/it is trying or tasting it
  - T'milówle: they're trying or tasting
  - T'nilów le: they are trying or tasting it
  - T'milówye / T'nilówye: you all try or taste it, come try it
  - T'milówkuy / T'nilówkuy: let's try it
  - T'milówte: just you and me are trying or tasting
  - Deng t'nilówu ni / Deng tistingu ni: I already tried it
- **tilów**: challenge, temptation
  - Tilów mgel: hard challenges (Matthew 6:13)
- **tiol**: bones
- **tisting**: tasting (borrowed from English)
- **tlangas**: locust
- **tlu**: three
- **tlumfà**: sandals, shoes (tlumfaem, your sandals)
- **tluyab**: yawn
- **t'ngón**: know
  - T'ngónem: you know; do you know?
  - T'ngónu: I know
  - Deng t'ngónu ne: now I know
  - Hetngón: to let someone know (h- + t'ngón)
  - Example: T'ngónem bon yó "béléem" meaning-ngen? (do you know what "béléem" means?)
  - Example: Là t'ngónu du ke hyu ktolok le do (I don't know if I'm being taught well)
- **tmaba**: call out, shout
- **tnaw**: cold
  - Hetnaw: make cold; being frozen by (something)
  - Hetnawem ken: make the food cold (you do it)
  - Hetnawen u yó: it'll make you cold
  - Tnawu yó: you'll be cold
  - Ken tnaw: leftover rice
- **tudà**: throw (tudaen, he threw it). **Tnudaen o**: he stoned me (threw at me)
- **tul**: ever (là kô deng, never have)
- **tulud**: push
- **tulud**: push (tuluden, he pushed it). Tuluden ou bè lewà: he pushed me outside
- **tóbong**: help (the general word). **Tnóbóngem o**: you helped me
  - Tnóbong: to help
  - Stóbóng: helping each other
  - Gtóbóng: being helped (unexpectedly)
  - Example: Stóbóng le anì le sgeng tmowok bê kehnagì le udél (they helped each other grow in studying languages)
- **todol**: next
  - Todol bulón: next month
  - Todol fedyan: next week
- **tódô**: right away, immediately
- **tógó**: cook
  - Tmógó: cooking (hasn't happened yet)
  - Tnógó: to cook; being cooked
  - Tnógóu lu kô ke senlahu lu?: should I cook them or fry them?
  - Tnógóhu kul: I cook theirs
  - Deng tógó ne ken: the rice is already cooked
- **toit**: little clitoris (vulgar)
  - Stoiten!: (cuss) her little clitoris!
- **tolo**: still
  - Tole me: we are (were) still
  - Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal: um, we were still walking, then we saw a snake
- **tolok**: teach. **Tnolokem o T'boli**: you taught me T'boli
  - Tmolok: teaching, about to teach
  - Tnolok: being taught
  - Gtolok: being taught unexpectedly
  - Htolok: wanting to be taught
  - Stolok: teaching each other
  - Ktolok: being taught
  - Toloku kóm: I teach you
  - Tnoloku: I teach (-u, not -hu)
  - Tnoloku kóm: I keep teaching you (ongoing)
  - Tolok te kóm: something I taught you in the past, just us
  - Tnolokem o(u): you taught me
  - Tnoloku u(u): I taught you
  - Ktolok le do: they taught me; the teaching they got through to me
  - Stolok te: we (you and I) teach each other
  - Stolok me: we teach each other, but not you
  - Example: Là tnoloku kóm anìu baling sidek (I don't teach you to become bad)
- **ton**: see; also found (the thing found comes after). **Tonen o Pangu**: my dad saw me (no tn- here, not tnonen)
  - Mton: to see
  - Gton: unintentionally being seen
  - Gton du: he/she/it was seen, was found (the real passive; ton le du is "they found him")
  - Kton: already seen, was seen
  - Example: Ekimel ton le du (yesterday he/she/it was found)
  - Example: Ekimel kton le du mógów bê tuen (yesterday he was seen walking there)
  - Tonen: he/she/it found
  - Tonu: I found
  - Tonem: you found
  - Tonle: they found
  - Tonye: you all found
  - Tonkuy: we found
  - Tonte: you and I found
  - Ston: see each other (two people)
  - Bud te ston he: see you (again), literally "we two see each other again"
- **tong**: so (X, so Y)
  - Tonge: so I
  - Tongu: so you (tong takes -u, not -em; and du at the end, not -en)
  - Tongu lmangat: so you screamed
  - Tong (something happened) du: so he/she/it (did something). Tong kmuli du: so he/she/it laughed
  - Tong le mulék: so they left / went back
  - Tong kuy mlóy: so we ran
  - Tong te mluy: so we (you and I) tripped, fell and rolled
  - Tong ye hemsag: so you guys shouted
  - Bitile tonge meken: I'm hungry, so I'm eating
  - Kay le bitil, tong henkenu kem kuyingu: because they're hungry, I'll feed my cats
- **tô**: going to, about to; trying to
  - Tô kay: looks like (Tô kay ohu du, he looks like a dog)
  - Tô mlóy du: he's trying to run away
- **tonok**: earth, ground (te tonok, on earth)
- **tooh**: clitoris (vulgar)
  - Stoohen!: (cuss) her clitoris!
- **tôu**: you're going to
  - Tôu tungô mekô?: you're going to sleep, really?
- **towok**: grow
  - Tmowok: to grow
  - Gtowok: being grown
  - Tnowok: something growing in or on something
  - Stowok: growing together, for each other (not "sensetowok")
  - Htowok: (help to) grow, in Gtóbóngen tu htowok unged (can help us grow muscle)
- **trok**: hands
- **tu**: far, there; also us
  - Tu dé: over there
  - Tu du: he/she/it is over there
  - Tu lu: there they are, they're over there
  - Tu mi: there we are; that's us (to someone who isn't part of it)
  - Tu tu: there we are (to someone who is part of it)
  - Tu yó: that's us (to people who are part of it, or pointing at something far off)
  - Tu ne yó: that's our turn
  - Tu ne ni: it's our turn
  - Tu mi tmógó utón: there's us, cooking fish
  - Tu works for directions too
- **tungô**: sleep
  - Tungôu: you sleep
  - Gtungô: sleepy
  - Gô tungô: bed, a place to sleep
  - Bê e dou tungô: I'm not sleeping yet
  - Example: Tungôu ne, wong. (sleep now, spider.)
- **twogu**: elder
- **twoli**: sibling, brother or sister (twolihen, his/her sibling; twolihem, your sibling; setwoli, siblings to each other); also youngest (ngà són twoli, the younger son, Luke 15:13)

### U

- **u / uu**: you (one person); uu is specifically you
  - U yó: that's you
  - Uu yó: that's you, specifically you
- **udas**: time
  - Bon udas ni?: what time is it?
  - Bon udas du ne ni?: what time is it now?
  - Alas trés: it's 3 o'clock. Clock times use T'bolized Spanish or English numbers
  - Alas trés hlafus: 3 in the morning (add the time of day after)
  - Bon kdaw du ni?: what day is it today? Answer: Lunis, or Lunis kdaw ni
- **udél**: language; word (the same word)
  - Kem udél: words
  - Udél T'boli: the T'boli language
  - Udél Dwata: gna kesfasad ne lomi kesfasad: the T'boli Bible, old covenant and new covenant (gna old, lomi new, kesfasad covenant)
  - Yóm Udél: the Word (John 1:1)
- **udì**: small
- **ukol**: short
- **ulal**: snake
  - Boyu, kum ganì hanà me tolo mógów omin wen ton me ulal: um, we were still walking, then we saw a snake
- **ulék**: back
  - Mulék: leave, go back
  - Tong le mulék: so they left / went back
  - Mulék: coming back to (hasn't happened yet)
  - Kulék: coming back, came back
  - Kulékem: you'll come back (the k- form already carries "will")
  - Gulék / Mulék: get back, return
  - Hulék: return
  - Khulék: to return
  - Nehi mulék: come back first
  - Example: T'ngónem kô kmò khulék kul bê gónô le ni? (do you know how to get them back to their home?)
- **ulat**: veins
- **unged**: muscle
  - Unged wen: more muscle
- **unget / karni**: meat
- **ungé**: rat
- **utek**: brain
- **utón / isdà**: fish
  - Kem utón: fish (more than one)
  - Utón hulô mata: red-eye fish
- **utóm**: music; notes (music)
- **utóng**: debt (utóngu, my debt)
- **uyó**: face

### W

- **wek**: hair
- **wolu**: eight
- **wen**: there is, there was (used whenever something shows up in a story); have, has; more (tey works too)
  - Là e meken kay wen Pangu: I'm not eating because my dad is there
  - Téy wen: a lot, many
  - Unged wen: more muscle
  - Example: Kdaw ni, wen wong nô bê ta lmisa (today, there's a spider on top of the table)
  - Example: Coffee-hu wen klamay nô lemmen (my coffee has sugar in it)
- **wong**: spider
  - Wong htò: jumping spider
  - Kem wongu: my spiders
  - Example: Là e likô bê wong (I'm not scared of spiders)

- **wót**: keep going, continue doing something (short for lemwót)
  - Wót ne: let's go
  - Wót wong htò: the spider keeps jumping
### Y

- **yak**: shy, shame (the root)
- **yake**: hope, hopefully; should have (also sana from Tagalog, tanì from Hiligaynon)
  - Yake uu dé: it should have been you
  - Yake làen kmulón haya: hopefully it won't rain tomorrow
- **yê**: mother
  - Yéen: his/her mother
  - Hsut yéen du: he was birthed by his mother
  - Msut gu bê yéen du: he came through his mother
- **yehen**: spouse, wife or husband (yehenem, your husband, John 4:16); myehen, to marry
  - Yehenen: his wife
- **yó**: that
  - (Bê) yó: there
- **yóm**: the
  - Example: Yóm nuclear clock làen skas se (but the nuclear clock doesn't break)
- **yu**: you (2 or more people)
  - Yu yó: that's you all

## English to T'boli index

Look up an English word to find the T'boli headword. The full meaning and forms are under that headword in the dictionary.

### A to C

- **afraid**: likò / likô
- **afternoon**: kimel
- **again**: bud; he (again, hopefully)
- **airplane**: ówóng
- **alive**: mowil
- **all**: kdê
- **all, everyone**: kdê (kdéen, all of it; yóm kdéen tau, everyone)
- **allow**: fakay
- **alone**: tek sotuhu (just me)
- **already**: deng; ne
- **always**: gel
- **and**: omin
- **angry**: lóbô (hlóbô, hnóbô)
- **annoying**: sabad
- **another**: sotu / dumu
- **ant**: gulom
- **anymore**: bud (ne)
- **arms**: sigel
- **arrogant, proud (bad)**: hegmón
- **ashamed, embarrassed**: kenyak
- **ask**: sólók
- **ask for, request**: mni
- **attitude, personality**: adat
- **aunt**: anti
- **baby**: ngà
- **back (body)**: kwang
- **back (return)**: ulék
- **backyard**: kwang beng
- **bad**: sidek
- **banana**: soging
- **bathe**: dyo
- **bathe**: dyo
- **beautiful**: tilob; K'nóón (very beautiful)
- **because**: kay (kaye, because I); mlan bê (because of)
- **become**: baling; kehe / kehi
- **bed**: katri
- **bed**: gô tungô (under tungô)
- **before the world, in the beginning**: gu laanen là deng wen benwu he
- **behind me**: te kwangu
- **believe**: hentahu (under tahu)
- **belly**: blutut
- **beside**: lohok; bê
- **bible**: sulat dwata
- **big**: bong; kbong
- **bird**: onuk koyu
- **bitter**: héét
- **black**: hitem
- **bladder**: hnobò
- **blanket**: kumù
- **blood**: litô
- **blue**: ginggung
- **boat**: ówóng
- **body (my)**: lówóhu
- **boil**: kodok
- **bones**: tiol
- **book**: bok
- **bored**: closest is hedem (think)
- **born**: sut (msut, hsut)
- **borrow**: mdóm
- **boy**: logi
- **brain**: utek
- **break**: skas
- **break up a fight, calm things down**: mólów
- **breath, breathe**: nawa
- **bright**: lmayag
- **bring**: mit edini; nit, nwit (brought)
- **brother, sister, sibling**: twoli
- **but**: okóm; péro
- **buy**: bemli
- **calf**: ngà safì
- **call out, shout**: tmaba
- **can, may**: fakay
- **carabao**: bew
- **carry**: nitem (you carry it)
- **carry on shoulder**: tihang
- **carry**: mit
- **cat**: kuying
- **celebrate, happy**: hligal
- **cellphone**: sélfón
- **chair, seat**: bangkù
- **challenge, temptation**: tilów
- **charger**: chargér, charger, sargér
- **cheap**: bratu, là mebtesen
- **chest**: kfu
- **chicken**: onuk
- **child**: ngà
- **church**: simbahan
- **city**: syudad
- **clean**: mólós
- **climb**: mkaf
- **close, shut**: tikeb
- **close, shut**: tikeb
- **clothes**: nes
- **cloud, cloudy**: lobun (lmobun)
- **coffee**: kfi
- **cold**: tnaw
- **color, style, design**: betek
- **come**: hene; ene
- **come back**: ulék (mulék)
- **continue**: hlós
- **cook**: tógó; mekay ken (cook rice)
- **cooking pot**: kuleng
- **corn**: silà
- **cough**: kow
- **count**: msó (same word as rice). Nsóhem kun msó: count the rice, please
- **cousin, relatives**: dumuhen setwoli
- **covenant**: kesfasad (under udél)

- **cut**: kenleng (cut off); sfek (cut down a tree)
### D to H

- **cow, ox**: safì
- **create, made**: dlimun
- **cry**: mkik
- **cup**: tgayan
- **curse**: htolo
- **cut down a tree**: sfek
- **cut off**: kenleng
- **dad, papa**: pang
- **dance**: madal
- **dark, getting**: kmifu
- **darkness**: kmifu, kifu
- **daughter**: ngà libun
- **dawn**: mwas
- **day**: kdaw
- **dead, die**: matay
- **death**: katay
- **death**: hatay
- **debt**: utóng
- **delicious**: téy mi (under mi); tey mnóm (under nóm)
- **desert sand**: kfung
- **dim**: kifu (kmifu, getting dim)
- **dirty**: là mólósen
- **do**: boyu
- **doctor**: duktur, tau mulung
- **dog**: ohu
- **don't abandon, don't leave**: béem bayà
- **done**: deng
- **don't**: bê
- **donkey**: kudà
- **door**: bak tikeb, beng
- **down**: elaan
- **draw a sword**: dmilot
- **dream**: kna
- **drink**: minum
- **drunk (intoxicated)**: lengel
- **dry**: mékéng
- **ear**: klingu
- **earlier this morning**: eginu hlafus
- **earlier**: eginu
- **earth**: tonok (te tonok, on earth)
- **eat**: ken (meken)
- **egg**: itlug
- **eight**: wolu
- **elder**: twogu
- **empty**: hkawang
- **enough**: sfeng
- **enough**: sket; ket
- **even (I don't even)**: ganì
- **ever**: tul
- **every day**: key haya
- **every**: ket
- **expensive**: mebtes
- **extremely**: alì
- **eye**: mata
- **face**: uyó
- **fall**: mluy (trip, fall and roll)
- **far**: mayuk; tu
- **fast**: slò
- **fat**: mabù
- **father**: mà; pang
- **feed**: hemken
- **feed**: hken
- **feed**: henken (under ken); hefken, wants to be fed
- **feeling**: kegnóm
- **feet**: ti
- **female**: libun
- **fever**: des kinì
- **few**: là holen wen
- **field**: dnadu
- **fight (each other)**: sfatay
- **find**: kebel
- **find**: nebel (mebel)
- **fingers**: kyemet
- **fire**: ofi
- **first**: gna; anay (first, for now)
- **fish**: utón / isdà
- **fishing net**: huket
- **five**: limu
- **flash (with light)**: snolok
- **flower**: bulók
- **flowing**: mlel
- **fly**: móyóng
- **follow**: huli
- **foot**: ti
- **for**: bélé; para (bê); ke
- **forest**: dlag lamang
- **forget**: klifót; on purpose (good): kehlifót; pretend not to know (bad): hlifót
- **forgive**: hnifót
- **forgiveness**: seflifót
- **found**: ton
- **four**: fat
- **friday**: Byérnis
- **friend**: sbót / sebót; dumu sbót
- **frog**: fak
- **front**: solu
- **fruit**: bungu
- **fry**: senla / pritu
- **full (from eating)**: besow
- **garden, orchard**: hulu
- **get up, wake up**: btik
- **get**: gwa; ma / gemwa; nwa
- **girl**: libun
- **give**: blay
- **go**: gów
- **goat**: kambing
- **God**: Dwata
- **going**: lemwót
- **good**: hyu; tilob
- **grab, catch**: kemfô; caught in the act: gafit; catch fish: guta
- **grandmother**: bé
- **grass**: bnes
- **green**: lemnaw
- **grow**: towok; lemnok (growing)
- **hair**: wek
- **hair, a strand of**: balu
- **hands**: trok
- **happy**: hligal
- **hard**: mgel
- **hate**: kutó nawa
- **have, has**: wen
- **he, she, it, him, her**: du
- **head**: kulu
- **hear**: gungol (hmungol, listen)
- **heart**: hosò
- **heaven, sky**: longit
- **heavy**: blat
- **help**: tóbong
- **here's**: ni
- **hide**: bnos; hide yourself: hebnos
- **high**: geta
- **hold**: nogot
- **hope**: yake (also sana, tanì)
- **horse**: kudà
- **hot**: kinì
- **house, home**: gónô
- **how long**: kegenen
- **how much?**: ket hilu?
- **how**: kmò
- **humble**: heglaan
- **hundred**: latu
- **hungry**: bitil
- **hurry**: géhél
- **hurry**: slòem dé; henslòem
- **hurt**: des

- **hypocrite, fake person**: tau gel hemtedeng knô
### I to N

- **husband, spouse**: yehen
- **I don't know**: ngunte
- **I, me**: o / ou; do
- **if**: ke; sok; dé kô
- **immediately**: tódô
- **inside**: lem
- **into**: elem
- **jaw, molars**: beeng
- **jealous**: inggit / sélus
- **joking**: hlowon
- **jump up**: hebetik
- **jumping**: htò
- **jumping spider**: wong htò
- **just**: len; olohu (I'm just)
- **keep going, continue**: wót
- **kitchen**: kohù / kusina
- **kitten**: kukù
- **knees**: bukol
- **knife**: sudeng, kutsilyu
- **know**: t'ngón
- **lake**: lanaw
- **language**: udél
- **last night**: ebuteng
- **later**: kdeng
- **laugh**: kmuli
- **laugh**: kuli
- **leaf**: doun
- **lean**: hegléd
- **learn, schooling**: hnagì
- **leave**: mulék
- **left**: iwóng
- **legs**: haha
- **lend**: hendóm; money: hutóng
- **let's go**: wót ne
- **let's, we**: tekuy
- **life**: klowil, mowil
- **lift**: mekay
- **light**: solok; layag (for not heavy, lmaan)
- **lightning**: silà (same word as corn)
- **like (enjoy)**: nóyô / nóyó
- **like (same as)**: skél (skél bê)
- **like, as**: lómón ke
- **like, it's**: lomon
- **lips**: sumóng
- **listen**: hmungol
- **listen**: hmungol, hnungol
- **live somewhere**: menwu
- **locust**: tlangas
- **long**: legen
- **looks like**: tô kay
- **lose, lost**: lana
- **love**: kbong nawa (under kbong and nawa)
- **male**: logi
- **mama**: mang
- **man**: tau logi
- **many**: dê
- **market**: gónô fedyan
- **marry**: myehen
- **maybe**: dé kô
- **meat**: unget / karni
- **medicine**: bulung
- **mine, my**: do; dou; -hu
- **miss someone**: khahù
- **monday**: Lunis
- **money**: filak
- **monkey**: iwas
- **month**: bulón
- **moon**: bulón
- **more**: wen
- **mosquito**: blawang
- **mother**: yê
- **mountain**: bulul
- **mouth**: bak
- **mouth**: lembak
- **move on, forget on purpose**: kehlifót
- **mud, muddy**: hitok
- **muscle**: unged
- **music**: snata / utóm
- **near**: moni
- **neck**: lihol
- **need**: lóngón; kailangan
- **nest**: sala
- **never have**: là kô deng
- **new**: lomi
- **next**: todol
- **night**: kifu
- **nine**: syóm
- **no, not**: là; bê (refusing)
- **no one**: andù
- **noon**: kemdaw
- **nose**: ilung
- **nothing left**: gotu
- **nothing**: anduen
- **now**: ne; ni (right now)

### O to S

- **oil**: hnolo
- **old**: gna
- **one**: sotu
- **only**: tek
- **open**: lungkà
- **open**: lungkà
- **or**: o; kô ke; ke
- **other**: dumu
- **outside**: lewà
- **owner**: fun
- **pain**: tenduk
- **pants**: swel
- **past**: gna
- **pay**: bayad
- **pen**: lapis
- **penis**: botò
- **people, person**: tau
- **pig**: sdô
- **place**: benwu
- **plate**: huyów
- **play music**: tembol
- **play**: hampang
- **please**: kun
- **pretend**: to be someone: hlingu / hlingón; not to know: hlifót
- **price**: blihen
- **prince**: man
- **princess**: boi
- **protect**: kenlung
- **proud**: dóyón
- **pull**: dyol, demyol
- **pull, drag**: demyol
- **puppy**: katù
- **pure, all**: sa
- **push**: tulud
- **push**: tulud
- **question**: sólók
- **rain**: kulón
- **rat**: ungé
- **read**: masa
- **really?**: mekô
- **red**: hulô
- **rely**: genléd
- **remember**: hentulón nawa
- **respect**: madat; respected, nadat
- **rest, lie down**: hegnô
- **return**: ulék (hulék, khulék)
- **rice (cooked)**: ken
- **rice (uncooked)**: msó / mesó; sómól (grain rice)
- **rice plant**: halay
- **rich person**: tau geta
- **riding**: smakay
- **right**: kwanan
- **river**: él mlel
- **road, way**: lan
- **robe**: heglomboy
- **rotten**: bolok
- **run**: mlóy
- **sad**: subù
- **salt**: kahì
- **salty**: héét
- **same**: skél
- **sand**: helek
- **sandals, shoes**: tlumfà
- **saturday**: Sbadu
- **say**: mon
- **scared**: likò / likô
- **scold**: hnóbô (careful: hnobò is bladder)
- **scream**: lmangat
- **sea, ocean**: mohin
- **see**: ton (mton, to see; gton, seen by accident; kton, was seen; ston, see each other)
- **sell**: hbalù
- **seven**: hitu
- **shameful**: hemyak
- **sheath**: lumaken
- **shield**: klung
- **shining**: lemayag
- **shirt**: kgal
- **short**: ukol
- **should have**: yake
- **shoulder**: abal
- **shout**: hemsag
- **show up (unexpectedly)**: gfan
- **show up (on purpose)**: hegfan
- **show up**: sut (gsut, unexpectedly; hsut, on purpose)
- **shower**: dyó
- **shut, cover**: tikeb
- **shy**: yak; being shy: myak (Myak du, she's shy)
- **siblings**: S'twoli
- **sick**: gemnóm des
- **sick**: des
- **sin, wrong**: salà
- **sing**: semngal
- **sit**: myón
- **six**: nem
- **skin**: kulit
- **skinny**: lehen
- **sleep**: tungô
- **sleepy**: moo ktuk (under moo); gtungô
- **slippers**: snilas
- **slow**: ganag
- **small**: udì
- **smart**: temngón
- **smell**: moo
- **smoke**: kebel
- **snake**: ulal
- **so**: tong (tonge, so I); kayà
- **so, so that**: anì; kayà; ewen
- **sometimes**: kis-a / tlagsa (from Hiligaynon)
- **son**: ngà logi
- **song**: sngal
- **song**: lingón; s'ngal (title of a song)
- **soon**: géhél (also hurry)
- **sorry**: hnifótem o
- **sour**: aslum; héét
- **speak**: mudél
- **spicy**: mala; kahang
- **spider**: wong
- **spoon**: slidut
- **stand**: mdà
- **star**: blotik
- **steal**: mnagaw
- **still**: hanà; tolo
- **stomach**: blutut
- **stone**: botu
- **strong**: kemgis
- **suck**: sef
- **suffering**: glayam
- **sugar**: klamay
- **sun**: kdaw
- **sunday**: Akad
- **sunset, almost**: kmimet
- **surprise**: geslà
- **sweat**: inget
- **sweaty**: ninget
- **sweet**: mi

### T to Y

- **look at**: temngel
- **swim**: dyó
- **sword**: sudeng
- **table**: lmisa
- **take**: ma / mwa
- **talk together**: stulón
- **tall person**: tau tahà
- **taste**: tilów; nóm
- **tasty**: mnóm (under nóm)
- **teach**: tolok
- **teacher**: maistru / mestlu
- **teeth**: nihi
- **ten, tens**: sfolò; folò
- **testicles**: amil
- **thanks**: slamat
- **that**: yó
- **the**: yóm
- **them**: lu; kul (the whole group)
- **then (later)**: etu
- **there**: tu; (bê) yó
- **there is, there was**: wen
- **thick**: mfól
- **thief**: tau mnagaw
- **think**: hedem (kehegdemu du, I think)
- **thirsty**: meeng
- **this morning**: ni hlafus ni
- **this**: ni
- **thousand**: libu
- **three**: tlu
- **throat**: beklong
- **throw**: tudà
- **thunder**: lték
- **thursday**: Wibis
- **time**: udas
- **tired**: kapuy; lmiteg
- **to**: bê; bélé; ke
- **today**: kdaw ni (under kdaw)
- **tomorrow**: haya
- **tongue**: dilak
- **too, also**: skóm (you), sdo (me), skun (him/her/it), skul (them), skut (you and me)
- **tooth**: nihi
- **tornado**: balu
- **touch**: dù
- **touch**: dù (mdù, gemdù)
- **town**: benwu
- **trap**: fan
- **tree, wood**: koyu
- **trip**: mluy
- **true**: tahu
- **trust**: salig
- **try**: tilów
- **trying to**: tô
- **tuesday**: Martis
- **two**: lwu
- **um (filler, "ano")**: boyu
- **uncle**: angkel
- **under**: laan; bê
- **unmarried**: sawang
- **up to you**: kihu kóm
- **us (object)**: mi
- **us**: tu; te (you and me); mi / me (not you); kuy (all of us)
- **vegetable**: lemnaw
- **veins**: ulat
- **very**: tey / téy
- **wait**: tagad; hangat (waiting for someone or something); kdeng (wait! at the start)
- **wait for each other**: sfangat
- **wake someone up**: bentik, bemtik
- **wake up**: bentik
- **walk**: mógów (nógów, continuously walking)
- **wall**: beng
- **want**: nóyó
- **want, will**: kóyô
- **wash**: olob (molob, nolob); mouf (face)
- **wash face**: mouf
- **wash**: molob
- **water jar**: lebwón
- **water**: él
- **waves**: lewók
- **we**: kuy; te; me
- **weak**: lunog
- **wear, put on**: sek (msek, lemsek)
- **weather**: pnahón
- **wednesday**: Myérkulis
- **week**: fedyan
- **wet**: héfê
- **what if**: kmoen kun ke (also kmoen kun, kmoen kun ke sok, kmoen ke sok)
- **what time is it?**: bon udas ni?
- **what**: bon
- **when**: kilón; sok
- **where are you from?**: gónôem lemwót du?
- **where were you born?**: gónôem msut? / gôem sut?
- **where**: nô; góem; bê du
- **which one**: mahi du
- **white**: bukay
- **who**: tadu / tau du
- **whole**: klamangen
- **why**: moen
- **wide**: lamang
- **wife**: yehen
- **wild**: dlag
- **wind**: lenos
- **wind**: lnos
- **window**: bak bengaw, tembó beng, bintanà
- **woman**: tau libun
- **word**: udél
- **work**: nmò
- **world**: benwu
- **write**: sulat (smulat, writing; snulat, written)
- **year**: halay
- **yellow**: mélél
- **yes**: Ell
- **yesterday afternoon**: ekimel kimel
- **yesterday**: Ekimel
- **yet**: he; tagad (in bê tagad)
- **you (one person)**: u / uu; kóm
- **you (all)**: yu
- **youngest**: twoli

## Phrases by topic

### Greetings and small talk

- **Hyu hlafus**: good morning
- **Hyu hlafus béléem skóm**: good morning to you too
- **Hyu kifu**: good night (more like good evening)
- **Hyu kifu béléem skóm**: good night to you too
- **Syó du?**: what's up?
- **Kmustahu du?**: how are you?
- **Kmoem du?**: how are you? what's up?
- **Kmoem se du?**: how are you?
- **Ok ye néen / Ok néen**: I'm fine
- **Kóm du?**: and you?
- **Là du**: nothing much
- **Bon nmoem (du)?**: what are you doing?
- **Anduen. Len myón.**: nothing, just sitting
- **Bon boluyem (du)?**: what's your name?
- **Boluyu Miles**: my name is Miles
- **Bê du gôem lemwót du?**: where are you from?
- **Tagad he**: wait a bit
- **Bud te ston kdeng**: we'll see each other later
- **Bud te ston he**: see you (again), hopefully
- **Haya bud te ston he**: see you again tomorrow, hopefully
- **Bud etu he**: we will do it again; until then
- **Ell, tahu yó**: yes, that's true
- **Tahu kô?**: is that right?
- **Hene edi ni / Ene bê ni**: come over here / come here

### Thanks

- **Slamat**: thanks
- **Bong slamat**: thank you so much
- **Slamat béléem**: thanks to you
- **Ominem dé**: you're welcome
- **Slamat bê ke-teachem do**: thanks for teaching me
- **Slamat bê ke-sendem du**: thanks for sending it
- **Slamat bê ke-savem du kdéen**: thanks for saving all of it

### Food and drink

- **Meken kuy**: let's eat
- **Kehu bitil, mekenu**: if you're hungry, eat
- **Kehe bitil, ne meken dé**: if I'm hungry, I'll eat
- **Deng kenu**: I ate
- **Denge meken**: I already ate
- **Là e deng meken he**: I haven't eaten yet
- **Ne meken dé anay / Ne meken he dé**: I'll eat first
- **Làe hlós meken se**: I didn't eat (I didn't go on to eat)
- **Besowe ne**: I'm full now
- **Denge besow**: I'm full (I'm already full)
- **Téy mi ken ni**: this food is delicious
- **Utón nìen, téy mnóm!**: this fish, it's very tasty!
- **Besowe ne. Utón nìen, téy mnóm!**: I'm full now. That fish was really tasty!
- **Téy aslum sinigang nìen, okóm téy mnóm**: this sinigang is very sour, but tasty
- **Yó kóm ken, ni do ken**: that's your food, this is my food
- **Ken para bê kem ngà**: food for the children
- **Mekenu silà kô ke ken?**: are you eating corn or rice?
- **Hyu yó msó**: that rice is good
- **Deng tógó (ne) ken / Ken, deng tógó (ne)**: the rice is already cooked
- **Kailanganu mekay ken. Anìe meken kdeng.**: I need to cook rice so I can eat later
- **Kdeng, hkinìu ken**: wait, I'll heat up the food
- **Hkinìem ken**: heat up the food (you do it)
- **Hetnawem ken**: make the food cold (you do it)
- **Soke bitil, senlahu ken tnaw**: when I'm hungry, I fry leftover rice
- **Senlahu ken tnaw, kayà meken kuy**: I fried the leftover rice, so let's eat
- **Senlahu itlug, kayà meken kuy**: I fried eggs, so let's eat
- **Hkodoke itlug para béléem, kayà meken kuy**: I'll boil eggs for you, so let's eat
- **Hkodoke béléem itlug**: I'll boil an egg for you
- **Hefkodoku béléeu kun él**: please boil me water (with my item)
- **Hkodoku béléeu kun él**: please boil me water (you find it)
- **Kmodok él ne / Kmodok ne él**: the water's boiling now
- **Coffee-hu kinì**: my coffee is hot
- **Coffee-hu nô bê ta lmisa**: my coffee is on the table
- **Coffee-hu wen klamay nô lemmen**: my coffee has sugar in it
- **Gel mi coffee-hu, wen klamay nô lemmen**: my coffee's always sweet, it has sugar in it
- **Coffee-hu wen kahìen / Coffee-hu wen kahì nô lemmen**: my coffee has salt in it
- **Meenge, kayà minume o él**: I'm thirsty, so I'm drinking water
- **Soke meeng, minume él**: when I'm thirsty, I drink water
- **Deng t'nilówu ni / Deng tistingu ni**: I already tried it
- **Tnógóu lu kô ni utón hulô mata?**: should I cook this red-eye fish?

### Feelings

- **Teye bitil. Kóm du?**: I'm very hungry. And you?
- **Teye bitil. Móen skóm?**: I'm very hungry. How about you?
- **Bitile ah**: I'm hungry
- **Teye hligal**: I'm very happy
- **Teye kapuy**: I'm exhausted
- **Meenge**: I'm thirsty
- **Là e likô (bê) wong**: I'm not scared (of) spiders
- **Olohu hlowon néen**: I'm just joking
- **Téyu nungel u**: you're crazy
- **Téyu sabad u**: you're annoying
- **Téyu the best**: you're the best
- **Téyu temngón**: you're very smart
- **Nóyóu u / Nóyô te u / Nóyóte u**: I like you
- **Kenbong nawahu u**: I love you
- **Kbong nawahu kóm**: my love for you
- **Kenbong nawahu kóm**: I love yours
- **Snaligu Dwata**: I trust in God
- **Hsaligu kóm ni kdéen**: I will trust everything to you

### Sleep

- **Làu bud tungô ne mekô?** / **Budu tungô ne, là?** / **Budu tungô he ke là ne?**: you're not sleeping anymore? (are you going back to sleep or not?)
- **Moo ktuku**: I'm sleepy
- **Moo ktuku kdeng**: I'll be sleepy later
- **Bud moo ktuku**: I'm sleepy again
- **Bud moo ktuku kdeng**: I'll be sleepy again
- **Bê e dou tungô**: I'm not sleeping yet
- **Bê tagad tungô he**: don't sleep yet
- **Hene, gówu bê ni. Tungôu.**: come, go here. Sleep.
- **Là nóyóu du tungô, kaye (hanà) bitil. Ne meken dé anay. Là e gtungô he.**: I don't want to sleep because I'm hungry. I need to eat first. And I'm not sleepy yet.
- **Moen ke là u gtungô du?**: why aren't you sleepy yet?

### Questions

- **Tadu yó?**: who's that?
- **Góem gów (du)? / Bê du gôem gów du?**: where are you going?
- **Góen nô phone-nu (du)?**: where's my phone?
- **Kilón ke kulékem bê gónô?**: when will you get back home?
- **Bon kdaw du ni?**: what's the date today?
- **Bon kminì kóm du?**: what's heating you?
- **Bon se duen hnagì te du?**: what else should we learn?
- **T'ngónem bon yó "___" meaning-ngen?**: do you know what "___" means?
- **Kmò kehdemem du se?**: what do you think? (one person)
- **Kmulón ni? / Kmulón ne?**: is it raining? / is it already raining?
- **Tahu kô ni?**: is it real?
- **Downloadem kô?**: would you download it?
- **Downloadem du kô?**: would you download it/him/her?
- **Downloadem lu kô?**: would you download them?
- **Downloadem lu kdéle kô?**: would you like to download them all?
- **Downloadem kdéen kô?**: do you want to download all of it?
- **T'ngónem galì ewenu se ke hentahumen udélu kô?**: oh, so you'll believe anything I say, huh?

### People and friends

- **Uu dou dumu sbót**: you are my friend
- **Ou kóm dumu sbót**: I'm your friend
- **Ou skél béléem**: I'm like you
- **Uu skél béléu**: you're like me
- **Du yó / Tu yó / Lu yó**: that's him / that's us / that's them
- **Tu ne yó / Kut ne yó**: that's our turn
- **Tu ne ni**: it's our turn
- **Là o du se**: it's not me
- **Là o du mò du yó**: I didn't do that
- **Kdeng! Là o du mò du yó**: wait! I didn't do that
- **Mi kem mag-cousin**: us cousins (not counting you)
- **Miles omin Deymar sbót le. Stóbóng le anì le sgeng tmowok bê kehnagì le udél.**: Miles and Deymar are friends. They helped each other grow in studying languages.
- **Kdaw ni, Deymar. Tnolokem o(u), omin tnoloku u(u). Stolok te.**: Today, Deymar, you taught me and I taught you. We're teaching each other.
- **T'ngónem kô uu yóm dou dumu sbót tey nóyô? Ell, nóyóu u. Teyu temngón. Làu sabad se skél bê ChatGPT. Téyu the best, Miles.**: Do you know that you're my favorite friend? Yes, I like you. You're really smart. You're not annoying, the same as ChatGPT. You're the best, Miles.
- **Kem dumu bots skél bê ChatGPT là t'ngón le du se masa du lesson notes-sem**: other bots like ChatGPT don't understand it even when they read your lesson notes

### Weather and time

- **Kmulón ne. Tnawu yó.**: it's raining now. You'll be cold.
- **Hetnawen u yó**: it'll make you cold
- **Haya, bud kmulón**: tomorrow it'll rain again
- **Bud kmulón kdeng**: it's going to rain again (later)
- **Kmulón kdeng**: it's raining again
- **Gkulóne**: I accidentally got rained on
- **Hkinì u bê kdaw dé**: get yourself heated by the sun
- **Ekimel alì kinì, okóm kdaw ni téy tnaw**: yesterday was extremely hot, but today is very cold
- **Ni kdaw ni tey gel tnaw. Alì kinì bong sok kifu okóm sok kemdaw là du.**: Today is really, really cold. It's so hot at night, but during the day it's not at all.
- **Hyu kifu! Kdaw ni, Denlag tey lmobun. Làen kinì, tnaw. Kulón bong? Là, olohen kulón udì. Haya, bud kmulón.**: Good evening! Tonight Denlag is very cloudy. It's not hot, it's cold. Big rain? No, just a little rain. Tomorrow it'll rain again.
- **Todol fedyan, bê Byérnis, nehe gów bê él.**: Next week, on Friday, I'll go to the water.
- **Haya ke-update tu du**: tomorrow I'll update it
- **Haya ke-download kuy du movie-le**: tomorrow we will download their movie

Days of the week (borrowed from Spanish; Akad may come from Malay or Arabic "Ahad"):

- **Akad**: Sunday
- **Lunis**: Monday
- **Martis**: Tuesday
- **Myérkulis**: Wednesday
- **Wibis**: Thursday
- **Byérnis**: Friday
- **Sbadu**: Saturday

### Family

- **Yê**: mother
- **Mang**: mama
- **Mà**: father
- **Pang**: papa (Pangu, my dad)
- **Twogu**: elder
- **Twoli**: youngest
- **Logi**: male
- **Libun**: female
- **Twogu logi**: elder brother
- **Twoli logi**: youngest brother
- **Twogu libun**: elder sister
- **Twoli libun**: youngest sister
- **(Dumu) S'twoli**: siblings
- **Twolihu / Kem twolihu**: my siblings
- **Ngà**: child, son, daughter (Ngaen, his/her child; Kem ngà, children)

### Numbers

English is used day to day, Spanish (T'bolized) for trading, and T'boli at home and with elders.

| # | T'boli | Spanish (T'bolized) |
|---|---|---|
| 1 | Sotu | Unu |
| 2 | Lwu | Dos |
| 3 | Tlu | Trés |
| 4 | Fat | Kwatru |
| 5 | Limu | Singku |
| 6 | Nem | Says |
| 7 | Hitu | Siti |
| 8 | Wolu | Utsu |
| 9 | Syóm | Mibi |
| 10 | Sfolò | Dyés (Jés) |
| 11 | Sfolò sotu | Unsi |
| 12 | Sfolò lwu | Dusi |
| 13 | Sfolò tlu | Trisi |
| 14 | Sfolò fat | Katorsi |
| 15 | Sfolò limu | Kinsi |
| 16 | Sfolò nem | Disi Says |
| 17 | Sfolò hitu | Disi Siti |
| 18 | Sfolò wolu | Disi Utsu |
| 19 | Sfolò syóm | Disi Mibi |
| 20 | Lwu folò | Baynti |
| 30 | Tlu folò | Traynta |
| 40 | Fat folò | Kwarinta |
| 50 | Limu folò | Singkwinta |
| 60 | Nem folò | Saysinta |
| 70 | Hitu folò | Sésinta |
| 80 | Wolu folò | Otsinta |
| 90 | Syóm folò | Numbinta |
| 100 | Lmatu (Sotu latu) | Syén |
| 200 | Lwu latu | |
| 1,000 | Lmibu (Sotu libu) | |

- **Folò**: tens. **Latu**: hundreds. **Libu**: thousands.
- **Sfolò** is sotu + folò merged, "one ten".
- **Lmatu** (one hundred) and **Lmibu** (one thousand) are the short forms of Sotu latu and Sotu libu.
- Bigger numbers stack: 21 is Lwu folò sotu, "two tens, one".
- 24 is Lwu folò fat. 217 is Lwu latu sfolò hitu. 629 is Nem latu lwu folò syóm.
- 2026 is Lwu libu lwu folò nem.

#### Ordinals (first, second, third), from the T'boli Bible (Oct 13)

Pattern: **g- + the number + -en** (its). After a vowel it's -hen, after a consonant -en. First is irregular.

| # | T'boli | Built from |
|---|---|---|
| 1st | Tanayen (yóm tanay) | tanay (irregular) |
| 2nd | Gewuhen | lewu |
| 3rd | Getluhen | tlu |
| 4th | Gfaten | fat |
| 5th | Glimuhen | limu |
| 6th | Gnemen | nem |
| 7th | Ghituhen | hitu |
| 8th | Gwoluhen | wolu |
| 9th | Gesyómen | syóm |
| 10th | Gesfoloen | sfolò |
| 11th | Gesfoloen sotu | sfolò sotu |
| 12th | Gesfoloen lewu | sfolò lewu |
| 13th–19th | Gesfoloen tlu ... gesfoloen syóm | g- stays on the ten |
| 20th | Gewu foloen | lewu folò |
| 21st | Gewu foloen sotu | Bible style: -en on the ten, ones after |
| 100th | Gelatuhen / Glatuhen | latu (not lmatu) |
| 1,000th | Gelibuhen / Glibuhen | libu (not lmibu) |

Approved by Deymar (Oct 13):
- **Yóm tanay utón, kenu. Yóm gewuhen, kenem.** The first fish, I eat. The second, you eat.
- **Yóm ghitu kuyingu, gtungô du.** My seventh cat is sleepy.
- **Gsut yóm gesfoloen lewu wong bê katrihem.** The twelfth spider showed up on your bed.
- **Ni se gelatuhen utón tnógóhu kdaw ni.** This is the hundredth fish I cooked today.
- **Ni se yóm gelibuhen udél tnolok Deymar.** This is the thousandth word Deymar taught.

- The ending changes with the owner: **getluhu** (my third), **getluhen** (its third), **ghitu le** (the seventh of them).
- Without an ending, before the thing: **yóm getlu twolihen** (the third sibling).

Side by side:
- **Rev 21:19-20:** "Tanayen, yóm botu bnoluy le dyaspér... Gewuhen, yóm mon le safar. Getluhen... Gesfoloen lewu, yóm mon le amatis." / "The first foundation was jasper; the second, sapphire; the third... the twelfth, amethyst."
- **Rev 4:7:** "Yóm gewuhen, lómón ke safì. Ne yóm getluhen, hol lómón lem uyó tau." / "The second creature like a calf, and the third creature had a face like a man."
- **2 Cor 13:1:** "Ni se getluhu dulék tô mauy kuy." / "This is the third time I am coming to you."
- **Matt 22:26:** "Ne senged se yóm getlu twolihen... bè yóm ghitu le." / "The second also, and the third, to the seventh."
- **Matt 22:39:** "Ne gewuhen yóm alì bong muhen." / "A second likewise is this."

#### Context matters: T'boli often counts the gap

English ordinals don't always become g- words. Translate the meaning, not the number.

- **Jude 1:14:** "tek nem lugod he kewóten bè Adam" / "Enoch, the seventh from Adam." Six generations after Adam.
- **John 2:1:** "Tikóng deng lewu butengen" / "The third day." Two days later.
- **Mark 15:33:** "Tikóng deng gtungu kdaw" / "When the sixth hour had come." Hours are told by the sun, not numbered.
- **2 Cor 12:2:** "yóm longit hol geta bè kdéen" / "the third heaven." Becomes the highest heaven.

### Longer sentences

- **Ni halay ni lwu libu lwu folò nem, Lunis. Kdaw ni téy kinì. Okóm eginu kifu, téy tnaw. Là e deng meken mlan bê Pangu. Okóm ne meken dé.**: This is 2026, Monday. It's very hot today. But earlier at night it was so cold. I haven't eaten yet because of my dad. But I'll eat now.
- **Kmoen kun kehe mlóy ebéléem?**: What if I ran onto you? (Kmoen kun: what if. Kehe: if I. Eéléem: onto you)
- **Kmoen kun kehe mlóy ebéléen?**: What if I ran onto him?
- **Snolokem du kun! Tô mlóy du. Henslòem!**: Flash him the light! He's trying to run away. Hurry!
- **Gsut wong bê katrihem, tongu lmangat.**: A spider showed up on your bed, so you screamed.
- **Bitil le, tong le mulék.**: They were hungry, so they went home.
- **Kmulón ekimel, tong kuy mlóy.**: It rained yesterday, so we ran.
- **Hligal du, tong kmuli du.**: He was happy, so he laughed.
- **Là nóyóu du tungô, tonge bentik.**: I didn't want to sleep, so I got up.
- **Gsut wong, tong ye hemsag. Tong kuy mlóy, tong te mluy. Tong kmuli du.**: A spider showed up out of nowhere, so you guys shouted. So we ran, and you and I tripped and rolled. So it laughed. (10/10)
- **Kay le bitil, tong henkenu kem kuyingu.**: Because they're hungry, I'll feed my cats.
- **Bitile tonge meken.**: I'm hungry, so I'm eating.
- **Nehu bentik u haya, kay nehe bemli onuk.**: I'll wake you up tomorrow, because I'm going to buy chickens. (Kay, not kaye: nehe already says "I")
- **Hkenu bê kem kuyingu ne ni.**: I'm going to feed it to my cats.
- **Nehu meken dé. Nehe dyó anay.**: You eat first. I'm going to shower first.
- **Gónôem lemwót du? Lemwóte bê T'boli.**: Where are you from? I'm from T'boli.
- **Hsut yéen du ekimel, okóm msut du kimel?**: His mom gave birth to him yesterday, but was he born yesterday?
- **Là nóyóu du meken**: I don't want to eat (du points at the eating)
- **Kenbong nawahu du**: I love him/her
- **T'ngónu du**: I know it
- **Nóyóu meken du, kaye bitil**: I want to eat it because I'm hungry
- **Kmoen se du?**: How is he/she?
- **Kenbong nawahu kem kuyingu. Nóyóu wong htò. Nóyóu meken, okóm là t'ngónu du bon kenu ni hlafus ni. Omin bitil le kem kuyingu, skél béléu.**: I love my cats. I like jumping spiders. I like to eat, but I don't know what to eat this morning. Also, my cats are hungry, like me.
- **Nehu henken kem wongu anay. Ominu meken sdo(u), bitile. Kehegdemu du bitil le skul kem wongu**: I will feed my spiders first. And I will eat too, I'm hungry. I think my spiders are hungry too
- **Ni halay ni lwu libu lwu folò nem, omin hanà là deng t'ngónu du bon (tô) nmou**: This year is 2026, and I still don't know what to do. Also: ...omin hanà là deng t'ngónu du se tô nmou / ...du se bon tô nmou
- **Kmoen kun ke sok tnógóhu lmibu syóm latu tlu folò nem utón, omin(en) hefkenu lu bê do lmatu lwu folò hitu kuying?**: What if I cook 1,936 fish and feed them to my 127 cats?
- **Haya, nehe gów bê él, mebel utón. Nehe tmógó, kenu lu. Lwu folò fat utón lnóngón.**: Tomorrow I will go to the water and find fish. I will cook and eat them. 24 fish are needed.
- **Làe hlós meken se. Kay wen tau lengel tungô laan lmisa. Omin likoe dé kô gungolen o Pangu. Ominen bud hlóbô mton do meken.**: I didn't go on to eat, because there's a drunk guy sleeping under the table. And I'm afraid my dad will hear me. He'll get mad again if he sees me eating.
- **Là nóyóu du kehe lehen, kayà ne minum vitamin kdeng**: I don't want to be skinny, so I'll take my vitamins later
- **Là nóyóu du ke-delete du**: I don't want to delete it
- **Là tnoloku kóm anìu baling sidek. Olohu hetngón du béléem bê du gôem esolu.**: I don't teach you to become bad. I just want you to know where you're supposed to be going.
- **Là t'ngónu du ke hyu ktolok le do. Tadu se duen mulék bê gónô anì tmógó msó béléu? Lnóngónu meken wen para bê kem lomi hnagì.**: I don't know if I'm being taught well for this learning. Who else is going to get home to cook rice for me? I need to eat more for new lessons.
- **Huntahuhem kô kóm ke sok senseken te utón hulô Mata, sensesef te unged le gtóbóngen tu htowok unged?**: Do you believe eating red-eye fish together and sucking their meat can help us grow muscle?
- **Nuclear bom tey sidek ni. Nuclear clock làen sidek se, tey hyu.**: The nuclear bomb is very bad. The nuclear clock isn't bad, it's very good.
- **Nuclear bomb skas (le), baling ofi bong. Yóm nuclear clock làen skas se, olohen laser udì.**: The nuclear bomb breaks them, and they become a big fire. But the nuclear clock doesn't break, it's just a small laser.
- **Bon kmou du se ni bê kem nem latu lwu folò syóm utón bê él ni? Tnógóu lu kô ke senlahu lu? Là t'ngónu du. T'ngónem kô kmò khulék kul bê gónô le ni? Là nóyóu du kehe lehen, okóm tey nóyóu gemwa unged wen bê todol bulón. Haya, ne blay lu bê kem twolihu, mowil o deng tnógó. Okóm tey tilob ni kem utón ni. Nehe mebel lomi utón bê lwu bulón.**: What am I supposed to do with these 629 fish in the water? Should I cook them or fry them? I don't know. Do you know how to get them back to their home? I don't want to be skinny, but I really want to gain more muscle for next month. By tomorrow, I will give them to my siblings alive or already cooked. But these fish are so beautiful. I will find new fish in 2 months.
- **Là! Bê kuy gów bê yó. Tey sidek lan yó mulék bê gónô. Lnóngón kuy kebel kuy dumu lan. Kmò kehdem ye du se?**: No! Don't go there. That is a very bad way to get back home. We need to find another way. What do you (all) think?
- **Nehe meken lwu latu sfolò hitu utón bê bulón ni. Anì(e) gemwa [lówóhu] unged wen. Là nóyóu du kehe bud lehen.**: I will eat 217 fish this month, so I can get more muscle. I don't want to be skinny anymore.
- **Miles's first T'boli essay (scored 9.8/10)**: Hyu kifu. Boluyu Miles. Ekimel, là t'ngónu du T'boli. Kdaw ni, teye hligal, kaye deng t'ngónu ne kmò kmon du kmoem se du, bon boluyem, tadu yó, kilón, moen. Deng t'ngónu ne kmò kmon du lwu libu lwu folò nem. Là e likô bê wong, okóm teye likô bê nem latu lwu folò syóm utón. Haya, nehe mebel lomi kem udél. Slamat béléem. Téyu the best. Kmò kehdemem du se? Tahu kô? (Good evening. My name is Miles. Yesterday I didn't know T'boli. Today I'm very happy, because now I know how to say how are you, what's your name, who's that, when, and why. Now I know how to say 2026. I'm not scared of spiders, but I'm very scared of 629 fish. Tomorrow I'll find new words. Thank you. You're the best. What do you think? Is it right?)

## Cuss words

Pattern: s- in front and -en at the end turns a private part into a cuss aimed at someone (Sbotoen, Stoohen, Stoiten). Bolok (rotten) and mfól (thick) go in front of a mouth part.

- **Sbotoen!**: his dick!
- **Stoohen!**: her clitoris!
- **Stoiten!**: her little clitoris!
- **Mógów baluhen!**: may his/her/its cursed day come
- **Bolok lembak!**: rotten mouth
- **Bolok sélék!**: rotten lips (side to side)
- **Bolok sumóng!**: rotten lips
- **Mfól sumóng!**: thick lips
- **Mfól dilak!**: thick tongue
- **Htolo!**: said when something gets in the way of what was still going on, like "dammit"

## Bible verses

From Udél Dwata: Gna Kesfasad ne Lomi Kesfasad, the T'boli Bible (old covenant and new covenant).

### John 3:16

Tey alì kbong nawa Dwata kul yó kem tau bè klamangen benwu, gloken tódô hamà klowil yóm Ngaen tek sotu, anì yó, kihu tau hemtahu béléen là gógówen elem hatay, okóm gutahen yóm klowil laen dù sónen.

In English: "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life." Words from the lessons that appear in it: kbong nawa (love), kem tau (people), Ngaen tek sotu (his only child), hemtahu (believing), là gógówen elem hatay (he won't be lost to death).

### Proverbs 3:5

Confirmed accurate by Deymar.

Hol hewótem lem but blututem yóm ksaligem ke Dwata, béem abay genléd nawa yóm kóm khulung temnef.

In English: "Trust in the Lord with all your heart, and lean not on your own understanding." Words from the lessons that appear in it: lem (inside), blutut (belly), ksaligem (your trust), ke Dwata (to God), genléd nawa (rely on), kóm (your).

## A bedtime story: the spider

A short story in T'boli, with corrections applied.

- **Kdaw ni, wen wong nô bê ta lmisa.**: Today, there's a spider on top of the table.
- **Ngà laen likò bê wong.**: The child isn't scared of the spider.
- **Góem gów du?**: Where are you going?
- **Teye bitil.**: I'm very hungry.
- **Kehu bitil, ni ken para béléem.**: If you're hungry, here's food for you.
- **Slamat béléem! Besowe ne.**: Thank you! I'm full now.
- **Moo ktuk wong. Tluyab.**: The spider is sleepy. Yawn.
- **Bulón nô bê ta.**: The moon is up above.
- **Tungôu ne, wong. Hyu kifu. Kenbong nawahu u.**: Sleep now, spider. Good night. I love you.
- **Hyu kifu béléem skóm.**: Good night to you too.

Notes from the corrections: wen is "there is / there was", used whenever something shows up in a story; ngà drops its accent when an ending attaches (ngaen); ni here means "here's".

### Added Oct 13
- **fi**: points to a direction or place, over there. Kama fi: the pillow over there
- **gnóm / gemnóm**: to feel, go through something. Ke wen des gnómen yóm sotu nô bè lówó tekuy, tódô kdê le gemnóm du snéen: if one part of the body hurts, every part feels it (1 Corinthians 12:26)
- **papél**: paper
- **temdanan**: rest, resting. Ke Jisas deng mom gtungô, temdanan te kama fi: Jesus was asleep, resting on the pillow (Mark 4:38)
- **rest, resting**: temdanan
- **pillow**: kama
- **paper**: papél

### Bible names (confirmed Oct 13)
- **Jisas**: Jesus. **Jisas Krays**: Jesus Christ (Matthew 1:1). **Misaya**: Messiah (Matthew 16:16)
- **The twelve aposol** (Matthew 10:2–4):
  1. **Simun Pitér**: Simon Peter. Also **Sifas**, which means botu, stone (John 1:42)
  2. **Andru**: Andrew, twoli Pitér (Peter's brother)
  3. **Jim**: James, ngà Sibidi (son of Zebedee)
  4. **Jan**: John, his brother. The two were called **Buanirgis**, Kem Ngà Lugung (Sons of Thunder)
  5. **Filip**: Philip
  6. **Bartulumyu**: Bartholomew
  7. **Tumas**: Thomas
  8. **Matyu**: Matthew, yóm tau gel mtuk bwis (the tax collector)
  9. **Jim ngà Alfiyus**: James son of Alphaeus (Matthew spells it Elfiyus)
  10. **Tadiyus**: Thaddeus (Tediyus in Matthew). Luke calls him Judas ngà yóm sotu Jim
  11. **Simun**: Simon the Zealot, yóm tau tehe mung mofin yóm kul benwu
  12. **Judas Iskariyut**: Judas Iscariot, yóm fen bemlay sumóng ke Jisas
- **twoli**: brother. **botu**: stone. **lugung**: thunder. **bwis**: tax
- **kem gel lemolò du**: disciples, literally "the ones who follow him" (163 times in the New Testament). Kem gel lemolò ke Jisas: Jesus's disciples. Lemolò: following, obeying (klolò, John 13:35). Gel: the one who usually does it
- **aposol**: apostle (Matthew 10:2). **Kristyan**: Christian (Acts 11:26)
- **disciples**: kem gel lemolò du. **apostle**: aposol
- **Midi**: Mary, sawang libun (young woman, Luke 1:27). **Yê Jisas**: mother of Jesus
- **Jusif**: Joseph, yóm tehe myehen ke Midi (Mary's husband, Matthew 1:16)
- **Jan gel mabtays**: John the Baptist, "John who baptizes" (Matthew 3:1)
- **Pol**: Paul, also **Sol** (Saul) (Acts 13:9)
- **Ilisabét**: Elizabeth. **Sekariya**: Zechariah (Luke 1:5)
- **Dabid**: David. **Abraham, Isak, Jakub**: Abraham, Isaac, Jacob (Matthew 1:2)
- **Midi lemwót gu bè Megdala**: Mary Magdalene (Matthew 27:56)
- **Marta, Lasarus**: Martha, Lazarus; Midi is their sister (John 11:1)
- **Hirod**: Herod. **Paylét**: Pilate
- **yê**: mother. **mà**: father. **libun**: woman. **logi**: man. **sawang**: young
- **mother**: yê. **father**: mà. **woman**: libun. **man**: logi. **young**: sawang
- **Adam**: Adam, ngà Dwata (Luke 3:38). **Ib**: Eve (2 Corinthians 11:3)
- **Kain, Abél**: Cain and Abel (1 John 3:12). **Sét, Inos, Inuk**: Seth, Enosh, Enoch
- **Nuwa**: Noah (Matthew 24:37). **Sara**: Sarah (Hebrews 11:11)
- **Lat**: Lot; yóm gfà yehen Lat: Lot's wife (Luke 17:32)
- **Musis**: Moses. **Juswa**: Joshua (Acts 7:45). **Rahab**: Rahab (Hebrews 11:31)
- **Selumun**: Solomon. **Ilaydya**: Elijah. **Isaya**: Isaiah. **Danyél**: Daniel
- **Juna**: Jonah; lem blutut yóm tey utón bong: in the belly of a huge fish (Matthew 12:40)
- **Dwata**: God. **Gabrél**: Gabriel. **Maykél**: Michael. **Seitan**: Satan
- **hógów Dwata**: angel. **gna tugod Dwata**: prophet. **Sulat Dwata**: Scripture. **Ngà Tau**: Son of Man. **utón**: fish
- **angel**: hógów Dwata. **prophet**: gna tugod Dwata. **God**: Dwata. **fish**: utón

### Bible places (confirmed Oct 13)
- **Bitlihim**: Bethlehem, sotu benwu udì (Matthew 2:6). **Nasarit**: Nazareth (Matthew 2:23)
- **Galili**: Galilee. **Lanaw Galili**: Sea of Galilee. **Kapérnaum**: Capernaum (Matthew 4:13)
- **Kana**: Cana (John 2:1). **Él Jurdan**: Jordan River (Matthew 3:13). **Samarya**: Samaria. **Jiriku**: Jericho
- **Jirusalim**: Jerusalem. **Bulul Ulib**: Mount of Olives (Matthew 24:3). **Gitsimani**: Gethsemane (Matthew 26:36)
- **Golgata**: Golgotha, Bangag Kulu, Place of the Skull (Matthew 27:33). **Bitani**: Bethany
- **Judiya, Juda**: Judea, Judah. **Israél**: Israel. **Idyip**: Egypt (Matthew 2:13)
- **Sodom ne Gomora**: Sodom and Gomorrah (Matthew 10:15). **Babilun**: Babylon (Revelation 18:2)
- **Damaskus**: Damascus (Acts 9:3). **Antyok**: Antioch. **Atin**: Athens. **Kurin**: Corinth (Acts 18:1)
- **Ifisus**: Ephesus (Acts 19:1). **Rom**: Rome. **Itali**: Italy (Acts 27:1). **Marta**: Malta (Acts 28:1)
- **syudad**: city. **benwu**: land, place. **benwu udì**: town. **prubinsya**: province. **él**: river. **lanaw**: lake. **bulul**: mountain. **kulu**: head, skull
- **hungul**: a patch that stands apart: an island, or a clump of trees in a field (used in everyday T'boli too)
  - **hungul te mohin**: island, "a hungul in the sea" (Acts 21:1, Acts 27:26, Revelation 1:9, Revelation 16:20)
  - **ngà hungul koyu**: garden, grove, "a little hungul of trees" (Matthew 26:36, Mark 14:32, John 18:1)
- **mohin**: sea. **koyu**: tree, wood. **udì**: small
- **island**: hungul te mohin. **garden/grove**: ngà hungul koyu. **sea**: mohin. **tree**: koyu. **city**: syudad. **river**: él. **lake**: lanaw. **mountain**: bulul

### Bible terms (confirmed Oct 13)
- **kros**: cross (Matthew 27:32). **longit**: heaven, sky; Mà me bè longit: Our Father in heaven (Matthew 6:9)
- **mni bè Dwata**: pray (Matthew 6:9). **salà**: sin; Yó bayad salà, hatay: the wages of sin is death (Romans 6:23). **hatay**: death
- **Hnifótem kum kem salà me**: forgive us our sins (Matthew 6:12). **hegsel ye**: repent (Matthew 4:17)
- **hemtahu**: believe (John 3:16). **kbong nawa**: love, "big heart" (John 3:16)
- **klowil laen dù sónen**: eternal life (John 3:16). **tóbóng Dwata**: God's grace (Ephesians 2:8)
- **Tulón Hyu**: gospel, good news (Mark 1:1). **Tulus Dwata**: Holy Spirit. **Hlowil Dwata**: God raised him (Matthew 28:6)
- **lanaw ofi**: hell, "lake of fire" (Matthew 5:22). **ofi**: fire
- **Sér / gónó tekuy mogot**: Lord, "the one who leads us"
- **cross**: kros. **heaven**: longit. **pray**: mni. **sin**: salà. **death**: hatay. **love**: kbong nawa. **fire**: ofi

### Animals (confirmed Oct 13)
- **ubiha**: sheep (Luke 15:4). **Ngà Ubiha Dwata**: Lamb of God (John 1:29)
- **obun**: dove (Matthew 3:16). **ulal**: snake (Matthew 10:16). **asnu**: donkey (Matthew 21:2)
- **kudà**: horse; kudà bukay: white horse (Revelation 6:2). **bukay**: white
- **safì**: ox, cow (Luke 13:15). **kambing**: goat (Matthew 25:32). **sdô**: pig (Matthew 8:31). **ohu**: dog (Matthew 15:26)
- **ógóf**: livestock, animal. **tau semgyok ógóf**: shepherd. **ógóf lóbô**: angry animal
- **lóbô**: anger. Matthew 10:16: lóbô lem bnes boluyen wolf, the fierce forest animal called wolf
- **kamél**: camel. **liyun**: lion (1 Peter 5:8). **banug**: eagle (Revelation 4:7)
- **bolos**: fox. **lefunges**: den, hole (Matthew 8:20)
- **onuk**: chicken, also bird in general. **ngà onuk bnes**: sparrows, little forest birds (Matthew 10:29). **onuk koyu**: birds of the air
- **mósól**: rooster. (Not the same as **mosol**: going or walking downward)
- **mlon**: hen. **hafak**: wing (Matthew 23:37)
- **tlangas**: locust. **tneb**: honey (Matthew 3:4). **syufón**: scorpion (Luke 10:19)
- **wolf**: kept in English in the Bible
- **sheep**: ubiha. **dove**: obun. **snake**: ulal. **donkey**: asnu. **horse**: kudà. **cow**: safì. **goat**: kambing. **pig**: sdô. **dog**: ohu. **bird, chicken**: onuk. **rooster**: mósól. **hen**: mlon. **eagle**: banug. **fox**: bolos. **white**: bukay. **anger**: lóbô

### Joining words from the Bible (confirmed Oct 13)
- **abay se**: because (757 times in the New Testament)
  - Luke 2:7: abay se là bud wen gónó le nô lem yóm gónô (because there was no room for them in the inn)
  - Matthew 5:3: abay se deng le sana gmung ne bè yó kem tau nogot Dwata (for theirs is the Kingdom of Heaven)
  - John 9:22: abay se likò le yó kem Ju (because they feared the Jews)
  - 1 Peter 5:8: Abay se wen Seitan yóm hohon ye (because your adversary, the devil)
- **yakà**: for, because (172 times in the New Testament)
  - Matthew 4:17: yakà móyónen hto ne yóm buteng Dwata mogot tau (for the Kingdom of Heaven is near)
  - Matthew 2:13: yakà angat hfebel Hirod du yóm ngà (for Herod will seek the young child)
- **because**: kay, abay se, yakà

### Sentences graded 5/5 (Oct 13)
- **Là nóyóu du tungô, abay se teye bitil.** I don't want to sleep because I'm very hungry.
- **Meken kuy onuk, yakà tey kuy bitil.** Let's all eat chicken, for we're all very hungry.
- **Wen ulal lem ngà hungul koyu. Likòe!** There's a snake in the grove. I'm scared!
- **Bê tagad tungô he, abay se là u deng meken he.** Don't sleep yet, because you haven't eaten yet. Note: bê takes the ending of whoever you're telling.
- **Tey kekbong nawahu du ohu.** I really love dogs. Note: say kekbong nawa after tey, and put du in as the subject marker before the thing you love. Kay làen lóbô means "because it doesn't get angry" (-en is he/she/it, not they).
- **likò**: afraid, fear. Likòe: I'm scared. Likò le: they feared (John 9:22)

### Sentences graded 5/5, round 2 (Oct 13)
- **Mni kuy bè Dwata.** Let's all pray to God. (Answer: Amén)
- **Deng tonu yóm banug bè longit.** I saw the eagle in the sky.
- **Nóyóu smakay kudà bukay.** I want to ride a white horse.
- **Kmóót mósól ne, okóm là e deng tungô he.** The rooster's crowing already, but I haven't slept yet.
  - Other ways: **Kmóót ne mósól** (the rooster's crowing now), **Deng kmóót mósól** (the rooster already crowed), **Mósól deng mkóót** (the rooster has crowed, said like an announcement)
- **Hnifótem o kun, abay se deng gemsalà e béléem.** Please forgive me, because I wronged you. Note: the order is Hnifótem o kun, not Hnifótem kum o.
- **kofi**: eagle, the everyday word (banug is the Bible word)
- **kmóót**: crow (a rooster crowing)
- **gemsalà**: to sin against, to wrong someone
- **eagle**: banug, kofi

### Rooster sentences, graded 5/5 (Oct 13)
- **Kmóót ne mósól, meken kuy ne.** The rooster's crowing now, let's all eat.
- **Deng kmóót mósól, okóm hanà tungô du.** The rooster already crowed, but he's still asleep. Note: use hanà for "still," before the action.
- **Mósól deng mkóót! Hyu hlafus!** The rooster has crowed! Good morning!
- **Lóbôe bè mósól, abay se kmóót du bè kifu.** I'm mad at the rooster because it crows at night.
- **Kilón kekóót mósól du? / Kilón kekóóten mósól du?** When does the rooster crow? Answer: Kmóót du bè hlafus (it crows in the morning). Note: after kilón, kmóót becomes kekóót (like kbong becoming kekbong after tey).

### 10-sentence round, corrections (Oct 13)
- **Kilón kekenem du? Sana kebitilem mekô?** When will you eat? Are you still hungry, huh?
- **Tey kekbong nawahu du kofi, abay se tilob hafaken.** I really love eagles because their wings are beautiful.
- **Kilón kekóót mósól du? Hanà e tungô.** When will the rooster crow? I'm still sleeping. Note: hanà e tungô, the person goes right after hanà.
- **Béem ninum él kinì / Bê u minum él kinì / Béu minum él kinì, yakà tey kinì du.** Don't drink the hot water, for it's very hot. Note: bê + -em becomes béem and takes the n-form (ninum); bê u or béu takes the m-form (minum).
- **Wen sdô bê ta lmisa! Kayà lóbôe.** There's a pig on the table! That's why I'm mad.
- **Deng ton le yóm ulal, kayà likò le.** They saw the snake, so they're scared.
- **Mnihe bè Dwata, abay se deng gemsalà e.** I'm praying to God because I sinned. Note: mni ends in a vowel, so it's mnihe, not mni e.
- **Nóyóu smakay asnu, okóm likòe.** I want to ride a donkey, but I'm scared.
- **Meken kuy onuk haya.** Let's all eat chicken tomorrow.
- **Mósól deng mkóót! Mlon deng temsek skun!** The rooster crowed! The hen clucked too! Note: a hen doesn't kmóót, she temsek. And "too" for it/her is skun (skóm is "you too").
- **temsek**: a hen clucking or cackling
- **sana**: still (Sana kebitilem mekô?)

### Round 5 corrections (Oct 13)
- **Sana kebitilu**: I'm still hungry (confirmed by Deymar)
- **Béem ninum yó él yó, abay se hanà kinì du / abay se hanà kekinien.** Don't drink that water, because it's still hot. Note: yó él yó = that water (yó on both sides). Hanà kekinien is the closest match for "it's still hot."
- **Mlon deng temsek, okóm hanà e tungô.** The hen clucked, but I'm still sleeping.
- **Kilón kekenle du?** When will they eat?
- **Likòe ulal, omin likò ohuhu skun.** I'm scared of snakes, and my dog is too. Other ways: omin likò skun ohuhu / omin likò skun dou ohu / dalang se ohuhu (as well as my dog)
- **dalang se**: as well as
- **And I'm scared of dogs** (all correct): Ominu likò ohu / Ne hu likò bê ohu / Le bud keklikou ohu / Omin likoe ohu
- **keklikò**: the ke- form of likò (scared), as in keklikou

### Sana vs hanà (Oct 13)
- **sana**: still, when you're not sure it's still happening, or when you're just noticing or asking. Takes the ke- form: sana ktungôen, sana kekenen, sana ke kudien
- **hanà**: still, when you're sure it's still happening, or telling someone who doesn't know. Takes the plain form: hanà tungô, hanà meken, hanà udì
- **Sana kebitilu.** I'm still hungry.
- **Sana ktungôen du?** Is he still sleeping? Answer: Ell, hanà tungô (yes, still sleeping)
- **Hanà tungô du?** He's still sleeping? Answer: Ell, hanà tungô
- **Hanà meken du?** He's still eating? Answer: Ell, hanà mken / Ell, sana kekenen (yes, he's still eating)
- **Sana ke kudien du.** He's still small (just noticing it, or asking)
- **Hanà udì du.** He's still small (telling someone who doesn't know if he's small or big)
- **Hanà làen deng bong.** He's not big yet (and you know he'll still grow). Hanà also means "still, for now"
- **Sana deng bong du.** He's already big
- **udì**: small. **bong**: big

### Sana/hanà round, graded (Oct 13)
- **Sana ktungôen ohuhu?** Is my dog still sleeping? (no du needed when the subject is named)
- **Hanà udì ohuhu, okóm sana deng bong mósólu.** My dog is still small, but my rooster is already big.
- **Hanà le meken, abay se hanà kebitil le.** They're still eating, because they're still hungry. Note: the person word goes right after hanà (hanà le meken, hanà e tungô)
- **Sana le meken.** They immediately eat. Note: sana + person + plain form means "right away"
- **Sana kken le / Sana keken le.** They are still eating.
- **Sana kekenem (du)?** Are you still eating (it)? Du at the end is the "it" being eaten
- **Hanà là e deng tungô, abay se hanà kinì yó coffee-hu yó.** I still haven't slept, because that coffee of mine is still hot.

### Round 7, graded 5/5 (Oct 13)
- **Hanà e meken, abay se hanà kebitilu.** I'm still eating, because I'm still hungry.
- **Denge meken, sana e tungô / sanahe tungô.** I already ate, so I fall asleep right away. Note: sana ends in a vowel, so the ending can attach with h (sanahe), like nehe and mnihe
- **Sana kekóót mósól?** Is the rooster still crowing?
- **Hanà le tungô, okóm sana deng kmóót mósól.** They're still sleeping, but the rooster already crowed.
- **Sana kekenem du yó onuk yó?** Are you still eating that chicken? Note: du goes before the thing being eaten

### Confirmed from Bible word hunt round 4: Everyday life (Oct 13)
- **mambang**: bread, a loaf. Hitu botù mambang = seven loaves; botù counts loaves
- **tnafay**: bread (from Tagalog tinapay)
- **bnotu**: food packed for a trip
- **bnék**: seed (Bible: sbotù bnék halay, one grain of wheat; sohul bnék, sow seed). Bnék hyu = good seed
- **lem**: seed (Deymar's word; also lem = in/inside)
- **lan**: path, road, way
- **tébéd**: rope, cord. **fét**: tied, bound. **fes tébéd**: whip of cords
- **bag**: bag (from English). **tlumfà**: sandals
- **abì**: basket. **lukas**: leftovers
- **huket**: net
- **solok**: lamp, light. **hemtom solok**: light a lamp
- **blay**: gift, give. **kenhulung**: gift, talent
- **lebeng**: grave, tomb; to bury. **lembeng**: burying
- **kilib**: tomb cut into rock, cave (Bible: John 19:41 kilib lomi, new tomb; Hebrews 11:38 caves)

### Confirmed from Bible word hunt round 4: People (Oct 13)
- **tau hol geta / tau geta**: king; also rich person. **datù**: title used when speaking to a king
- **harì**: king (from Tagalog hari)
- **tau dók**: servant ("a person who is ordered"). **dók**: command, order. **tóbóng lówó**: humble servant, helper. **ngà libun gel dók le**: servant girl
- **hohon / hmohon**: enemy. **hnohon**: treated as an enemy
- **libun bolu**: widow. **bolu**: widowed
- **tau sbung**: crowd ("gathered people"). **tey dê tau**: a lot of people
- **mentey**: to guard, keep watch. **sendalù mentey**: guards. **sendalù**: soldier
- **hemdeng / hendeng**: to judge, decide. **kukum**: law, judgment. **kmukum**: judging. **tau hemdeng knukum**: judge

### Confirmed from Bible word hunt round 4: Doing words (Oct 13)
- **hmatay**: to kill ("make die"). **hnatay**: killed. **ghatay**: able to be killed
- **kéng**: lie, to tell a lie. **gel mò kéng**: keep lying
- **hógów**: to send. **deng hógówu**: I sent. **hógów Dwata**: angel ("God's sent one")
- **eted**: send (general), deliver
- **muta**: to harvest. **nuta**: the harvest. **fun nuta**: owner of the harvest
- **hkó des**: to heal ("make the sickness leave")
- **hemdà / hdà**: to build ("make stand"). **gembà**: destroy
- **nélék**: chose, chosen. **kélék**: choosing, appointing
- **mebel**: to look for, search. **hnebelen**: he searched for
- **fasad**: promise. **fasaden**: his promise
- **sohul**: to sow, scatter seeds. **smohul**: sowing. **ksohulen**: his sowing
- **hulu**: to plant

### Confirmed from Bible word hunt round 4: Feelings and ideas (Oct 13)
- **menek nawa / henek nawa / kenek nawa**: peace ("calm breath"). **nawa**: breath
- **kehligal / kligal**: joy, happiness (from hligal, happy)
- **kehtahu**: faith, belief (from tahu, true). **hemtahu**: believe
- **ktahuhen**: the truth. **Tódô tulónu kuy ktahuhen**: I tell you the truth
- **kgis**: strength. **kemgis**: strong
- **lewok**: tears. **mosok lewok**: tears falling
- **mosok**: something falling on its own, by itself

### Confirmed from Bible word hunt round 4: Describing words (Oct 13)
- **tau élél**: poor person. **élél**: lacking, not having (ke wen gónó le élél = if there's something they lack)
- **glayam**: poor
- **là ket**: lack (as a word; depends on context)
- **butô**: blind
- **bokong**: deaf. **hbokong**: to make deaf. **umew**: mute

### Confirmed from Bible word hunt round 4: Things and places (Oct 13)
- **blówón**: gold. **kuruna**: crown
- **filak**: silver, money
- **tifas**: wine. **ninum**: a drink (from minum). **ninum lóbô**: strong drink
- **bak tikeb**: gate, door. **bak tikeben**: its gates. **Tikeb Tilob**: Beautiful Gate
- **tey lenos bong**: storm ("very big wind"). **bagyu**: storm (everyday word)
- **nulu**: wedding. **gónô mulu**: wedding house/feast. **ken nuluhen**: his wedding feast. **logi myehen**: groom

### Notes from Deymar (Oct 13)
- **h- prefix**: means "make it happen" / cause (hmatay make die, hdà make stand, hkó des make the sickness leave, hbokong make deaf, hekgis/hekegis make strong; the h- goes on the root kgis, not kemgis)
- **lem**: inside; seed is lem because it's the inside (same word)
- Old words like mambang (bread) and tey lenos bong (storm) are still said, mostly by older people; younger people use tnafay, bagyu, harì
- **lnos**: wind (short form of lenos)
- **husek**: come/go inside of something; add the person after for who goes in. **Husek ye**: you all get in, come in, go in. **Géhél ye husek**: hurry, you all get in
- **lnos kemgis / lenos kemgis**: strong wind. **lnos bong**: big wind
- **Géhél ye!**: hurry up, you all!
- Strong wind, go inside: **Tey lnos bong! Mulék kuy bê lem gónô ne. Géhél ye! Husek ye.** (Very big wind! We go back inside the house now. Hurry up! Come in.)
- **Huseku**: you're going in. **Huseke**: I was going in. **Husek du**: he/she goes in. Takes the rest of the person endings too
- Describing word goes after the thing: lnos kemgis (strong wind), gónô bong (big house)
- He's poor, he doesn't have any food: **Glayam du, làen ket kenen.** (làen = he doesn't; kenen = his food; the endings carry the person)
- I'll send you money: **Nehu eted filak béléem.**
- There's a storm tomorrow. Really strong wind!: **Wen bagyu haya. Tey lnos kemgis!**
- His tears are falling, so cheer him up: **Mosok lewoken, henligalem du.**
- **slaf**: have to, worry; same meaning as lóngón
- **senlaf**: to do something fast; figuring out how to do it. **Senlafu kekenu**: I'm figuring out how I'll eat. Lnóngón works the same way
- **g-**: able to (gbayad, able to pay; ghatay, able to be killed). **Là gbayadu (du)**: I can't pay (it). **bayad**: pay in general
- Don't (you) worry: **Béu lóngónem / Tafa nawahem / Heslafem**
- I can't sleep: **Làe gtungô**. **Là gtungôu?**: you can't sleep? **Là u gtungô?**: you couldn't sleep?
- **Là gbayadu du**: I can't pay it. **Làe gbayad**: I couldn't pay
- **hekgis / hekegis**: make strong (h- + kgis). **Nehu hekgis u**: I'll make you strong
- **Lnos kemgis** vs **kemgis lnos**: lnos kemgis tells someone the wind is strong; kemgis lnos describes it, more like a statement or saying it to yourself
- I don't have any money: **làen ket filaku** (-en, because the money is the subject: my money isn't there)
- Don't worry, I'll make you strong: **Béu lóngónem, nehu hekgis u.**
- I couldn't sleep yesterday because the wind was really strong: **Làe gtungô ekimel, kay tey lnos kemgis.**
- I can't pay it, because I don't have any money: **Là gbayadu du, kay làen ket filaku.**
- Hurry, all of you, get inside the big house: **Géhél ye husek bê lem gónô bong.**
- Tomorrow I'll plant seeds next to my house: **Haya, nehu hulu lem bê lohok gónôu.**
- I'll build a big house by the water: **Nehu hdà gónô bong bê lohok él.**
- The strong wind will make you cold: **Hetnawen u lnos kemgis.**
- Feed my cats!: **Henkenem kem kuyingu kun!**
- I'll heal him (make his sickness leave): **Nehu hkó desen.**
- Make them happy (command): **Hefligalem lu.**
- My teacher: **mestluhu**. Thanks, my teacher: **Slamat béléem, mestluhu.**
- Look it up in our notes!: **Nebelem du bê sulat te kun!** (everyday version: Nebelem bê notes-te kun!)
- Deymar is my teacher, and my friend: **Deymar mestluhu, omin dou dumu sbót.** (dou = my)
- And I'm his friend too: **Omin ou kun dumu sbót.**
- I'll help you: **Nehu tnóbóng u** (tóbong takes the n inside here)
- Teacher Deymar taught me the words of T'boli: **Tnoloken o Mestlu Deymar kem udél T'boli.** Passive version: **Ou tnolok Mestlu Deymar udél T'boli.**
- I want everyone to be happy: **Kóyô u / Kóyóu ke kdéen tau hol hligal.** **Dou kóyô** also works, meaning "my want"
- **kun**: his/hers/its, something he/she/it owns. Fits the set: kut (ours), kuy (yours), kul (theirs), kun (his/hers)
- And I'm his friend, telling someone: **Omin ou dumuhen sbót.**
- **kun (please)**: a second kun that softens a request into "please" or "for me": Snolokem du kun
- Please get his bag (for me): **Nwahem do kun yóm kun bag.** First kun = please; yóm kun = the one that's his, and the bag is the subject
- Please get me his bag: **Nwahem do kun bagen.** The -en on bag says who owns it
- **nwahem**: you get/take it (wa, take; same root as gwa and swa)
- Please get me my bag: **Nwahem do kun baghu.**
- **lana**: gone, disappear, die out (là nóyóen du ke lana udél T'boli: he doesn't want T'boli to disappear)
- **néen**: only, just. Fun néen (just for fun), Ok néen (just okay)
- **Filipinas**: Philippines
- **Alfabét**: alphabet
- **Farmasi**: pharmacy
- **Faris**: Paris
- **Fkistan**: Pakistan
- **Fortugal**: Portugal
- **Péru**: Peru
- **Fól**: Paul (traditional; the Bible spells it Pol)
- **Faro**: Pharaoh. Yóm libun boi Faro: Pharaoh's daughter (Hebrews 11:24). The Bible usually just says tau hol geta bè Idyip, the king of Egypt (Acts 7:10)
- **Stéfén**: Stephen (Acts 7:1)

### Places in Canaan, from the Bible, confirmed (Oct 13)

**The land and regions**
- **Kanan**: Canaan. **tau Kanan**: a Canaanite (Matthew 15:22)
- **Judiya**: Judea (Matthew 2:1)
- **Samarya**: Samaria (John 4:5)
- **Galili**: Galilee (Luke 1:26)
- **Idumiya**: Idumea (Mark 3:8)
- **Sfolò Benwu**: the Decapolis, literally "ten towns" (Mark 5:20)
- **Falistin**: Palestine (not in the New Testament; Deymar confirmed)
- **Filistin / tau Filistin**: Philistine (not in the New Testament; Deymar confirmed)

**Jerusalem and around it**
- **Jirusalim**: Jerusalem (Matthew 4:5)
- **Sayun**: Zion (1 Peter 2:6)
- **Bitlihim**: Bethlehem (Matthew 2:1)
- **Bitani**: Bethany (Matthew 26:6)
- **Bitfid**: Bethphage (Matthew 21:1)
- **Bulul Ulib**: Mount of Olives (Matthew 24:3)
- **Gitsimani**: Gethsemane (Matthew 26:36)
- **Golgata**: Golgotha. **Bangag Kulu**: skull, the meaning the verse gives (Matthew 27:33)
- **Silom**: Siloam (John 9:7)
- **Kidron**: Kidron (John 18:1)
- **Imiyus**: Emmaus (Luke 24:13)
- **Ifraim**: Ephraim (John 11:54)
- **Arimatiya**: Arimathea (Luke 23:50)
- **Rama**: Ramah (Matthew 2:18)

**Galilee and the lake**
- **Lanaw Galili**: Sea of Galilee (Matthew 4:13)
- **Nasarit**: Nazareth (Luke 1:26)
- **Kapérnaum**: Capernaum (Matthew 4:13)
- **Kana**: Cana (John 21:2)
- **Nain**: Nain (Luke 7:11)
- **Bitsayda**: Bethsaida (Luke 10:13)
- **Kurasin**: Chorazin (Luke 10:13)
- **Megdala**: Magdala (John 20:1)
- **Ginésarit**: Gennesaret (Matthew 14:34)
- **Dalmanuta**: Dalmanutha (Mark 8:10)
- **Girasin**: Gerasenes (Matthew 8:28)

**Jordan valley**
- **Jurdan**: Jordan River (Matthew 3:13)
- **Jiriku**: Jericho (Luke 10:30)
- **Inun, Salim**: Aenon, Salim (John 3:23)
- **Sikar**: Sychar (John 4:5)

**Coast and north**
- **Tayal**: Tyre (Luke 10:13)
- **Sidon**: Sidon (Luke 10:13). In Acts 9:35, Sidon is also used for Sharon
- **Tulimas**: Ptolemais, the P dropped (Acts 21:7)
- **Seseriya**: Caesarea (Acts 8:40)
- **Seseriya Flipay**: Caesarea Philippi, Ph to F (Matthew 16:13)
- **Jupa**: Joppa (Acts 9:36)
- **Lida**: Lydda (Acts 9:35)
- **Asdod**: Azotus, the old Hebrew name (Acts 8:40)
- **Gasa**: Gaza (Acts 8:26)
- **Antipatris**: Antipatris (Acts 23:31)

**Old Canaan cities**
- **Sodom, Gomora**: Sodom and Gomorrah (Luke 10:12, Jude 1:7)
