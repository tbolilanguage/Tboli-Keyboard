import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PenLine, c as Languages, g as ChevronRight, l as Keyboard, o as MessageSquare, y as BookOpen } from "../_libs/lucide-react.mjs";
import { n as useIme, o as VOWELS, s as cn } from "./router-DW5w4w-K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-2j3escaE.js
var import_jsx_runtime = require_jsx_runtime();
function HomeScreen() {
	const ime = useIme();
	const on = ime.installed && ime.selected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium tracking-wide text-primary",
				children: "Lake Sebu"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-4xl font-semibold tracking-tight",
				children: "T'boli Keyboard"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-sm leading-relaxed text-muted",
				children: "Open the app for translate and writing tools. Turn the keyboard on in settings, then it pops up like any other keyboard when you type."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/enable",
				className: cn("mt-5 flex items-center gap-3 rounded-xl p-4 shadow-panel", on ? "bg-surface" : "bg-primary text-primary-fg"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, {
						className: "size-6 shrink-0",
						strokeWidth: 1.75
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: on ? "Keyboard is on" : "Turn on the keyboard"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("text-sm", on ? "text-subtle" : "text-primary-fg/80"),
							children: on ? `${ime.lang === "tbl" ? "Tboli" : "English"} · tap any field to type` : "Add it in Keyboard settings, then choose it as your board"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
						className: "size-5 shrink-0 opacity-70",
						strokeWidth: 2
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/translate",
						icon: Languages,
						title: "Translate",
						hint: "English to Tboli"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/dictionary",
						icon: BookOpen,
						title: "Dictionary",
						hint: "Deymar's word list"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/write",
						icon: PenLine,
						title: "Write",
						hint: "Notes in Tboli"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/try",
						icon: MessageSquare,
						title: "Try typing",
						hint: "Messages, Notes, Search"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/settings",
						icon: Keyboard,
						title: "Settings",
						hint: "Languages and keys"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				"aria-label": "Tboli vowels",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-muted",
					children: "Seven vowels"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 grid grid-cols-7 gap-1",
					children: VOWELS.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col items-center rounded-md bg-surface py-2 shadow-panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl font-semibold leading-none",
							children: v.letter
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 text-2xs text-subtle",
							children: v.ipa
						})]
					}, v.letter))
				})]
			})
		]
	});
}
function Tile({ to, icon: Icon, title, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "flex h-full flex-col rounded-xl bg-surface p-3.5 shadow-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-5 text-primary",
				strokeWidth: 1.75
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs text-subtle",
				children: hint
			})
		]
	}) });
}
var SplitComponent = HomeScreen;
//#endregion
export { SplitComponent as component };
