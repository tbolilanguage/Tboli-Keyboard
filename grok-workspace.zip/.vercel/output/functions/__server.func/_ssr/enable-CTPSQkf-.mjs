import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronLeft, v as Check } from "../_libs/lucide-react.mjs";
import { n as useIme, r as openSystemKeyboardSettings, s as cn } from "./router-DW5w4w-K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enable-CTPSQkf-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EnableScreen() {
	const ime = useIme();
	const [step, setStep] = (0, import_react.useState)(null);
	const [osNote, setOsNote] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!ime.ready || step !== null) return;
		setStep(ime.installed ? ime.selected ? 3 : 2 : 1);
	}, [
		ime.installed,
		ime.ready,
		ime.selected,
		step
	]);
	function openPhone() {
		const result = openSystemKeyboardSettings();
		if (result.platform === "android") setOsNote("Opening Keyboard settings on this phone…");
		else if (result.platform === "ios") setOsNote("On iPhone: Settings → General → Keyboard → Keyboards → Add New Keyboard → Tboli.");
		else setOsNote("On a phone, this switch lives in Keyboard settings. Use the steps below here.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 pt-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/settings",
				className: "inline-flex h-10 items-center gap-1 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: "size-4",
					strokeWidth: 2
				}), "Settings"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-semibold tracking-tight",
				children: "Keyboard settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Add Tboli Keyboard, then choose it as the board that pops up when you type."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 flex gap-2 text-2xs font-medium",
				children: [
					1,
					2,
					3
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { className: cn("h-1 flex-1 rounded-full", step !== null && n <= step ? "bg-primary" : "bg-surface-2") }, n))
			}),
			step === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-sm text-subtle",
				children: "Loading keyboard settings…"
			}) : null,
			step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "1. Manage keyboards"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-subtle",
						children: "Same list as Android On-screen keyboard / iPhone Keyboards."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 overflow-hidden rounded-xl bg-surface shadow-panel",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between px-4 py-3.5 text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "English (US)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-subtle",
									children: "System"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { className: "h-px bg-border" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between px-4 py-3.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: "Tboli Keyboard"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-subtle",
									children: "English · Tboli"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									role: "switch",
									"aria-checked": ime.installed,
									onClick: () => ime.setInstalled(!ime.installed),
									className: cn("relative h-7 w-12 rounded-full transition-colors duration-150", ime.installed ? "bg-primary" : "bg-key-mod"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-6 rounded-full bg-key transition-transform duration-150", ime.installed ? "translate-x-5" : "translate-x-0.5") })
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: openPhone,
						className: "mt-3 h-11 w-full rounded-md bg-key-mod text-sm font-medium text-key-mod-fg",
						children: "Open phone keyboard settings"
					}),
					osNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-relaxed text-subtle",
						children: osNote
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !ime.installed,
						onClick: () => setStep(2),
						className: "mt-4 h-11 w-full rounded-md bg-primary text-sm font-medium text-primary-fg disabled:opacity-40",
						children: "Next"
					})
				]
			}) : null,
			step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "2. Choose input method"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-subtle",
						children: "Pick which board pops up when a text field is focused."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 overflow-hidden rounded-xl bg-surface shadow-panel",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => ime.setSelected(false),
								className: "flex w-full items-center justify-between px-4 py-3.5 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Phone keyboard" }), ime.selected ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-5 text-primary",
									strokeWidth: 2
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { className: "h-px bg-border" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => ime.setSelected(true),
								className: "flex w-full items-center justify-between px-4 py-3.5 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Tboli Keyboard"
								}), ime.selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-5 text-primary",
									strokeWidth: 2
								}) : null]
							}) })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setStep(1),
							className: "h-11 flex-1 rounded-md bg-key-mod text-sm font-medium text-key-mod-fg",
							children: "Back"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !ime.selected,
							onClick: () => setStep(3),
							className: "h-11 flex-1 rounded-md bg-primary text-sm font-medium text-primary-fg disabled:opacity-40",
							children: "Next"
						})]
					})
				]
			}) : null,
			step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "3. Ready to type"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-subtle",
						children: "Tboli Keyboard is on. Tap a field and it slides up — globe key switches English and Tboli."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 rounded-xl bg-surface p-4 shadow-panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Current keyboard"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-lg font-display",
							children: ["Tboli Keyboard · ", ime.lang === "tbl" ? "Tboli" : "English"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/try",
						className: "mt-4 flex h-11 items-center justify-center rounded-md bg-primary text-sm font-medium text-primary-fg",
						children: "Try it in Messages"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setStep(2),
						className: "mt-2 h-11 w-full rounded-md bg-key-mod text-sm font-medium text-key-mod-fg",
						children: "Change keyboard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							ime.disable();
							setStep(1);
						},
						className: "mt-2 h-11 w-full rounded-md text-sm font-medium text-subtle",
						children: "Turn off Tboli Keyboard"
					})
				]
			}) : null
		]
	});
}
var SplitComponent = EnableScreen;
//#endregion
export { SplitComponent as component };
