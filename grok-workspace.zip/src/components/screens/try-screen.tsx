import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronLeft, Search } from "lucide-react";
import { ImeInput, ImeTextarea } from "@/components/ime-field";
import { useIme } from "@/components/ime-provider";
import { cn } from "@/lib/utils";

type AppId = "messages" | "notes" | "search";

export function TryScreen() {
  const ime = useIme();
  const [app, setApp] = useState<AppId>("messages");
  const on = ime.installed && ime.selected;

  return (
    <div className="flex min-h-full flex-col px-4 pt-4 pb-4">
      <Link to="/" className="inline-flex h-10 items-center gap-1 text-sm text-muted">
        <ChevronLeft className="size-4" strokeWidth={2} />
        Home
      </Link>
      <h1 className="font-display text-3xl font-semibold tracking-tight">Type anywhere</h1>
      <p className="mt-1 text-sm text-muted">
        {on
          ? "These are ordinary fields. Tap one — the keyboard pops up, same as on the phone."
          : "Turn the keyboard on first, then tap a field here."}
      </p>

      {!on ? (
        <Link
          to="/enable"
          className="mt-3 flex h-11 items-center justify-center rounded-md bg-primary text-sm font-medium text-primary-fg"
        >
          Open keyboard settings
        </Link>
      ) : null}

      <div className="mt-4 flex rounded-lg bg-surface p-1">
        {(
          [
            ["messages", "Messages"],
            ["notes", "Notes"],
            ["search", "Search"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setApp(id)}
            className={cn(
              "h-9 flex-1 rounded-md text-sm font-medium",
              app === id ? "bg-primary text-primary-fg" : "text-muted",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="mt-3 min-h-0 flex-1 rounded-xl bg-surface p-3 shadow-panel">
        {app === "messages" ? <MessagesApp /> : null}
        {app === "notes" ? <NotesApp /> : null}
        {app === "search" ? <SearchApp /> : null}
      </div>
    </div>
  );
}

function MessagesApp() {
  const [draft, setDraft] = useState("");
  const [thread, setThread] = useState<string[]>(["Holo — type below in Tboli or English."]);

  function send() {
    const next = draft.trim();
    if (!next) return;
    setThread((t) => [...t, next]);
    setDraft("");
  }

  return (
    <div className="flex h-80 flex-col">
      <p className="text-xs font-medium tracking-wide text-subtle">Messages</p>
      <ul className="mt-2 min-h-0 flex-1 space-y-2 overflow-y-auto">
        {thread.map((line, i) => (
          <li
            key={`${i}-${line}`}
            className={cn(
              "max-w-[85%] rounded-lg px-3 py-2 text-sm",
              i === 0 ? "bg-surface-2 text-muted" : "ml-auto bg-primary text-primary-fg",
            )}
          >
            {line}
          </li>
        ))}
      </ul>
      <form
        className="mt-2 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <ImeInput
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Message"
          className="flex-1 bg-bg"
        />
        <button
          type="submit"
          className="h-11 shrink-0 rounded-md bg-primary px-3 text-sm font-medium text-primary-fg"
        >
          Send
        </button>
      </form>
    </div>
  );
}

function NotesApp() {
  const [note, setNote] = useState("");
  return (
    <div className="flex h-80 flex-col">
      <p className="text-xs font-medium tracking-wide text-subtle">Notes</p>
      <ImeTextarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Start a note…"
        className="mt-2 min-h-0 flex-1 bg-bg"
      />
    </div>
  );
}

function SearchApp() {
  const [q, setQ] = useState("");
  return (
    <div className="flex h-80 flex-col">
      <p className="text-xs font-medium tracking-wide text-subtle">Search</p>
      <div className="relative mt-2">
        <Search className="pointer-events-none absolute top-3 left-3 size-4 text-subtle" strokeWidth={2} />
        <ImeInput
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search"
          className="bg-bg pl-9"
        />
      </div>
      <p className="mt-4 text-sm text-muted">
        {q ? `Results for “${q}”` : "Type with Tboli Keyboard — globe key for English."}
      </p>
    </div>
  );
}
